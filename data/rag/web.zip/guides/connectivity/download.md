# Content Downloads

You can download files from the Internet and monitor the progress and status of ongoing downloads.

The Download API is optional for TV and IoT profiles. This means that it may not be supported on all TV and IoT devices. The Download API is supported on all Tizen emulators.

The main features of the Download API include the following:

- Managing downloads

  You can [start, pause, resume, cancel, and abandon a download](#manage-downloads) of content using the `DownloadManager` interface (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadManager) applications).

- Checking the download state and information

  You can [access the current download state and retrieve the download information](#check-the-download-state-and-information) using the `DownloadManager` interface. The states are defined in the `DownloadState` enumerator (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadState) applications).

## Prerequisites

To use the Download API (in [TV](../../api/latest/device_api/tv/tizen/download.html) applications), the application has to request permission by adding the following privilege to the `config.xml` file:

```
<tizen:privilege name="http://tizen.org/privilege/download"/>
```

## Manage downloads

To provide the user access to Internet resources, you must learn how to manage download operations through the following steps:

1. Create an instance of the `DownloadRequest` interface (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadRequest) applications) that defines the URL of the file to be downloaded:

   ```
   var downloadRequest = new tizen.DownloadRequest('http://download.tizen.org/tools/README.txt', 'downloads');
   ```

   The final parameter (`downloads`) defines the folder where the downloaded content is stored. The parameter uses a relative folder location defined in the Filesystem API (in [TV](../../api/latest/device_api/tv/tizen/filesystem.html) applications). The folder is not an absolute folder location, but instead uses a [virtual root location](../data/file-system.md#supported-virtual-roots) (`downloads` is the default download location in the virtual root).

2. It is not possible to download anything when the device is not connected to a network. To check whether any connection is available, use the `getPropertyValue()` method of the `SystemInfo` interface (in [TV](../../api/latest/device_api/tv/tizen/systeminfo.html#SystemInfo) applications):

   ```
   tizen.systeminfo.getPropertyValue('NETWORK', function(networkInfo) {
       if (networkInfo.networkType === 'NONE') {
           console.log('Network connection is not available.
                        Download is not possible.');
           downloadRequest = null;
       }
   });
   ```

3. Define the event handlers for different download process notifications using the `DownloadCallback` listener interface (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadCallback) applications):

   ```
   var listener = {
       /* When the download progresses (interval is platform-dependent) */
       onprogress: function(id, receivedSize, totalSize) {
           console.log('Received with id: ' + id + ', ' + receivedSize + '/' + totalSize);
       },

       /* When the user pauses the download */
       onpaused: function(id) {
           console.log('Paused with id: ' + id);
       },

       /* When the user cancels the download */
       oncanceled: function(id) {
           console.log('Canceled with id: ' + id);
       },

       /* When the download is completed */
       oncompleted: function(id, fullPath) {
           console.log('Completed with id: ' + id + ', full path: ' + fullPath);
       },

       /* When the download fails */
       onfailed: function(id, error) {
           console.log('Failed with id: ' + id + ', error name: ' + error.name);
       }
   };
   ```

4. To start downloading the file from the Internet, use the `start()` method of the `DownloadManager` interface (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadManager) applications):

   ```
   downloadId = tizen.download.start(downloadRequest, listener);
   ```

   The `start()` method returns a unique identifier for the download operation.

   You can check the status of the download operation by calling the `getState()` method with the download ID:

      ```
      tizen.download.getState(downloadId);
      ```

5. During the download operation, you can modify the download state by using the following methods:

    >[!NOTE]
    >For downloading small file with using high speed connection, the download operation completes almost instantly.

   1. To pause the download, use the `pause()` method with the download ID:

      ```
      tizen.download.pause(downloadId);
      ```
        If the current state is DOWNLOADING or QUEUED, calling the `pause()` method changes the download state to PAUSED.

   2. To resume the download, use the `resume()` method with the download ID:

      ```
      tizen.download.resume(downloadId);
      ```
        If the current state is PAUSED, CANCELED, or FAILED, calling the `resume()` method changes the download state to DOWNLOADING or QUEUED.

   3. To cancel the download, use the `cancel()` method with the download ID:

      ```
      tizen.download.cancel(downloadId);
      ```
        If the current state is DOWNLOADING or QUEUED, calling the `cancel()` method changes the download state to CANCELED.

   4. To abandon the download, use the `abandon()` method with the download ID:

      ```
      tizen.download.abandon(downloadId);
      ```
        For any abandoned download operation, the resources are already released. Thus, the download operation cannot be resumed.

## Check the download state and information

To provide the user access to Internet resources, you must learn how to check the state of a download operation and retrieve relevant information by following these steps:

1. To be able to monitor the download state, you need the download ID, which is the return value of the `start()` method of the `DownloadManager` interface (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadManager) applications):

   ```
   downloadId = tizen.download.start(downloadRequest, listener);
   ```

2.  Use the `getState()` method with the download ID as a parameter to get the current state:

    ```
    var state = tizen.download.getState(downloadId);
    ```

    The method returns a `DownloadState` enumerator value (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadState) applications).

3. Use the `getDownloadRequest()` method with the download ID as a parameter to get the download request details that the user has previously set:

   ```
   var downloadRequest = tizen.download.getDownloadRequest(downloadId);
   ```

   The method returns the `DownloadRequest` information (in [TV](../../api/latest/device_api/tv/tizen/download.html#DownloadRequest) applications) which is used as the parameter when starting the download.

4. Use the `getMIMEType()` method with the download ID as a parameter to get the MIME type of the file that you have started downloading:

   ```
   var MIMEType = tizen.download.getMIMEType(downloadId);
   ```

## Related information
- Dependencies
   - Tizen 3.0 and Higher for TV
* API References
  - [TV](../../api/latest/device_api/tv/tizen/download.html)
