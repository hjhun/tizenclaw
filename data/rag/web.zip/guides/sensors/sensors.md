# Sensors

The sensor features introduce how you can manage sensor and human activity data from various sensors on the device.

The following sensor features are optional:

- [Human Activity Monitor](./ham.md)

  You can access the human activity data from the sensors on the device. You can retrieve data from the sensors, and also receive notifications when the sensor data changes. You can access various activity information, such as steps and sleep.

- [Device Sensors](./device-sensors.md)

  You can read and manage data from various sensors on the device, and also receive notifications when the sensor data changes. You can access information from various environmental sensors, such as the light and magnetic sensors, and from user-related sensors, such as the heart rate monitor.

## Related information
- Dependencies
  - Tizen 2.4 and Higher
