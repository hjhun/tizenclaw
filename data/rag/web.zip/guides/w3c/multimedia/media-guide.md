# Media

The media features include playing various media, and accessing media streams and capture capabilities.

The main media features are the following:

- [getUserMedia](./getusermedia.md)

  Enables you to access a local device to generate a multimedia stream.

- [HTML5 video and audio element](./video-audio.md)

  Enables you to control multimedia playback, retrieve information about playback duration and media content downloading progress, and check supported media formats using the HTML5 `<audio>` and `<video>` elements.

- [HTML Media Capture](./media-capture.md) **(Optional feature)**

  Enables you to easily access the media capture capabilities, such as a camera or microphone, based on their type using the HTML `capture` attribute.

- [Web Audio](./webaudio.md) **(Optional feature)**

  Enables you to play audio content using the HTML5 `<audio>` element.

- [Tizen WebKit Tap Sound Policy](./sound-policy.md) **(Optional feature)**

  Allows you to play sounds to provide responsiveness on user interaction.

## Related information
- Dependencies
  - Tizen 2.4 and Higher
  - Tizen 3.0 and Higher for TV
