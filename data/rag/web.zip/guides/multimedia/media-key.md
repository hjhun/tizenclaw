# Media Key Events

You can manage media key events in your application. The media keys are used to [control multimedia playback](#manage-media-key-state-changes). The user can click keys, such as **PLAY** and **FAST FORWARD**, and you can detect the key clicks in your application and change the playback accordingly.

This feature is optional.

The main features of the Media Key API include the following:

- Registering a listener

  You can register and deregister a listener for the media key state changes.

  > [!NOTE]
  > You can register only one media key state change listener for your application. If you attempt to register a second listener, the first listener is unset and replaced with the new one.

- Handling state changes

  With the registered listener, you can monitor the media keys and react to their state changes when the user presses or releases a key.

## Manage media key state changes

Learning how to register key event listener is a basic media key management skill:

1. Implement the listener to handle media key state changes. The listener can contain event listeners for key press (`onpressed`) and release (`onreleased`) notifications:

   ```
   var myMediaKeyChangeListener = {
       onpressed: function(key) {
           console.log('Pressed key: ' + key);
       },
       onreleased: function(key) {
           console.log('Released key: ' + key);
       }
   }
   ```

2. Register the media key state change listener:

   ```
   tizen.mediakey.setMediaKeyEventListener(myMediaKeyChangeListener);
   ```

3. Deregister the media key state change listener when it is no longer needed:

   ```
   tizen.mediakey.unsetMediaKeyEventListener();
   ```

## Related information
* Dependencies
  - Tizen 3.0 and Higher for TV
* API References
  - [TV](../../api/latest/device_api/tv/tizen/mediakey.html)
