# Media and Camera

The media and camera features introduce how you can use multimedia features in your application.

You can use the following media and camera features in your Web applications:

- [JPEG File EXIF Information](./jpeg-exif.md)

  You can access and modify EXIF (exchangeable image format) information in a JPEG file. You can add or update information in a file, copy it between files, and retrieve both the information and the thumbnail image of the file.

- [Metadata of multimedia files](./metadata.md)

  You can extract metadata information from multimedia files.

- [Audio Management](./audio.md) **(Optional feature)**

  You can control the volume level of several sound types. You can also retrieve information about the current sound mode and the state of the current sound devices, and monitor changes in the sound device states.

- [Audio Latency](./player-util.md) **(Optional feature)**

  You can control the audio latency mode of the W3C player. You can both retrieve the current mode and set a new mode.

- [Media Controller](./media-controller.md)

  You can communicate between the media controller server and client. The client can send requests to the server to modify the media, and the server can respond to the requests by modifying the media directly as requested. For the media controller feature to work, you must create both the client and server applications.

- [Media Key Events](./media-key.md) **(Optional feature)**

  You can handle media keys in your application to control multimedia playback. When the user clicks a media key, you can detect the event in the application and adjust the media playback accordingly.

- [Radio](./radio.md) **(Optional feature)**

  You can allow the user to listen to the FM radio on the device. You can scan for available frequencies and change between found frequencies. You can control the radio playback, and get information about interruptions from other sound sources.

- [Camera](./camera.md) **(Optional feature)**

  You can control the device camera by using the camera options. You can capture images and record video.

## Related information
- Dependencies
  - Tizen 3.0 and Higher for TV
