# W3C_API_Modules API

## Table of Contents

- 1. Interfaces
- 1.1. Navigator
- 1.2. MediaStream
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| Navigator |  |
| MediaStream |  |

## 1. Interfaces

### 1.1. Navigator

This interface is a pointer to W3C navigator interface.

```webidl
    interface Navigator {};
```

### 1.2. MediaStream

This interface is a pointer to W3C MediaStream interface.

```webidl
    interface MediaStream {};
```

## 2. Full WebIDL

```webidl
module W3C_API_Modules {
    interface Navigator {};

    interface MediaStream {};
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
