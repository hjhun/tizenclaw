# Tizen TV Web W3C/HTML5 and Supplementaries API Reference

The APIs listed in this category are all part of the W3C specifications. Some of the APIs are stable while others are draft specifications. The draft APIs are subject to change as the W3C specification evolves.

The W3C APIs are categorized based on the functionality to make it easier to locate specific APIs.
                 To learn the Tizen features provided by the W3C/HTML5 and  some supplementary APIs, see Guide to W3C/HTML5 and Some Supplementary Features .

#### Default Web Privilege

Tizen WebApp have default privileges listed in below table.

| Privilege | Required Version | Description |
| --- | --- | --- |
| http://tizen.org/privilege/appmanager.launch | all | The application can open other applications. |
| http://tizen.org/privilege/haptic | all | The application can control vibration feedback. |
| http://tizen.org/privilege/network.get | all | The application can retrieve network information such as the status of each network, its type, and detailed network profile information. |
| http://tizen.org/privilege/notification | all | The application can show and hide its own notifications and badges. |
| http://tizen.org/privilege/packagemanager.info | all | The application can retrieve detailed application package information. |
| http://tizen.org/privilege/mediastorage | all | The application can read and write files in media folders. |
| http://tizen.org/privilege/externalstorage | all | The application can read and write files that are saved to external storage, such as SD cards. |
| http://tizen.org/privilege/display | all | The application can manage display settings, such as brightness. This may increase battery consumption. |

#### DOM, Forms and Styles

| Specification | Description | Status * |
| --- | --- | --- |
HTML5 form features. The content attribute currently not supported is:
- `autocomplete `of `HTMLTextAreaElement `interface
| HTML5 Forms (Partial) |  | REC |
| Selectors API Level 1 | API for retrieving Element nodes from the DOM by matching against a group of selectors | REC |
API for retrieving Element nodes from the DOM by matching against a group of selectors, and for testing if a given element matches a particular selector. The methods currently not supported are:
- `find `, `findAll `of `Document `interface
- `find `, `findAll `of `DocumentFragment `interface
- `find `, `findAll `of `Element `interface
| Selectors API Level 2 (Partial) |  | Note |
Offers a mechanism that allows adapting the layout and behavior of a Web page based on some of the characteristics of the device, including the screen width/height. The query currently not supported is:
- `color-index, min-color-index, max-color-index, resolution, scan, print, 3d-glasses, grid `
| Media Queries (Partial) |  | REC |
| CSS Transforms | CSS transforms allows elements styled with CSS to be transformed in two-dimensional or three-dimensional space. | WD |
CSS Animations allow an author to modify CSS property values over time. The attributes currently not supported are:
- `pseudoElement `of `AnimationEvent `interface
- `pseudoElement `of `AnimationEventInit `dictionary
| CSS Animations Module Level 3 (Partial) |  | WD |
| CSS Transitions Module Level 3 | CSS Transitions allow property changes in CSS values to occur smoothly over a specified duration. | WD |
| CSS Color Module Level 3 | CSS3 color enhancements related to color values and properties for foreground color and group opacity | REC |
| CSS Backgrounds and Borders Module Level 3 | Rounded corners, complex background images, shadow effects. | CR |
| CSS Flexible Box Layout Module | CSS box model optimized for user interface design. | LCWD |
Creates multiple columns for laying out text. The properties currently not supported are:
- `column-fill `, `break-before `, `break-after `, `break-inside `
| CSS Multi-column Layout Module (Partial) |  | CR |
CSS properties for text manipulation and specifies their processing model. The properties currently not supported are:
- `hyphens `, `hanging-punctuation `
| CSS Text Module Level 3 (Partial) |  | LCWD |
CSS properties for text decoration, such as underlines, text shadows, and emphasis marks. The properties currently not supported are:
- `text-decoration-color `, `text-decoration-line `, `text-decoration-style `, `text-decoration-skip `, `text-emphasis property `
| CSS Text Decoration Module Level 3 (Partial) |  | CR |
User interface related CSS enhancements. The properties currently not supported are:
- `caret-color `, `nav-up `, `nav-right `, `nav-down `, `nav-left `
| CSS Basic User Interface Module Level 3 (CSS3 UI) (Partial) |  | CR |
@font-face rule with downloadable font src URL. The properties currently not supported are:
- `font-feature-settings `, `font-language-override `, `font-synthesis `, `font-variant-alternates `, `font-variant-caps `, `font-variant-east-asian `, `font-variant-numeric `, `font-variant-position `, `font-size-adjust `, `font-stretch `
| CSS Fonts Module Level 3 (Partial) |  | CR |
| WOFF File Format 2.0 | Web Open Font Format: File Format 2.0. | WD |
| HTML5 The session history of browsing contexts | Navigating the sequence of documents in a browsing context. | REC |
| Custom Elements | Method of defining and using new types of DOM elements in a document. | WD |
| HTML Templates | Method of declaring a portion of reusable markup that is parsed but not rendered until cloned. | WD |
| HTML Imports | Method of including and reusing HTML documents in other HTML documents. | WD |

#### Device

| Specification | Description | Status * |
| --- | --- | --- |
| HTML5 Browser state | Signals when network connectivity is available to the Web environment | REC |
To provide an interface for web applications to be able to read
                                    the screen orientation state, to be informed when this state changes
                                    and to be able to lock the screen orientation to a specific state
- Required feature :
- `http://tizen.org/feature/sensor.accelerometer `
| The Screen Orientation API |  | WD |

#### Graphics

| Specification | Description | Status * |
| --- | --- | --- |
HTML5 canvas element including 2D context and text. The method currently not supported is:
- `toBlob `of `HTMLCanvasElement `interface
| HTML5 The `canvas `element (Partial) |  | REC |
| HTML Canvas 2D Context | 2D Context for the HTML canvas element. | REC |
| Scalable Vector Graphics (SVG) 2 | Scalable Vector Graphics (SVG) 2 | WD |

#### Media

| Specification | Description | Status * |
| --- | --- | --- |
| HTML5 The `video `element | Method of playing videos on webpages (without requiring a plug-in). | REC |
| HTML5 The `audio `element | Method of playing sound on webpages (without requiring a plug-in). | REC |
API that directly manipulates streams from cameras and microphones. However, TV supports only getUsermedia using microphone becuase it has no camera. The dictionary member currently not supported are:
- `getCapabilities, getConstraints, getSettings, applyConstraint, onoverconstrained `of `MediaStreamTrack `interface
- `ondevicechange, getSupportedConstraints `of `MediaDevices `interface
- `Constructor `of `MediaStreamTrackEvent `interface
The interfaces and method currently replaced are:
- inteface `MediaStreamError -> NavigatorUserMediaError `
- inteface `NavigatorUserMedia -> Navigator `
- method `getUserMedia() -> webkitGetUserMedia() `
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/mediacapture `
- Required feature :
- `http://tizen.org/feature/microphone `
| `getUserMedia `(Partial) |  | ED |
W3C Web Audio API describes a high-level JavaScript API for processing and synthesizing audio in Web Applications. The interfaces and attribute currently not supported are:
- `AudioWorker, AudioProcessEvent, SpatialPannerNode, SpatialListener, DynamicsCompressorNode `and `IIRFilterNode `interfaces
- `PeriodicWaveConstraints `dictionary
| Web Audio API (Partial) |  | WD |
W3C Web Speech API defines a JavaScript API to enable web developers to incorporate speech recognition and synthesis into their web pages. The attributes and events currently not supported are:
- `pitch, volume `of `SpeechSynthesisUtterance `interface
- `onmark, onboundary `of `SpeechSynthesisUtterance `interface
The interfaces currently not supported are:
- `SpeechRecognition `interface
- `SpeechSynthesisErrorEvent `interface
SpeechSynthesis
- Required feature :
- `http://tizen.org/feature/speech.synthesis `
| Web Speech (Partial) | Note |

#### Communication

| Specification | Description | Status * |
| --- | --- | --- |
Offers bi-directional network connectivity.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
| The WebSocket API |  | CR |
Enhancements on XHR, including binary file uploading, formdata submission, transfer progress, etc.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
| XMLHttpRequest Level 1 |  | WD |
The API allows triggering DOM events based on push notifications(via HTTP and other protocols).
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
| Server-Sent Events |  | REC |
| HTML5 Web Messaging | HTML5 Web Messaging. The postMessage API allows for Web Applications to communicate between each other. | REC |
| Beacon | Allows data to be sent asynchronously to a server with navigator.sendBeacon, even after a page was closed. Useful for posting analytics data the moment a user was finished using the page. | WD |

#### Storage

| Specification | Description | Status * |
| --- | --- | --- |
| Web Storage | W3C storage specification including session and local storage. | CR |
Reads files from local device file system.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/unlimitedstorage `
| File API |  | WD |
HTML5 application cache and custom handlers.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
| HTML5 Application caches |  | REC |
A database of values and hierarchical objects that integrates naturally with JavaScript, and can be queried and updated very efficiently.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/unlimitedstorage `
| Indexed Database API |  | REC |
Method that enables applications to take advantage of persistent background processing, including hooks to enable bootstrapping of web applications while offline. The interface and dictionary currently not supported are:
- `ExtendableMessageEvent `interface
- `CacheBatchOperation `, `ExtendableMessageEventInit `dictionaries
| Service Workers (Partial) |  | WD |

#### Security

| Specification | Description | Status * |
| --- | --- | --- |
Sharing of resources across different domains.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
| Cross-Origin Resource Sharing |  | REC |
Access restriction (sandboxing) for iframe content. The available values of sandbox attribute are:
- `allow-same-origin, allow-scripts, allow-forms, allow-top-navigation `
| HTML5 The `iframe `element |  | REC |
Defines a policy language used to declare a set of content restrictions for a web resource, and a mechanism for transmitting the policy from a server to a client where the policy is enforced. The directive currently not supported is:
- `object-src `
| Content Security Policy Level 2 (Partial) |  | CR |
| Web Crypto API | JavaScript API for performing basic cryptographic operations in web applications | CR |

#### Performance and Optimization

| Specification | Description | Status * |
| --- | --- | --- |
API that allows Web application authors to spawn background workers running scripts in parallel to their main page. The attributes currently not supported are:
- `onlanguagechange, ononline, onoffline `of `WorkerGlobalScope `interface
- `applicationCache `of `SharedWorkerGlobalScope `interface
| Web Workers (Partial) |  | WD |
| Page Visibility | This specification defines a means for developers to programmatically determine the current visibility state of the page in order to develop power and CPU efficient Web applications. | REC |
| Timing control for script-based animations | Resource effective animation timing control by user agent. | CR |
| Navigation Timing | This specification defines an interface for web applications to access timing information related to navigation and elements. | REC |

#### Widget

| Specification | Description | Status * |
| --- | --- | --- |
| Widget Packaging and XML Configuration | A packaging format and metadata for a class of software known as `widgets. ` | REC |
| Widget Interface | API for widgets that provides, amongst other things, functionality for accessing a widget's metadata and persistently storing data. | LCWD |
| XML Digital Signatures for Widgets | A profile of the XML Signature Syntax and Processing 1.1 specification to allow a widget package to be digitally signed. | PR |
| Widget Access Request Policy | The security model controlling network access from within a widget, as well as a method for authors to request that the user agent grant access to certain network resources or sets thereof. | REC |

#### Supplementary

| Specification | Description |
| --- | --- |
| Typed Array - Khronos | Provides an API for interoperability with native binary data. |
This specification describes an additional rendering context and support objects for the HTML 5 canvas element. This context allows rendering using an API that conforms closely to the OpenGL ES 2.0 API. The method and attribute currently not supported are:
- `initWebGLContextEvent `of `WebGLContextEvent `interface
- `NUM_COMPRESSED_TEXTURE_FORMATS `of `WebGLRenderingContext `interface
| WebGL - Khronos (Partial) |  |
Provides a way for an element to be displayed in full screen mode programmatically. The method and attribute currently not supported are:
- `requestFullScreenWithKeys `of element
- `allowFullScreen `of `iframe `element
Privilege Level : Public Privilege : `http://tizen.org/privilege/fullscreen `

| FullScreen API - Mozilla (Partial) |  |
Allows Web developers control the viewport's size and scale. `https://developer.apple.com/library/safari/documentation/Appleapplications/Reference/SafariWebContent/UsingtheViewport/UsingtheViewport.html#//apple_ref/doc/uid/TP40006509-SW26 `

| `viewport `Meta Tag - Apple |  |

**** W3C Specification Status ***
- ED = Editor’s Draft
- WD = Working Draft
- LCWD = Last Call Working Draft
- CR = Candidate Recommendation
- PR = Proposed Recommendation
- REC = Recommendation
(see W3C Technical Report Development Process)
***Note: The APIs in ED, WD, LC status are considered to be in preliminary state. Such APIs do not carry a version compatibility promise. They may change in future versions of Tizen if the specifications change. ***Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
