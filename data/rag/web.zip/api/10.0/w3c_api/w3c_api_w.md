# Tizen Wearable Web W3C/HTML5 and Supplementaries API Reference

The APIs listed in this category are all part of the W3C specifications. Some of the APIs are stable while others are draft specifications. The draft APIs are subject to change as the W3C specification evolves.

The W3C APIs are categorized based on the functionality to make it easier to locate specific APIs. 
                 To learn the Tizen features provided by the W3C/HTML5 and  some supplementary APIs, see Guide to W3C/HTML5 and Some Supplementary Features .

#### Default Web Privilege

Tizen WebApp have default privileges listed in below table. Some privileges are granted only when required version is under 2.2.1

| Privilege | Required Version | Description |
| --- | --- | --- |
| http://tizen.org/privilege/location | <= 2.2.1 | The application can use your location data. |
| http://tizen.org/privilege/call | <= 2.2.1 | The application can make phone calls to numbers when they are tapped without further confirmation. This may result in additional charges depending on your payment plan. |
| http://tizen.org/privilege/internet | <= 2.2.1 | The application can access the Internet. This may result in additional charges depending on your payment plan. |
| http://tizen.org/privilege/recorder | <= 2.2.1 | The application can record audio and video. |
| http://tizen.org/privilege/camera | <= 2.2.1 | The application can take pictures and turn the camera flash on and off while using Camera. |
| http://tizen.org/privilege/appmanager.launch | all | The application can open other applications. |
| http://tizen.org/privilege/haptic | all | The application can control vibration feedback. |
| http://tizen.org/privilege/network.get | all | The application can retrieve network information such as the status of each network, its type, and detailed network profile information. |
| http://tizen.org/privilege/notification | all | The application can show and hide its own notifications and badges. |
| http://tizen.org/privilege/packagemanager.info | all | The application can retrieve detailed application package information. |
| http://tizen.org/privilege/mediastorage | <=3.0 | The application can read and write files in
                                media folders. (Since 4.0,
                            http://tizen.org/privilege/mediastorage privilege
                        needs to be added explicitly) |
| http://tizen.org/privilege/externalstorage | <=3.0 | The application can read and write files that
                                are saved to external storage, such as SD
                            cards. (Since 4.0,
                        http://tizen.org/privilege/externalstorage privilege
                    needs to be added explicitly) |
| http://tizen.org/privilege/display | all | The application can manage display settings, such as brightness. This may increase battery consumption. |

#### DOM, Forms and Styles

| Specification | Description | Status * |
| --- | --- | --- |
HTML5 form features. The method and attribute currently not supported is:
- `getter (RadioNodeList or Element) (DOMString name) `of `HTMLFormElement `interface
- `tooShort `of `ValidityState `interface
| HTML5 Forms (Partial) |  | CR |
| Selectors API Level 1 | API for retrieving Element nodes from the DOM by matching against a group of selectors | REC |
API for retrieving Element nodes from the DOM by matching against a group of selectors, and for testing if a given element matches a particular selector. The methods currently not supported are:
- `find, findAll `of `Document `interface
- `find, findAll `of `DocumentFragment `interface
- `find, findAll `of `Element `interface
| Selectors API Level 2 (Partial) |  | Note |
| Media Queries | Offers a mechanism that allows adapting the layout and behavior of a Web page based on some of the characteristics of the device, including the screen width/height. | REC |
| CSS Transforms | CSS transforms allows elements styled with CSS to be transformed in two-dimensional or three-dimensional space. | WD |
| CSS Animations Module Level 3 | CSS Animations allow an author to modify CSS property values over time. | WD |
| CSS Transitions Module Level 3 | CSS Transitions allow property changes in CSS values to occur smoothly over a specified duration. | WD |
| CSS Color Module Level 3 | CSS3 color enhancements related to color values and properties for foreground color and group opacity | REC |
| CSS Backgrounds and Borders Module Level 3 | Rounded corners, complex background images, shadow effects. | LCWD |
| CSS Flexible Box Layout Module | CSS box model optimized for user interface design. | LCWD |
CSS properties for text manipulation and specifies their processing model. The property and property values currently not supported are:
- `hanging-punctuation `
- `full-width `of `text-transform `property
- `keep-all `of `word-break `property
| CSS Text Module Level 3 (Partial) |  | LCWD |
| CSS Basic User Interface Module Level 3 (CSS3 UI) | User interface related CSS enhancements. | WD |
@font-face rule with downloadable font src URL. The properties and property values currently not supported are:
- `font-language-override, font-size-adjust, font-synthesis, font-variant-alternates, font-variant-east-asian, font-variant-numeric, font-variant-position `
- `font-variant-caps, petite-caps, all-petite-caps, unicase, titling-caps `of `font-variant-caps `property
| CSS Fonts Module Level 3 (Partial) |  | CR |
| WOFF File Format 1.0 | Web Open Font Format: File Format 1.0. | REC |
| DOM/JavaScript related HTML5 Enhancements | Handy DOM/JavaScript related enhancements in HTML5. | CR |
Navigating the sequence of documents in a browsing context. The dictionaries currently not supported are:
- `PopStateEventInit `
- `HashChangeEventInit `
- `PageTransitionEventInit `
| HTML5 The session history of browsing contexts (Partial) |  | CR |

#### Device

| Specification | Description | Status * |
| --- | --- | --- |
| Touch Events version 1 | W3C touch event specification for touch devices. | REC |
Provides access to orientation and acceleration data. The event currently not supported is:
- `compassneedscalibration `
- Required feature :
- `http://tizen.org/feature/sensor.accelerometer `
- `http://tizen.org/feature/sensor.gyroscope `
- `http://tizen.org/feature/sensor.magnetometer `
| DeviceOrientation Event Specification (Partial) |  | WD |
| Battery Status API | W3C Battery API defines new DOM event types that provide information about the battery status of the hosting device. | CR |
| Vibration API | Haptic feedback API from W3C. | LCWD |

#### Graphics

| Specification | Description | Status * |
| --- | --- | --- |
HTML5 canvas element including 2D context and text. The method currently not supported is:
- `toBlob `of `HTMLCanvasElement `interface
| HTML5 The `canvas `element (Partial) |  | CR |
2D Context for the HTML canvas element. The methods currently not supported are:
- `drawSystemFocusRing, drawCustomFocusRing, scrollPathIntoView, addHitRegion, removeHitRegion `of `CanvasRenderingContext2D `interface
- `ellipse `of `CanvasPathMethods `interface
| HTML Canvas 2D Context (Partial) |  | CR |
Inline SVG (1.1) support in HTML5. The attributes and methods currently not supported are:
- `iccColor `of `SVGColor `interface
- `title, referrer, domain, URL `of `SVGDocument `interface
- `kernelUnitLengthX, kernelUnitLengthY `of `SVGFESpecularLightingElement `interface
- `suspendRedraw, unsuspendRedraw, unsuspendRedrawAll, forceRedraw `of `SVGSVGElement `interface
- `hasExtension `of `SVGTests `interface
| HTML5 SVG (Partial) |  | CR |

#### Media

| Specification | Description | Status * |
| --- | --- | --- |
HTML5 video element. The attributes currently not supported are:
- `crossorigin `of `HTMLMediaElement `interface
| HTML5 The `video `element (Partial) |  | CR |
HTML5 audio element. The attributes currently not supported are:
- `crossorigin `of `HTMLMediaElement `interface
| HTML5 The `audio `element (Partial) |  | CR |
API that directly manipulates streams from cameras and microphones.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/mediacapture `
- Required feature :
- `http://tizen.org/feature/camera `
- `http://tizen.org/feature/microphone `
| `getUserMedia ` |  | ED |
W3C Web Speech API defines a JavaScript API to enable web developers to incorporate speech recognition and synthesis into their web pages. The attributes and events currently not supported are:
- `pitch, volume `of `SpeechSynthesisUtterance `interface
- `onmark, onboundary `of `SpeechSynthesisUtterance `interface
- `interpretation, emma `of `SpeechRecognitionEvent `interface
The interfaces currently not supported are:
- `SpeechSynthesisErrorEvent `interface
SpeechSynthesis
- Required feature :
- `http://tizen.org/feature/speech.synthesis `
Speech Recognition
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/mediacapture `
- Required feature :
- `http://tizen.org/feature/microphone `
- `http://tizen.org/feature/speech.recognition `
| Web Speech (Partial) |  | Note |

#### Communication

| Specification | Description | Status * |
| --- | --- | --- |
Offers bi-directional network connectivity.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
- Required feature :
- `http://tizen.org/feature/network.internet `
| The WebSocket API |  | CR |
Enhancements on XHR, including binary file uploading, formdata submission, transfer progress, etc.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
- Required feature :
- `http://tizen.org/feature/network.internet `
| XMLHttpRequest Level 1 |  | WD |
| HTML5 Web Messaging | HTML5 Web Messaging. The postMessage API allows for Web Applications to communicate between each other. | CR |

#### Storage

| Specification | Description | Status * |
| --- | --- | --- |
| Web Storage | W3C storage specification including session and local storage. | WD |
| File API | Reads files from local device file system. | WD |
A database of values and hierarchical objects that integrates naturally with JavaScript, and can be queried and updated very efficiently. The attributes and method currently not supported are:
- `oldVersion, newVersion `of `IDBVersionChangeEvent `interface
- `initIDBVersionChangeEvent `of `IDBVersionChangeEvent `interface
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/unlimitedstorage `
| Indexed Database API |  | LCWD |

#### Security

| Specification | Description | Status * |
| --- | --- | --- |
Sharing of resources across different domains.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/internet `
- Required feature :
- `http://tizen.org/feature/network.internet `
| Cross-Origin Resource Sharing |  | REC |
Access restriction (sandboxing) for iframe content. The available values of sandbox attribute are:
- `allow-same-origin, allow-scripts, allow-forms, allow-top-navigation `
| HTML5 The `iframe `element |  | CR |
Defines a policy language used to declare a set of content restrictions for a web resource, and a mechanism for transmitting the policy from a server to a client where the policy is enforced. The directive currently not supported is:
- `object-src `
| Content Security Policy 1.0 |  | CR |

#### Performance and Optimization

| Specification | Description | Status * |
| --- | --- | --- |
API that allows Web application authors to spawn background workers running scripts in parallel to their main page. The event handlers, interfaces and attributes currently not supported are:
- `ononline, onoffline `of `WorkerGlobalScope `interface
| Web Workers (Partial) |  | CR |
| Page Visibility | This specification defines a means for developers to programmatically determine the current visibility state of the page in order to develop power and CPU efficient Web applications. | REC |
| Timing control for script-based animations | Resource effective animation timing control by user agent. | CR |

#### Location

| Specification | Description | Status * |
| --- | --- | --- |
Provides scripted access to geographical location information associated with the hosting device.
- Privilege level : Public
- Privilege : `http://tizen.org/privilege/location `
- Required feature :
- `http://tizen.org/feature/location.gps `
| Geolocation API Specification |  | REC |

#### Widget

| Specification | Description | Status * |
| --- | --- | --- |
| Widget Packaging and XML Configuration | A packaging format and metadata for a class of software known as `widgets. ` | REC |
| Widget Interface | API for widgets that provides, amongst other things, functionality for accessing a widget's metadata and persistently storing data. | LCWD |
| XML Digital Signatures for Widgets | A profile of the XML Signature Syntax and Processing 1.1 specification to allow a widget package to be digitally signed. | PR |

#### Supplementary

| Specification | Description |
| --- | --- |
Provides interfaces for configuring camera options, recording video/audio, and capturing images.
- Privilege level : Public
- Privilege :
- `http://tizen.org/privilege/camera `
- `http://tizen.org/privilege/audiorecorder `
- Required feature :
- `http://tizen.org/feature/media.video_recording `
- `http://tizen.org/feature/media.image_capture `
- `http://tizen.org/feature/media.audio_recording `
| Camera API (Tizen Extension) |  |
| Typed Array - Khronos | Provides an API for interoperability with native binary data. |
This specification describes an additional rendering context and support objects for the HTML 5 canvas element. This context allows rendering using an API that conforms closely to the OpenGL ES 2.0 API. The method and attribute currently not supported are:
- `initWebGLContextEvent `of `WebGLContextEvent `interface
- `NUM_COMPRESSED_TEXTURE_FORMATS `of `WebGLRenderingContext `interface
| WebGL - Khronos (Partial) |  |
Allows Web developers control the viewport's size and scale.  For more details:
- `https://developer.apple.com/library/safari/documentation/Appleapplications/Reference/SafariWebContent/UsingtheViewport/UsingtheViewport.html#//apple_ref/doc/uid/TP40006509-SW26 `

| `viewport `Meta Tag - Apple |  |

**** W3C Specification Status ***
- ED = Editor’s Draft
- WD = Working Draft
- LCWD = Last Call Working Draft
- CR = Candidate Recommendation
- PR = Proposed Recommendation
- REC = Recommendation
(see W3C Technical Report Development Process)
***Note: The APIs in ED, WD, LC status are considered to be in preliminary state. Such APIs do not carry a version compatibility promise. They may change in future versions of Tizen if the specifications change. ***Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
