# Base

In the Tizen Web UI framework, the application page structure is based on a header and content elements:

- The header is placed at the top, and displays the page title.

- The content is the section below the header, showing the main content of the page.

- The footer is placed at the bottom, and can include buttons.

## Basic Layout

The following table describes the specific information for each section.

| Base | Description |
| --- | --- |
| Page Handling | Show Reference for page handling. |
| Popup Handling | Show Reference for popup handling. |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
