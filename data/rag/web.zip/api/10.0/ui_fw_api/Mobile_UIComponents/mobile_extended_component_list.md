# Extended Mobile UI Components

The Web UI Framework (called as **TAU **; Tizen Advanced UI framework) provides rich Tizen components that are optimized for the Tizen Web browser. 
Each extended component includes an external library for use.

## UI components list

The following table displays the extended components provided by the Tizen mobile Web UI Framework.

| UI component | Description | Version (Since) |
| --- | --- | --- |
| Coverflow | Coverflow component visually applies various effects to selected images. | 5.5 |
| Graph | Graph component allows to show statistics data in graph mode. | 5.5 |
| Interactive 3D | Interactive 3D component allows you to load and control a 3D model freely. | 5.5 |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
		3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
