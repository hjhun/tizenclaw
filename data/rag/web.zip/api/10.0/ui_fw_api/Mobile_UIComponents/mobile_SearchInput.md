# Search Input

The SearchInput component is used to search for page content. It can be placed within the page content.

| Note |
| --- |
| This component is supported since **Tizen 2.4. ** |
| It was renamed from *SearchBar *component of Tizen 2.3. |

## Table of Contents

- Default Selectors
- Manual Constructor
- Methods
## Default Selectors

By default, all `<input> `elements with the `type="search" `or `class="ui-search-input" `attribute are displayed as search input.

## Manual Constructor

To manually create a SearchInput component, use the component constructor from the `tau `namespace.

HTML code:

```
<input type="search" id="search-test"/>
```

JS code:

```
var searchEl = document.getElementById("search-test"),
    searchWidget = tau.widget.SearchInput(searchEl);
```

## Methods

To call a method on the component, please refer the following:

```
var searchInputElement = document.getElementById('search-test'),
    searchInput = tau.widget.SearcnInput(searchInputElement);

searchInput.methodName(methodArgument1, methodArgument2, ...);
```

### Summary

| Method | Description |
| --- | --- |
```
SearchInput disable() 
```

Disable the SearchInput.

|  |  |
```
SearchInput enable() 
```

Enable the SearchInput.

|  |  |

`**disable **`Disable the SearchInput.

```javascript
SearchInput disable() 
```

The method sets the disabled attribute for the search input and changes the look of the search input to the disabled state.

Return value:

| Type | Description |
| --- | --- |
| SearchInput | Returns SearchInput. |

Code
								example:

```javascript
var element = document.getElementById("searchinput"),
    searchInputWidget = tau.widget.SearchInput(element);

searchInputWidget.disable();
```

`**enable **`Enable the SearchInput.

```javascript
SearchInput enable() 
```

The method removes the disabled attribute from the search input and changes the look of the search input to the enabled state.

Return value:

| Type | Description |
| --- | --- |
| SearchInput | Returns SearchInput. |

Code
								example:

```javascript
var element = document.getElementById("searchinput"),
    searchInputWidget = tau.widget.SearchInput(element);

searchInputWidget.enable();
```

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
		3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
