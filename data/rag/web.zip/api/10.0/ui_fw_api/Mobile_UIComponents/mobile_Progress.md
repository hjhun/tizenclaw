# Progress

The progress component shows that an operation is in progress.

| Note |
| --- |
| This component is supported since Tizen 2.4. |
| *deprecated *Progress and ProgressBar component has been merged and renamed to *new ***Progress. ** |

## Table of Contents

- Default Selectors
- HTML Examples
- Manual Constructor
- Options
- Methods
## Default Selectors

By default, all elements with the `class="ui-progress" `or `data-role="progress" `attribute are displayed as progress components.

## HTML Examples

#### bar type

```
<div class="ui-progress" data-type="bar"></div>
```

#### activitybar type

```
<div class="ui-progress" data-type="activitybar"></div>
```

#### circle type

```
<div class="ui-progress" data-type="circle"></div>
```

#### activitycircle type

```
<div class="ui-progress" data-type="activitycircle"></div>
```

## Manual Constructor

To manually create a progress component, use the component constructor from the `tau `namespace:

HTML code:

```
<div id="progress"></div>
```

JS code:

```
var element = document.getElementById("progress"),
   progress = tau.widget.Progress(element, {type : "progressbar"});
```

## Options

The options for a component can be defined as `data `attributes or passed as parameters to the constructor.

You can change an option for the component using the `option `method.

| Option | Input type | Default value | Description |
| --- | --- | --- | --- |
| data-type | "bar" | "circle" | 
"activitybar" | "activitycircle" | "progressbar" | Sets type of progress component. |
| data-size | "small" | "medium" | 
"large" | "full" | "medium" | Sets size of progress component. 
(It used only with "circle" and "activitycircle" type) |
| data-value | number | 100 | Sets default value of progress component. |
| data-max | number | 100 | Sets default max value of progress component. |
| data-min | number | 0 | Sets default min value of progress component. |

## Methods

To call a method on the component, please refer the following example:

HTML code:

```
<div id="progress"></div>
```

JS code:

```
var element = document.getElementById("progress"),
    progress = tau.widget.Progress(element);

/*
   progress.methodName(argument1, argument2, ...);
   For example:
*/
progress.refresh();
```

### Summary

| Method | Description |
| --- | --- |
```
number value() 
```

Sets or gets value of Progress component.

|  |  |
```
number option() 
```

Sets or gets options of Progress component.

|  |  |
```
refresh() 
```

Refreshes the Progress DOM.

|  |  |

`**value **`Sets or gets value of Progress component.

```javascript
number value(number value) 
```

When this method has no parameter, it returns Progress value. 
If you call value with new number, you don't need to call refresh() method because it calls automatically.

Return value:

| Type | Description |
| --- | --- |
| number | Returns value of Progress. |

Code
								example:

```javascript
var element = document.getElementById("progress"),
    progress = tau.widget.Progress(element),
    originValue;

/* Get the origin value of progress */
originValue = progress.value();
console.log(originValue);

/* Set the value of progress to 70 */
progress.value(70);
```

`**option **`Sets or gets options of Progress component.

```javascript
number option() 
```

When changing value option of progress, we recommend to use value() method.

Return value:

| Type | Description |
| --- | --- |
| number | Returns value of option specified in the argument. |

Code
								example:

```javascript
var element = document.getElementById("progress"),
    progress = tau.widget.Progress(element),
    type;

progress.option("value", 50);
/* After change option, call refresh method */
progress.refresh();

/* Get type option value */
type = progress.option("type");
console.log(type);
```

`**refresh **`Refresh Progress DOM.

```javascript
refresh() 
```

Return value:

No return value

Code
								example:

```javascript
var element = document.getElementById("progress"),
    progress = tau.widget.Progress(element);

/* Change DOM dynamically or change option */
progress.refresh();
```

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
		3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
