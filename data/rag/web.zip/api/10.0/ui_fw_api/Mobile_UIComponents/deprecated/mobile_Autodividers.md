# Autodividers

The autodividers component is an extension of the list view component , and it automatically creates dividers for a list view.

| Note |
| --- |
| This component has been DEPRECATED since **Tizen 2.4 **and will be *deleted in Tizen 3.0. *
To support Backward compatibility, please import tau.support-2.3.js. |

## Table of Contents

- Default Selectors
- HTML Examples
- Options
## Default Selectors

By default, all the list view elements with the `data-autodividers="true" `attribute are displayed as with automatically-generated dividers for the list items.

## HTML Examples

To add an autodividers component to the application, use the following code:

```
<ul data-role="listview" data-autodividers="true">
   <li><a href="#">Amy</a></li>
   <li><a href="#">Arabella</a></li>
   <li><a href="#">Barry</a></li>
</ul>
```

## Options

The following table lists the options for the autodividers component.

| Option | Input type | Default value | Description |
| --- | --- | --- | --- |
| data-autodividers | boolean | false | Enables the creation of autodividers for a list view component. |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
        3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
