# Checkbox Radio

The checkbox radio component changes the default browser checkboxes and radio buttons to a form more adapted to the mobile environment.

| Note |
| --- |
| This component has been DEPRECATED since **Tizen 2.4 **and will be *deleted in Tizen 3.0. *
To support Backward compatibility, please import tau.support-2.3.js. |

Since 2.4, to use checkbox and radio button, please refer Checkbox and Radio Component.
## Table of Contents

- Default Selectors
- HTML Examples
- Methods
## Default Selectors

By default, all `<input> `elements with the `type="checkbox" `or `type="radio" `attribute are displayed as checkboxes and radio buttons.

## HTML Examples

To create a checkbox radio component:

```
<input type="checkbox" name="checkbox-yes" id="checkbox-yes"/>
<label for="checkbox-yes">Yes</label>
```

## Methods

### Summary

| Method | Description |
| --- | --- |
```
disable() 
```

Disables the component.

|  |  |
```
enable() 
```

Enables the component.

|  |  |
```
getCheckedElement() 
```

Returns a checked checkbox radio element.

|  |  |

`**disable **`Disables the component.

```javascript
disable() 
```

Return value:

| Type | Description |
| --- | --- |
| Checkboxradio | Returns this. |

Code
								example:

```javascript
<input type="checkbox" name="checkbox-1" id="checkbox-1"/>
<label for="checkbox-1">Normal</label>
<script>
   var element = document.getElementById("checkbox-1"),
       checkboxWidget = tau.widget.Checkboxradio(element);
   checkboxWidget.disable();
</script>
```

`**enable **`Enables the component.

```javascript
enable() 
```

Return value:

| Type | Description |
| --- | --- |
| Checkboxradio | Returns this. |

Code
								example:

```javascript
<input type="checkbox" name="checkbox-1" id="checkbox-1"/>
<label for="checkbox-1">Normal</label>
<script>
   var element = document.getElementById("checkbox-1"),
       checkboxWidget = tau.widget.Checkboxradio(element);
   checkboxWidget.enable();
</script>
```

`**getCheckedElement **`Returns a checked checkbox radio element.

```javascript
HTMLElement getCheckedElement() 
```

Return value:

| Type | Description |
| --- | --- |
| HTMLElement |  |

Code
								example:

```javascript
<input type="checkbox" name="checkbox-1" id="checkbox-1"/>
<label for="checkbox-1">Normal</label>
<script>
   var element = document.getElementById("checkbox-1"),
       checkboxWidget = tau.widget.Checkboxradio(element);
   checkboxWidget.getCheckedElement();
   /* Returns checked checkbox element */
</script>
```

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
		3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
