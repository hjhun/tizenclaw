# Control Group

The control group component improves the  styling of multiple buttons by grouping them into a single block.

| Note |
| --- |
| This component has been DEPRECATED since **Tizen 2.4 **and will be *deleted in Tizen 3.0. *
To support Backward compatibility, please import tau.support-2.3.js. |

## Table of Contents

- Default Selectors
- HTML Examples
- Options
## Default Selectors

By default, all `<div> `elements with the `data-role="controlgroup" `attribute are displayed as control groups.

## HTML Examples

To create a control group, use the following code:

```
<div data-role="controlgroup">
   <a href="#" data-role="button">Yes</a>
   <a href="#" data-role="button">No</a>
   <a href="#" data-role="button">Cancel</a>
</div>
```

## Options

The following table lists the options for the control group component.

| Option | Input type | Default value | Description |
| --- | --- | --- | --- |
| data-type | "vertical" | "horizontal" | "vertical" | Direction of the control group. |
| data-excludeInvisible | true | false | false | Flag specifying exclusion of invisible elements. |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
		3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
