Multimedia View
# Multimedia View

The multimedia view component displays the audio and video player.

| Note |
| --- |
| This component has been DEPRECATED since **Tizen 2.3 **. |
| Since 2.3, this component is supported by standard HTML tag. |

## Table of Contents

- HTML Examples
## HTML Examples

It is very simple to use the multimedia view in a Web application. For more information, see HTML5 Video .

- To create a video view:
```
<div data-role="content">
   <video data-controls="true" style="width:100%;" controls>
      <source src="Color_short_version.mp4" type="video/mp4"/>
      <p>Your browser does not support the video tag.</p>
   </video>
</div>
```

- To create an audio view:
```
<div data-role="content">
   <audio data-controls="true" style="width:100%;" controls>
      <source src="Color_short_version.mp3" type="audio/mpeg"/>
      <p>Your browser does not support the audio tag.</p>
   </audio>
</div>
```

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
		3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
