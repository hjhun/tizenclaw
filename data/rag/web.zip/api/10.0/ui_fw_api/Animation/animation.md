# Animation

Provides features that make and control animation. TAU Animation has relevance to Tween Animator. As you can see below APIs, almost APIs make Tween-able object and control animation.

## Table of Contents

- Methods
- stop
- transform
- tween
- target
## Methods

### Summary

| Method | Description |
| --- | --- |
```
stop() 
```

Stops animation or group animations.

|  |  |
```
transform() 
```

Sets transform property of target.

|  |  |
```
tween() 
```

Adds tween animation with animation information and target is animated.

|  |  |
```
Target target(String str) 
```

Returns animation target object

|  |  |

`**stop **`Stops animation or group animations.

```javascript
stop()
```

Return value:

No Return Value

`**transform **`Sets transform property of target.

```javascript
transform()
```

Return value:

No Return Value

`**tween **`Adds tween animation with animation information and target is animated.

```javascript
tween()
```

Return value:

No Return Value

`**target **`Returns animation target object

```javascript
Target target(String str)
```

Parameters:

| Parameter | Type | Required / optional | Default value | Description |
| --- | --- | --- | --- | --- |
| str | String | required |  |  |

Return value:

| Type | Description |
| --- | --- |
| Target | Target Object |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution
        3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
