# Globalization

## Table of Contents

- Methods
- getCalendar
- getLocale
- importModule
- setLocale
## Methods

### Summary

| Method | Description |
| --- | --- |
```
Object getCalendar()
```

Get gregorian calendar.

|  |  |
```
string getLocale()
```

Get Locale.

|  |  |
```
importModule(string fileName) 
```

Put the module into module array of core.util.globalize

|  |  |
```
Deferred setLocale(string localeId) 
```

Set Locale. This API is Async API. 
Please use deferred callback functions which are returned (.done(), .then() .etc)

|  |  |

`**getCalendar **`Get gregorian calendar.

```javascript
Object getCalendar() 
```

Return value:

| Type | Description |
| --- | --- |
| Object | gregorian calendar data given locale. |

`**getLocale **`Get Locale.

```javascript
string getLocale() 
```

Return value:

| Type | Description |
| --- | --- |
| string | Current locale |

`**importModule **`Put the module into module array of core.util.globalize

```javascript
importModule(string fileName) 
```

Parameters:

| Parameter | Type | Required / optional | Default value | Description |
| --- | --- | --- | --- | --- |
| fileName | string | required |  |  |

Return value:

No Return Value

`**setLocale **`Set Locale. This API is Async API. 
Please use deferred callback functions which are returned (.done(), .then() .etc)

```javascript
Deferred setLocale(string localeId) 
```

Parameters:

| Parameter | Type | Required / optional | Default value | Description |
| --- | --- | --- | --- | --- |
| localeId | string | required |  |  |

Return value:

| Type | Description |
| --- | --- |
| Deferred |  |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
