# Processing

The processing component shows on the screen that an operation is in progress.

Two size of processing components are supported by TAU. please refer this document.

## Table of Contents

- HTML Examples
## HTML Examples

### small processing component To add a small processing component to the application, use the following code:

```
<div class="ui-processing"></div>
<div class="ui-processing-text">
   Description about progress
</div>
```

### Full size processing component

To add a **FULL SIZE **processing component to the application, you need to declare processing html in page level. 
Please use the following code:

| Note |
| --- |
| This component(full-size processing) is supported since **2.3 **. |

```
<div class="ui-page">
   <header class="ui-header">
      <h2 class="ui-title">Processing</h2>
   </header>
   <div class="ui-content content-padding">
      It was a real pleasure for me to finally get to meet you. My colleagues join me in sending you our holiday...
   </div>
   <div class="ui-processing ui-processing-full-size"></div>
</div>
```

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
