# Wearable UI Components

The Tizen Wearable Web UI framework provides rich Tizen Wearable UI Components that are optimized for the Tizen Wearable Web application. You can use the UI Components for:

- CSS animation
- Rendering
The following table displays the UI Components provided by the Tizen Wearable Web UI framework.

| Table: Tizen Wearable Web UI Components UI Component | Description |
| --- | --- |
| Button | Shows a component that can be used to generate an action event. |
| Checkbox and radio button | Shows a list of options where 1 or more can be selected. |
| Circle ProgressBar | Shows a control that indicates the progress percentage of an on-going operation by circular shape. |
| Circular index scroll bar | Shows a circular index scroll bar which uses rotary. |
| Date picker | Shows a control in which you can set date. |
| Dimmer | Shows the value that can be identified with intensity of widget color. |
| Drawer | Shows a panel that in the sub-layout on the left or right edge of screen. |
| Index scroll bar | Shows an index scroll bar with indices, usually for the list. |
| List | Shows a list view. |
| Marquee | Shows a component which moves left and right. |
| Number picker | Shows a control in which you can set number. |
| Page Indicator | Shows a dot-style page indicator. |
| Popup | Shows a pop-up window. |
| Processing | Shows a control that operates as progress infinitely. |
| Progress | Shows a control that indicates the linear shape progressbar percentage of an on-going operation. |
| Section changer |
| Shows a control that you can use to scroll through multiple <section> elements. Selector | Shows a selector that select items. |
| Slider | Shows a control that you can use to change values by dragging a handle on a horizontal scale. |
| SnapListview | Shows a snap listview that you can detect which item be positioned at center. |
| Swipe list | Shows a list where you can swipe horizontally through a list item to perform a specific task. |
| Time picker | Shows a control in which you can set time. |
| Toggle switch | Shows a 2-state switch. |
| View Switcher | Shows a viewswitcher that controls each view elements. |
| Virtual list | Shows a list view for large amounts of data. |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
