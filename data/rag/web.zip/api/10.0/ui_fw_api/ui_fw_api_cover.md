Related Info

- TAU guides
- TAU source code
- TAU web page
# Tizen Advanced UI framework Reference

| Note |
| --- |
| Tizen Advanced UI framework(TAU) is **optional **, but recommended for making web applications for Tizen. |

**The Web UI framework is called Tizen Advanced UI (TAU) framework. **It provides tools, such as UI components, events, effects, and animations, for Web application development. You can leverage these tools by just selecting the required screen elements and creating the applications.

## Table of Contents

| Title | Description |
| --- | --- |
| Base | References of base APIs to organize and managing application. |
| Mobile UI Components | References of UI Components for Mobile profile. |
| Extended Mobile UI Components | References of Extended UI Components for Mobile profile. |
| Wearable UI Components | References of UI Components for Wearable profile. |
| Extended Wearable UI Components | References of Extended UI Components for Wearable profile. |
| Gesture Events | References of TAU-specific gesture event. |
| Globalization | References of Globalization utility library. |
| Animation | References of Animation APIs. |

| Note *(important!) * |
| --- |
| **TAU (Tizen Advanced UI) **is the new name of tizen-web-ui-fw. |
**Since 2.3, **tizen-web-ui-fw has been ***deprecated ***(include tizen-web-ui-fw.js, tizen-web-ui-fw-libs.js, tizen-web-ui-fw.css). 
So, in all documents and source code, TAU is used instead of tizen-web-ui-fw.

**Since 2.4 **, tizen-web-ui-fw will be fully deleted and we will **not support **old version anymore.

|  |

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
