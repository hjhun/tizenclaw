# Tizen TV Web Device API Reference

The Tizen Web Device API, based on JavaScript, provides you advanced access to the device's platform capabilities.

You can develop rich Web applications using the Tizen Web Device APIs. You can, for example, control the application life-cycle, manage your schedules, exchange data, or make payments using NFC.

The APIs listed in this category are created by the Tizen platform to expose device capabilities to Web Applications.

#### Base

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Archive | This API provides interfaces and methods to create an archive file as well as various other kinds of manipulation (e.g. extract files, add a file to an archive file). | 2.3 | Mandatory | Yes |
| Filesystem | This API provides access to the file system of a device. This API might be obsolete in the future when W3C File APIs are extended to access system-sensitive files by Web applications. | 1.0 | Mandatory | Yes |
| Tizen | The base object for accessing the Tizen Web Device API. | 1.0 | Mandatory | Yes |

#### Account

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Account | This API provides interfaces and methods for managing accounts (e.g. create an account, change the account information). | 5.0 | Optional | Yes |

#### Application Framework

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Alarm | This API provides functionality for setting and unsetting alarms. | 1.0 | Mandatory | Yes |
| Application | This API provides information about running and installed applications and controls them. | 1.0 | Mandatory | Yes |
| Data Control | This API provides interfaces and methods for accessing specific data exported by other applications. | 2.4 | Mandatory | Yes |
| Message Port | This API provides the functionality for communication with other applications. | 2.1 | Mandatory | Yes |
| Package | This API provides information install/uninstall package and get information about installed packages. | 2.1 | Mandatory | Yes |

#### Content

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Content | This API provides functionality to discover multimedia content (such as images, videos or music). | 2.0 | Mandatory | Yes |
| Download | This API provides interfaces and methods for downloading remote objects by HTTP request. | 2.0 | Optional | Yes |

#### Machine Learning

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Machine Learning | This API provides functions for Machine Learning features that help you to handle Neural Network Frameworks. | 6.5 | Mandatory | Yes |
| Single | This API provides functionality for a simple usage scenario of neural network models. | 6.5 | Mandatory | Yes |
| Pipeline | This API provides functionality for managing machine learning inference pipelines. | 6.5 | Mandatory | Yes |
| Trainer | This API provides functionality for creating, controlling, and training a machine learning model. | 7.0 | Mandatory | Yes |

#### Messaging

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Push | This API provides the functionality for receiving push notifications. | 3.0 | Optional | Yes |

#### Multimedia

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Exif | This API provides interfaces and methods for manipulating Exif data from JPEG file. | 2.3 | Mandatory | Yes |
| Media Controller | This API provides functions for communication between the media controller server and the media controller client. | 5.0 | Optional | Yes |
| Metadata | This API provides interfaces and methods for extracting metadata information from a media file. | 6.0 | Mandatory | Yes |

#### Network

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Bluetooth | This API enables control over Bluetooth. | 6.0 | Optional | No |

#### Security

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Keymanager | This API provides interfaces and methods for a secure repository for storing, retrieving and removing the sensitive data of users and their applications. | 2.4 | Mandatory | Yes |

#### System

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| System Information | This API provides information about the device's display, network, storage and other capabilities. | 1.0 | Mandatory | Yes |
| Time | This API exposes information about date, time and time zones. | 1.0 | Mandatory | Yes |
| Web Setting | This API manages the setting states of the web view in web applications. | 2.2 | Mandatory | Yes |

#### UIX

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Voice Control | This API provides functions for users to set voice commands and to control the web application through their voices. | 4.0 | Mandatory | Yes |

#### TV Controls

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| TV Audio Control | This API provides interfaces and methods for control of TV audio. | 2.3 | Optional | No |
| TV Display Control | This API provides interfaces and methods to get information about the effects of stereoscopy (3D mode). | 2.3 | Optional | No |
| TV Information | This API provides interfaces and methods to get information about the TV settings. | 2.4 | Optional | No |
| TV Input Device | This API allows to receive the key events generated from an input device. For example, when a user presses a key of the TV remote control. | 2.3 | Optional | Yes |
| TV Window | This API provides interfaces and methods to control the TV Window. For example, the main window and PIP window. | 2.3 | Optional | No |

#### Cordova

| API | Description | Version (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- |
| Console | The Console module provides function to access the console. | 3.0 | Mandatory | Yes |
| Cordova | This API provides common Cordova functionality. | 3.0 | Mandatory | Yes |
| Device | This plugin defines a global device object, which describes the device's hardware and software. | 3.0 | Mandatory | Yes |
| Device Motion | This plugin provides access to the device's accelerometer. | 3.0 | Mandatory | Yes |
| Dialogs | This plugin provides the ability to make different types of notifications to the user. | 3.0 | Mandatory | Yes |
| Events | This plugin provides information about events defined in cordova. | 3.0 | Mandatory | Yes |
| File | This plugin implements a File API allowing read/write access to files residing on the device. | 3.0 | Mandatory | Yes |
| File Transfer | This module allows you to upload and download files. | 3.0 | Mandatory | Yes |
| Globalization | This plugin obtains information and performs operations specific to the user's locale, language, and timezone. | 3.0 | Mandatory | Yes |
| Media | This plugin provides the ability to record and play back audio files on a device. | 3.0 | Mandatory | Yes |
| Network Information | This plugin provides information about the device's cellular and wifi connection, and whether the device has an internet connection. | 3.0 | Mandatory | Yes |

#### Deprecated API

| API | Description | Version (Since) | Deprecated (Since) | TV | Supported on 
TV Emulator |
| --- | --- | --- | --- | --- | --- |
| Iotcon | This API provides functions for IoT (Internet of Things) connectivity. | 3.0 | 10.0 | Optional | Yes |
| LibTeec | This API provides interfaces and methods for a TrustZone. | 4.0 | 6.5 | Mandatory | Yes |

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
