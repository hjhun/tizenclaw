# MediaController API

The Media Controller API provides functions for communication between the media
controller server and the media controller client.

It helps to transfer the information like playback info, shuffle/repeat mode
and metadata from media controller server to client. Allows to control server state
by sending commands from client.

For more information on the Media Controller features, see Media Controller Guide .

Since: 5.0

## Table of Contents

- 1. Type Definitions
- 1.1. MediaControllerServerState
- 1.2. MediaControllerSearchCategory
- 1.3. MediaControllerPlaybackState
- 1.4. MediaControllerPlaybackAction
- 1.5. MediaControllerRepeatState
- 1.6. MediaControllerContentType
- 1.7. MediaControllerContentAgeRating
- 1.8. MediaControllerAbilitySupport
- 1.9. MediaControllerSimpleAbility
- 1.10. MediaControllerDisplayModeType
- 1.11. MediaControllerDisplayRotationType
- 2. Interfaces
- 2.1. MediaControllerObject
- 2.2. MediaControllerManager
- 2.3. MediaControllerServer
- 2.4. MediaControllerClient
- 2.5. MediaControllerServerInfo
- 2.6. MediaControllerServerPlaybackInfo
- 2.7. MediaControllerServerInfoPlaybackInfo
- 2.8. MediaControllerPlaylists
- 2.9. MediaControllerPlaylistsInfo
- 2.10. MediaControllerAbilities
- 2.11. MediaControllerPlaybackAbilities
- 2.12. MediaControllerDisplayModeAbilities
- 2.13. MediaControllerDisplayRotationAbilities
- 2.14. MediaControllerAbilitiesInfo
- 2.15. MediaControllerPlaybackAbilitiesInfo
- 2.16. MediaControllerDisplayModeAbilitiesInfo
- 2.17. MediaControllerDisplayRotationAbilitiesInfo
- 2.18. MediaControllerSubtitles
- 2.19. MediaControllerSubtitlesInfo
- 2.20. MediaControllerMode360
- 2.21. MediaControllerMode360Info
- 2.22. MediaControllerDisplayMode
- 2.23. MediaControllerDisplayModeInfo
- 2.24. MediaControllerDisplayRotation
- 2.25. MediaControllerClientInfo
- 2.26. MediaControllerDisplayRotationInfo
- 2.27. MediaControllerMetadata
- 2.28. MediaControllerPlaylistItem
- 2.29. MediaControllerMetadataInit
- 2.30. MediaControllerPlaylist
- 2.31. SearchFilter
- 2.32. MediaControllerServerInfoArraySuccessCallback
- 2.33. MediaControllerSendCommandSuccessCallback
- 2.34. RequestReply
- 2.35. MediaControllerSearchRequestReplyCallback
- 2.36. MediaControllerSearchRequestCallback
- 2.37. MediaControllerReceiveCommandCallback
- 2.38. MediaControllerEnabledChangeRequestCallback
- 2.39. MediaControllerEnabledChangeCallback
- 2.40. MediaControllerDisplayModeChangeRequestCallback
- 2.41. MediaControllerDisplayModeChangeCallback
- 2.42. MediaControllerDisplayRotationChangeRequestCallback
- 2.43. MediaControllerDisplayRotationChangeCallback
- 2.44. MediaControllerServerStatusChangeCallback
- 2.45. MediaControllerPlaybackInfoChangeCallback
- 2.46. MediaControllerChangeRequestPlaybackInfoCallback
- 2.47. MediaControllerGetAllPlaylistsSuccessCallback
- 2.48. MediaControllerPlaylistUpdatedCallback
- 2.49. MediaControllerGetItemsSuccessCallback
- 2.50. MediaControllerAbilityChangeCallback
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| MediaControllerObject |  |
| MediaControllerManager | MediaControllerClient getClient () MediaControllerServer createServer () |
| MediaControllerServer | MediaControllerClientInfo [] getAllClientsInfo () void setSearchRequestListener ( MediaControllerSearchRequestCallback listener) void unsetSearchRequestListener () long addCommandListener ( MediaControllerReceiveCommandCallback listener) void removeCommandListener (long watchId) |
| MediaControllerClient | void findServers ( MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback) MediaControllerServerInfo ? getLatestServerInfo () long addAbilityChangeListener ( MediaControllerAbilityChangeCallback listener) void removeAbilityChangeListener (long watchId) void findSubscribedServers ( MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback) void setCustomEventListener ( MediaControllerReceiveCommandCallback listener) void unsetCustomEventListener () |
| MediaControllerServerInfo | void sendSearchRequest ( SearchFilter [] request, MediaControllerSearchRequestReplyCallback replyCallback, optional ErrorCallback ? errorCallback) void sendCommand (DOMString command, Bundle ? data, MediaControllerSendCommandSuccessCallback successCallback, optional ErrorCallback ? errorCallback) long addServerStatusChangeListener ( MediaControllerServerStatusChangeCallback listener) void removeServerStatusChangeListener (long watchId) |
| MediaControllerServerPlaybackInfo | void updatePlaybackItem (DOMString playlistName, DOMString index) long addChangeRequestListener ( MediaControllerChangeRequestPlaybackInfoCallback listener) void removeChangeRequestListener (long watchId) |
| MediaControllerServerInfoPlaybackInfo | void sendPlaybackAction ( MediaControllerPlaybackAction action, optional MediaControllerSendCommandSuccessCallback ? replyCallback) void sendPlaybackPosition (unsigned long long position, optional MediaControllerSendCommandSuccessCallback ? replyCallback) void sendShuffleMode (boolean mode, optional MediaControllerSendCommandSuccessCallback ? replyCallback) void sendRepeatState ( MediaControllerRepeatState state, optional MediaControllerSendCommandSuccessCallback ? replyCallback) long addPlaybackInfoChangeListener ( MediaControllerPlaybackInfoChangeCallback listener) void removePlaybackInfoChangeListener (long watchId) |
| MediaControllerPlaylists | MediaControllerPlaylist createPlaylist (DOMString name) void savePlaylist ( MediaControllerPlaylist playlist, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void deletePlaylist (DOMString playlistName, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void getAllPlaylists ( MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback ? errorCallback) MediaControllerPlaylist getPlaylist (DOMString playlistName) |
| MediaControllerPlaylistsInfo | void getAllPlaylists ( MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void sendPlaybackItem (DOMString playlistName, DOMString index, MediaControllerPlaybackAction action, unsigned long long position, optional MediaControllerSendCommandSuccessCallback ? replyCallback) long addPlaylistUpdatedListener ( MediaControllerPlaylistUpdatedCallback listener) void removePlaylistUpdatedListener (long listenerId) MediaControllerPlaylist getPlaylist (DOMString playlistName) |
| MediaControllerAbilities |  |
| MediaControllerPlaybackAbilities | void saveAbilities () |
| MediaControllerDisplayModeAbilities |  |
| MediaControllerDisplayRotationAbilities |  |
| MediaControllerAbilitiesInfo | void subscribe () void unsubscribe () |
| MediaControllerPlaybackAbilitiesInfo |  |
| MediaControllerDisplayModeAbilitiesInfo |  |
| MediaControllerDisplayRotationAbilitiesInfo |  |
| MediaControllerSubtitles | long addChangeRequestListener ( MediaControllerEnabledChangeRequestCallback listener) void removeChangeRequestListener (long watchId) |
| MediaControllerSubtitlesInfo | void sendRequest (boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback) long addModeChangeListener ( MediaControllerEnabledChangeCallback listener) void removeModeChangeListener (long watchId) |
| MediaControllerMode360 | long addChangeRequestListener ( MediaControllerEnabledChangeRequestCallback listener) void removeChangeRequestListener (long watchId) |
| MediaControllerMode360Info | void sendRequest (boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback) long addModeChangeListener ( MediaControllerEnabledChangeCallback listener) void removeModeChangeListener (long watchId) |
| MediaControllerDisplayMode | long addChangeRequestListener ( MediaControllerDisplayModeChangeRequestCallback listener) void removeChangeRequestListener (long watchId) |
| MediaControllerDisplayModeInfo | void sendRequest ( MediaControllerDisplayModeType type, MediaControllerSendCommandSuccessCallback replyCallback) long addModeChangeListener ( MediaControllerDisplayModeChangeCallback listener) void removeModeChangeListener (long watchId) |
| MediaControllerDisplayRotation | long addChangeRequestListener ( MediaControllerDisplayRotationChangeRequestCallback listener) void removeChangeRequestListener (long watchId) |
| MediaControllerClientInfo | void sendEvent (DOMString eventName, Bundle ? data, MediaControllerSendCommandSuccessCallback successCallback) |
| MediaControllerDisplayRotationInfo | void sendRequest ( MediaControllerDisplayRotationType displayRotation, MediaControllerSendCommandSuccessCallback replyCallback) long addDisplayRotationChangeListener ( MediaControllerDisplayRotationChangeCallback listener) void removeDisplayRotationChangeListener (long watchId) |
| MediaControllerMetadata | void save () |
| MediaControllerPlaylistItem |  |
| MediaControllerMetadataInit |  |
| MediaControllerPlaylist | void addItem (DOMString index, MediaControllerMetadataInit metadata) void getItems ( MediaControllerGetItemsSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| SearchFilter |  |
| MediaControllerServerInfoArraySuccessCallback | void onsuccess ( MediaControllerServerInfo [] servers) |
| MediaControllerSendCommandSuccessCallback | void onsuccess (object? data, optional long code) |
| RequestReply |  |
| MediaControllerSearchRequestReplyCallback | void onreply ( RequestReply ? reply) |
| MediaControllerSearchRequestCallback | RequestReply ? onrequest ( ApplicationId clientName, SearchFilter [] request) |
| MediaControllerReceiveCommandCallback | RequestReply ? onsuccess ( ApplicationId senderAppName, DOMString command, object data) |
| MediaControllerEnabledChangeRequestCallback | RequestReply ? onreply ( ApplicationId clientName, boolean enabled) |
| MediaControllerEnabledChangeCallback | void onchange (boolean enabled) |
| MediaControllerDisplayModeChangeRequestCallback | RequestReply ? onreply ( ApplicationId clientName, MediaControllerDisplayModeType mode) |
| MediaControllerDisplayModeChangeCallback | void onchange ( MediaControllerDisplayModeType mode) |
| MediaControllerDisplayRotationChangeRequestCallback | RequestReply ? onreply ( ApplicationId clientName, MediaControllerDisplayRotationType displayRotation) |
| MediaControllerDisplayRotationChangeCallback | void onchange ( MediaControllerDisplayRotationType displayRotation) |
| MediaControllerServerStatusChangeCallback | void onsuccess ( MediaControllerServerState status) |
| MediaControllerPlaybackInfoChangeCallback | void onplaybackchanged ( MediaControllerPlaybackState state, unsigned long long position) void onshufflemodechanged (boolean mode) void onrepeatstatechanged ( MediaControllerRepeatState state) void onmetadatachanged ( MediaControllerMetadata metadata) |
| MediaControllerChangeRequestPlaybackInfoCallback | RequestReply ? onplaybackactionrequest ( MediaControllerPlaybackAction action, ApplicationId clientName) RequestReply ? onplaybackpositionrequest (unsigned long long position, ApplicationId clientName) RequestReply ? onshufflemoderequest (boolean mode, ApplicationId clientName) RequestReply ? onrepeatstaterequest ( MediaControllerRepeatState state, ApplicationId clientName) RequestReply ? onplaybackitemrequest (DOMString playlistName, DOMString index, MediaControllerPlaybackAction action, unsigned long long position, ApplicationId clientName) |
| MediaControllerGetAllPlaylistsSuccessCallback | void onsuccess ( MediaControllerPlaylist [] playlists) |
| MediaControllerPlaylistUpdatedCallback | void onplaylistupdated (DOMString serverName, MediaControllerPlaylist playlist) void onplaylistdeleted (DOMString serverName, DOMString playlistName) |
| MediaControllerGetItemsSuccessCallback | void onsuccess ( MediaControllerPlaylistItem [] items) |
| MediaControllerAbilityChangeCallback | void onplaybackabilitychanged ( MediaControllerServerInfo server, MediaControllerPlaybackAbilitiesInfo abilities) void ondisplaymodeabilitychanged ( MediaControllerServerInfo server, MediaControllerDisplayModeAbilitiesInfo abilities) void ondisplayrotationabilitychanged ( MediaControllerServerInfo server, MediaControllerDisplayRotationAbilitiesInfo abilities) void onsimpleabilitychanged ( MediaControllerServerInfo server, MediaControllerSimpleAbility type, MediaControllerAbilitySupport support) |

## 1. Type Definitions

### 1.1. MediaControllerServerState

The media controller server state.

```webidl
  enum MediaControllerServerState { "ACTIVE", "INACTIVE" };
```

Since: 5.0

- ACTIVE - Corresponds to active server state.
- INACTIVE - Corresponds to inactive server state.

### 1.2. MediaControllerSearchCategory

Search category.

```webidl
  enum MediaControllerSearchCategory { "NO_CATEGORY", "TITLE", "ARTIST", "ALBUM", "GENRE", "TPO" };
```

Since: 5.5

- NO_CATEGORY - No search category.
- TITLE - Search by title.
- ARTIST - Search by artist.
- ALBUM - Search by album.
- GENRE - Search by genre.
- TPO - Search by Time Place Occasion.

### 1.3. MediaControllerPlaybackState

Defines media playback state.

```webidl
  enum MediaControllerPlaybackState { "PLAY", "PAUSE", "STOP", "NEXT", "PREV", "FORWARD", "REWIND" };
```

Since: 5.0

- PLAY - Corresponds to the "playing" media controller playback state.
- PAUSE - Corresponds to the "paused" media controller playback state.
- STOP - Corresponds to the "stopped" media controller playback state.
- NEXT - Corresponds to the "moving to next" media controller playback state.
- PREV - Corresponds to the "moving to previous" media controller playback state.
- FORWARD - Corresponds to the "forwarding" media controller playback state.
- REWIND - Corresponds to the "rewinding" media controller playback state.

### 1.4. MediaControllerPlaybackAction

Defines media playback actions.

```webidl
  enum MediaControllerPlaybackAction { "PLAY", "PAUSE", "STOP", "NEXT", "PREV", "FORWARD", "REWIND", "TOGGLE_PLAY_PAUSE" };
```

Since: 6.0

- PLAY - Corresponds to the "play" media controller playback action.
- PAUSE - Corresponds to "pause" media controller playback action.
- STOP - Corresponds to the "stop" media controller playback action.
- NEXT - Corresponds to the "next" media controller playback action.
- PREV - Corresponds to the "previous" media controller playback action.
- FORWARD - Corresponds to the "forward" media controller playback action.
- REWIND - Corresponds to the "rewind" media controller playback action.
- TOGGLE_PLAY_PAUSE - Corresponds to the "toggle play/pause" media controller playback action.

### 1.5. MediaControllerRepeatState

Defines states for repeating media.

```webidl
  enum MediaControllerRepeatState { "REPEAT_OFF", "REPEAT_ONE", "REPEAT_ALL" };
```

Since: 5.5

The possible states are:

- REPEAT_OFF - repeating is disabled.
- REPEAT_ONE - repeating one media.
- REPEAT_ALL - repeating all media.

### 1.6. MediaControllerContentType

Content type.

```webidl
  enum MediaControllerContentType { "IMAGE", "MUSIC", "VIDEO", "OTHER", "UNDECIDED" };
```

Since: 5.5

- IMAGE - content type for images.
- MUSIC - content type for music.
- VIDEO - content type for videos.
- OTHER - content type for other media.
- UNDECIDED - content type for unspecified media types.

### 1.7. MediaControllerContentAgeRating

Media Controller content age rating.

```webidl
  enum MediaControllerContentAgeRating { "ALL", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
    "17", "18", "19" };
```

Since: 5.5

Each value represents the minimum age restriction for the media.

### 1.8. MediaControllerAbilitySupport

The media controller ability support values.

```webidl
  enum MediaControllerAbilitySupport { "YES", "NO", "UNDECIDED" };
```

Since: 5.5

- YES - Ability is supported.
- NO - Ability is not supported.
- UNDECIDED - The support of ability is not set.

### 1.9. MediaControllerSimpleAbility

The media controller simple ability types. Simple means, that each ability is described by a single MediaControllerAbilitySupport value and is not a part of a complex ability structure.

```webidl
  enum MediaControllerSimpleAbility { "PLAYBACK_POSITION", "SHUFFLE", "REPEAT", "PLAYLIST", "CLIENT_CUSTOM", "SEARCH", "SUBTITLES",
    "MODE_360" };
```

Since: 5.5

- PLAYBACK_POSITION - Ability to change playback position.
- SHUFFLE - Ability to change shuffle mode.
- REPEAT - Ability to change repeat state.
- PLAYLIST - Ability to add/change/remove playlists.
- CLIENT_CUSTOM - Ability to receive custom commands from media controller clients.
- SEARCH - Ability to receive search requests from media controller clients.
- SUBTITLES - Ability to receive requests for subtitles mode change from media controller clients.
- MODE_360 - Ability to receive requests for spherical (360°) mode change from media controller clients.

### 1.10. MediaControllerDisplayModeType

Types of supported media controller display modes.

```webidl
  enum MediaControllerDisplayModeType { "LETTER_BOX", "ORIGIN_SIZE", "FULL_SCREEN", "CROPPED_FULL" };
```

Since: 5.5

- LETTER_BOX - Letter box display mode type.
- ORIGIN_SIZE - Origin size display mode type.
- FULL_SCREEN - Full screen display mode type.
- CROPPED_FULL - Cropped full screen display mode type.

### 1.11. MediaControllerDisplayRotationType

The media controller rotation values.

```webidl
  enum MediaControllerDisplayRotationType { "ROTATION_NONE", "ROTATION_90", "ROTATION_180", "ROTATION_270" };
```

Since: 5.5

- ROTATION_NONE - Display is not rotated.
- ROTATION_90 - Display is rotated by 90°.
- ROTATION_180 - Display is rotated by 180°.
- ROTATION_270 - Display is rotated by 270°.

## 2. Interfaces

### 2.1. MediaControllerObject

This interface defines what is instantiated by the *Tizen *object from the Tizen platform.

```webidl
  [NoInterfaceObject] interface MediaControllerObject {
    readonly attribute MediaControllerManager mediacontroller;
  };
```

```webidl
  Tizen implements MediaControllerObject;
```

Since: 5.0

There is a *tizen.mediacontroller *object that allows access to the Media Controller API.

#### Attributes

- readonly MediaControllerManager mediacontroller Object representing a media controller manager.

Since: 5.0

### 2.2. MediaControllerManager

This interface provides access to the *MediaControllerObject *object.

```webidl
  [NoInterfaceObject] interface MediaControllerManager {
    MediaControllerClient getClient() raises(WebAPIException);
    MediaControllerServer createServer() raises(WebAPIException);
  };
```

Since: 5.0

#### Methods

`**getClient **`Gets the client object. If not exist, client will be automatically created.

```javascript
MediaControllerClient getClient();
```

Since: 5.0

Privilege level: public

Privilege: http://tizen.org/privilege/mediacontroller.client

Return value:

MediaControllerClient: The *MediaController Client *object.

Exceptions:

- WebAPIException
- with error type NotSupportedError, if this feature is not supported.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
try
{
  var mcClient = tizen.mediacontroller.getClient();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**createServer **`Creates the Server object which holds playback state, meta data
and is controlled by Client.

```javascript
MediaControllerServer createServer();
```

Since: 5.0

Privilege level: public

Privilege: http://tizen.org/privilege/mediacontroller.server

Return value:

MediaControllerServer: The *MediaController Server *object.

Exceptions:

- WebAPIException
- with error type NotSupportedError, if this feature is not supported.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
try
{
  var mcServer = tizen.mediacontroller.createServer();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

### 2.3. MediaControllerServer

Provides functions for sending the server information to the client.

```webidl
  [NoInterfaceObject] interface MediaControllerServer {
    readonly attribute MediaControllerServerPlaybackInfo playback;
    readonly attribute MediaControllerPlaylists playlists;
    attribute DOMString? iconURI raises(WebAPIException);
    readonly attribute MediaControllerAbilities abilities;
    readonly attribute MediaControllerSubtitles subtitles;
    readonly attribute MediaControllerMode360 mode360;
    readonly attribute MediaControllerDisplayMode displayMode;
    readonly attribute MediaControllerDisplayRotation displayRotation;
    MediaControllerClientInfo[] getAllClientsInfo() raises(WebAPIException);
    void setSearchRequestListener(MediaControllerSearchRequestCallback listener) raises(WebAPIException);
    void unsetSearchRequestListener() raises(WebAPIException);
    long addCommandListener(MediaControllerReceiveCommandCallback listener) raises(WebAPIException);
    void removeCommandListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.0

Allows the application to send the playback state and metadata to other application
and be controlled by other application(client) remotely.

#### Attributes

- readonly MediaControllerServerPlaybackInfo playback Current playback info.

Since: 6.0

- readonly MediaControllerPlaylists playlists Object representing features related to playlists of a media controller server.

Since: 6.0

- DOMString iconURI [nullable] Server icon URI.

Since: 5.5

Remark: The readonly modifier is removed since 6.0 version.

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilities abilities Abilities of the media controller server.

Since: 5.5

- readonly MediaControllerSubtitles subtitles Object representing features related to subtitles control of a media controller server.

Since: 5.5

- readonly MediaControllerMode360 mode360 Object representing features related to spherical (360°) mode control of a media controller server.

Since: 5.5

- readonly MediaControllerDisplayMode displayMode Object representing features related to display mode control of a media controller server.

Since: 5.5

- readonly MediaControllerDisplayRotation displayRotation Object representing features related to display rotation control of a media controller server.

Since: 5.5

#### Methods

`**getAllClientsInfo **`Returns all existing clients info.

```javascript
MediaControllerClientInfo[] getAllClientsInfo();
```

Since: 5.5

Remark: Code example available at sendEvent() method documentation.

Return value:

MediaControllerClientInfo[]: All existing clients info.

Exceptions:

- WebAPIException
- with error type UnknownError, if any platform error occurs.

`**setSearchRequestListener **`Sets the listener for receiving search requests from a client.

```javascript
void setSearchRequestListener(MediaControllerSearchRequestCallback listener);
```

Since: 5.5

Parameters:

- **listener :
 Function to be called for each search command received. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any of the arguments has invalid type.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
function searchRequestListener(clientName, request)
{
  console.log("name of the client application which sent the request: " + clientName);
  console.log("search command received.");
  request.forEach(filter =>
  {
    console.log("filter: " + JSON.stringify(filter));
  });
}
mcServer.setSearchRequestListener(searchRequestListener);
```

`**unsetSearchRequestListener **`Unsets search request listener.

```javascript
void unsetSearchRequestListener();
```

Since: 5.5

Calling this function has no effect if the listener was not set.

Exceptions:

- WebAPIException
- with error type UnknownError, if unknown error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
function searchRequestListener(clientName, request)
{
  console.log("search command received.");
}
mcServer.setSearchRequestListener(searchRequestListener);
mcServer.unsetSearchRequestListener();
```

`**addCommandListener **`Adds the listener for receiving custom commands from client.
See *MediaControllerServerInfo *to check how to send custom commands from client.

```javascript
long addCommandListener(MediaControllerReceiveCommandCallback listener);
```

Since: 5.0

Parameters:

- **listener :
 Custom commands listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var commandReceiveListener = function(clientName, command, data)
{
  console.log("Command " + command + " received from: " + clientName + " with data: " +
              JSON.stringify(data));

  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({myReply: "someValue"}), 0);
};

/* Registers to receive custom commands from client. */
watcherId = mcServer.addCommandListener(commandReceiveListener);
```

`**removeCommandListener **`Removes the listener, so stop receiving custom commands from clients.

```javascript
void removeCommandListener(long watchId);
```

Since: 5.0

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Subscription identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var commandReceiveListener = function(clientName, command, data)
{
  console.log("Command " + command + " received from: " + clientName + " with data: " +
              JSON.stringify(data));

  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({myReply: "someValue"}), 0);
};

/* Registers to receive custom commands from client. */
watcherId = mcServer.addCommandListener(commandReceiveListener);

/* Cancels the watch operation. */
mcServer.removeCommandListener(watcherId);
```

### 2.4. MediaControllerClient

The media controller client API and functions related with handling media control.
Functions include operations to get the latest status of the media controller servers.

```webidl
  [NoInterfaceObject] interface MediaControllerClient {
    void findServers(MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                     raises(WebAPIException);
    MediaControllerServerInfo? getLatestServerInfo() raises(WebAPIException);
    long addAbilityChangeListener(MediaControllerAbilityChangeCallback listener) raises(WebAPIException);
    void removeAbilityChangeListener(long watchId) raises(WebAPIException);
    void findSubscribedServers(MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
    void setCustomEventListener(MediaControllerReceiveCommandCallback listener) raises(WebAPIException);
    void unsetCustomEventListener() raises(WebAPIException);
  };
```

Since: 5.0

#### Methods

`**findServers **`Retrieves all activated media controller servers.

```javascript
void findServers(MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 5.0

Parameters:

- **successCallback :
 The method to invoke when all of the registered media controller servers have been found. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of retrieving servers list. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient;
try
{
  mcClient = tizen.mediacontroller.getClient();
}
catch (err)
{
  console.log(err.name + " error: " + err.message);
}

function successCallback(list)
{
  for (var s in list)
  {
    console.log("Found server: " + list[s].name + ", state: " + list[s].state);
  }
}

function errorCallback(err)
{
  console.log(err.name + " error: " + err.message);
}

mcClient.findServers(successCallback, errorCallback);
```

Output example:

```
Found server: og8WN4XlLg.BasicUIStudio, state: ACTIVE
```

`**getLatestServerInfo **`Gets the latest activated media controller server info.

```javascript
MediaControllerServerInfo? getLatestServerInfo();
```

Since: 5.0

Remark: If there is no activated media controller server, null value is returned.

Return value:

MediaControllerServerInfo [nullable] : Server info or null .

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
/* Access latest server info. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();
console.log(
    "Latest server name is: " + mcServerInfo.name + ", server state: " + mcServerInfo.state);
```

Output example:

```
Latest server name is: 2cpQcelP8a.HelloTizen, server state: INACTIVE
```

`**addAbilityChangeListener **`Adds a listener to be invoked when ability of the media controller server is changed.

```javascript
long addAbilityChangeListener(MediaControllerAbilityChangeCallback listener);
```

Since: 5.5

Remark: Implicitly the media controller client will receive information about ability changes of every active media controller server.
To receive information only from selected servers, calling function subscribe() is required.

Parameters:

- **listener :
 Function to call on mediacontroller server's ability change. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Client-side code */
var mcClient = tizen.mediacontroller.getClient();

var listener =
{
  onplaybackabilitychanged: function(server, ability)
  {
    console.log("Playback ability changed, server name: " + server.name + ", abilities: ");
    console.log(JSON.stringify(ability));
  },
  ondisplaymodeabilitychanged: function(server, ability)
  {
    console.log("Display mode ability changed, server name: " + server.name + ", abilities: ");
    console.log(JSON.stringify(ability));
  },
  ondisplayrotationabilitychanged: function(server, ability)
  {
    console.log("Display rotation ability changed, server name: " + server.name + ", abilities: ");
    console.log(JSON.stringify(ability));
  },
  onsimpleabilitychanged: function(server, type, ability)
  {
    console.log(type + " ability changed, server name: " + server.name + ", ability: " + ability);
  }
};

var watchId = mcClient.addAbilityChangeListener(listener);

/* Server-side code */
var mcServer = tizen.mediacontroller.createServer();
mcServer.abilities.playback.play = "YES";
mcServer.abilities.playback.saveAbilities();
mcServer.abilities.shuffle = "NO";
mcServer.abilities.repeat = "YES";
mcServer.abilities.displayMode.fullScreen = "YES";
mcServer.abilities.displayRotation.rotation180 = "YES";
```

Output example:

```
Playback ability changed, server name: GC8qUW5iQj.MediaControllerServer, abilities:
{"play":"YES","pause":"UNDECIDED","stop":"UNDECIDED","next":"UNDECIDED","prev":"UNDECIDED","forward":"UNDECIDED","rewind":"UNDECIDED","togglePlayPause":"UNDECIDED"}
SHUFFLE ability changed, server name: GC8qUW5iQj.MediaControllerServer, ability: "NO"
REPEAT ability changed, server name: GC8qUW5iQj.MediaControllerServer, ability: "YES"
Display mode ability changed, server name: GC8qUW5iQj.MediaControllerServer, abilities: "
{"letterBox":"NO","originSize":"NO","fullScreen":"YES","croppedFull":"NO"}
Display rotation ability changed, server name: GC8qUW5iQj.MediaControllerServer, abilities: "
{"rotationNone":"NO","rotation90":"NO","rotation180":"YES","rotation270":"NO"}
```

`**removeAbilityChangeListener **`Removes selected MediaControllerAbilityChangeListener .

```javascript
void removeAbilityChangeListener(long watchId);
```

Since: 5.5

Remark: All subscriptions added by function subscribe() will be lost after removing last MediaControllerAbilityChangeListener .

Parameters:

- **watchId :
 Subscription identifier returned by addAbilityChangeListener() . **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
/* Client-side code */
var mcClient = tizen.mediacontroller.getClient();

var listener =
{
  onplaybackabilitychanged: function(server, ability)
  {
    console.log("Playback ability changed, server name: " + mcServer.name + ", abilities: ");
    console.log(JSON.stringify(ability));
  }
};

var watchId = mcClient.addAbilityChangeListener(listener);

/* Server-side code */
var mcServer = tizen.mediacontroller.createServer();
mcServer.abilities.playback.play = "YES";
mcServer.abilities.playback.saveAbilities();

/* Client-side code */
mcClient.removeAbilityChangeListener(watchId);

/* Server-side code */
mcServer.abilities.playback.forward = "YES";
mcServer.abilities.playback.saveAbilities();
```

Output example:

```
Playback ability changed, server name: GC8qUW5iQj.MediaControllerServer, abilities:
{"play":"YES","pause":"UNDECIDED","stop":"UNDECIDED","next":"UNDECIDED","prev":"UNDECIDED","forward":"UNDECIDED","rewind":"UNDECIDED","togglePlayPause":"UNDECIDED"}
```

`**findSubscribedServers **`Retrieves all subscribed media controller servers.

```javascript
void findSubscribedServers(MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 5.5

The ErrorCallback may be triggered for one of the following errors:

- UnknownError: if any error prevents function from successful completion.

Parameters:

- **successCallback :
 The method to invoke when all of subscribed media controller servers have been found. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of retrieving servers list. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();

var listener =
{
  onsimpleabilitychanged: function(server, type, ability)
  {
    console.log(type + " ability changed, server name: " + server.name + ", ability: " + ability);
  }
};

var watchId = mcClient.addAbilityChangeListener(listener);

function errorCB(err)
{
  console.log(err.name + " error: " + err.message);
}

function subscribedSuccessCB(list)
{
  console.log("Subscribed servers:");
  for (var s in list)
  {
    console.log("  server name: " + list[s].name + ", state: " + list[s].state);
  }
}

function findSuccessCB(list)
{
  console.log("Found servers:");
  for (var s in list)
  {
    console.log("  server name: " + list[s].name + ", state: " + list[s].state);
  }
  if (list.length > 0)
  {
    list[0].abilities.subscribe();
    mcClient.findSubscribedServers(subscribedSuccessCB, errorCB);
  }
}

mcClient.findServers(findSuccessCB, errorCB);
```

Output example:

```
Found servers:
  server name: XX8qUW5iFF.MediaControllerServerOne, state: ACTIVE
  server name: 2cpQcelP8a.MediaControllerServerTwo, state: ACTIVE
  server name: To0BJCUxbR.MediaControllerServerThree, state: ACTIVE
Subscribed servers:
  server name: XX8qUW5iFF.MediaControllerServerOne, state: ACTIVE
```

`**setCustomEventListener **`Sets the media controller client's listener for custom events from the server.

```javascript
void setCustomEventListener(MediaControllerReceiveCommandCallback listener);
```

Since: 5.5

If the listener has already been set, calling this method will override it.

Parameters:

- **listener :
 Event handling function. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any of the arguments has invalid types.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* this example assumes that the server and client objects already exist. */
mcClient.setCustomEventListener(function(serverName, eventName, data)
{
  return new tizen.mediacontroller.RequestReply({"reply": "data"}, 123);
});
mcClient.unsetCustomEventListener();
```

`**unsetCustomEventListener **`Removes the server's events listener.

```javascript
void unsetCustomEventListener();
```

Since: 5.5

Calling this function has no effect, if the listener is not set.

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
/* this example assumes that the server and client already exist. */
mcClient.setCustomEventListener(function(serverName, eventName, data)
{
  return new tizen.mediacontroller.RequestReply({"reply": "data"}, 123);
});
mcClient.unsetCustomEventListener();
```

### 2.5. MediaControllerServerInfo

This interface provides media controller server state and playback info.
Provides methods to send commands to server and listen for server status change.

```webidl
  [NoInterfaceObject] interface MediaControllerServerInfo {
    readonly attribute ApplicationId name;
    readonly attribute MediaControllerServerState state;
    readonly attribute MediaControllerServerInfoPlaybackInfo playback raises(WebAPIException);
    readonly attribute MediaControllerPlaylistsInfo playlists;
    readonly attribute DOMString? iconURI raises(WebAPIException);
    readonly attribute MediaControllerAbilitiesInfo abilities;
    readonly attribute MediaControllerSubtitlesInfo subtitles;
    readonly attribute MediaControllerMode360Info mode360;
    readonly attribute MediaControllerDisplayModeInfo displayMode;
    readonly attribute MediaControllerDisplayRotationInfo displayRotation;
    void sendSearchRequest(SearchFilter[] request, MediaControllerSearchRequestReplyCallback replyCallback,
                           optional ErrorCallback? errorCallback) raises(WebAPIException);
    void sendCommand(DOMString command, Bundle? data, MediaControllerSendCommandSuccessCallback successCallback,
                     optional ErrorCallback? errorCallback) raises(WebAPIException);
    long addServerStatusChangeListener(MediaControllerServerStatusChangeCallback listener) raises(WebAPIException);
    void removeServerStatusChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.0

#### Attributes

- readonly ApplicationId name The appId of the media controller server.

Since: 5.0

- readonly MediaControllerServerState state State of the media controller server.

Since: 5.0

- readonly MediaControllerServerInfoPlaybackInfo playback Playback info of current server info.

Since: 6.0

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerPlaylistsInfo playlists An attribute providing access to the playlist information from the server.

Since: 6.0

- readonly DOMString iconURI [nullable] Server icon URI.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitiesInfo abilities Abilities of the media controller server.

Since: 5.5

- readonly MediaControllerSubtitlesInfo subtitles Object representing features related to subtitles control of a media controller server.

Since: 5.5

- readonly MediaControllerMode360Info mode360 Object representing features related to spherical (360°) mode control of a media controller server.

Since: 5.5

- readonly MediaControllerDisplayModeInfo displayMode Object representing features related to display mode control of a media controller server.

Since: 5.5

- readonly MediaControllerDisplayRotationInfo displayRotation Object representing features related to display rotation control of a media controller server.

Since: 5.5

#### Methods

`**sendSearchRequest **`Sends a search request to the media controller server.

```javascript
void sendSearchRequest(SearchFilter[] request, MediaControllerSearchRequestReplyCallback replyCallback,
                       optional ErrorCallback? errorCallback);
```

Since: 5.5

The *errorCallback *may be triggered for one of the following errors:

- *UnknownError *: if any error prevents function from successful completion.

Remark: Search request handler should be specified on the server using setSearchRequestListener() method.

Parameters:

- **request :
 A collection of between 1 and 20 SearchFilter objects. **
- **replyCallback :
 Function to be invoked when server reply is received. **
- **errorCallback [optional] [nullable] :
 Function to be invoked if server reports failure. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if request has invalid number of filters.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Server-side code */
var mcServer = tizen.mediacontroller.createServer();
function searchRequestListener(clientName, request)
{
  console.log("search command received");
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"key": "value"}), 5);
}
mcServer.setSearchRequestListener(searchRequestListener);
mcServer.updatePlaybackState("PLAY");

/* Client-side code */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var query = [
  new tizen.mediacontroller.SearchFilter("MUSIC", "GENRE", "rock"),
  new tizen.mediacontroller.SearchFilter(
      "MUSIC", "GENRE", "pop", new tizen.Bundle({"releasedAfter": "1993"}))
];

mcServerInfo.sendSearchRequest(query, function(reply)
{
  console.log("reply status: " + reply.code);
  console.log("reply data: " + reply.data);
});
```

Output example:

```
search command received
reply status: 5
reply data: {"key": "value"}
```

`**sendCommand **`Allows to send custom command to media controller server.

```javascript
void sendCommand(DOMString command, Bundle? data, MediaControllerSendCommandSuccessCallback successCallback,
                 optional ErrorCallback? errorCallback);
```

Since: 5.0

Remark: See addCommandListener() method to check how to receive
and respond to custom commands.

Parameters:

- **command :
 Custom command name which is handled on server side. **
- **data [nullable] :
 Additional data for custom command which is send to server. **
- **successCallback :
 The method to invoke when server responded to custom command. **
- **errorCallback [optional] [nullable] :
 The method to invoke on operation failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var exampleCustomCommandData = new tizen.Bundle({myFilter: "rock"});
mcServerInfo.sendCommand("myPlaylistFilter", exampleCustomCommandData,
    function(data, code)
    {
      console.log(
          "Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
    },
    function(e)
    {
      console.log("Error executing command: " + e.message);
    });
```

`**addServerStatusChangeListener **`Adds the listener for a media controller server status change.

```javascript
long addServerStatusChangeListener(MediaControllerServerStatusChangeCallback listener);
```

Since: 5.0

Parameters:

- **listener :
 Status change listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when server status changes. */
watcherId = mcServerInfo.addServerStatusChangeListener(function(status)
{
  console.log(mcServerInfo.name + " server status changed to " + status);
});
```

`**removeServerStatusChangeListener **`Removes the listener, so stop receiving notifications about media controller server status.

```javascript
void removeServerStatusChangeListener(long watchId);
```

Since: 5.0

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Subscription identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when server status changes. */
watcherId = mcServerInfo.addServerStatusChangeListener(function(status)
{
  console.log(mcServerInfo.name + " server status changed to " + status);
});

/* Cancels the watch operation. */
mcServerInfo.removeServerStatusChangeListener(watcherId);
```

### 2.6. MediaControllerServerPlaybackInfo

Server-side object representing current playback info.

```webidl
  [NoInterfaceObject] interface MediaControllerServerPlaybackInfo {
    attribute MediaControllerPlaybackState state raises(WebAPIException);
    attribute unsigned long long position raises(WebAPIException);
    attribute MediaControllerContentAgeRating ageRating raises(WebAPIException);
    attribute MediaControllerContentType contentType raises(WebAPIException);
    attribute boolean shuffleMode raises(WebAPIException);
    attribute MediaControllerRepeatState repeatState raises(WebAPIException);
    readonly attribute MediaControllerMetadata metadata;
    readonly attribute DOMString? index;
    readonly attribute DOMString? playlistName;
    void updatePlaybackItem(DOMString playlistName, DOMString index) raises(WebAPIException);
    long addChangeRequestListener(MediaControllerChangeRequestPlaybackInfoCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
```

Since: 6.0

#### Attributes

- MediaControllerPlaybackState state Current playback state.

Since: 6.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the set value will not be compatible with MediaControllerPlaybackState enum.

- with error type UnknownError, if any other error occurs.

- unsigned long long position Current playback position.

Since: 6.0

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if the set value is less than 0.

- with error type UnknownError, if any other error occurs.

- MediaControllerContentAgeRating ageRating Current playback age rating.

Since: 6.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the set value will not be compatible with MediaControllerContentAgeRating enum.

- with error type UnknownError, if any other error occurs.

- MediaControllerContentType contentType Current playback content type.

Since: 6.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the set value will not be compatible with MediaControllerContentType enum.

- with error type UnknownError, if any other error occurs.

- boolean shuffleMode Current shuffle mode.

Since: 6.0

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- MediaControllerRepeatState repeatState Current repeat state.

Since: 6.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the set value will not be compatible with MediaControllerRepeatState enum.

- with error type UnknownError, if any other error occurs.

- readonly MediaControllerMetadata metadata Current playback metadata.

Since: 6.0

- readonly DOMString index [nullable] Current item index.

Since: 6.0

- readonly DOMString playlistName [nullable] Current playlist name.

Since: 6.0

#### Methods

`**updatePlaybackItem **`Sets index and playlist name properties of playback info object.

```javascript
void updatePlaybackItem(DOMString playlistName, DOMString index);
```

Since: 6.0

Parameters:

- **playlistName :
 Name of playlist to be set. **
- **index :
 Index of item on playlist *playlistName *to be set. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();

mcServer.playback.updatePlaybackItem("testPlaylistName", "index1");
console.log("Current playlist: " + mcServer.playback.playlistName);
console.log("Current index: " + mcServer.playback.index);
```

Output example:

```
Current playlist: testPlaylistName
Current index: index1
```

`**addChangeRequestListener **`Adds the listener for change requests of a media controller playback info.

```javascript
long addChangeRequestListener(MediaControllerChangeRequestPlaybackInfoCallback listener);
```

Since: 6.0

Parameters:

- **listener :
 Change request listener to add. **

Return value:

long: The identifier used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var playbackRequestListener =
{
  onplaybackactionrequest: function(action, clientName)
  {
    console.log("Playback action requested to: " + action + " by " + clientName);
  },
  onplaybackpositionrequest: function(position, clientName)
  {
    console.log("Playback position requested to: " + position + " by " + clientName);
  },
  onshufflemoderequest: function(mode, clientName)
  {
    console.log("Shuffle mode requested to: " + mode + " by " + clientName);
  },
  onrepeatstaterequest: function(state, clientName)
  {
    console.log("Repeat state requested to: " + state + " by " + clientName);
  },
  onplaybackitemrequest: function(playlistName, index, state, position, clientName)
  {
    console.log("Playlist: " + playlistName + " index: " + index + " state: " + state +
                " position " + position + " requested by " + clientName);
  }
};

/* Registers to receive playback info change requests from client. */
watcherId = mcServer.playback.addChangeRequestListener(playbackRequestListener);
```

`**removeChangeRequestListener **`Removes the listener and stops receiving change requests of media controller playback info.

```javascript
void removeChangeRequestListener(long watchId);
```

Since: 6.0

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var playbackRequestListener =
{
  onplaybackactionrequest: function(action, clientName) {},
  onplaybackpositionrequest: function(position, clientName) {},
  onshufflemoderequest: function(mode, clientName) {},
  onrepeatstaterequest: function(state, clientName) {},
  onplaybackitemrequest: function(playlistName, index, state, position, clientName) {}
};

/* Registers to receive playback info change requests from client. */
watcherId = mcServer.playback.addChangeRequestListener(playbackRequestListener);

/* Cancels the watch operation. */
mcServer.playback.removeChangeRequestListener(watcherId);
```

### 2.7. MediaControllerServerInfoPlaybackInfo

Client-side object representing current playback info.

```webidl
  [NoInterfaceObject] interface MediaControllerServerInfoPlaybackInfo {
    readonly attribute MediaControllerPlaybackState state;
    readonly attribute unsigned long long position;
    readonly attribute MediaControllerContentAgeRating ageRating;
    readonly attribute MediaControllerContentType contentType;
    readonly attribute boolean shuffleMode;
    readonly attribute MediaControllerRepeatState repeatState;
    readonly attribute MediaControllerMetadata metadata;
    readonly attribute DOMString? index;
    readonly attribute DOMString? playlistName;
    void sendPlaybackAction(MediaControllerPlaybackAction action, optional MediaControllerSendCommandSuccessCallback? replyCallback)
                            raises(WebAPIException);
    void sendPlaybackPosition(unsigned long long position, optional MediaControllerSendCommandSuccessCallback? replyCallback)
                              raises(WebAPIException);
    void sendShuffleMode(boolean mode, optional MediaControllerSendCommandSuccessCallback? replyCallback) raises(WebAPIException);
    void sendRepeatState(MediaControllerRepeatState state, optional MediaControllerSendCommandSuccessCallback? replyCallback)
                         raises(WebAPIException);
    long addPlaybackInfoChangeListener(MediaControllerPlaybackInfoChangeCallback listener) raises(WebAPIException);
    void removePlaybackInfoChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 6.0

#### Attributes

- readonly MediaControllerPlaybackState state Current playback state.

Since: 6.0

- readonly unsigned long long position Current playback position.

Since: 6.0

- readonly MediaControllerContentAgeRating ageRating Current playback age rating.

Since: 6.0

- readonly MediaControllerContentType contentType Current playback content type.

Since: 6.0

- readonly boolean shuffleMode Current shuffle mode.

Since: 6.0

- readonly MediaControllerRepeatState repeatState Current repeat state.

Since: 6.0

- readonly MediaControllerMetadata metadata Current playback metadata.

Since: 6.0

- readonly DOMString index [nullable] Current item index. Value set to null means no playlist set in playback

Since: 6.0

- readonly DOMString playlistName [nullable] Current playlist name. Value set to null means no playlist set in playback

Since: 6.0

#### Methods

`**sendPlaybackAction **`Sends request to change the playback state of a media controller server.

```javascript
void sendPlaybackAction(MediaControllerPlaybackAction action, optional MediaControllerSendCommandSuccessCallback? replyCallback);
```

Since: 6.0

Parameters:

- **action :
 Playback action. **
- **replyCallback [optional] [nullable] :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

mcServerInfo.playback.sendPlaybackAction("STOP", function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**sendPlaybackPosition **`Sends request to change the playback position of a media controller server.

```javascript
void sendPlaybackPosition(unsigned long long position, optional MediaControllerSendCommandSuccessCallback? replyCallback);
```

Since: 6.0

Parameters:

- **position :
 Playback position. **
- **replyCallback [optional] [nullable] :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

mcServerInfo.playback.sendPlaybackPosition(164, function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**sendShuffleMode **`Sends request to change the shuffle mode of a media controller server.

```javascript
void sendShuffleMode(boolean mode, optional MediaControllerSendCommandSuccessCallback? replyCallback);
```

Since: 6.0

Parameters:

- **mode :
 Shuffle mode. **
- **replyCallback [optional] [nullable] :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

mcServerInfo.playback.sendShuffleMode(true, function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**sendRepeatState **`Sends request to change the repeat state of a media controller server.

```javascript
void sendRepeatState(MediaControllerRepeatState state, optional MediaControllerSendCommandSuccessCallback? replyCallback);
```

Since: 6.0

Parameters:

- **state :
 Repeat state to be set. **
- **replyCallback [optional] [nullable] :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

mcServerInfo.playback.sendRepeatState("REPEAT_ALL", function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**addPlaybackInfoChangeListener **`Adds the listener for a media playback info changes.

```javascript
long addPlaybackInfoChangeListener(MediaControllerPlaybackInfoChangeCallback listener);
```

Since: 6.0

Parameters:

- **listener :
 Status change listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* receives playback state changes. */
var playbackListener =
{
  onplaybackchanged: function(state, position)
  {
    console.log("Current playback state: " + state);
    console.log("Current playback position: " + position);
  },
  onshufflemodechanged: function(mode)
  {
    console.log("Shuffle mode changed to: " + mode);
  },
  onrepeatstatechanged: function(state)
  {
    console.log("Repeat state changed to: " + state);
  },
  onmetadatachanged: function(metadata)
  {
    console.log("Playback metadata changed: " + JSON.stringify(metadata));
  }
};

/* Registers to be notified when playback state changes. */
watcherId = mcServerInfo.playback.addPlaybackInfoChangeListener(playbackListener);
```

`**removePlaybackInfoChangeListener **`Removes the listener, so stop receiving notifications about media playback info changes.

```javascript
void removePlaybackInfoChangeListener(long watchId);
```

Since: 6.0

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Subscription identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* receives playback state changes. */
var playbackListener =
{
  onplaybackchanged: function(state, position) {},
  onshufflemodechanged: function(mode) {},
  onrepeatstatechanged: function(state) {},
  onmetadatachanged: function(metadata) {}
};

/* Registers to be notified when playback state changes. */
watcherId = mcServerInfo.playback.addPlaybackInfoChangeListener(playbackListener);

/* Cancels the watch operation. */
mcServerInfo.playback.removePlaybackInfoChangeListener(watcherId);
```

### 2.8. MediaControllerPlaylists

Server-side object representing methods for playlists of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerPlaylists {
    MediaControllerPlaylist createPlaylist(DOMString name) raises(WebAPIException);
    void savePlaylist(MediaControllerPlaylist playlist, optional SuccessCallback? successCallback,
                      optional ErrorCallback? errorCallback) raises(WebAPIException);
    void deletePlaylist(DOMString playlistName, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void getAllPlaylists(MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    MediaControllerPlaylist getPlaylist(DOMString playlistName) raises(WebAPIException);
  };
```

Since: 6.0

#### Methods

`**createPlaylist **`Creates *MediaControllerPlaylist *object.

```javascript
MediaControllerPlaylist createPlaylist(DOMString name);
```

Since: 6.0

Remark: Please note that there is a need to use savePlaylist() , otherwise playlist creation will have no effect on a device. All playlists will be deleted after application is closed.

Parameters:

- **name :
 Name of the new playlist. **

Return value:

MediaControllerPlaylist: New empty *MediaControllerPlaylist *object with given name.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if playlist with given name already exists.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var playlist = mcServer.playlists.createPlaylist("testPlaylistName");
```

`**savePlaylist **`Saves the playlist in a local database.

```javascript
void savePlaylist(MediaControllerPlaylist playlist, optional SuccessCallback? successCallback,
                  optional ErrorCallback? errorCallback);
```

Since: 6.0

The *errorCallback *may be triggered for one of the following errors:

- *InvalidValuesError *: if playlist with given name does not exist.
- *UnknownError *: if any other error prevents the function from successful completion.

Remark: All playlists will be deleted after the application is closed.

Parameters:

- **playlist : *MediaControllerPlaylist *object to save. **
- **successCallback [optional] [nullable] :
 Function to be called when *savePlaylist *is finished without error. **
- **errorCallback [optional] [nullable] :
 Function to be called when *savePlaylist *fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var playlist = mcServer.playlists.createPlaylist("testPlaylistName");
function successCallback()
{
  console.log("savePlaylist successful.");
}
function errorCallback(error)
{
  console.log("savePlaylist failed with error: " + error);
}
mcServer.playlists.savePlaylist(playlist, successCallback, errorCallback);
```

Output example:

```
savePlaylist successful.
```

`**deletePlaylist **`Deletes the playlist from a local database.

```javascript
void deletePlaylist(DOMString playlistName, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

The *errorCallback *may be triggered for one of the following errors:

- *InvalidValuesError *: if playlist with given name does not exist.
- *UnknownError *: if any other error prevents the function from successful completion.

Parameters:

- **playlistName :
 Name of the playlist to remove. **
- **successCallback [optional] [nullable] :
 Function to be called when *deletePlaylist *is finished without error. **
- **errorCallback [optional] [nullable] :
 Function to be called when *deletePlaylist *fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var playlist = mcServer.playlists.createPlaylist("testPlaylistName");
function deleteSuccess()
{
  console.log("deletePlaylist successful.");
}
function deleteFailure(error)
{
  console.log("deletePlaylist failed with error: " + error);
}
function saveSuccess()
{
  mcServer.playlists.deletePlaylist(playlist.name, deleteSuccess, deleteFailure);
}
mcServer.playlists.savePlaylist(playlist, saveSuccess);
```

Output example:

```
deletePlaylist successful.
```

`**getAllPlaylists **`Retrieves all playlists from a local database.

```javascript
void getAllPlaylists(MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

The *errorCallback *may be triggered for one of the following errors:

- *UnknownError *: if any error prevents function from successful completion.

Parameters:

- **successCallback :
 Function to be called on *getAllPlaylists *success. **
- **errorCallback [optional] [nullable] :
 Function to be called when *getAllPlaylists *fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any parameter has invalid type.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var playlist = mcServer.playlists.createPlaylist("testPlaylist");

function saveSuccess()
{
  console.log("savePlaylist successful");
  function successCallback(playlists)
  {
    playlists.forEach(function(playlist)
    {
      console.log("Playlist name: " + playlist.name);
    });
  }
  function errorCallback(error)
  {
    console.log("getAllPlaylists failed with error: " + error);
  }
  mcServer.playlists.getAllPlaylists(successCallback, errorCallback);
}
function saveError(error)
{
  console.log("savePlaylist failed with error: " + error);
}

mcServer.playlists.savePlaylist(playlist, saveSuccess, saveError);
```

Output example:

```
savePlaylist successful
Playlist name: testPlaylistName
```

`**getPlaylist **`Returns the playlist with the given name.

```javascript
MediaControllerPlaylist getPlaylist(DOMString playlistName);
```

Since: 6.0

Parameters:

- **playlistName :
 The name of playlist to get. **

Exceptions:

- WebAPIException
- with error type NotFoundError, if the playlist with the given name does not exist.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* assuming that the playlist was previously created */
var mcServer = tizen.mediacontroller.createServer();
var playlist = null;
try
{
  playlist = mcServer.playlists.getPlaylist("testPlaylist");
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

### 2.9. MediaControllerPlaylistsInfo

Client-side object representing methods for playlists of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerPlaylistsInfo {
    void getAllPlaylists(MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    void sendPlaybackItem(DOMString playlistName, DOMString index, MediaControllerPlaybackAction action, unsigned long long position,
                          optional MediaControllerSendCommandSuccessCallback? replyCallback) raises(WebAPIException);
    long addPlaylistUpdatedListener(MediaControllerPlaylistUpdatedCallback listener) raises(WebAPIException);
    void removePlaylistUpdatedListener(long listenerId) raises(WebAPIException);
    MediaControllerPlaylist getPlaylist(DOMString playlistName) raises(WebAPIException);
  };
```

Since: 6.0

#### Methods

`**getAllPlaylists **`Retrieves all playlists saved in local database.

```javascript
void getAllPlaylists(MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

The *errorCallback *may be triggered for one of the following errors:

- *UnknownError *: if any error prevents function from successful completion.

Parameters:

- **successCallback :
 Function to be called upon success. **
- **errorCallback [optional] [nullable] :
 Function to be called upon failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any parameter has invalid type.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();
var playlist = mcServer.playlists.createPlaylist("testPlaylist");

function saveSuccess()
{
  console.log("savePlaylist successful");
  function successCallback(playlists)
  {
    playlists.forEach(function(playlist)
    {
      console.log("Playlist name: " + playlist.name);
    });
  }
  function errorCallback(error)
  {
    console.log("getAllPlaylists failed with error: " + error);
  }
  mcServerInfo.playlists.getAllPlaylists(successCallback, errorCallback);
}

function saveError(error)
{
  console.log("savePlaylist failed with error: " + error);
}

mcServer.playlists.savePlaylist(playlist, saveSuccess, saveError);
```

Output example:

```
savePlaylist successful
Playlist name: testPlaylist
```

`**sendPlaybackItem **`Asks the server to set a new playback item.

```javascript
void sendPlaybackItem(DOMString playlistName, DOMString index, MediaControllerPlaybackAction action, unsigned long long position,
                      optional MediaControllerSendCommandSuccessCallback? replyCallback);
```

Since: 6.0

Remark: *PlaybackInfoChangeListener *should be invoked, if registered.

Parameters:

- **playlistName :
 Name of playlist to be set. **
- **index :
 Index of item on playlist to be set. **
- **action :
 Playback action. **
- **position :
 Playback position. **
- **replyCallback [optional] [nullable] :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var serverInfo = mcClient.getLatestServerInfo();
serverInfo.playlists.sendPlaybackItem("testPlaylist", "1", "PLAY", 0);
```

`**addPlaylistUpdatedListener **`Adds listener to be invoked when playlist is updated by server.

```javascript
long addPlaylistUpdatedListener(MediaControllerPlaylistUpdatedCallback listener);
```

Since: 6.0

Parameters:

- **listener :
 Listener for adding, updating or deleting of any playlist. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var listener =
{
  onplaylistupdated: function(serverName, playlist)
  {
    console.log("updated playlist " + playlist);
  },
  onplaylistdeleted: function(serverName, playlistName)
  {
    console.log("deleted playlist " + playlistName);
  }
};
var listenerId = mcServerInfo.playlists.addPlaylistUpdatedListener(listener);
```

`**removePlaylistUpdatedListener **`Stops listening for playlist updates.

```javascript
void removePlaylistUpdatedListener(long listenerId);
```

Since: 6.0

Remark: This function has no effect, if there is no listener for given id.

Parameters:

- **listenerId :
 Listener ID returned by *addPlaylistUpdatedListener *. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var listener =
{
  onplaylistupdated: function(serverName, playlist) {},
  onplaylistdeleted: function(serverName, playlistName) {}
};
var listenerId = mcServerInfo.playlists.addPlaylistUpdatedListener(listener);
mcServerInfo.playlists.removePlaylistUpdatedListener(listenerId);
```

`**getPlaylist **`Returns the playlist with the given name.

```javascript
MediaControllerPlaylist getPlaylist(DOMString playlistName);
```

Since: 6.0

Parameters:

- **playlistName :
 The name of the playlist to get. **

Exceptions:

- WebAPIException
- with error type NotFoundError, if the playlist with the given name does not exist.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* assuming that the playlist was previously created */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();
var playlist = null;
try
{
  playlist = mcServerInfo.playlists.getPlaylist("testPlaylist");
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

### 2.10. MediaControllerAbilities

Server-side object representing abilities of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerAbilities {
    readonly attribute MediaControllerPlaybackAbilities playback;
    readonly attribute MediaControllerDisplayModeAbilities displayMode;
    readonly attribute MediaControllerDisplayRotationAbilities displayRotation;
    attribute MediaControllerAbilitySupport playbackPosition raises(WebAPIException);
    attribute MediaControllerAbilitySupport shuffle raises(WebAPIException);
    attribute MediaControllerAbilitySupport repeat raises(WebAPIException);
    attribute MediaControllerAbilitySupport playlist raises(WebAPIException);
    attribute MediaControllerAbilitySupport clientCustom raises(WebAPIException);
    attribute MediaControllerAbilitySupport search raises(WebAPIException);
    attribute MediaControllerAbilitySupport subtitles raises(WebAPIException);
    attribute MediaControllerAbilitySupport mode360 raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerPlaybackAbilities playback Represents abilities of server's playback actions.

Since: 5.5

- readonly MediaControllerDisplayModeAbilities displayMode Represents abilities of server's display modes.

Since: 5.5

- readonly MediaControllerDisplayRotationAbilities displayRotation Represents display orientations supported by the media controller server.

Since: 5.5

- MediaControllerAbilitySupport playbackPosition Represents server's ability to change playback position.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport shuffle Represents server's ability to change shuffle mode.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport repeat Represents server's ability to change repeat state.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport playlist Represents server's ability to add/change/remove playlists.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport clientCustom Represents server's ability to receive custom commands from the media controller client.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport search Represents server's ability to receive search requests from the media controller client.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport subtitles Represents server's ability to receive requests for subtitles mode change from the media controller client.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport mode360 Represents server's ability to receive requests for spherical (360°) mode change from the media controller client.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

### 2.11. MediaControllerPlaybackAbilities

Server-side object representing playback abilities of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerPlaybackAbilities {
    attribute MediaControllerAbilitySupport play raises(WebAPIException);
    attribute MediaControllerAbilitySupport pause raises(WebAPIException);
    attribute MediaControllerAbilitySupport stop raises(WebAPIException);
    attribute MediaControllerAbilitySupport next raises(WebAPIException);
    attribute MediaControllerAbilitySupport prev raises(WebAPIException);
    attribute MediaControllerAbilitySupport forward raises(WebAPIException);
    attribute MediaControllerAbilitySupport rewind raises(WebAPIException);
    attribute MediaControllerAbilitySupport togglePlayPause raises(WebAPIException);
    void saveAbilities() raises(WebAPIException);
  };
```

Since: 5.5

Remark: Calling saveAbilities() is required to
update playback abilities on the media controller server.

#### Attributes

- MediaControllerAbilitySupport play Represents server's ability to perform PLAY action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport pause Represents server's ability to perform PAUSE action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport stop Represents server's ability to perform STOP action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport next Represents server's ability to perform NEXT action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport prev Represents server's ability to perform PREV action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport forward Represents server's ability to perform FORWARD action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport rewind Represents server's ability to perform REWIND action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport togglePlayPause Represents server's ability to perform TOGGLE_PLAY_PAUSE action.

Default value is UNDECIDED.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

#### Methods

`**saveAbilities **`Saves the current state of playback abilities to the database.

```javascript
void saveAbilities();
```

Since: 5.5

Remark: Using this function is required to save changes of playback abilities into database, otherwise changes
will have no effect on the device and clients will not be notified about an update.

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
/* Server-side code */
var mcServer = tizen.mediacontroller.createServer();
mcServer.updatePlaybackState("PLAY");

mcServer.abilities.playback.next = "YES";
mcServer.abilities.playback.prev = "YES";
mcServer.abilities.playback.rewind = "NO";
mcServer.abilities.playback.forward = "NO";

/* Client-side code */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();
console.log("Before save:");
console.log("ability NEXT: " + mcServerInfo.abilities.playback.next);
console.log("ability PREV: " + mcServerInfo.abilities.playback.prev);
console.log("ability REWIND: " + mcServerInfo.abilities.playback.rewind);
console.log("ability FORWARD: " + mcServerInfo.abilities.playback.forward);

/* Server-side code */
mcServer.abilities.playback.saveAbilities();

/* Client-side code */
mcServerInfo = mcClient.getLatestServerInfo();
console.log("After save:");
console.log("ability NEXT: " + mcServerInfo.abilities.playback.next);
console.log("ability PREV: " + mcServerInfo.abilities.playback.prev);
console.log("ability REWIND: " + mcServerInfo.abilities.playback.rewind);
console.log("ability FORWARD: " + mcServerInfo.abilities.playback.forward);
```

Output example:

```
Before save:
ability NEXT: UNDECIDED
ability PREV: UNDECIDED
ability REWIND: UNDECIDED
ability FORWARD: UNDECIDED
After save:
ability NEXT: YES
ability PREV: YES
ability REWIND: NO
ability FORWARD: NO
```

### 2.12. MediaControllerDisplayModeAbilities

Server-side object representing display mode abilities of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayModeAbilities {
    attribute MediaControllerAbilitySupport letterBox raises(WebAPIException);
    attribute MediaControllerAbilitySupport originSize raises(WebAPIException);
    attribute MediaControllerAbilitySupport fullScreen raises(WebAPIException);
    attribute MediaControllerAbilitySupport croppedFull raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- MediaControllerAbilitySupport letterBox Represents server's ability to set letterBox mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport originSize Represents server's ability to set originSize mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport fullScreen Represents server's ability to set fullScreen mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport croppedFull Represents server's ability to set croppedFull mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

### 2.13. MediaControllerDisplayRotationAbilities

The server-side object representing display rotation abilities
of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayRotationAbilities {
    attribute MediaControllerAbilitySupport rotationNone raises(WebAPIException);
    attribute MediaControllerAbilitySupport rotation90 raises(WebAPIException);
    attribute MediaControllerAbilitySupport rotation180 raises(WebAPIException);
    attribute MediaControllerAbilitySupport rotation270 raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- MediaControllerAbilitySupport rotationNone Represents the server's ability to set 0° display orientation.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport rotation90 Represents the server's ability to set 90° display orientation.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport rotation180 Represents the server's ability to set 180° display orientation.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

- MediaControllerAbilitySupport rotation270 Represents the server's ability to set 270° display orientation.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if set value will not be compatible with MediaControllerAbilitySupport enum.

- with error type InvalidValuesError, if set value will be "UNDECIDED" .

- with error type UnknownError, if any other error occurs.

### 2.14. MediaControllerAbilitiesInfo

Client-side object representing abilities of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerAbilitiesInfo {
    readonly attribute MediaControllerPlaybackAbilitiesInfo playback;
    readonly attribute MediaControllerDisplayModeAbilitiesInfo displayMode;
    readonly attribute MediaControllerDisplayRotationAbilitiesInfo displayRotation;
    readonly attribute MediaControllerAbilitySupport playbackPosition raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport shuffle raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport repeat raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport playlist raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport clientCustom raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport search raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport subtitles raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport mode360 raises(WebAPIException);
    void subscribe() raises(WebAPIException);
    void unsubscribe() raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerPlaybackAbilitiesInfo playback Represents abilities of server's playback actions.

Since: 5.5

- readonly MediaControllerDisplayModeAbilitiesInfo displayMode Represents abilities of server's display modes.

Since: 5.5

- readonly MediaControllerDisplayRotationAbilitiesInfo displayRotation Represents server abilities of setting display orientations.

Since: 5.5

- readonly MediaControllerAbilitySupport playbackPosition Represents server's ability to change playback position.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport shuffle Represents server's ability to change shuffle mode.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport repeat Represents server's ability to change repeat state.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport playlist Represents server's ability to add/change/remove playlists.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport clientCustom Represents server's ability to receive custom commands from media controller client.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport search Represents server's ability to receive search requests from media controller client.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport subtitles Represents server's ability to receive requests for subtitles mode change from media controller client.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport mode360 Represents server's ability to receive requests for spherical (360°) mode change from media controller client.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**subscribe **`Adds a subscription for monitoring status of all abilities of server represented by this object.

```javascript
void subscribe();
```

Since: 5.5

Remark: Function addAbilityChangeListener() must be called before current method.
For code example see unsubscribe() .

Exceptions:

- WebAPIException
- with error type InvalidStateError, if addAbilityChangeListener() is not set.

- with error type UnknownError, if any other error occurs.

`**unsubscribe **`Removes a subscription for monitoring status of all abilities of server represented by this object.

```javascript
void unsubscribe();
```

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
/* Code example uses two applications: */
/* XX8qUW5iDD.FirstMCServer - both server and client app */
/* GC8qUW5iQf.SecondMCServer - only server app */

/* APP XX8qUW5iDD.FirstMCServer */
var mcServer = tizen.mediacontroller.createServer();
mcServer.updatePlaybackState("PLAY");
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var listener =
{
  onsimpleabilitychanged: function(server, type, ability)
  {
    console.log(type + " ability changed, server name: " + server.name + ", ability: " + ability);
  }
};

var watchId = mcClient.addAbilityChangeListener(listener);
console.log("#### All events would be handled by listener ####");
mcServer.abilities.shuffle = "YES";  /* triggers listener */

/* APP GC8qUW5iQf.SecondMCServer */
var server2 = tizen.mediacontroller.createServer();
server2.abilities.repeat = "NO";  /* triggers listener */

/* APP XX8qUW5iDD.FirstMCServer */
console.log("#### Subscribe only changes from XX8qUW5iDD.FirstMCServer ####");
mcServerInfo.abilities.subscribe();
mcServer.abilities.shuffle = "NO";  /* triggers listener */

/* APP GC8qUW5iQf.SecondMCServer */
server2.abilities.repeat = "YES";  /* does NOT trigger listener */

/* APP XX8qUW5iDD.FirstMCServer */
console.log("#### Handle all events again ####");
mcServerInfo.abilities.unsubscribe();
mcServer.abilities.shuffle = "YES";  /* triggers listener */

/* APP GC8qUW5iQf.SecondMCServer */
server2.abilities.repeat = "NO";  /* triggers listener */
```

Output example:

```
#### All events would be handled by listener ####
SHUFFLE ability changed, server name: XX8qUW5iDD.FirstMCServer, ability: "YES"
REPEAT ability changed, server name: GC8qUW5iQf.SecondMCServer, ability: "NO"
#### Subscribe only changes from XX8qUW5iDD.FirstMCServer ####
SHUFFLE ability changed, server name: XX8qUW5iDD.FirstMCServer, ability: "NO"
#### Handle all events again ####
SHUFFLE ability changed, server name: XX8qUW5iDD.FirstMCServer, ability: "YES"
REPEAT ability changed, server name: GC8qUW5iQf.SecondMCServer, ability: "NO"
```

### 2.15. MediaControllerPlaybackAbilitiesInfo

Client-side object representing playback abilities of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerPlaybackAbilitiesInfo {
    readonly attribute MediaControllerAbilitySupport play raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport pause raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport stop raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport next raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport prev raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport forward raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rewind raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport togglePlayPause raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerAbilitySupport play Represents server's ability to perform PLAY action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport pause Represents server's ability to perform PAUSE action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport stop Represents server's ability to perform STOP action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport next Represents server's ability to perform NEXT action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport prev Represents server's ability to perform PREV action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport forward Represents server's ability to perform FORWARD action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport rewind Represents server's ability to perform REWIND action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport togglePlayPause Represents server's ability to perform TOGGLE_PLAY_PAUSE action.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

### 2.16. MediaControllerDisplayModeAbilitiesInfo

Client-side object representing display mode abilities of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayModeAbilitiesInfo {
    readonly attribute MediaControllerAbilitySupport letterBox raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport originSize raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport fullScreen raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport croppedFull raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerAbilitySupport letterBox Represents server's ability to set letterBox mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any other error occurs.

- readonly MediaControllerAbilitySupport originSize Represents server's ability to set originSize mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any other error occurs.

- readonly MediaControllerAbilitySupport fullScreen Represents server's ability to set fullScreen mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any other error occurs.

- readonly MediaControllerAbilitySupport croppedFull Represents server's ability to set croppedFull mode.

Default value is NO.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any other error occurs.

### 2.17. MediaControllerDisplayRotationAbilitiesInfo

The client-side object representing display rotation abilities
of the media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayRotationAbilitiesInfo {
    readonly attribute MediaControllerAbilitySupport rotationNone raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rotation90 raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rotation180 raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rotation270 raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerAbilitySupport rotationNone Represents the server's ability to set 0° display orientation.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport rotation90 Represents the server's ability to set 90° display orientation.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport rotation180 Represents the server's ability to set 180° display orientation.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

- readonly MediaControllerAbilitySupport rotation270 Represents the server's ability to set 270° display orientation.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

### 2.18. MediaControllerSubtitles

Server-side object representing subtitles mode of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerSubtitles {
    attribute boolean enabled raises(WebAPIException);
    long addChangeRequestListener(MediaControllerEnabledChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- boolean enabled State of subtitles mode on the server. Default value for a newly created server is false .

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**addChangeRequestListener **`Adds the listener for change requests of a media controller subtitles mode.

```javascript
long addChangeRequestListener(MediaControllerEnabledChangeRequestCallback listener);
```

Since: 5.5

Remark: Remember to set corresponding server's MediaControllerAbilities.subtitles ability
to "YES" to let clients send change requests to the server.

Parameters:

- **listener :
 Change request listener to add. **

Return value:

long: The identifier used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, enabled)
{
  console.log("Subtitles mode change requested to: " + enabled + " by " + clientName);
  var result = false;
  /* do some action here and return according to the result */
  if (!result)
  {
    return new tizen.mediacontroller.RequestReply(
        new tizen.Bundle({"message": "Error - Not allowed"}), 13);
  }
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to subtitles mode change requests from client. */
watcherId = mcServer.subtitles.addChangeRequestListener(changeListener);
```

`**removeChangeRequestListener **`Removes the listener and stops receiving change requests of media controller subtitles mode.

```javascript
void removeChangeRequestListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, enabled)
{
  console.log("Subtitles mode change requested to: " + enabled + " by " + clientName);
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to receive subtitles mode change requests from clients. */
watcherId = mcServer.subtitles.addChangeRequestListener(changeListener);

/* Cancels the watch operation. */
mcServer.subtitles.removeChangeRequestListener(watcherId);
```

### 2.19. MediaControllerSubtitlesInfo

Client-side object representing subtitles mode of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerSubtitlesInfo {
    readonly attribute boolean enabled raises(WebAPIException);
    void sendRequest(boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback) raises(WebAPIException);
    long addModeChangeListener(MediaControllerEnabledChangeCallback listener) raises(WebAPIException);
    void removeModeChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly boolean enabled State of subtitles mode on the server represented by this object.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**sendRequest **`Allows to send change requests for subtitles mode to media controller server.

```javascript
void sendRequest(boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback);
```

Since: 5.5

Remark: See addChangeRequestListener() method to check how to receive
and respond to commands.

Parameters:

- **enabled :
 State which is requested by a media controller client. **
- **replyCallback :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if related ability is not supported by the media controller server.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var enabled = true;
mcServerInfo.subtitles.sendRequest(enabled, function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**addModeChangeListener **`Adds the listener for changes of a media controller subtitles mode of a media controller server.

```javascript
long addModeChangeListener(MediaControllerEnabledChangeCallback listener);
```

Since: 5.5

Parameters:

- **listener :
 Subtitles mode change listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when subtitles mode changes. */
watcherId = mcServerInfo.subtitles.addModeChangeListener(function(enabled)
{
  console.log(mcServerInfo.name + " server subtitles mode changed to " + enabled);
});
```

`**removeModeChangeListener **`Removes the listener, so stop receiving notifications about media controller server subtitles mode changes.

```javascript
void removeModeChangeListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when subtitles mode changes. */
watcherId = mcServerInfo.subtitles.addModeChangeListener(function(enabled)
{
  console.log(mcServerInfo.name + " server subtitles mode changed to " + enabled);
});

/* Cancels the watch operation. */
mcServerInfo.subtitles.removeModeChangeListener(watcherId);
```

### 2.20. MediaControllerMode360

Server-side object representing spherical (360°) mode of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerMode360 {
    attribute boolean enabled raises(WebAPIException);
    long addChangeRequestListener(MediaControllerEnabledChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- boolean enabled State of spherical (360°) mode on the server. Default value for a newly created server is false .

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**addChangeRequestListener **`Adds the listener for change requests of a media controller spherical (360°) mode.

```javascript
long addChangeRequestListener(MediaControllerEnabledChangeRequestCallback listener);
```

Since: 5.5

Remark: Remember to set corresponding server's MediaControllerAbilities.mode360 ability
to "YES" to let clients send change requests to the server.

Parameters:

- **listener :
 Change request listener to add. **

Return value:

long: The identifier used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, enabled)
{
  console.log("Spherical mode change requested to: " + enabled + " by " + clientName);
  var result = false;
  /* do some action here and return according to the result */
  if (!result)
  {
    return new tizen.mediacontroller.RequestReply(
        new tizen.Bundle({"message": "Error - Not allowed"}), 13);
  }
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to receive spherical mode change requests from clients. */
watcherId = mcServer.mode360.addChangeRequestListener(changeListener);
```

`**removeChangeRequestListener **`Removes the listener and stops receiving change requests of media controller spherical (360°) mode.

```javascript
void removeChangeRequestListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, enabled)
{
  console.log("Spherical mode change requested to: " + enabled + " by " + clientName);
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to receive spherical mode change requests from clients. */
watcherId = mcServer.mode360.addChangeRequestListener(changeListener);

/* Cancels the watch operation. */
mcServer.mode360.removeChangeRequestListener(watcherId);
```

### 2.21. MediaControllerMode360Info

Client-side object representing spherical (360°) mode of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerMode360Info {
    readonly attribute boolean enabled raises(WebAPIException);
    void sendRequest(boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback) raises(WebAPIException);
    long addModeChangeListener(MediaControllerEnabledChangeCallback listener) raises(WebAPIException);
    void removeModeChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly boolean enabled State of spherical (360°) mode on the server represented by this object.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**sendRequest **`Allows to send change requests for spherical (360°) mode to media controller server.

```javascript
void sendRequest(boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback);
```

Since: 5.5

Remark: See addChangeRequestListener() method to check how to receive
and respond to commands.

Parameters:

- **enabled :
 State which is requested by a media controller client. **
- **replyCallback :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if related ability is not supported by the media controller server.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var enabled = true;
mcServerInfo.mode360.sendRequest(enabled, function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**addModeChangeListener **`Adds the listener for changes of a media controller spherical (360°) mode of a media controller server.

```javascript
long addModeChangeListener(MediaControllerEnabledChangeCallback listener);
```

Since: 5.5

Parameters:

- **listener :
 Spherical (360°) mode change listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when spherical mode changes. */
watcherId = mcServerInfo.mode360.addModeChangeListener(function(enabled)
{
  console.log(mcServerInfo.name + " server spherical mode changed to " + enabled);
});
```

`**removeModeChangeListener **`Removes the listener, so stop receiving notifications about media controller server spherical (360°) mode changes.

```javascript
void removeModeChangeListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when spherical mode changes. */
watcherId = mcServerInfo.mode360.addModeChangeListener(function(enabled)
{
  console.log(mcServerInfo.name + " server spherical mode changed to " + enabled);
});

/* Cancels the watch operation. */
mcServerInfo.mode360.removeModeChangeListener(watcherId);
```

### 2.22. MediaControllerDisplayMode

Server-side object representing display mode of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayMode {
    attribute MediaControllerDisplayModeType type raises(WebAPIException);
    long addChangeRequestListener(MediaControllerDisplayModeChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- MediaControllerDisplayModeType type Type of display mode on the server. Default value for a newly created server is "FULL_SCREEN" .

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if an input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

#### Methods

`**addChangeRequestListener **`Adds the listener for change requests of the media controller display mode.

```javascript
long addChangeRequestListener(MediaControllerDisplayModeChangeRequestCallback listener);
```

Since: 5.5

Remark: Remember to set corresponding server's display mode ability to "YES" to let clients send change requests to the server.

Parameters:

- **listener :
 Change request listener to add. **

Return value:

long: The identifier used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, type)
{
  console.log("Display mode change requested to: " + type + " by " + clientName);
  var result = false;
  /* do some action here and return according to the result */
  if (!result)
  {
    return new tizen.mediacontroller.RequestReply(
        new tizen.Bundle({"message": "Error - Not allowed"}), 13);
  }
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to receive display mode change requests from clients. */
watcherId = mcServer.displayMode.addChangeRequestListener(changeListener);
```

`**removeChangeRequestListener **`Removes the listener and stops receiving change requests of media controller display mode.

```javascript
void removeChangeRequestListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, type)
{
  console.log("Display mode change requested to: " + type + " by " + clientName);
};

/* Registers to receive display mode change requests from clients. */
watcherId = mcServer.displayMode.addChangeRequestListener(changeListener);

/* Cancels the watch operation. */
mcServer.displayMode.removeChangeRequestListener(watcherId);
```

### 2.23. MediaControllerDisplayModeInfo

Client-side object representing display mode of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayModeInfo {
    readonly attribute MediaControllerDisplayModeType type raises(WebAPIException);
    void sendRequest(MediaControllerDisplayModeType type, MediaControllerSendCommandSuccessCallback replyCallback)
                     raises(WebAPIException);
    long addModeChangeListener(MediaControllerDisplayModeChangeCallback listener) raises(WebAPIException);
    void removeModeChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerDisplayModeType type Type of display mode on the server represented by this object.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**sendRequest **`Allows to send change requests for display mode to media controller server.

```javascript
void sendRequest(MediaControllerDisplayModeType type, MediaControllerSendCommandSuccessCallback replyCallback);
```

Since: 5.5

Remark: See addChangeRequestListener() method to check how to receive
and respond to commands.

Parameters:

- **type :
 Type of display mode, which is requested by a media controller client. **
- **replyCallback :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if related ability is not supported by the media controller server.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var type = "CROPPED_FULL";
mcServerInfo.displayMode.sendRequest(type, function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**addModeChangeListener **`Adds the listener for changes of a media controller display mode of a media controller server.

```javascript
long addModeChangeListener(MediaControllerDisplayModeChangeCallback listener);
```

Since: 5.5

Parameters:

- **listener :
 Display mode change listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when display mode changes. */
watcherId = mcServerInfo.displayMode.addModeChangeListener(function(mode)
{
  console.log(mcServerInfo.name + " server display mode changed to " + mode);
});
```

`**removeModeChangeListener **`Removes the listener, so stop receiving notifications about media controller server display mode changes.

```javascript
void removeModeChangeListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when display mode changes. */
watcherId = mcServerInfo.displayMode.addModeChangeListener(function(mode)
{
  console.log(mcServerInfo.name + " server display mode changed to " + mode);
});

/* Cancels the watch operation. */
mcServerInfo.displayMode.removeModeChangeListener(watcherId);
```

### 2.24. MediaControllerDisplayRotation

Server-side object representing display rotation of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayRotation {
    attribute MediaControllerDisplayRotationType displayRotation raises(WebAPIException);
    long addChangeRequestListener(MediaControllerDisplayRotationChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- MediaControllerDisplayRotationType displayRotation State of display rotation on the server. Default value for a newly created server is "ROTATION_NONE" .

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if an input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

#### Methods

`**addChangeRequestListener **`Adds the listener for change requests of a media controller display rotation.

```javascript
long addChangeRequestListener(MediaControllerDisplayRotationChangeRequestCallback listener);
```

Since: 5.5

Remark: Remember to set corresponding server's display rotation ability to "YES" to let clients send change requests to the server.

Parameters:

- **listener :
 Change request listener to add. **

Return value:

long: The identifier used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, rotation)
{
  console.log("Display rotation change requested to: " + rotation + " by " + clientName);
  var result = false;
  /* do some action here and return according to the result */
  if (!result)
  {
    return new tizen.mediacontroller.RequestReply(
        new tizen.Bundle({"message": "Error - Not allowed"}), 13);
  }
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to receive display rotation change requests from clients. */
watcherId = mcServer.displayRotation.addChangeRequestListener(changeListener);
```

`**removeChangeRequestListener **`Removes the listener and stops receiving change requests of media controller display rotation.

```javascript
void removeChangeRequestListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcServer = tizen.mediacontroller.createServer();

var changeListener = function(clientName, rotation)
{
  console.log("Display rotation change requested to: " + rotation + " by " + clientName);
  return new tizen.mediacontroller.RequestReply(new tizen.Bundle({"message": "Success"}), 0);
};

/* Registers to receive display rotation change requests from clients. */
watcherId = mcServer.displayRotation.addChangeRequestListener(changeListener);

/* Cancels the watch operation. */
mcServer.displayRotation.removeChangeRequestListener(watcherId);
```

### 2.25. MediaControllerClientInfo

This interface provides communication methods from the server to the client.

```webidl
  [NoInterfaceObject] interface MediaControllerClientInfo {
    readonly attribute ApplicationId name;
    void sendEvent(DOMString eventName, Bundle? data, MediaControllerSendCommandSuccessCallback successCallback)
                   raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly ApplicationId name Id of the client application.

Since: 5.5

#### Methods

`**sendEvent **`Sends an event to the client.

```javascript
void sendEvent(DOMString eventName, Bundle? data, MediaControllerSendCommandSuccessCallback successCallback);
```

Since: 5.5

Parameters:

- **eventName :
 Name of the event. **
- **data [nullable] :
 Additional event data. **
- **successCallback :
 Reply handling function. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any argument has invalid type.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* CLIENT APPLICATION */
var mcClient = tizen.mediacontroller.getClient();
mcClient.setCustomEventListener(function(serverName, eventName, data)
{
  console.log("Media controller client received an event from the server:");
  console.log("  name: " + eventName);
  console.log("  data: " + JSON.stringify(data));
  mcClient.unsetCustomEventListener();
  return new tizen.mediacontroller.RequestReply({response: "response data"}, 123);
});

/* SERVER APPLICATION */
var mcServer = tizen.mediacontroller.createServer();
mcServer.updatePlaybackState("PLAY");

var mcClientsInfoAll = mcServer.getAllClientsInfo();
if (mcClientsInfoAll.length < 1)
{
  console.log("Server has no active clients.");
}
else
{
  mcClientsInfoAll[0].sendEvent(
      "test", new tizen.Bundle({param1: "value1", param2: "value2"}), function(response)
      {
        console.log("Media controller server received a reply to the event:");
        console.log("  response: " + JSON.stringify(response));
      });
}
```

Output example:

```
Media controller client received an event from the server:
  name: test
  data: '{param1: "value1", param2: "value2"}'
Media controller server received a reply to the event:
  response: '{data: {response: "response data"}, code: 123}'
```

### 2.26. MediaControllerDisplayRotationInfo

Client-side object representing display rotation of a media controller server.

```webidl
  [NoInterfaceObject] interface MediaControllerDisplayRotationInfo {
    readonly attribute MediaControllerDisplayRotationType displayRotation raises(WebAPIException);
    void sendRequest(MediaControllerDisplayRotationType displayRotation, MediaControllerSendCommandSuccessCallback replyCallback)
                     raises(WebAPIException);
    long addDisplayRotationChangeListener(MediaControllerDisplayRotationChangeCallback listener) raises(WebAPIException);
    void removeDisplayRotationChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly MediaControllerDisplayRotationType displayRotation State of display rotation on the server represented by this object.

Since: 5.5

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

#### Methods

`**sendRequest **`Allows to send change requests for display rotation change to a media controller server.

```javascript
void sendRequest(MediaControllerDisplayRotationType displayRotation, MediaControllerSendCommandSuccessCallback replyCallback);
```

Since: 5.5

Remark: See addChangeRequestListener() method to check how to receive
and respond to commands.

Parameters:

- **displayRotation :
 Display rotation, which is requested by client. **
- **replyCallback :
 The method to invoke when server responded to change request. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if related ability is not supported by server.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

var rotation = "ROTATION_180";
mcServerInfo.displayRotation.sendRequest(rotation, function(data, code)
{
  console.log("Server replied with return data: " + JSON.stringify(data) + " and code: " + code);
});
```

`**addDisplayRotationChangeListener **`Adds the listener for changes of a display rotation of a media controller server.

```javascript
long addDisplayRotationChangeListener(MediaControllerDisplayRotationChangeCallback listener);
```

Since: 5.5

Parameters:

- **listener :
 Display rotation change listener to add. **

Return value:

long: The identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when display rotation changes. */
watcherId = mcServerInfo.displayRotation.addDisplayRotationChangeListener(function(rotation)
{
  console.log(mcServerInfo.name + " server display rotation changed to " + rotation);
});
```

`**removeDisplayRotationChangeListener **`Removes the listener, so stop receiving notifications about media controller server display rotation changes.

```javascript
void removeDisplayRotationChangeListener(long watchId);
```

Since: 5.5

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Watcher identifier. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var watcherId = 0;  /* Watcher identifier. */
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();

/* Registers to be notified when display rotation changes. */
watcherId = mcServerInfo.displayRotation.addDisplayRotationChangeListener(function(rotation)
{
  console.log(mcServerInfo.name + " server display rotation changed to " + rotation);
});

/* Cancels the watch operation. */
mcServerInfo.displayRotation.removeDisplayRotationChangeListener(watcherId);
```

### 2.27. MediaControllerMetadata

Playback metadata.

```webidl
  [NoInterfaceObject] interface MediaControllerMetadata {
    attribute DOMString title;
    attribute DOMString artist;
    attribute DOMString album;
    attribute DOMString author;
    attribute DOMString genre;
    attribute DOMString duration;
    attribute DOMString date;
    attribute DOMString copyright;
    attribute DOMString description;
    attribute DOMString trackNum;
    attribute DOMString picture;
    attribute long seasonNumber;
    attribute DOMString? seasonTitle;
    attribute long episodeNumber;
    attribute DOMString? episodeTitle;
    attribute long resolutionWidth;
    attribute long resolutionHeight;
    void save() raises(WebAPIException);
  };
```

Since: 5.0

#### Attributes

- DOMString title Media title.

Since: 5.0

- DOMString artist Media artist.

Since: 5.0

- DOMString album Media album.

Since: 5.0

- DOMString author Media author.

Since: 5.0

- DOMString genre Media genre.

Since: 5.0

- DOMString duration Media duration.

Since: 5.0

- DOMString date Media date.

Since: 5.0

- DOMString copyright Media copyright.

Since: 5.0

- DOMString description Media description.

Since: 5.0

- DOMString trackNum Media track number.

Since: 5.0

- DOMString picture Media picture.

Since: 5.0

- long seasonNumber Season number. Default value is 0.

Since: 5.5

- DOMString seasonTitle [nullable] Season title. Default value is null .

Since: 5.5

- long episodeNumber Episode number. Default value is 0.

Since: 5.5

- DOMString episodeTitle [nullable] Episode title. Default value is null .

Since: 5.5

- long resolutionWidth Resolution width. Default value is 0. It cannot be changed to less than 0. Setting inappropriate values has no effect on the attribute.

Since: 5.5

- long resolutionHeight Resolution height. Default value is 0. It cannot be changed to less than 0. Setting inappropriate values has no effect on the attribute.

Since: 5.5

#### Methods

`**save **`Saves current state of metadata to the database and sends notification to the listening clients.

```javascript
void save();
```

Since: 6.0

Exceptions:

- WebAPIException
- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var mcClient = tizen.mediacontroller.getClient();
var mcServerInfo = mcClient.getLatestServerInfo();
mcServer.playback.metadata.artist = "Artist Name";

console.log("Before save metadata is: " + JSON.stringify(mcServerInfo.playback.metadata));

mcServer.playback.metadata.save();
console.log("After save metadata is: " + JSON.stringify(mcServerInfo.playback.metadata));
```

Output example:

```
Before save metadata is: {"title":"","artist":"","album":"","author":"","genre":"","duration":"","date":"",
"copyright":"","description":"","trackNum":"","picture":"","seasonNumber":0,"seasonTitle":null,
"episodeNumber":0,"episodeTitle":null,"resolutionWidth":0,"resolutionHeight":0}
After save metadata is: {"title":"","artist":"ArtistName","album":"","author":"","genre":"","duration":"","date":"",
"copyright":"","description":"","trackNum":"","picture":"","seasonNumber":0,"seasonTitle":null,
"episodeNumber":0,"episodeTitle":null,"resolutionWidth":0,"resolutionHeight":0}
```

### 2.28. MediaControllerPlaylistItem

Object represents single playlist item.

```webidl
  [NoInterfaceObject] interface MediaControllerPlaylistItem {
    readonly attribute DOMString index;
    readonly attribute MediaControllerMetadata metadata;
  };
```

Since: 5.5

#### Attributes

- readonly DOMString index Index of playlist's item. Should be unique within playlist.

Since: 5.5

- readonly MediaControllerMetadata metadata Metadata associated with item.

Since: 5.5

### 2.29. MediaControllerMetadataInit

The MediaControllerMetadataInit dictionary defines the properties of a MediaControllerMetadata to add in addItem method.

```webidl
  dictionary MediaControllerMetadataInit {
    DOMString title;
    DOMString artist;
    DOMString album;
    DOMString author;
    DOMString genre;
    DOMString duration;
    DOMString date;
    DOMString copyright;
    DOMString description;
    DOMString trackNum;
    DOMString picture;
    long seasonNumber;
    DOMString seasonTitle;
    long episodeNumber;
    DOMString episodeTitle;
    long resolutionWidth;
    long resolutionHeight;
  };
```

Since: 5.5

See MediaControllerMetadata interface for more information about the members.

### 2.30. MediaControllerPlaylist

Object represents single playlist (collection of items).

```webidl
  [NoInterfaceObject] interface MediaControllerPlaylist {
    readonly attribute DOMString name;
    void addItem(DOMString index, MediaControllerMetadataInit metadata) raises(WebAPIException);
    void getItems(MediaControllerGetItemsSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                  raises(WebAPIException);
  };
```

Since: 5.5

#### Attributes

- readonly DOMString name Name of this playlist.

Since: 5.5

#### Methods

`**addItem **`Adds new item to the playlist.

```javascript
void addItem(DOMString index, MediaControllerMetadataInit metadata);
```

Since: 5.5

Parameters:

- **index :
 Index for new item, should be unique within playlist. **
- **metadata :
 Metadata to be associated with new item. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var mcServer = tizen.mediacontroller.createServer();
var playlist = mcServer.createPlaylist("testPlaylist");
var metadata =
{
  title: "testTitle",
  artist: "testArtist",
  album: "testAlbum",
  author: "testAuthor",
  genre: "testGenre",
  duration: "testDuration",
  date: "testDate",
  copyright: "testCopyright",
  description: "testDescription",
  trackNum: "testTrackNum",
  picture: "testPicture",
  seasonNumber: 1,
  seasonTitle: "testSeasonTitle",
  episodeNumber: 1,
  episodeTitle: "testEpisodeTitle",
  resolutionWidth: 1600,
  resolutionHeight: 900
};

playlist.addItem("index1", metadata);
console.log("Item added.");
function successCallback()
{
  console.log("savePlaylist successful.");
}
function errorCallback(error)
{
  console.log("savePlaylist failed with error: " + error);
}
mcServer.savePlaylist(playlist, successCallback, errorCallback);
```

Output example:

```
Item added.
savePlaylist successful.
```

`**getItems **`Gets all items from playlist.

```javascript
void getItems(MediaControllerGetItemsSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 5.5

The *errorCallback *may be triggered for one of the following errors:

- *UnknownError *: if any error prevents function from successful completion.

Remark: Note that getItems() method return only those items from playlist which been saved by savePlaylist() method.

Parameters:

- **successCallback :
 Function to be called when *getItems *is finished without error. **
- **errorCallback [optional] [nullable] :
 Function to be called when *getItems *fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Assumes that code example from addItem was executed before */
function successCallback(items)
{
  items.forEach(function(item)
  {
    console.log("Index: " + item.index + " Title: " + item.metadata.title);
  });
}
function errorCallback(error)
{
  console.log("getItems failed with error: " + error);
}

playlist.getItems(successCallback, errorCallback);
```

Output example:

```
Index: index1 Title: testTitle
```

### 2.31. SearchFilter

Search filter representation.

```webidl
  [Constructor(MediaControllerContentType contentType, optional MediaControllerSearchCategory category = "NO_CATEGORY", optional DOMString? keyword = null, optional Bundle? extraData = null)]
  interface SearchFilter {
    attribute MediaControllerContentType contentType raises(WebAPIException);
    attribute MediaControllerSearchCategory category raises(WebAPIException);
    attribute DOMString? keyword raises(WebAPIException);
    attribute Bundle? extraData;
  };
```

Since: 5.5

Remark: throws WebAPIException with error type TypeMismatchError, if constructor is called with invalid argument types.

Remark: throws WebAPIException with error type InvalidValuesError, if constructor is called with null keyword and category different than NO_CATEGORY.

#### Constructors

`**Constructor ( MediaControllerContentType , MediaControllerSearchCategory , DOMString?, Bundle ?) **`
```webidl
SearchFilter(MediaControllerContentType contentType, optional MediaControllerSearchCategory category = "NO_CATEGORY", optional DOMString? keyword = null, optional Bundle? extraData = null);
```

#### Attributes

- MediaControllerContentType contentType Specifies filter's content type parameter.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- MediaControllerSearchCategory category Specifies filter's search category parameter.

Since: 5.5

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type InvalidValuesError, if keyword is null and new category value is not NO_CATEGORY.

- DOMString keyword [nullable] Specifies filter's search keyword parameter.

Since: 5.5

Remark: Keyword can only be null or empty if the category is set to NO_CATEGORY.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if the category is not NO_CATEGORY and the keyword is null.

- Bundle extraData [nullable] Additional application-dependent search parameters.

Since: 5.5

### 2.32. MediaControllerServerInfoArraySuccessCallback

The MediaControllerServerInfoArraySuccessCallback interface that defines the success method
for *MediaControllerClient.findServers() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerServerInfoArraySuccessCallback {
    void onsuccess(MediaControllerServerInfo[] servers);
  };
```

Since: 5.0

#### Methods

`**onsuccess **`Called when all registered media controller servers found.

```javascript
void onsuccess(MediaControllerServerInfo[] servers);
```

Since: 5.0

Parameters:

- **servers :
 List of registered media controller servers. **

### 2.33. MediaControllerSendCommandSuccessCallback

The MediaControllerSendCommandSuccessCallback interface that defines the success method which is triggered, when the server responds to a command.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerSendCommandSuccessCallback {
    void onsuccess(object? data, optional long code);
  };
```

Since: 5.0

Interface is used as a success method for:

- *MediaControllerServerInfo.sendCommand() *
- *MediaControllerMode360Info.sendRequest() *
- *MediaControllerSubtitlesInfo.sendRequest() *
- *MediaControllerDisplayMode.sendRequest() *
- *MediaControllerDisplayRotationInfo.sendRequest() *
- *MediaControllerClientInfo.sendEvent() *

#### Methods

`**onsuccess **`Called when a response to the request is received.

```javascript
void onsuccess(object? data, optional long code);
```

Since: 5.0

Parameters:

- **data [nullable] :
 Response data object sent by the command handler. This object is compatible with Bundle object. **
- **code [optional] :
 Response code. **

### 2.34. RequestReply

Representation of server's response to a request.

```webidl
  [Constructor(Bundle? data, optional long code = 0)]
  interface RequestReply {
    attribute Bundle? data;
    attribute long code;
  };
```

Since: 5.5

#### Constructors

`**Constructor ( Bundle ?, long) **`
```webidl
RequestReply(Bundle? data, optional long code = 0);
```

#### Attributes

- Bundle data [nullable] Response data bundle.

Since: 5.5

- long code Response status code.

Since: 5.5

### 2.35. MediaControllerSearchRequestReplyCallback

The MediaControllerSearchRequestReplyCallback interface defines reply callback for *MediaControllerServerInfo.sendSearchRequest() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerSearchRequestReplyCallback {
    void onreply(RequestReply? reply);
  };
```

Since: 5.5

#### Methods

`**onreply **`Function called when search request has been processed.

```javascript
void onreply(RequestReply? reply);
```

Since: 5.5

Interpretation of status and data parameters depends on the server implementation.

Parameters:

- **reply [nullable] :
 Reply object returned by request handler. **

### 2.36. MediaControllerSearchRequestCallback

Server search request listener interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerSearchRequestCallback {
    RequestReply? onrequest(ApplicationId clientName, SearchFilter[] request);
  };
```

Since: 5.5

#### Methods

`**onrequest **`Function called on the server when it receives a search request from a client.

```javascript
RequestReply? onrequest(ApplicationId clientName, SearchFilter[] request);
```

Since: 5.5

Parameters:

- **clientName :
 Request sender name. **
- **request :
 Collection of filters to refine the search results. **

Return value:

RequestReply [nullable] : RequestReply object with status code and reply data bundle.
It will be passed to the replyCallback of sendSearchRequest() .

### 2.37. MediaControllerReceiveCommandCallback

The MediaControllerReceiveCommandCallback interface that defines the listener
for custom communication between server and client.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerReceiveCommandCallback {
    RequestReply? onsuccess(ApplicationId senderAppName, DOMString command, object data);
  };
```

Since: 5.0

Related functions:

- sendCommand()
- addCommandListener()
- sendEvent()
- setEventListener()

#### Methods

`**onsuccess **`Called when custom command is received by the server or custom event is received by the client.

```javascript
RequestReply? onsuccess(ApplicationId senderAppName, DOMString command, object data);
```

Since: 5.0

Parameters:

- **senderAppName :
 Sender application id. **
- **command :
 Custom command or event. **
- **data :
 Response object. This object is compatible with Bundle . **

Return value:

RequestReply [nullable] : RequestReply object which will be returned to the author of the request.

### 2.38. MediaControllerEnabledChangeRequestCallback

The MediaControllerEnabledChangeRequestCallback interface that defines the listener
for change requests for spherical mode in *MediaControllerMode360.addChangeRequestListener() *and
subtitles mode in *MediaControllerSubtitles.addChangeRequestListener() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerEnabledChangeRequestCallback {
    RequestReply? onreply(ApplicationId clientName, boolean enabled);
  };
```

Since: 5.5

#### Methods

`**onreply **`Called when change request is received from client.

```javascript
RequestReply? onreply(ApplicationId clientName, boolean enabled);
```

Since: 5.5

Remark: You can return data object from callback which will be sent in reply to the client.
See mode360.addChangeRequestListener() and subtitles.addChangeRequestListener() methods
to check how to handle and respond to commands.

Parameters:

- **clientName :
 The ID of a client application which the request was sent from. **
- **enabled :
 The value requested by a client application. **

Return value:

RequestReply [nullable] : RequestReply object which is sent with the reply to the client.

### 2.39. MediaControllerEnabledChangeCallback

The MediaControllerEnabledChangeCallback interface that defines the listener
for a media controller server's attribute changes.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerEnabledChangeCallback {
    void onchange(boolean enabled);
  };
```

Since: 5.5

#### Methods

`**onchange **`Called when server's attribute is changed.

```javascript
void onchange(boolean enabled);
```

Since: 5.5

Parameters:

- **enabled :
 Current server's attribute status, which specifies if attribute is enabled or disabled. **

### 2.40. MediaControllerDisplayModeChangeRequestCallback

The MediaControllerDisplayModeChangeRequestCallback interface that defines the listener
for change requests for display mode in *MediaControllerDisplayMode.addChangeRequestListener() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayModeChangeRequestCallback {
    RequestReply? onreply(ApplicationId clientName, MediaControllerDisplayModeType mode);
  };
```

Since: 5.5

#### Methods

`**onreply **`Called when change request is received from client.

```javascript
RequestReply? onreply(ApplicationId clientName, MediaControllerDisplayModeType mode);
```

Since: 5.5

Remark: You can return data object from callback which will be sent in reply to the client.
See addChangeRequestListener() method
to check how to handle and respond to commands.

Parameters:

- **clientName :
 An id of a client application which sent the request. **
- **mode :
 The value requested by a client application. **

Return value:

RequestReply [nullable] : RequestReply object which is sent with the reply to the client.

### 2.41. MediaControllerDisplayModeChangeCallback

The MediaControllerDisplayModeChangeCallback interface that defines the listener
for display mode changes of the media controller server.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayModeChangeCallback {
    void onchange(MediaControllerDisplayModeType mode);
  };
```

Since: 5.5

#### Methods

`**onchange **`Called when server's display mode is changed.

```javascript
void onchange(MediaControllerDisplayModeType mode);
```

Since: 5.5

Parameters:

- **mode :
 Current server display mode. **

### 2.42. MediaControllerDisplayRotationChangeRequestCallback

The MediaControllerDisplayRotationChangeRequestCallback interface that defines the listener
for change requests for display rotation in *MediaControllerDisplayRotation.addChangeRequestListener() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayRotationChangeRequestCallback {
    RequestReply? onreply(ApplicationId clientName, MediaControllerDisplayRotationType displayRotation);
  };
```

Since: 5.5

#### Methods

`**onreply **`Called when change request is received from a client.

```javascript
RequestReply? onreply(ApplicationId clientName, MediaControllerDisplayRotationType displayRotation);
```

Since: 5.5

Remark: You can return data object from callback which will be sent in reply to the client.
See displayRotation.addChangeRequestListener() method
to check how to handle and respond to commands.

Parameters:

- **clientName :
 An id of a client application which sent the request. **
- **displayRotation :
 The value requested by a client application. **

Return value:

RequestReply [nullable] : RequestReply object which is sent with the reply to the client.

### 2.43. MediaControllerDisplayRotationChangeCallback

The MediaControllerDisplayModeChangeCallback interface that defines the listener
for changes of a media controller server's display rotation.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayRotationChangeCallback {
    void onchange(MediaControllerDisplayRotationType displayRotation);
  };
```

Since: 5.5

#### Methods

`**onchange **`Called when display rotation is changed.

```javascript
void onchange(MediaControllerDisplayRotationType displayRotation);
```

Since: 5.5

Parameters:

- **displayRotation :
 Current server display rotation state. **

### 2.44. MediaControllerServerStatusChangeCallback

The MediaControllerServerStatusChangeCallback interface that defines the listener
for media controller server status changes.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerServerStatusChangeCallback {
    void onsuccess(MediaControllerServerState status);
  };
```

Since: 5.0

#### Methods

`**onsuccess **`Called when server status changed.

```javascript
void onsuccess(MediaControllerServerState status);
```

Since: 5.0

Parameters:

- **status :
 Current server status. **

### 2.45. MediaControllerPlaybackInfoChangeCallback

The MediaControllerPlaybackInfoChangeCallback interface that defines the listeners
object for receiving media controller playback info changes from server.

```webidl
  [Callback, NoInterfaceObject] interface MediaControllerPlaybackInfoChangeCallback {
    void onplaybackchanged(MediaControllerPlaybackState state, unsigned long long position);
    void onshufflemodechanged(boolean mode);
    void onrepeatstatechanged(MediaControllerRepeatState state);
    void onmetadatachanged(MediaControllerMetadata metadata);
  };
```

Since: 5.0

#### Methods

`**onplaybackchanged **`Called when playback state or position is changed.

```javascript
void onplaybackchanged(MediaControllerPlaybackState state, unsigned long long position);
```

Since: 5.0

Parameters:

- **state :
 Current playback state. **
- **position :
 Current playback position. **

`**onshufflemodechanged **`Called when shuffle mode is changed.

```javascript
void onshufflemodechanged(boolean mode);
```

Since: 5.0

Parameters:

- **mode :
 Current shuffle mode. **

`**onrepeatstatechanged **`Called when repeat state is changed.

```javascript
void onrepeatstatechanged(MediaControllerRepeatState state);
```

Since: 5.5

It is guaranteed that the onrepeatstatechanged callback
will be invoked after the onrepeatmodechanged .

Parameters:

- **state :
 Current repeat state. **

`**onmetadatachanged **`Called when playback metadata is changed.

```javascript
void onmetadatachanged(MediaControllerMetadata metadata);
```

Since: 5.0

Parameters:

- **metadata :
 Current playback metadata. **

### 2.46. MediaControllerChangeRequestPlaybackInfoCallback

The MediaControllerChangeRequestPlaybackInfoCallback interface that defines the listeners
object for receiving playback info change requests from client.

```webidl
  [Callback, NoInterfaceObject] interface MediaControllerChangeRequestPlaybackInfoCallback {
    RequestReply? onplaybackactionrequest(MediaControllerPlaybackAction action, ApplicationId clientName);
    RequestReply? onplaybackpositionrequest(unsigned long long position, ApplicationId clientName);
    RequestReply? onshufflemoderequest(boolean mode, ApplicationId clientName);
    RequestReply? onrepeatstaterequest(MediaControllerRepeatState state, ApplicationId clientName);
    RequestReply? onplaybackitemrequest(DOMString playlistName, DOMString index, MediaControllerPlaybackAction action,
                                        unsigned long long position, ApplicationId clientName);
  };
```

Since: 5.0

#### Methods

`**onplaybackactionrequest **`Called when a client requested the playback state changes by sending the playback action.

```javascript
RequestReply? onplaybackactionrequest(MediaControllerPlaybackAction action, ApplicationId clientName);
```

Since: 6.0

Parameters:

- **action :
 Playback action sent by the client. **
- **clientName :
 Id of client application, which sent a command. **

`**onplaybackpositionrequest **`Called when client requested playback position changes.

```javascript
RequestReply? onplaybackpositionrequest(unsigned long long position, ApplicationId clientName);
```

Since: 5.0

Remark: Parameter *clientName *is passed since Tizen 5.5.

Parameters:

- **position :
 Requested playback position. **
- **clientName :
 Id of client application, which sent a command. **

`**onshufflemoderequest **`Called when client requested shuffle mode changes.

```javascript
RequestReply? onshufflemoderequest(boolean mode, ApplicationId clientName);
```

Since: 5.0

Remark: Parameter *clientName *is passed since Tizen 5.5.

Parameters:

- **mode :
 Requested shuffle mode. **
- **clientName :
 Id of client application, which sent a command. **

`**onrepeatstaterequest **`Called when client requested change of repeat state.

```javascript
RequestReply? onrepeatstaterequest(MediaControllerRepeatState state, ApplicationId clientName);
```

Since: 5.5

It is guaranteed that the onrepeatstaterequest callback
will be invoked after the onrepeatmoderequest .

Parameters:

- **state :
 Requested repeat state. **
- **clientName :
 Id of client application, which sent a command. **

`**onplaybackitemrequest **`Called when client request change of playback item.

```javascript
RequestReply? onplaybackitemrequest(DOMString playlistName, DOMString index, MediaControllerPlaybackAction action,
                                    unsigned long long position, ApplicationId clientName);
```

Since: 5.5

Parameters:

- **playlistName :
 Name of playlist. **
- **index :
 Index of the item to be changed. **
- **action :
 Playback action. **
- **position :
 Playback position. **
- **clientName :
 Id of client application, which sent a command. **

### 2.47. MediaControllerGetAllPlaylistsSuccessCallback

Interface for success callback for *getAllPlaylists *function.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerGetAllPlaylistsSuccessCallback {
    void onsuccess(MediaControllerPlaylist[] playlists);
  };
```

Since: 5.5

#### Methods

`**onsuccess **`Success callback for *getAllPlaylists *function.

```javascript
void onsuccess(MediaControllerPlaylist[] playlists);
```

Since: 5.5

Parameters:

- **playlists :
 Collection of *MediaControllerPlaylist *objects. **

### 2.48. MediaControllerPlaylistUpdatedCallback

Interface for specific playlist update events (including deletion).

```webidl
  [Callback, NoInterfaceObject] interface MediaControllerPlaylistUpdatedCallback {
    void onplaylistupdated(DOMString serverName, MediaControllerPlaylist playlist);
    void onplaylistdeleted(DOMString serverName, DOMString playlistName);
  };
```

Since: 5.5

#### Methods

`**onplaylistupdated **`Event triggered when playlist is updated in database.

```javascript
void onplaylistupdated(DOMString serverName, MediaControllerPlaylist playlist);
```

Since: 5.5

Parameters:

- **serverName :
 Name of server which triggered the event. **
- **playlist :
 Playlist for which event was triggered. **

`**onplaylistdeleted **`Event triggered when playlist is removed from database.

```javascript
void onplaylistdeleted(DOMString serverName, DOMString playlistName);
```

Since: 5.5

Parameters:

- **serverName :
 Name of server which triggered the event. **
- **playlistName :
 Name of playlist for which the event was triggered. **

### 2.49. MediaControllerGetItemsSuccessCallback

Interface for success callback for *getItems *function.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerGetItemsSuccessCallback {
    void onsuccess(MediaControllerPlaylistItem[] items);
  };
```

Since: 5.5

#### Methods

`**onsuccess **`Success callback for *getItems *function.

```javascript
void onsuccess(MediaControllerPlaylistItem[] items);
```

Since: 5.5

Parameters:

- **items :
 Collection of *MediaControllerPlaylistItem *objects. **

### 2.50. MediaControllerAbilityChangeCallback

Interface for handling ability events.

```webidl
  [Callback, NoInterfaceObject] interface MediaControllerAbilityChangeCallback {
    void onplaybackabilitychanged(MediaControllerServerInfo server, MediaControllerPlaybackAbilitiesInfo abilities);
    void ondisplaymodeabilitychanged(MediaControllerServerInfo server, MediaControllerDisplayModeAbilitiesInfo abilities);
    void ondisplayrotationabilitychanged(MediaControllerServerInfo server, MediaControllerDisplayRotationAbilitiesInfo abilities);
    void onsimpleabilitychanged(MediaControllerServerInfo server, MediaControllerSimpleAbility type,
                                MediaControllerAbilitySupport support);
  };
```

Since: 5.5

#### Methods

`**onplaybackabilitychanged **`Event triggered when server's playback ability is updated.

```javascript
void onplaybackabilitychanged(MediaControllerServerInfo server, MediaControllerPlaybackAbilitiesInfo abilities);
```

Since: 5.5

Parameters:

- **server :
 Server which triggered the event. **
- **abilities :
 Object with current state of playback abilities on the media controller server. **

`**ondisplaymodeabilitychanged **`Event triggered when server's display mode ability is updated.

```javascript
void ondisplaymodeabilitychanged(MediaControllerServerInfo server, MediaControllerDisplayModeAbilitiesInfo abilities);
```

Since: 5.5

Parameters:

- **server :
 Server which triggered the event. **
- **abilities :
 Object with current state of display mode abilities on the media controller server. **

`**ondisplayrotationabilitychanged **`Event triggered when server's display rotation is updated.

```javascript
void ondisplayrotationabilitychanged(MediaControllerServerInfo server, MediaControllerDisplayRotationAbilitiesInfo abilities);
```

Since: 5.5

Parameters:

- **server :
 Server which triggered the event. **
- **abilities :
 Object with current state of display mode abilities on the media controller server. **

`**onsimpleabilitychanged **`Event triggered when server's simple ability is updated.

```javascript
void onsimpleabilitychanged(MediaControllerServerInfo server, MediaControllerSimpleAbility type,
                            MediaControllerAbilitySupport support);
```

Since: 5.5

Parameters:

- **server :
 Server which triggered the event. **
- **type :
 Type of simple ability. **
- **support :
 Ability value which was set on the media controller server. **

## 3. Full WebIDL

```webidl
module MediaController {
  enum MediaControllerServerState { "ACTIVE", "INACTIVE" };
  enum MediaControllerSearchCategory { "NO_CATEGORY", "TITLE", "ARTIST", "ALBUM", "GENRE", "TPO" };
  enum MediaControllerPlaybackState { "PLAY", "PAUSE", "STOP", "NEXT", "PREV", "FORWARD", "REWIND" };
  enum MediaControllerPlaybackAction { "PLAY", "PAUSE", "STOP", "NEXT", "PREV", "FORWARD", "REWIND", "TOGGLE_PLAY_PAUSE" };
  enum MediaControllerRepeatState { "REPEAT_OFF", "REPEAT_ONE", "REPEAT_ALL" };
  enum MediaControllerContentType { "IMAGE", "MUSIC", "VIDEO", "OTHER", "UNDECIDED" };
  enum MediaControllerContentAgeRating { "ALL", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
    "17", "18", "19" };
  enum MediaControllerAbilitySupport { "YES", "NO", "UNDECIDED" };
  enum MediaControllerSimpleAbility { "PLAYBACK_POSITION", "SHUFFLE", "REPEAT", "PLAYLIST", "CLIENT_CUSTOM", "SEARCH", "SUBTITLES",
    "MODE_360" };
  enum MediaControllerDisplayModeType { "LETTER_BOX", "ORIGIN_SIZE", "FULL_SCREEN", "CROPPED_FULL" };
  enum MediaControllerDisplayRotationType { "ROTATION_NONE", "ROTATION_90", "ROTATION_180", "ROTATION_270" };
  dictionary MediaControllerMetadataInit {
    DOMString title;
    DOMString artist;
    DOMString album;
    DOMString author;
    DOMString genre;
    DOMString duration;
    DOMString date;
    DOMString copyright;
    DOMString description;
    DOMString trackNum;
    DOMString picture;
    long seasonNumber;
    DOMString seasonTitle;
    long episodeNumber;
    DOMString episodeTitle;
    long resolutionWidth;
    long resolutionHeight;
  };
  Tizen implements MediaControllerObject;
  [NoInterfaceObject] interface MediaControllerObject {
    readonly attribute MediaControllerManager mediacontroller;
  };
  [NoInterfaceObject] interface MediaControllerManager {
    MediaControllerClient getClient() raises(WebAPIException);
    MediaControllerServer createServer() raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerServer {
    readonly attribute MediaControllerServerPlaybackInfo playback;
    readonly attribute MediaControllerPlaylists playlists;
    attribute DOMString? iconURI raises(WebAPIException);
    readonly attribute MediaControllerAbilities abilities;
    readonly attribute MediaControllerSubtitles subtitles;
    readonly attribute MediaControllerMode360 mode360;
    readonly attribute MediaControllerDisplayMode displayMode;
    readonly attribute MediaControllerDisplayRotation displayRotation;
    MediaControllerClientInfo[] getAllClientsInfo() raises(WebAPIException);
    void setSearchRequestListener(MediaControllerSearchRequestCallback listener) raises(WebAPIException);
    void unsetSearchRequestListener() raises(WebAPIException);
    long addCommandListener(MediaControllerReceiveCommandCallback listener) raises(WebAPIException);
    void removeCommandListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerClient {
    void findServers(MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                     raises(WebAPIException);
    MediaControllerServerInfo? getLatestServerInfo() raises(WebAPIException);
    long addAbilityChangeListener(MediaControllerAbilityChangeCallback listener) raises(WebAPIException);
    void removeAbilityChangeListener(long watchId) raises(WebAPIException);
    void findSubscribedServers(MediaControllerServerInfoArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
    void setCustomEventListener(MediaControllerReceiveCommandCallback listener) raises(WebAPIException);
    void unsetCustomEventListener() raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerServerInfo {
    readonly attribute ApplicationId name;
    readonly attribute MediaControllerServerState state;
    readonly attribute MediaControllerServerInfoPlaybackInfo playback raises(WebAPIException);
    readonly attribute MediaControllerPlaylistsInfo playlists;
    readonly attribute DOMString? iconURI raises(WebAPIException);
    readonly attribute MediaControllerAbilitiesInfo abilities;
    readonly attribute MediaControllerSubtitlesInfo subtitles;
    readonly attribute MediaControllerMode360Info mode360;
    readonly attribute MediaControllerDisplayModeInfo displayMode;
    readonly attribute MediaControllerDisplayRotationInfo displayRotation;
    void sendSearchRequest(SearchFilter[] request, MediaControllerSearchRequestReplyCallback replyCallback,
                           optional ErrorCallback? errorCallback) raises(WebAPIException);
    void sendCommand(DOMString command, Bundle? data, MediaControllerSendCommandSuccessCallback successCallback,
                     optional ErrorCallback? errorCallback) raises(WebAPIException);
    long addServerStatusChangeListener(MediaControllerServerStatusChangeCallback listener) raises(WebAPIException);
    void removeServerStatusChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerServerPlaybackInfo {
    attribute MediaControllerPlaybackState state raises(WebAPIException);
    attribute unsigned long long position raises(WebAPIException);
    attribute MediaControllerContentAgeRating ageRating raises(WebAPIException);
    attribute MediaControllerContentType contentType raises(WebAPIException);
    attribute boolean shuffleMode raises(WebAPIException);
    attribute MediaControllerRepeatState repeatState raises(WebAPIException);
    readonly attribute MediaControllerMetadata metadata;
    readonly attribute DOMString? index;
    readonly attribute DOMString? playlistName;
    void updatePlaybackItem(DOMString playlistName, DOMString index) raises(WebAPIException);
    long addChangeRequestListener(MediaControllerChangeRequestPlaybackInfoCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerServerInfoPlaybackInfo {
    readonly attribute MediaControllerPlaybackState state;
    readonly attribute unsigned long long position;
    readonly attribute MediaControllerContentAgeRating ageRating;
    readonly attribute MediaControllerContentType contentType;
    readonly attribute boolean shuffleMode;
    readonly attribute MediaControllerRepeatState repeatState;
    readonly attribute MediaControllerMetadata metadata;
    readonly attribute DOMString? index;
    readonly attribute DOMString? playlistName;
    void sendPlaybackAction(MediaControllerPlaybackAction action, optional MediaControllerSendCommandSuccessCallback? replyCallback)
                            raises(WebAPIException);
    void sendPlaybackPosition(unsigned long long position, optional MediaControllerSendCommandSuccessCallback? replyCallback)
                              raises(WebAPIException);
    void sendShuffleMode(boolean mode, optional MediaControllerSendCommandSuccessCallback? replyCallback) raises(WebAPIException);
    void sendRepeatState(MediaControllerRepeatState state, optional MediaControllerSendCommandSuccessCallback? replyCallback)
                         raises(WebAPIException);
    long addPlaybackInfoChangeListener(MediaControllerPlaybackInfoChangeCallback listener) raises(WebAPIException);
    void removePlaybackInfoChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerPlaylists {
    MediaControllerPlaylist createPlaylist(DOMString name) raises(WebAPIException);
    void savePlaylist(MediaControllerPlaylist playlist, optional SuccessCallback? successCallback,
                      optional ErrorCallback? errorCallback) raises(WebAPIException);
    void deletePlaylist(DOMString playlistName, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void getAllPlaylists(MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    MediaControllerPlaylist getPlaylist(DOMString playlistName) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerPlaylistsInfo {
    void getAllPlaylists(MediaControllerGetAllPlaylistsSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    void sendPlaybackItem(DOMString playlistName, DOMString index, MediaControllerPlaybackAction action, unsigned long long position,
                          optional MediaControllerSendCommandSuccessCallback? replyCallback) raises(WebAPIException);
    long addPlaylistUpdatedListener(MediaControllerPlaylistUpdatedCallback listener) raises(WebAPIException);
    void removePlaylistUpdatedListener(long listenerId) raises(WebAPIException);
    MediaControllerPlaylist getPlaylist(DOMString playlistName) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerAbilities {
    readonly attribute MediaControllerPlaybackAbilities playback;
    readonly attribute MediaControllerDisplayModeAbilities displayMode;
    readonly attribute MediaControllerDisplayRotationAbilities displayRotation;
    attribute MediaControllerAbilitySupport playbackPosition raises(WebAPIException);
    attribute MediaControllerAbilitySupport shuffle raises(WebAPIException);
    attribute MediaControllerAbilitySupport repeat raises(WebAPIException);
    attribute MediaControllerAbilitySupport playlist raises(WebAPIException);
    attribute MediaControllerAbilitySupport clientCustom raises(WebAPIException);
    attribute MediaControllerAbilitySupport search raises(WebAPIException);
    attribute MediaControllerAbilitySupport subtitles raises(WebAPIException);
    attribute MediaControllerAbilitySupport mode360 raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerPlaybackAbilities {
    attribute MediaControllerAbilitySupport play raises(WebAPIException);
    attribute MediaControllerAbilitySupport pause raises(WebAPIException);
    attribute MediaControllerAbilitySupport stop raises(WebAPIException);
    attribute MediaControllerAbilitySupport next raises(WebAPIException);
    attribute MediaControllerAbilitySupport prev raises(WebAPIException);
    attribute MediaControllerAbilitySupport forward raises(WebAPIException);
    attribute MediaControllerAbilitySupport rewind raises(WebAPIException);
    attribute MediaControllerAbilitySupport togglePlayPause raises(WebAPIException);
    void saveAbilities() raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayModeAbilities {
    attribute MediaControllerAbilitySupport letterBox raises(WebAPIException);
    attribute MediaControllerAbilitySupport originSize raises(WebAPIException);
    attribute MediaControllerAbilitySupport fullScreen raises(WebAPIException);
    attribute MediaControllerAbilitySupport croppedFull raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayRotationAbilities {
    attribute MediaControllerAbilitySupport rotationNone raises(WebAPIException);
    attribute MediaControllerAbilitySupport rotation90 raises(WebAPIException);
    attribute MediaControllerAbilitySupport rotation180 raises(WebAPIException);
    attribute MediaControllerAbilitySupport rotation270 raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerAbilitiesInfo {
    readonly attribute MediaControllerPlaybackAbilitiesInfo playback;
    readonly attribute MediaControllerDisplayModeAbilitiesInfo displayMode;
    readonly attribute MediaControllerDisplayRotationAbilitiesInfo displayRotation;
    readonly attribute MediaControllerAbilitySupport playbackPosition raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport shuffle raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport repeat raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport playlist raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport clientCustom raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport search raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport subtitles raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport mode360 raises(WebAPIException);
    void subscribe() raises(WebAPIException);
    void unsubscribe() raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerPlaybackAbilitiesInfo {
    readonly attribute MediaControllerAbilitySupport play raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport pause raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport stop raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport next raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport prev raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport forward raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rewind raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport togglePlayPause raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayModeAbilitiesInfo {
    readonly attribute MediaControllerAbilitySupport letterBox raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport originSize raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport fullScreen raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport croppedFull raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayRotationAbilitiesInfo {
    readonly attribute MediaControllerAbilitySupport rotationNone raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rotation90 raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rotation180 raises(WebAPIException);
    readonly attribute MediaControllerAbilitySupport rotation270 raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerSubtitles {
    attribute boolean enabled raises(WebAPIException);
    long addChangeRequestListener(MediaControllerEnabledChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerSubtitlesInfo {
    readonly attribute boolean enabled raises(WebAPIException);
    void sendRequest(boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback) raises(WebAPIException);
    long addModeChangeListener(MediaControllerEnabledChangeCallback listener) raises(WebAPIException);
    void removeModeChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerMode360 {
    attribute boolean enabled raises(WebAPIException);
    long addChangeRequestListener(MediaControllerEnabledChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerMode360Info {
    readonly attribute boolean enabled raises(WebAPIException);
    void sendRequest(boolean enabled, MediaControllerSendCommandSuccessCallback replyCallback) raises(WebAPIException);
    long addModeChangeListener(MediaControllerEnabledChangeCallback listener) raises(WebAPIException);
    void removeModeChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayMode {
    attribute MediaControllerDisplayModeType type raises(WebAPIException);
    long addChangeRequestListener(MediaControllerDisplayModeChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayModeInfo {
    readonly attribute MediaControllerDisplayModeType type raises(WebAPIException);
    void sendRequest(MediaControllerDisplayModeType type, MediaControllerSendCommandSuccessCallback replyCallback)
                     raises(WebAPIException);
    long addModeChangeListener(MediaControllerDisplayModeChangeCallback listener) raises(WebAPIException);
    void removeModeChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayRotation {
    attribute MediaControllerDisplayRotationType displayRotation raises(WebAPIException);
    long addChangeRequestListener(MediaControllerDisplayRotationChangeRequestCallback listener) raises(WebAPIException);
    void removeChangeRequestListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerClientInfo {
    readonly attribute ApplicationId name;
    void sendEvent(DOMString eventName, Bundle? data, MediaControllerSendCommandSuccessCallback successCallback)
                   raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerDisplayRotationInfo {
    readonly attribute MediaControllerDisplayRotationType displayRotation raises(WebAPIException);
    void sendRequest(MediaControllerDisplayRotationType displayRotation, MediaControllerSendCommandSuccessCallback replyCallback)
                     raises(WebAPIException);
    long addDisplayRotationChangeListener(MediaControllerDisplayRotationChangeCallback listener) raises(WebAPIException);
    void removeDisplayRotationChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerMetadata {
    attribute DOMString title;
    attribute DOMString artist;
    attribute DOMString album;
    attribute DOMString author;
    attribute DOMString genre;
    attribute DOMString duration;
    attribute DOMString date;
    attribute DOMString copyright;
    attribute DOMString description;
    attribute DOMString trackNum;
    attribute DOMString picture;
    attribute long seasonNumber;
    attribute DOMString? seasonTitle;
    attribute long episodeNumber;
    attribute DOMString? episodeTitle;
    attribute long resolutionWidth;
    attribute long resolutionHeight;
    void save() raises(WebAPIException);
  };
  [NoInterfaceObject] interface MediaControllerPlaylistItem {
    readonly attribute DOMString index;
    readonly attribute MediaControllerMetadata metadata;
  };
  [NoInterfaceObject] interface MediaControllerPlaylist {
    readonly attribute DOMString name;
    void addItem(DOMString index, MediaControllerMetadataInit metadata) raises(WebAPIException);
    void getItems(MediaControllerGetItemsSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                  raises(WebAPIException);
  };
  [Constructor(MediaControllerContentType contentType, optional MediaControllerSearchCategory category = "NO_CATEGORY", optional DOMString? keyword = null, optional Bundle? extraData = null)]
  interface SearchFilter {
    attribute MediaControllerContentType contentType raises(WebAPIException);
    attribute MediaControllerSearchCategory category raises(WebAPIException);
    attribute DOMString? keyword raises(WebAPIException);
    attribute Bundle? extraData;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerServerInfoArraySuccessCallback {
    void onsuccess(MediaControllerServerInfo[] servers);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerSendCommandSuccessCallback {
    void onsuccess(object? data, optional long code);
  };
  [Constructor(Bundle? data, optional long code = 0)]
  interface RequestReply {
    attribute Bundle? data;
    attribute long code;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerSearchRequestReplyCallback {
    void onreply(RequestReply? reply);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerSearchRequestCallback {
    RequestReply? onrequest(ApplicationId clientName, SearchFilter[] request);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerReceiveCommandCallback {
    RequestReply? onsuccess(ApplicationId senderAppName, DOMString command, object data);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerEnabledChangeRequestCallback {
    RequestReply? onreply(ApplicationId clientName, boolean enabled);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerEnabledChangeCallback {
    void onchange(boolean enabled);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayModeChangeRequestCallback {
    RequestReply? onreply(ApplicationId clientName, MediaControllerDisplayModeType mode);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayModeChangeCallback {
    void onchange(MediaControllerDisplayModeType mode);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayRotationChangeRequestCallback {
    RequestReply? onreply(ApplicationId clientName, MediaControllerDisplayRotationType displayRotation);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerDisplayRotationChangeCallback {
    void onchange(MediaControllerDisplayRotationType displayRotation);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerServerStatusChangeCallback {
    void onsuccess(MediaControllerServerState status);
  };
  [Callback, NoInterfaceObject] interface MediaControllerPlaybackInfoChangeCallback {
    void onplaybackchanged(MediaControllerPlaybackState state, unsigned long long position);
    void onshufflemodechanged(boolean mode);
    void onrepeatstatechanged(MediaControllerRepeatState state);
    void onmetadatachanged(MediaControllerMetadata metadata);
  };
  [Callback, NoInterfaceObject] interface MediaControllerChangeRequestPlaybackInfoCallback {
    RequestReply? onplaybackactionrequest(MediaControllerPlaybackAction action, ApplicationId clientName);
    RequestReply? onplaybackpositionrequest(unsigned long long position, ApplicationId clientName);
    RequestReply? onshufflemoderequest(boolean mode, ApplicationId clientName);
    RequestReply? onrepeatstaterequest(MediaControllerRepeatState state, ApplicationId clientName);
    RequestReply? onplaybackitemrequest(DOMString playlistName, DOMString index, MediaControllerPlaybackAction action,
                                        unsigned long long position, ApplicationId clientName);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerGetAllPlaylistsSuccessCallback {
    void onsuccess(MediaControllerPlaylist[] playlists);
  };
  [Callback, NoInterfaceObject] interface MediaControllerPlaylistUpdatedCallback {
    void onplaylistupdated(DOMString serverName, MediaControllerPlaylist playlist);
    void onplaylistdeleted(DOMString serverName, DOMString playlistName);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MediaControllerGetItemsSuccessCallback {
    void onsuccess(MediaControllerPlaylistItem[] items);
  };
  [Callback, NoInterfaceObject] interface MediaControllerAbilityChangeCallback {
    void onplaybackabilitychanged(MediaControllerServerInfo server, MediaControllerPlaybackAbilitiesInfo abilities);
    void ondisplaymodeabilitychanged(MediaControllerServerInfo server, MediaControllerDisplayModeAbilitiesInfo abilities);
    void ondisplayrotationabilitychanged(MediaControllerServerInfo server, MediaControllerDisplayRotationAbilitiesInfo abilities);
    void onsimpleabilitychanged(MediaControllerServerInfo server, MediaControllerSimpleAbility type,
                                MediaControllerAbilitySupport support);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
