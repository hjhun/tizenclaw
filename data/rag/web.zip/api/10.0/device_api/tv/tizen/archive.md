# Archive API

The Archive API provides functions to create and manage archive files.
You can extract files, add a file to an archive file, and so on.

**Remark: **In order to access files, a proper privilege has to be defined additionally:

- for accessing only internal storage using this API, a privilege http://tizen.org/privilege/mediastorage must be provided,
- for accessing only external storage using this API, a privilege http://tizen.org/privilege/externalstorage must be provided,
- for accessing internal and external storage using this API, privileges ( http://tizen.org/privilege/mediastorage and http://tizen.org/privilege/externalstorage ) must be provided.
For more information about how to use Archive API, see File Archiving Guide .

Since: 2.3

## Table of Contents

- 1. Type Definitions
- 1.1. FileReference
- 1.2. ArchiveCompressionLevel
- 2. Interfaces
- 2.1. ArchiveManagerObject
- 2.2. ArchiveFileOptions
- 2.3. ArchiveFileEntryOptions
- 2.4. ArchiveManager
- 2.5. ArchiveFile
- 2.6. ArchiveFileEntry
- 2.7. ArchiveFileSuccessCallback
- 2.8. ArchiveFileEntrySuccessCallback
- 2.9. ArchiveFileEntryArraySuccessCallback
- 2.10. ArchiveFileProgressCallback
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| ArchiveManagerObject |  |
| ArchiveFileOptions |  |
| ArchiveFileEntryOptions |  |
| ArchiveManager | long open ( FileReference file, FileMode mode, ArchiveFileSuccessCallback onsuccess, optional ErrorCallback ? onerror, optional ArchiveFileOptions ? options) void abort (long operationIdentifier) |
| ArchiveFile | long add ( FileReference sourceFile, optional SuccessCallback ? onsuccess, optional ErrorCallback ? onerror, optional ArchiveFileProgressCallback ? onprogress, optional ArchiveFileEntryOptions ? options) long extractAll ( FileReference destinationDirectory, optional SuccessCallback ? onsuccess, optional ErrorCallback ? onerror, optional ArchiveFileProgressCallback ? onprogress, optional boolean? overwrite) long getEntries ( ArchiveFileEntryArraySuccessCallback onsuccess, optional ErrorCallback ? onerror) long getEntryByName (DOMString name, ArchiveFileEntrySuccessCallback onsuccess, optional ErrorCallback ? onerror) void close () |
| ArchiveFileEntry | long extract ( FileReference destinationDirectory, optional SuccessCallback ? onsuccess, optional ErrorCallback ? onerror, optional ArchiveFileProgressCallback ? onprogress, optional boolean? stripName, optional boolean? overwrite) |
| ArchiveFileSuccessCallback | void onsuccess ( ArchiveFile archive) |
| ArchiveFileEntrySuccessCallback | void onsuccess ( ArchiveFileEntry entry) |
| ArchiveFileEntryArraySuccessCallback | void onsuccess ( ArchiveFileEntry [] entries) |
| ArchiveFileProgressCallback | void onprogress (long operationIdentifier, double value, DOMString filename) |

## 1. Type Definitions

### 1.1. FileReference

File reference for an archive file.
It can be either a File object or a virtual path.

```webidl
  typedef (DOMString or File) FileReference;
```

Since: 2.3

### 1.2. ArchiveCompressionLevel

Enumeration for the compression level.

```webidl
  enum ArchiveCompressionLevel { "STORE", "FAST", "NORMAL", "BEST" };
```

Since: 2.3

- STORE - No compression. The file is stored unchanged.
- FAST - Choose the fastest compression method, compression savings will be less.
- NORMAL - Default compression level.
- BEST - Choose the best compression method, compression may be slow.

## 2. Interfaces

### 2.1. ArchiveManagerObject

The ArchiveManagerObject interface defines what is instantiated in the *Tizen *object.

```webidl
  [NoInterfaceObject] interface ArchiveManagerObject {
    readonly attribute ArchiveManager archive;
  };
```

```webidl
  Tizen implements ArchiveManagerObject;
```

Since: 2.3

The *tizen.archive *object allows access to the Archive API.

#### Attributes

- readonly ArchiveManager archive Object representing an archive manager.

Since: 2.3

### 2.2. ArchiveFileOptions

The ArchiveFileOptions dictionary represents the option to decide if an archive file can be overwritten when an archive file is opened.

```webidl
  dictionary ArchiveFileOptions {
    boolean overwrite;
  };
```

Since: 2.3

#### Dictionary members

boolean overwrite Indicates whether opening an archive file for writing can overwrite the contents of the existing file.

- true - The archive file is overwritten if an archive file with a same name exists in the same location. The previous contents are lost.
- false - The archive file is not overwritten if an archive file with a same name exists in the same location.
The default value is false

See description of the *mode *argument of the *open() *method.

Since: 2.3

### 2.3. ArchiveFileEntryOptions

The ArchiveFileEntryOptions dictionary controls behavior when adding a file to an archive.

```webidl
  dictionary ArchiveFileEntryOptions {
    DOMString destination;
    boolean stripSourceDirectory;
    ArchiveCompressionLevel compressionLevel;
  };
```

Since: 2.3

#### Dictionary members

DOMString destination Path where *ArchiveFileEntry *should be stored in an archive file.

Since: 2.3

Remark: If destination is not set, then the root directory of archive will be used (equivalent to destination = "" ).

boolean stripSourceDirectory Controls whether leading directory information is stripped from the source file name before storing.

The virtual root is always removed.
To omit all the remaining directory names, set *stripSourceDirectory *to true .

| Source file name | Target file name when *destination *is "mypackage" |
| --- | --- |
| stripSourceDirectory: true | stripSourceDirectory: false |
| documents/tizen/archive/example/test.js | mypackage/test.js | mypackage/tizen/archive/example/test.js |
| wgt-private/test/js/main.js | mypackage/main.js | mypackage/test/js/main.js |
| downloads/test.c | mypackage/test.c | mypackage/test.c |

Since: 2.3

Remark: The default value is false .

ArchiveCompressionLevel compressionLevel Compression level.

Since: 2.3

Remark: The default compression level is NORMAL .

### 2.4. ArchiveManager

The ArchiveManager interface provides methods for global operations related to ArchiveFile.

```webidl
  [NoInterfaceObject] interface ArchiveManager {
    long open(FileReference file, FileMode mode, ArchiveFileSuccessCallback onsuccess, optional ErrorCallback? onerror,
              optional ArchiveFileOptions? options) raises(WebAPIException);
    void abort(long operationIdentifier) raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**open **`Opens the archive file. After this operation, it is possible to add or get files to and from the archive.

```javascript
long open(FileReference file, FileMode mode, ArchiveFileSuccessCallback onsuccess, optional ErrorCallback? onerror,
          optional ArchiveFileOptions? options);
```

Since: 2.3

The errorCallback is launched with these error types:

- InvalidValuesError: If archiveFile format is not recognized
- NotFoundError: If the *mode *is "r" and the *file *does not exist, or the *mode *is not "r" and the *file *cannot be created because the path of the file after excluding its file name does not exist
- IOError: If the access is denied due to insufficient permissions
- UnknownError: In case of any other error
Use *mode *depending on which operation are intended:

| Mode | Description |
| --- | --- |
| r | Use this mode for extracting or getting information about the contents of an archive file. 
*file *must exist. If the *file *does not exist, *onerror *will be invoked ( *NotFoundError *). 
When an archive file is opened in this mode, *add() *will not be available. ( *IOError *will be thrown.) |
| w | Use this mode to create an archive file and add files to the archive file. 
If *file *does not exist, it will be created. 
If *file *exists and the *overwrite *option is true , the existing file will be overwritten with empty archive. 
If *file *exists and the *overwrite *option is false , *onerror *callback will be invoked ( *InvalidModificationError *). 
When an archive file is opened in this mode, *getEntries() *, *getEntryByName() *, and *extractAll() *are not available. ( *IOError *will be thrown.) |
| rw | Use this mode for archive zipping/unzipping. 
If *file *does not exist, it will be created. 
If *file *exists and the *overwrite *option is true , the existing file will be overwritten with an empty archive. 
If *file *exists and the *overwrite *option is false , the existing contents are preserved.
Both adding and extracting will be available. |
| a | Use this mode to add new files to an archive file. 
If *file *does not exist, it will be created. 
If *file *exists, then the previous contents of the archive file are preserved and new files can be added to the archive file.
In this mode, *getEntries() *, *getEntryByName() *, and *extractAll() *are not available. ( *IOError *will be thrown.) |

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **file :
 File to open. **
- **mode :
 File mode for the opened archive. Determines which operations are available. **
- **onsuccess :
 Callback method to be invoked when archive is opened successfully. **
- **onerror [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **options [optional] [nullable] :
 Additional options for initializing the ArchiveFile instance. **

Return value:

long: Task ID which can be used to cancel the operation with abort().

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if parameter type does not match.

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
function successCallback(archive)
{
  console.log("Success, can now read from archive " + archive);
}

function errorCallback(error)
{
  console.log(error);
}

tizen.archive.open("downloads/some_archive.zip", "r", successCallback, errorCallback);
```

`**abort **`Cancels an operation with the given identifier.

```javascript
void abort(long operationIdentifier);
```

Since: 2.3

Parameters:

- **operationIdentifier :
 Task ID returned by an asynchronous function from this module. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
function openSuccess(archive)
{
  operationId = archive.extractAll("downloads/extracted");
  tizen.archive.abort(operationId);
}

tizen.archive.open("downloads/some_archive.zip", "r", openSuccess);
```

### 2.5. ArchiveFile

The ArchiveFile interface provides access to member files of the archive file.

```webidl
  interface ArchiveFile {
    readonly attribute FileMode mode;
    readonly attribute unsigned long long? decompressedSize;
    long add(FileReference sourceFile, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
             optional ArchiveFileProgressCallback? onprogress, optional ArchiveFileEntryOptions? options) raises(WebAPIException);
    long extractAll(FileReference destinationDirectory, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
                    optional ArchiveFileProgressCallback? onprogress, optional boolean? overwrite) raises(WebAPIException);
    long getEntries(ArchiveFileEntryArraySuccessCallback onsuccess, optional ErrorCallback? onerror) raises(WebAPIException);
    long getEntryByName(DOMString name, ArchiveFileEntrySuccessCallback onsuccess, optional ErrorCallback? onerror)
                        raises(WebAPIException);
    void close() raises(WebAPIException);
  };
```

Since: 2.3

#### Attributes

- readonly FileMode mode Describes the mode the file is opened with.

Since: 2.3

- readonly unsigned long long decompressedSize [nullable] Size of all the files included in the archive after decompression.

The size is null until the archive is opened.

Since: 2.3

#### Methods

`**add **`Adds a new member file to *ArchiveFile *.

```javascript
long add(FileReference sourceFile, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
         optional ArchiveFileProgressCallback? onprogress, optional ArchiveFileEntryOptions? options);
```

Since: 2.3

If *sourceFile *refers to a directory,
the directory and its content will be added to ArchiveFile.

The errorCallback is launched with these error types:

- NotFoundError: If the given *sourceFile *does not exist
- IOError: If archiveFile can not be written due the lack of access permission
- InvalidModificationError: If the operation results in a name conflict in the archive 
i.e. two entries in the archive with the same name (including directory names).
- UnknownError: In any case of any other error
Name stored for new entries is constructed from *sourceFile *according to the stripSourceDirectory and destination options. Names are constructed as follows:

| source file | destination | stripSourceDirectory | resulting entry name |
| --- | --- | --- | --- |
| documents/subdir/second/justName.ext | *(empty) * | false | subdir/second/justName.ext |
| documents/subdir/second/justName.ext | *(empty) * | true | justName.ext |
| documents/subdir/justName.ext | "report3" | false | report3/subdir/justName.ext |
| documents/subdir/justName.ext | "report3" | true | report3/justName.ext |

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **sourceFile :
 File or directory to be added to archive. **
- **onsuccess [optional] [nullable] :
 Callback method to be invoked when this operation is completed successfully. **
- **onerror [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **onprogress [optional] [nullable] :
 Callback method to be invoked to notify about operation progress 
It is called every time a single source file has been completely added.
If the source file is big then the callback can also be called while the file is being processed.
- **options [optional] [nullable] :
 Additional options used to control how the sourceFile will be compressed and stored in the archive. **
Return value:

long: Task ID which can be used to cancel the operation with abort().

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if parameter is of the wrong type.

- with error type InvalidStateError, if ArchiveFile is not open.

- with error type InvalidAccessError, if the file mode is "r" .

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
function errorCallback(error)
{
  console.log(error);
}

function successCallback()
{
  console.log("done");
}

function progressCallback(opId, val, name)
{
  console.log("opId: " + opId + " with progress val: " + val);
}

function createSuccess(archive)
{
  archive.add("downloads/file.txt", successCallback, errorCallback, progressCallback);
}

tizen.archive.open("downloads/new_archive.zip", "w", createSuccess);
```

`**extractAll **`Extracts every file from this *ArchiveFile *to a given directory.

```javascript
long extractAll(FileReference destinationDirectory, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
                optional ArchiveFileProgressCallback? onprogress, optional boolean? overwrite);
```

Since: 2.3

All extracted files will be located in the given directory.

The overwrite attribute determines whether extracted files can overwrite existing files.

The errorCallback is launched with these error types:

- NotFoundError: If the given *destinationDirectory *does not exist
- IOError: If destinationDirectory can not be written to (e.g due to insufficient permissions)
- InvalidModificationError: If during extracting it is detected that an existing file would
have to be overwritten and the *overwrite *argument is false
- UnknownError: In any other error case

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **destinationDirectory :
 Directory where extracted files will be stored 
Specified as a virtual path or a *File *object representing a directory.
- **onsuccess [optional] [nullable] :
 Callback method to be invoked when an archive is extracted successfully. **
- **onerror [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **onprogress [optional] [nullable] :
 Callback method to be invoked while the extracting is in progress 
The onprogress callback is called at least once. It will be invoked for every extracted file.
- **overwrite [optional] [nullable] :
 Flag indicating whether to overwrite or keep the existing files with the same name in the destinationDirectory location when extracting an archive 
By default, this attribute is set to false .
Return value:

long: Task ID which can be used to cancel the operation with abort().

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if parameter is of the wrong type.

- with error type InvalidStateError, if ArchiveFile is not open.

- with error type InvalidAccessError, if the file mode is "w" or "a" .

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
function errorCallback(error)
{
  console.log(error);
}

function successCallback()
{
  console.log("done");
}

function progressCallback(opId, val, name)
{
  console.log(
      "extracting operation (: " + opId + ") is in progress (" + (val * 100).toFixed(1) + "%)");
}

function openSuccess(archive)
{
  archive.extractAll("music", successCallback, errorCallback, progressCallback);
}

tizen.archive.open("downloads/some_archive.zip", "r", openSuccess);
```

`**getEntries **`Retrieves information about the member files in *ArchiveFile *.

```javascript
long getEntries(ArchiveFileEntryArraySuccessCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 2.3

The errorCallback is launched with these error types:

- UnknownError: In case of any error

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 Callback method to be invoked when information about all the files in the archive is successfully retrieved. **
- **onerror [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Return value:

long: Task ID which can be used to cancel the operation with abort().

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if parameter is of the wrong type.

- with error type InvalidStateError, if ArchiveFile is not open.

- with error type InvalidAccessError, if the file mode is "w" or "a" .

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
function errorCallback(error)
{
  console.log(error);
}

function getEntriesSuccess(entries)
{
  console.log("Entries length: " + entries.length);
  for (var i = 0; i < entries.length; i++)
  {
    console.log(entries[i].name);
  }
}

function openSuccess(archive)
{
  archive.getEntries(getEntriesSuccess, errorCallback);
}

tizen.archive.open("downloads/some_archive.zip", "r", openSuccess, errorCallback);
```

`**getEntryByName **`Retrieves information about *ArchiveFileEntry *with the specified name in *ArchiveFile *.

```javascript
long getEntryByName(DOMString name, ArchiveFileEntrySuccessCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 2.3

The errorCallback is launched with these error types:

- NotFoundError: If *ArchiveFileEntry *with the specific name does not exist
- UnknownError: In case of any other error

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **name :
 Name of *ArchiveFileEntry *to extract. **
- **onsuccess :
 Callback method to be invoked when a file matched with the given name is found. **
- **onerror [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Return value:

long: Task ID which can be used to cancel the operation with abort().

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if parameter is of the wrong type.

- with error type InvalidStateError, if ArchiveFile is not opened.

- with error type InvalidAccessError, if the file mode is "w" or "a" .

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
function errorCallback(error)
{
  console.log(error);
}

function getEntrySuccess(entry)
{
  console.log("Entry: " + entry.name + " size: " + entry.size);
}

function openSuccess(archive)
{
  archive.getEntryByName("arch/my_file.txt", getEntrySuccess, errorCallback);
}

tizen.archive.open("downloads/some_archive.zip", "r", openSuccess);
```

`**close **`Closes the *ArchiveFile *.

```javascript
void close();
```

Since: 2.3

Call this method when the archive file is not used any more. Once you call this method, the archive file object will not be available and any further operation attempt results in an *InvalidStateError *. 
Calling *close() *on an archive file object which is already closed does not raise any exception.

Exceptions:

- WebAPIException
- with error type UnknownError, if any other error occurs.

### 2.6. ArchiveFileEntry

The ArchiveFileEntry interface provides access to ArchiveFile member information and file data.

```webidl
  interface ArchiveFileEntry {
    readonly attribute DOMString name;
    readonly attribute unsigned long long size;
    readonly attribute unsigned long long? compressedSize;
    readonly attribute Date modified;
    long extract(FileReference destinationDirectory, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
                 optional ArchiveFileProgressCallback? onprogress, optional boolean? stripName, optional boolean? overwrite)
                 raises(WebAPIException);
  };
```

Since: 2.3

#### Attributes

- readonly DOMString name Path identifying the member file of ArchiveFile. 
This is a full path with the directory and base name of the entry. Since: 2.3

- readonly unsigned long long size Original size of the member file [bytes].

If the ArchiveFileEntry member is a folder, the attribute value will be the sum of sizes of all files in this directory.

Since: 2.3

- readonly unsigned long long compressedSize [nullable] Amount of storage space used by the member file, which may be compressed, in ArchiveFile [bytes].

If ArchiveFileEntry member is a folder, the attribute will be sum of the sizes of all files in this directory.

Until a new entry is added to the archive, the compressedSize is null

Since: 2.3

- readonly Date modified Date and time stored with the member file.
This is usually the modification date of the file.

Since: 2.3

#### Methods

`**extract **`Extracts ArchiveFileEntry to the given location.

```javascript
long extract(FileReference destinationDirectory, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
             optional ArchiveFileProgressCallback? onprogress, optional boolean? stripName, optional boolean? overwrite);
```

Since: 2.3

The errorCallback is launched with these error types:

- NotFoundError: If the given *destinationDirectory *does not exist
- InvalidModificationError: If the file already exists and overwriting is not allowed
- IOError: If destinationDirectory can not be written to
- UnknownError: In case of any other error

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **destinationDirectory :
 Directory where extracted files will be stored 
Given as a virtual path or a *File *object representing a directory.
- **onsuccess [optional] [nullable] :
 Callback method to be invoked when an extract operation is completed. **
- **onerror [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **onprogress [optional] [nullable] :
 Callback method to be invoked while the extracting is in progress 
The onprogress callback is called at least once. It will be invoked for every extracted file.
- **stripName [optional] [nullable] :
 Flag which determines if directory name part of *ArchiveFileEntry *should be removed or preserved 
The default value is false . If it is true , use only base name (part after last slash) as a target path.
- **overwrite [optional] [nullable] :
 Flag which determines if it possible to overwrite files when the decompressed file already exists in this destination location 
The default value is false .
Return value:

long: Task ID which can be used to cancel the operation with abort().

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if parameter is of the wrong type.

- with error type InvalidValuesError, if directory parameter does not represent a directory.

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
function errorCallback(error)
{
  console.log(error);
}

function extractSuccessCallback()
{
  console.log("done");
}

function getEntrySuccess(entry)
{
  entry.extract("downloads/extract", extractSuccessCallback, errorCallback);
}

function openSuccess(archive)
{
  archive.getEntryByName("my_file.txt", getEntrySuccess, errorCallback);
}

tizen.archive.open("downloads/some_archive.zip", "r", openSuccess, errorCallback);
```

### 2.7. ArchiveFileSuccessCallback

The ArchiveFileSuccessCallback interface provides a SuccessCallback for the ArchiveManager::open() method.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileSuccessCallback {
    void onsuccess(ArchiveFile archive);
  };
```

Since: 2.3

#### Methods

`**onsuccess **`Called when the archive file with the given name is ready to use.

```javascript
void onsuccess(ArchiveFile archive);
```

Since: 2.3

Parameters:

- **archive :
 Archive file object. **

### 2.8. ArchiveFileEntrySuccessCallback

The ArchiveFileEntrySuccessCallback interface provides a SuccessCallback for the ArchiveFile::getEntryByName() method.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileEntrySuccessCallback {
    void onsuccess(ArchiveFileEntry entry);
  };
```

Since: 2.3

#### Methods

`**onsuccess **`Called when the file with the given name through getEntryByName() is found successfully.

```javascript
void onsuccess(ArchiveFileEntry entry);
```

Since: 2.3

Parameters:

- **entry :
 ArchiveFileEntry object representing the file found in ArchiveFile. **

### 2.9. ArchiveFileEntryArraySuccessCallback

The ArchiveFileEntryArraySuccessCallback interface provides a SuccessCallback for the ArchiveFile::getEntries() method.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileEntryArraySuccessCallback {
    void onsuccess(ArchiveFileEntry[] entries);
  };
```

Since: 2.3

#### Methods

`**onsuccess **`Called when all file entries in the archive file are retrieved successfully.

```javascript
void onsuccess(ArchiveFileEntry[] entries);
```

Since: 2.3

Parameters:

- **entries :
 List of ArchiveFileEntry objects found in ArchiveFile. **

### 2.10. ArchiveFileProgressCallback

The ArchiveFileProgressCallback interface provides a ProgressCallback for ArchiveFile and ArchiveFileEntry methods.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileProgressCallback {
    void onprogress(long operationIdentifier, double value, DOMString filename);
  };
```

Since: 2.3

#### Methods

`**onprogress **`Called to signal compressing or extracting operation progress.

```javascript
void onprogress(long operationIdentifier, double value, DOMString filename);
```

Since: 2.3

Parameters:

- **operationIdentifier :
 Operation identifier for which progress is reported. **
- **value :
 Progress of the operation, value between 0.0 and 1.0 where 1.0 is 100% progress. **
- **filename :
 Name of the compressed or extracted file. **

## 3. Full WebIDL

```webidl
module Archive {
  typedef (DOMString or File) FileReference;
  enum ArchiveCompressionLevel { "STORE", "FAST", "NORMAL", "BEST" };
  dictionary ArchiveFileOptions {
    boolean overwrite;
  };
  dictionary ArchiveFileEntryOptions {
    DOMString destination;
    boolean stripSourceDirectory;
    ArchiveCompressionLevel compressionLevel;
  };
  Tizen implements ArchiveManagerObject;
  [NoInterfaceObject] interface ArchiveManagerObject {
    readonly attribute ArchiveManager archive;
  };
  [NoInterfaceObject] interface ArchiveManager {
    long open(FileReference file, FileMode mode, ArchiveFileSuccessCallback onsuccess, optional ErrorCallback? onerror,
              optional ArchiveFileOptions? options) raises(WebAPIException);
    void abort(long operationIdentifier) raises(WebAPIException);
  };
  interface ArchiveFile {
    readonly attribute FileMode mode;
    readonly attribute unsigned long long? decompressedSize;
    long add(FileReference sourceFile, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
             optional ArchiveFileProgressCallback? onprogress, optional ArchiveFileEntryOptions? options) raises(WebAPIException);
    long extractAll(FileReference destinationDirectory, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
                    optional ArchiveFileProgressCallback? onprogress, optional boolean? overwrite) raises(WebAPIException);
    long getEntries(ArchiveFileEntryArraySuccessCallback onsuccess, optional ErrorCallback? onerror) raises(WebAPIException);
    long getEntryByName(DOMString name, ArchiveFileEntrySuccessCallback onsuccess, optional ErrorCallback? onerror)
                        raises(WebAPIException);
    void close() raises(WebAPIException);
  };
  interface ArchiveFileEntry {
    readonly attribute DOMString name;
    readonly attribute unsigned long long size;
    readonly attribute unsigned long long? compressedSize;
    readonly attribute Date modified;
    long extract(FileReference destinationDirectory, optional SuccessCallback? onsuccess, optional ErrorCallback? onerror,
                 optional ArchiveFileProgressCallback? onprogress, optional boolean? stripName, optional boolean? overwrite)
                 raises(WebAPIException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileSuccessCallback {
    void onsuccess(ArchiveFile archive);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileEntrySuccessCallback {
    void onsuccess(ArchiveFileEntry entry);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileEntryArraySuccessCallback {
    void onsuccess(ArchiveFileEntry[] entries);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ArchiveFileProgressCallback {
    void onprogress(long operationIdentifier, double value, DOMString filename);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
