# DataControl API

This specification defines a Data Control API for applications.

The Data Control functionality provides a way to access specific data that is exported by other applications.

Please read the Data Control guide to know how to share own application data with other applications.

Since: 2.4

## Table of Contents

- 1. Type Definitions
- 1.1. DataType
- 1.2. EventType
- 2. Interfaces
- 2.1. DataControlManagerObject
- 2.2. DataControlManager
- 2.3. DataControlConsumerObject
- 2.4. SQLDataControlConsumer
- 2.5. MappedDataControlConsumer
- 2.6. DataControlSuccessCallback
- 2.7. DataControlErrorCallback
- 2.8. DataControlInsertSuccessCallback
- 2.9. DataControlSelectSuccessCallback
- 2.10. DataControlGetValueSuccessCallback
- 2.11. DataControlChangeCallback
- 2.12. RowData
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| DataControlManagerObject |  |
| DataControlManager | DataControlConsumerObject getDataControlConsumer (DOMString providerId, DOMString dataId, DataType type) |
| DataControlConsumerObject | long addChangeListener ( DataControlChangeCallback dataChangeCallback, optional ErrorCallback ? errorCallback) void removeChangeListener (long watchId) |
| SQLDataControlConsumer | void insert (unsigned long reqId, RowData insertionData, optional DataControlInsertSuccessCallback ? successCallback, optional DataControlErrorCallback ? errorCallback) void update (unsigned long reqId, RowData updateData, DOMString where, optional DataControlSuccessCallback ? successCallback, optional DataControlErrorCallback ? errorCallback) void remove (unsigned long reqId, DOMString where, optional DataControlSuccessCallback ? successCallback, optional DataControlErrorCallback ? errorCallback) void select (unsigned long reqId, DOMString[] columns, DOMString where, DataControlSelectSuccessCallback successCallback, optional DataControlErrorCallback ? errorCallback, optional unsigned long? page, optional unsigned long? maxNumberPerPage, optional DOMString? order) |
| MappedDataControlConsumer | void addValue (unsigned long reqId, DOMString key, DOMString value, optional DataControlSuccessCallback ? successCallback, optional DataControlErrorCallback ? errorCallback) void removeValue (unsigned long reqId, DOMString key, DOMString value, DataControlSuccessCallback successCallback, optional DataControlErrorCallback ? errorCallback) void getValue (unsigned long reqId, DOMString key, DataControlGetValueSuccessCallback successCallback, optional DataControlErrorCallback ? errorCallback) void updateValue (unsigned long reqId, DOMString key, DOMString oldValue, DOMString newValue, DataControlSuccessCallback successCallback, optional DataControlErrorCallback ? errorCallback) |
| DataControlSuccessCallback | void onsuccess (unsigned long reqId) |
| DataControlErrorCallback | void onerror (unsigned long reqId, WebAPIError error) |
| DataControlInsertSuccessCallback | void onsuccess (unsigned long reqId, long insertRowId) |
| DataControlSelectSuccessCallback | void onsuccess ( RowData [] rows, unsigned long reqId) |
| DataControlGetValueSuccessCallback | void onsuccess (DOMString[] values, unsigned long reqid) |
| DataControlChangeCallback | void onsuccess ( EventType type, RowData data) |
| RowData |  |

## 1. Type Definitions

### 1.1. DataType

Data types.

```webidl
  enum DataType { "MAP", "SQL" };
```

Since: 2.4

- MAP - corresponds to map data type
- SQL - corresponds to SQL data type

### 1.2. EventType

Specifies the data change event types. The possible values are:

```webidl
  enum EventType { "SQL_UPDATE", "SQL_INSERT", "SQL_DELETE", "MAP_SET", "MAP_ADD", "MAP_REMOVE" };
```

Since: 4.0

- SQL_UPDATE - SQL update event
- SQL_INSERT - SQL insert event
- SQL_DELETE - SQL delete event
- MAP_SET - Map update event
- MAP_ADD - Map add event
- MAP_REMOVE - Map remove event

## 2. Interfaces

### 2.1. DataControlManagerObject

Defines what is instantiated in the *Tizen *object.

```webidl
  [NoInterfaceObject] interface DataControlManagerObject {
    readonly attribute DataControlManager datacontrol;
  };
```

```webidl
  Tizen implements DataControlManagerObject;
```

Since: 2.4

The *tizen.datacontrol *object allows access to the
Data Control API.

#### Attributes

- readonly DataControlManager datacontrol Object representing a data control manager.

Since: 2.4

### 2.2. DataControlManager

This interface provides access to the *DataControlManager *object.

```webidl
  [NoInterfaceObject] interface DataControlManager {
    DataControlConsumerObject getDataControlConsumer(DOMString providerId, DOMString dataId, DataType type) raises(WebAPIException);
  };
```

Since: 2.4

#### Methods

`**getDataControlConsumer **`Gets *DataControlConsumerObject *with a given DataType.

```javascript
DataControlConsumerObject getDataControlConsumer(DOMString providerId, DOMString dataId, DataType type);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **providerId :
 A provider ID to use, which should be shared between the DataControl provider and DataControl consumer. **
- **dataId :
 A string for identifying specific data. **
- **type :
 The DataType to use. **

Return value:

DataControlConsumerObject: The local *DataControlConsumerObject *.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* The data provider, a native application, should be pre-installed and launched. */
/* The same provider ID should be defined for the use of this API between a native */
/* application(provider) and a web application(consumer). */
/* In this example, the DictionaryDataControlProvider native sample application is used as a data */
/* control provider. */

/* Gets SQL type DataControlConsumerObject. */
try
{
  var globalSQLConsumer = tizen.datacontrol.getDataControlConsumer(
      "http://tizen.org/datacontrol/provider/DictionaryDataControlProvider", "Dictionary", "SQL");
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
/* Gets MAP type DataControlConsumerObject. */
try
{
  globalMappedConsumer = tizen.datacontrol.getDataControlConsumer(
      "http://tizen.org/datacontrol/provider/DictionaryDataControlProvider", "Dictionary", "MAP");
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

### 2.3. DataControlConsumerObject

This interface provides common attributes and methods for other derived DataControlConsumerObject.

```webidl
  [NoInterfaceObject] interface DataControlConsumerObject {
    readonly attribute DataType type;
    readonly attribute DOMString providerId;
    readonly attribute DOMString dataId;
    long addChangeListener(DataControlChangeCallback dataChangeCallback, optional ErrorCallback? errorCallback)
                           raises(WebAPIException);
    void removeChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 2.4

#### Attributes

- readonly DataType type An attribute to store the DataType.

Since: 2.4

- readonly DOMString providerId An attribute to hold a provider identifier of the application with whom it shares the DataControl.
This attribute should be known to users who want to interact with the application.

Since: 2.4

- readonly DOMString dataId The dataId identifies specific data, usually a database table to process(insert, delete, update).
The string consists of one or more components, separated by a slash("/").

Since: 2.4

#### Methods

`**addChangeListener **`Adds a listener to receive notifications about provider data changes.

```javascript
long addChangeListener(DataControlChangeCallback dataChangeCallback, optional ErrorCallback? errorCallback);
```

Since: 4.0

The *ErrorCallback *method is launched with these error types:

- IOError - If a DB operation has failed.

Privilege level: public

Privilege: http://tizen.org/privilege/datasharing

Privilege: http://tizen.org/privilege/appmanager.launch

Remark: To monitor DataControl provider data changes, it is not enough to implement a listener in the DataControl consumer. You also need to implement the data change sending functionality in the DataControl provider.
The data sending implementation determines the actual change data returned to the DataControl consumer. For more information on the DataControl provider implementation, see Monitoring Data Changes .

Parameters:

- **dataChangeCallback :
 Callback method to be invoked when received data changed notification from provider application. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked if provider changes cannot be watched. **

Return value:

long: An identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter
is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type ServiceNotAvailableError, if the application could not connect with the provider.

Code example:

```javascript
var watcherId = 0;

function dataChangeSuccessCallback(eventType, rowData)
{
  console.log("Operation " + eventType + " was performed");
  console.log("Data changed: ");
  for (var i = 0; i < rowData.columns.length; i++)
  {
    console.log("Column " + rowData.columns[i] + " value " + rowData.values[i]);
  }
}

function errorCallback(error)
{
  console.log("The following error occurred: " + error.name);
}

try
{
  var rowData = {columns: ["WORD", "WORD_DESC"], values: ["'tizen1'", "'tizen2'"]};

  watcherId = globalSQLConsumer.addChangeListener(dataChangeSuccessCallback, errorCallback);
  console.log("Change listener has been added with watchId = " + watcherId);

  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalSQLConsumer.insert(globalReqId, rowData);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Change listener has been added with watchId = 1
Operation SQL_INSERT was performed
Data changed:
column WORD value 'tizen1'
column WORD_DESC value 'tizen2'
```

`**removeChangeListener **`Removes data change listener.

```javascript
void removeChangeListener(long watchId);
```

Since: 4.0

If the watchId argument is valid and corresponds to a subscription already in
place, the watch process must immediately stop and no further callbacks must be
invoked. If the watchId argument is not valid or does not correspond to a
valid subscription, the method should return without any further action.

Privilege level: public

Privilege: http://tizen.org/privilege/datasharing

Privilege: http://tizen.org/privilege/appmanager.launch

Parameters:

- **watchId :
 Subscription identifier. **

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type IOError, if a DB operation has failed.

Code example:

```javascript
var watcherId = 0;

function dataChangeSuccessCallback(type, rowData)
{
  console.log("Operation " + type + " was performed");
  console.log("Data changed: ");
  for (var i = 0; i < rowData.columns.length; i++)
  {
    console.log("Column " + rowData.columns[i] + " value " + rowData.values[i]);
  }
}

try
{
  var rowData = {columns: ["WORD", "WORD_DESC"], values: ["'tizen1'", "'tizen2'"]};

  watcherId = globalSQLConsumer.addChangeListener(dataChangeSuccessCallback);
  console.log("Change listener has been added with watchId = " + watcherId);

  /* Removes addChangeListener. */
  globalSQLConsumer.removeChangeListener(watcherId);
  console.log("RemoveChangeListener was invoked");

  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalSQLConsumer.insert(globalReqId, rowData);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Change listener has been added with watchId = 1
removeChangeListener was invoked
```

### 2.4. SQLDataControlConsumer

This interface defines SQL data type operators.

```webidl
  [NoInterfaceObject] interface SQLDataControlConsumer : DataControlConsumerObject {
    void insert(unsigned long reqId, RowData insertionData, optional DataControlInsertSuccessCallback? successCallback,
                optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void update(unsigned long reqId, RowData updateData, DOMString where, optional DataControlSuccessCallback? successCallback,
                optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void remove(unsigned long reqId, DOMString where, optional DataControlSuccessCallback? successCallback,
                optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void select(unsigned long reqId, DOMString[] columns, DOMString where, DataControlSelectSuccessCallback successCallback,
                optional DataControlErrorCallback? errorCallback, optional unsigned long? page,
                optional unsigned long? maxNumberPerPage, optional DOMString? order) raises(WebAPIException);
  };
```

Since: 2.4

#### Methods

`**insert **`Inserts new rows into a table owned by an SQL-type data control provider.

```javascript
void insert(unsigned long reqId, RowData insertionData, optional DataControlInsertSuccessCallback? successCallback,
            optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **insertionData :
 The data on columns and values to insert. **
- **successCallback [optional] [nullable] :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function successcb(id, insertRowId)
{
  console.log("Ok: reqid " + id);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  var rowData = {columns: ["WORD", "WORD_DESC"], values: ["'tizen1'", "'tizen2'"]};

  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalSQLConsumer.insert(globalReqId, rowData, successcb, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**update **`Updates values of a table owned by an SQL-type data control provider.

```javascript
void update(unsigned long reqId, RowData updateData, DOMString where, optional DataControlSuccessCallback? successCallback,
            optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **updateData :
 The data on columns and values to update. **
- **where :
 A filter to select desired rows to update. 
It is an SQL WHERE clause excluding the WHERE itself such as column1 = 'stringValue' AND column2 = numericValue .
- **successCallback [optional] [nullable] :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function successcb(id)
{
  console.log("Ok: reqid " + id);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  var rowData = {columns: ["WORD", "WORD_DESC"], values: ["'tizen1'", "'Web apps platform!'"]};

  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalSQLConsumer.update(globalReqId, rowData, "WORD='tizen1'", successcb, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**remove **`Delete rows from a table that is owned by an SQL-type data control provider.

```javascript
void remove(unsigned long reqId, DOMString where, optional DataControlSuccessCallback? successCallback,
            optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **where :
 A filter to select desired rows to remove. 
It is an SQL WHERE clause excluding the WHERE itself such as column1 = 'stringValue' AND column2 = numericValue .
- **successCallback [optional] [nullable] :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function successcb(id)
{
  console.log("Ok: reqid " + id);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  /* Defines globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalSQLConsumer.remove(globalReqId, "WORD='tizen1'", successcb, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**select **`Selects the specified columns to be queried. The result set of the specified columns is retrieved from a table owned by an SQL-type data control provider.

```javascript
void select(unsigned long reqId, DOMString[] columns, DOMString where, DataControlSelectSuccessCallback successCallback,
            optional DataControlErrorCallback? errorCallback, optional unsigned long? page,
            optional unsigned long? maxNumberPerPage, optional DOMString? order);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Remark: *order *is supported since Tizen 3.0

Remark: If *page *and *maxNumberPerPage *parameters are not specified and result set contains more than 20 rows, only first 20 rows are included in the result.

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **columns :
 The columns to select. **
- **where :
 A filter to select desired rows. 
It is an SQL WHERE clause excluding the WHERE itself such as column1 = 'stringValue' AND column2 = numericValue .
- **successCallback :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
- **page [optional] [nullable] :
 The page number of the result set. 
It starts from 1 . If the number is out of page, DataControlSelectSuccessCallback is invoked with no result data.
- **maxNumberPerPage [optional] [nullable] :
 The maximum number of rows on a page. The maximum allowed value is equal to 1024 . **
- **order [optional] [nullable] :
 The sorting order of the selected rows. 
It is an SQL ORDER BY clause excluding the ORDER BY itself such as column1, column2 ASC . If it is set to null, the order in which the rows are returned is undefined.
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function getValueSuccessCB(result, id)
{
  console.log("getValueSuccessCB result.length: " + result.length);
  var length = result.length;
  for (var i = 0; i < length; i++)
  {
    var rowData = "| ";
    var j = 0;
    for (j = 0; j < result[i].columns.length; j++)
    {
      rowData += "column: " + result[i].columns[j] + ", value: " + result[i].values[j] + " | ";
    }
    console.log(rowData);
  }
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  /* globalSQLConsumer and globalReqId should be defined before. */
  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  var columns = ["WORD", "WORD_DESC"];
  var whereClause = "1";
  console.log("----- Calling for ascending order -----");
  globalSQLConsumer.select(
      globalReqId, columns, whereClause, getValueSuccessCB, errorcb, null, null, "WORD_DESC ASC");
  setTimeout(function()
  {
    console.log("----- Calling descending order -----");
    globalSQLConsumer.select(globalReqId, columns, whereClause, getValueSuccessCB, errorcb, null,
        null, "WORD_DESC DESC");
  }, 1000);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

### 2.5. MappedDataControlConsumer

This interface defines MAP data type operators.

```webidl
  [NoInterfaceObject] interface MappedDataControlConsumer : DataControlConsumerObject {
    void addValue(unsigned long reqId, DOMString key, DOMString value, optional DataControlSuccessCallback? successCallback,
                  optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void removeValue(unsigned long reqId, DOMString key, DOMString value, DataControlSuccessCallback successCallback,
                     optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void getValue(unsigned long reqId, DOMString key, DataControlGetValueSuccessCallback successCallback,
                  optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void updateValue(unsigned long reqId, DOMString key, DOMString oldValue, DOMString newValue,
                     DataControlSuccessCallback successCallback, optional DataControlErrorCallback? errorCallback)
                     raises(WebAPIException);
  };
```

Since: 2.4

#### Methods

`**addValue **`Adds the value associated with the specified key to a key-values map owned by a MAP-type data control provider.

```javascript
void addValue(unsigned long reqId, DOMString key, DOMString value, optional DataControlSuccessCallback? successCallback,
              optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **key :
 The key to search mapped data. **
- **value :
 The value to add into a values array mapped by the key. **
- **successCallback [optional] [nullable] :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function successcb(id)
{
  console.log("Ok: reqid " + id);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalMappedConsumer.addValue(globalReqId, "tizen", "Foo", successcb, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**removeValue **`Removes the value associated with the specified key from a key-values map owned by a MAP-type data control provider.

```javascript
void removeValue(unsigned long reqId, DOMString key, DOMString value, DataControlSuccessCallback successCallback,
                 optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **key :
 The key to search mapped data. **
- **value :
 The value to remove from a values array mapped by the key. **
- **successCallback :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type NotFoundError, if the key cannot be found.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function successcb(id)
{
  console.log("Ok: reqid " + id);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  /* Defines globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalMappedConsumer.removeValue(globalReqId, "tizen", "Foo", successcb, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**getValue **`Gets the value associated with the specified key, from a key-values map owned by a MAP-type data control provider.

```javascript
void getValue(unsigned long reqId, DOMString key, DataControlGetValueSuccessCallback successCallback,
              optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **key :
 The key to search mapped data. **
- **successCallback :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type NotFoundError, if the key cannot be found.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function getValueSuccessCB(result, id)
{
  console.log(result.length + ": " + result[0]);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalMappedConsumer.getValue(globalReqId, "tizen", getValueSuccessCB, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**updateValue **`Sets the value associated with the specified key to a new value.

```javascript
void updateValue(unsigned long reqId, DOMString key, DOMString oldValue, DOMString newValue,
                 DataControlSuccessCallback successCallback, optional DataControlErrorCallback? errorCallback);
```

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/datacontrol.consumer

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So a developer should increase the *reqId *value to ensure it is unique for each method.
- **key :
 The key to search mapped data. **
- **oldValue :
 The value to update in a values array mapped by the key. **
- **newValue :
 The new value to replace in a values array mapped by the key. **
- **successCallback :
 The method to invoke when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the parameter type is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type NotFoundError, if the key cannot be found.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function successcb(id)
{
  console.log("Ok: reqid " + id);
}

function errorcb(id, error)
{
  console.log("Error id: " + id + ", error msg: " + error.message);
}

try
{
  /* Define globalReqId before. */

  /* Increases globalReqId for uniqueness. */
  globalReqId++;
  globalMappedConsumer.updateValue(globalReqId, "tizen", "Foo", "Bar", successcb, errorcb);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

### 2.6. DataControlSuccessCallback

This interface provides a SuccessCallback for DataControlConsumerObject.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlSuccessCallback {
    void onsuccess(unsigned long reqId);
  };
```

Since: 2.4

#### Methods

`**onsuccess **`Called on success.

```javascript
void onsuccess(unsigned long reqId);
```

Since: 2.4

Parameters:

- **reqId :
 A unique identifier of the successful operation. **

### 2.7. DataControlErrorCallback

This interface provides an ErrorCallback for DataControlConsumerObject.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlErrorCallback {
    void onerror(unsigned long reqId, WebAPIError error);
  };
```

Since: 2.4

#### Methods

`**onerror **`Called on error.

```javascript
void onerror(unsigned long reqId, WebAPIError error);
```

Since: 2.4

Parameters:

- **reqId :
 A unique identifier of the failed operation. **
- **error :
 An error message. **

### 2.8. DataControlInsertSuccessCallback

This interface provides a SuccessCallback for *SQLDataControlConsumer.insert() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlInsertSuccessCallback {
    void onsuccess(unsigned long reqId, long insertRowId);
  };
```

Since: 2.4

#### Methods

`**onsuccess **`Called on success.

```javascript
void onsuccess(unsigned long reqId, long insertRowId);
```

Since: 2.4

Parameters:

- **reqId :
 A unique identifier for the current operation. 
So it is recommended to increase the *reqId *value every time to guarantee uniqueness.
- **insertRowId :
 The inserted row ID set by the data control provider if the specified providerResult is true , else -1 . **

### 2.9. DataControlSelectSuccessCallback

This interface provides a SuccessCallback for *SQLDataControlConsumer.select() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlSelectSuccessCallback {
    void onsuccess(RowData[] rows, unsigned long reqId);
  };
```

Since: 2.4

#### Methods

`**onsuccess **`Called on success.

```javascript
void onsuccess(RowData[] rows, unsigned long reqId);
```

Since: 2.4

Parameters:

- **rows :
 Rows of SQL selection results from another application. 
The array operation of rows would be different from general JavaScript array behavior depending on platform implementation. For example, *Array.isArray(rows) *returns false .
- **reqId :
 A unique identifier for the current operation. 
So it is recommended to increase the *reqId *value every time to guarantee uniqueness.

### 2.10. DataControlGetValueSuccessCallback

This interface provides a SuccessCallback for *MapDataControlConsumer.getValue() *.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlGetValueSuccessCallback {
    void onsuccess(DOMString[] values, unsigned long reqid);
  };
```

Since: 2.4

#### Methods

`**onsuccess **`Called on success.

```javascript
void onsuccess(DOMString[] values, unsigned long reqid);
```

Since: 2.4

Parameters:

- **values :
 A list of values assigned to the requested key. **
- **reqid :
 A unique identifier of the successful operation. **

### 2.11. DataControlChangeCallback

This interface provides a DataControlChangeCallback for addChangeListener method.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlChangeCallback {
    void onsuccess(EventType type, RowData data);
  };
```

Since: 4.0

#### Methods

`**onsuccess **`Called when the data is modified.

```javascript
void onsuccess(EventType type, RowData data);
```

Since: 4.0

Parameters:

- **type :
 A type of performed operation. **
- **data :
 Object with information of columns and values of changed data. Actual data to be returned depends on data returned by data control provider application. Please refer to native documentation. **

### 2.12. RowData

The dictionary represents RowData holding 1 row of SQL selection results from another application.

```webidl
  dictionary RowData {
    DOMString[] columns;
    DOMString[] values;
  };
```

Since: 2.4

#### Dictionary members

DOMString[] columns An attribute to hold column names to select, update, and insert.

Since: 2.4

DOMString[] values An attribute to hold values of columns to select, update, and insert.

Since: 2.4

## 3. Full WebIDL

```webidl
module DataControl {
  enum DataType { "MAP", "SQL" };
  enum EventType { "SQL_UPDATE", "SQL_INSERT", "SQL_DELETE", "MAP_SET", "MAP_ADD", "MAP_REMOVE" };
  dictionary RowData {
    DOMString[] columns;
    DOMString[] values;
  };
  Tizen implements DataControlManagerObject;
  [NoInterfaceObject] interface DataControlManagerObject {
    readonly attribute DataControlManager datacontrol;
  };
  [NoInterfaceObject] interface DataControlManager {
    DataControlConsumerObject getDataControlConsumer(DOMString providerId, DOMString dataId, DataType type) raises(WebAPIException);
  };
  [NoInterfaceObject] interface DataControlConsumerObject {
    readonly attribute DataType type;
    readonly attribute DOMString providerId;
    readonly attribute DOMString dataId;
    long addChangeListener(DataControlChangeCallback dataChangeCallback, optional ErrorCallback? errorCallback)
                           raises(WebAPIException);
    void removeChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface SQLDataControlConsumer : DataControlConsumerObject {
    void insert(unsigned long reqId, RowData insertionData, optional DataControlInsertSuccessCallback? successCallback,
                optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void update(unsigned long reqId, RowData updateData, DOMString where, optional DataControlSuccessCallback? successCallback,
                optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void remove(unsigned long reqId, DOMString where, optional DataControlSuccessCallback? successCallback,
                optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void select(unsigned long reqId, DOMString[] columns, DOMString where, DataControlSelectSuccessCallback successCallback,
                optional DataControlErrorCallback? errorCallback, optional unsigned long? page,
                optional unsigned long? maxNumberPerPage, optional DOMString? order) raises(WebAPIException);
  };
  [NoInterfaceObject] interface MappedDataControlConsumer : DataControlConsumerObject {
    void addValue(unsigned long reqId, DOMString key, DOMString value, optional DataControlSuccessCallback? successCallback,
                  optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void removeValue(unsigned long reqId, DOMString key, DOMString value, DataControlSuccessCallback successCallback,
                     optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void getValue(unsigned long reqId, DOMString key, DataControlGetValueSuccessCallback successCallback,
                  optional DataControlErrorCallback? errorCallback) raises(WebAPIException);
    void updateValue(unsigned long reqId, DOMString key, DOMString oldValue, DOMString newValue,
                     DataControlSuccessCallback successCallback, optional DataControlErrorCallback? errorCallback)
                     raises(WebAPIException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlSuccessCallback {
    void onsuccess(unsigned long reqId);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlErrorCallback {
    void onerror(unsigned long reqId, WebAPIError error);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlInsertSuccessCallback {
    void onsuccess(unsigned long reqId, long insertRowId);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlSelectSuccessCallback {
    void onsuccess(RowData[] rows, unsigned long reqId);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlGetValueSuccessCallback {
    void onsuccess(DOMString[] values, unsigned long reqid);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DataControlChangeCallback {
    void onsuccess(EventType type, RowData data);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
