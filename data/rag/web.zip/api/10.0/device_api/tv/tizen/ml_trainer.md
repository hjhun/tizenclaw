# Trainer API

The Machine Learning Trainer API provides functionality for training neural network models.

**Remark: **In order to access files, a proper privilege has to be defined additionally:

- for accessing only internal storage using this API, a privilege http://tizen.org/privilege/mediastorage must be provided.
- for accessing only external storage using this API, a privilege http://tizen.org/privilege/externalstorage must be provided.
- for accessing internal and external storage using this API, privileges http://tizen.org/privilege/mediastorage and http://tizen.org/privilege/externalstorage must be provided.

Since: 7.0

## Table of Contents

- 1. Type Definitions
- 1.1. OptimizerType
- 1.2. DatasetMode
- 1.3. LayerType
- 1.4. VerbosityLevel
- 1.5. SaveFormat
- 2. Interfaces
- 2.1. MachineLearningTrainer
- 2.2. Layer
- 2.3. Optimizer
- 2.4. Dataset
- 2.5. CompileOptions
- 2.6. RunOptions
- 2.7. Model
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| MachineLearningTrainer | Layer createLayer ( LayerType type) Dataset createFileDataset ( Path train, optional Path ? validate, optional Path test) Optimizer createOptimizer ( OptimizerType type) Model createModel (optional Path configPath) |
| Layer | void setProperty (DOMString name, any value) void dispose () |
| Optimizer | void setProperty (DOMString name, any value) void dispose () |
| Dataset | void setProperty (DOMString name, any value, DatasetMode mode) void dispose () |
| CompileOptions |  |
| RunOptions |  |
| Model | void compile (optional CompileOptions ? options) void run ( RunOptions ? options, SuccessCallback successCallback, optional ErrorCallback ? errorCallback) DOMString summarize (optional VerbosityLevel ? level) void addLayer ( Layer layer) void setDataset ( Dataset dataset) void setOptimizer ( Optimizer optimizer) void saveToFile (DOMString path, SaveFormat format) void load (DOMString path, SaveFormat format) void dispose () |

## 1. Type Definitions

### 1.1. OptimizerType

Specifies type of Optimizer .

```webidl
  enum OptimizerType { "OPTIMIZER_ADAM", "OPTIMIZER_SGD", "OPTIMIZER_UNKNOWN" };
```

Since: 7.0

- OPTIMIZER_ADAM - Adam Optimizer
- OPTIMIZER_SGD - Stochastic Gradient Descent Optimizer
- OPTIMIZER_UNKNOWN - Unknown Optimizer

### 1.2. DatasetMode

Specifies mode of a Dataset selected for property setting.

```webidl
  enum DatasetMode { "MODE_TRAIN", "MODE_VALID", "MODE_TEST" };
```

Since: 7.0

- MODE_TRAIN - Refers to data used as a training part of Dataset
- MODE_VALID - Refers to data used as a validation part of Dataset
- MODE_TEST - Refers to data used as a test part of Dataset

### 1.3. LayerType

Specifies type of Layer .

```webidl
  enum LayerType { "LAYER_INPUT", "LAYER_FC", "LAYER_BN", "LAYER_CONV2D", "LAYER_POOLING2D", "LAYER_FLATTEN", "LAYER_ACTIVATION",
    "LAYER_ADDITION", "LAYER_CONCAT", "LAYER_MULTIOUT", "LAYER_EMBEDDING", "LAYER_RNN", "LAYER_LSTM", "LAYER_SPLIT", "LAYER_GRU",
    "LAYER_PERMUTE", "LAYER_DROPOUT", "LAYER_BACKBONE_NNSTREAMER", "LAYER_CENTROID_KNN", "LAYER_PREPROCESS_FLIP",
    "LAYER_PREPROCESS_TRANSLATE", "LAYER_PREPROCESS_L2NORM", "LAYER_LOSS_MSE", "LAYER_LOSS_CROSS_ENTROPY_SIGMOID",
    "LAYER_LOSS_CROSS_ENTROPY_SOFTMAX", "LAYER_UNKNOWN" };
```

Since: 7.0

- LAYER_INPUT - Input Layer type
- LAYER_FC - Fully Connected Layer type
- LAYER_BN - Batch Normalization Layer type
- LAYER_CONV2D - Convolution 2D Layer type
- LAYER_POOLING2D - Pooling 2D Layer type
- LAYER_FLATTEN - Flatten Layer type
- LAYER_ACTIVATION - Activation Layer type
- LAYER_ADDITION - Addition Layer type
- LAYER_CONCAT - Concat Layer type
- LAYER_MULTIOUT - Multi Output Layer type
- LAYER_EMBEDDING - Embedding Layer type
- LAYER_RNN - RNN Layer type
- LAYER_LSTM - LSTM Layer type
- LAYER_SPLIT - Split Layer type
- LAYER_GRU - GRU Layer type
- LAYER_PERMUTE - Permute Layer type
- LAYER_DROPOUT - Dropout Layer type
- LAYER_BACKBONE_NNSTREAMER - Backbone using NNStreamer
- LAYER_CENTROID_KNN - Centroid KNN Layer type
- LAYER_PREPROCESS_FLIP - Preprocess flip Layer type
- LAYER_PREPROCESS_TRANSLATE - Preprocess translate Layer type
- LAYER_PREPROCESS_L2NORM - Preprocess L2Normalization Layer type
- LAYER_LOSS_MSE - Mean Squared Error Loss Layer type
- LAYER_LOSS_CROSS_ENTROPY_SIGMOID - Cross Entropy with Sigmoid Loss Layer type
- LAYER_LOSS_CROSS_ENTROPY_SOFTMAX - Cross Entropy with Softmax Loss Layer type
- LAYER_UNKNOWN - Unknown

### 1.4. VerbosityLevel

Specifies the level of verbosity of the model summary.

```webidl
  enum VerbosityLevel { "SUMMARY_MODEL", "SUMMARY_LAYER", "SUMMARY_TENSOR" };
```

Since: 7.0

- SUMMARY_MODEL - Overview of model summary with one-line layer information
- SUMMARY_LAYER - Detailed model summary with layer properties
- SUMMARY_TENSOR - Model summary layer's including weight information

### 1.5. SaveFormat

Specifies the output file format of model saving operation

```webidl
  enum SaveFormat { "FORMAT_BIN", "FORMAT_INI", "FORMAT_INI_WITH_BIN" };
```

Since: 7.0

- FORMAT_BIN - Model saved in binary file
- FORMAT_INI - Model configuration saved in INI file
- FORMAT_INI_WITH_BIN - Model saved in two files, INI file contains configuration and reference to binary file

## 2. Interfaces

### 2.1. MachineLearningTrainer

The *MachineLearningTrainer *interface provides access to the Trainer API.

```webidl
  [NoInterfaceObject] interface MachineLearningTrainer {
    Layer createLayer(LayerType type) raises(WebAPIException);
    Dataset createFileDataset(Path train, optional Path? validate, optional Path test) raises(WebAPIException);
    Optimizer createOptimizer(OptimizerType type) raises(WebAPIException);
    Model createModel(optional Path configPath) raises(WebAPIException);
  };
```

Since: 7.0

#### Methods

`**createLayer **`Creates a neural network layer.

```javascript
Layer createLayer(LayerType type);
```

Since: 7.0

Parameters:

- **type :
 Type of the layer. **

Exceptions:

- WebAPIException
- with error type NotSupportedError, if the feature is not supported.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var l1 = tizen.ml.trainer.createLayer("LAYER_INPUT");
console.log("Type of layer: " + l1.type);
```

Output example:

```
Type of layer: LAYER_INPUT
```

`**createFileDataset **`Creates a dataset with files to feed to a neural network.

```javascript
Dataset createFileDataset(Path train, optional Path? validate, optional Path test);
```

Since: 7.0

Each file provided to the function should match format described in machine learning guide

Parameters:

- **train :
 Path for file with data for training. Check Filesystem API for more information about valid path in Tizen. **
- **validate [optional] [nullable] :
 Path for file with data for validating. Check Filesystem API for more information about valid path in Tizen. **
- **test [optional] :
 Path for file with data for testing. Check Filesystem API for more information about valid path in Tizen. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to access the storage. For more information, see Storage privileges .

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var trainsetFile = "documents/trainingSet.dat";
var validsetFile = "documents/valSet.dat";
var dataset = tizen.ml.trainer.createFileDataset(trainsetFile, validsetFile);
console.log("Type of dataset: " + dataset.type);
```

Output example:

```
Type of dataset: DATASET_FILE
```

`**createOptimizer **`Creates a neural network optimizer.

```javascript
Optimizer createOptimizer(OptimizerType type);
```

Since: 7.0

Parameters:

- **type :
 Type of the optimizer. **

Exceptions:

- WebAPIException
- with error type NotSupportedError, if the feature is not supported.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var opt = tizen.ml.trainer.createOptimizer("OPTIMIZER_ADAM");
console.log("Type of optimizer: " + opt.type);
```

Output example:

```
Type of optimizer: OPTIMIZER_ADAM
```

`**createModel **`Creates model basing on config file. If optional configPath is not provided, empty model is created.

```javascript
Model createModel(optional Path configPath);
```

Since: 7.0

See the Trainer Guide to learn about configuration file structure.

Even if the model is created from a file, switching, modifying, or setting a component is possible until you compile model with Model::compile .

Parameters:

- **configPath [optional] :
 Path to config file. Only INI formatted files *.ini are supported to create a model from a file. Check Filesystem API for more information about valid path in Tizen. **

Exceptions:

- WebAPIException
- with error type NotFoundError, if file does not exist.

- with error type SecurityError, if the application does not have the privilege to access the storage. For more information, see Storage privileges .

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var configFile = "documents/config.ini";
var m = tizen.ml.trainer.createModel(configFile);
console.log("Model with config:
" + m.summarize());

var m2 = tizen.ml.trainer.createModel();
console.log("Model without config:
" + m2.summarize());
```

Output example:

```
Model with config:
===================<N9nntrainer13NeuralNetworkE at 0xb8095df0>
graph contains 3 operation nodes
Model without config:
===================<N9nntrainer13NeuralNetworkE at 0xb8093f38>
graph contains 0 operation nodes
model is empty!
```

### 2.2. Layer

The *Layer *interface.

```webidl
  [NoInterfaceObject] interface Layer {
    readonly attribute DOMString name;
    readonly attribute LayerType type;
    void setProperty(DOMString name, any value) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
```

Since: 7.0

#### Attributes

- readonly DOMString name The name of the layer.

Name is unique to this layer in a model and might be changed once layer is added to the model to keep the name unique. name value can be changed using Layer::setProperty() method.

Since: 7.0

- readonly LayerType type The type of the layer.

Since: 7.0

#### Methods

`**setProperty **`Sets the value of layer's property.

```javascript
void setProperty(DOMString name, any value);
```

Since: 7.0

Properties available for every LayerType:

| Property name | Property type | Description |
| --- | --- | --- |
| name | (string) | An identifier for each layer |
| input_shape | (string) | Formatted string as dim 1 :dim 2 :dim 3 :dim 4 . 
First layer of the model must have input_shape. Other can be omitted as it is calculated at compile phase. |
| activation | (categorical) | Activation type |
|  | tanh | hyperbolic tangent |
|  | sigmoid | sigmoid function |
|  | relu | relu function |
|  | softmax | softmax function |
| weight_initializer | (categorical) | Weight initializer |
|  | zeros | Zero initialization |
|  | lecun_normal | LeCun Normal Initialization |
|  | lecun_uniform | LeCun Uniform Initialization |
|  | xavier_normal | Xavier Normal Initialization |
|  | xavier_uniform | Xavier Uniform Initialization |
|  | he_normal | He Normal Initialization |
|  | he_uniform | He Uniform Initialization |
| bias_initializer | (categorical) | Bias initializer, same category as weight_initializer |
| weight_regularizer | (categorical) | Weight regularizer |
|  | l2norm | L2 weight regularizer |
| weight_regularizer_constant | (double) | Weight regularizer constant |
| flatten | (boolean) | Flatten shape from c:h:w to 1:1:c*h*w |

Properties available only for *LAYER_INPUT *LayerType:

| Property name | Property type | Description |
| --- | --- | --- |
| normalization | (boolean) | Normalize input if true |
| standardization | (boolean) | Standardize input if true |

Properties available only for *LAYER_FC *LayerType:

| Property name | Property type | Description |
| --- | --- | --- |
| unit | (long) | number of outputs |

Parameters:

- **name :
 Name of the property. **
- **value :
 The new value of the property. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if the layer does not exist anymore.

Code example:

```javascript
var l1 = tizen.ml.trainer.createLayer("LAYER_INPUT");
l1.setProperty("input_shape", "1:1:62720");
console.log("Layer type: " + l1.type);
```

Output example:

```
Layer type: LAYER_INPUT
```

`**dispose **`Destroys layer object and releases the resources associated by the layer object.

```javascript
void dispose();
```

Since: 7.0

Layer will not be destroyed and function will throw exception if Layer is added to model. Such layer will be destroyed on Model disposal.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the layer does not exist anymore.

- with error type NoModificationAllowedError, if the layer is attached to a model.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
var l1 = tizen.ml.trainer.createLayer("LAYER_INPUT");
l1.dispose();
try
{
  m.addLayer(l1);
}
catch (e)
{
  console.log("Adding disposed layer will fail.");
}
```

Output example:

```
Adding disposed layer will fail.
```

### 2.3. Optimizer

The *Optimizer *interface.

```webidl
  [NoInterfaceObject] interface Optimizer {
    readonly attribute OptimizerType type;
    void setProperty(DOMString name, any value) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
```

Since: 7.0

#### Attributes

- readonly OptimizerType type The type of the optimizer.

Since: 7.0

#### Methods

`**setProperty **`Sets the value of optimizer's property.

```javascript
void setProperty(DOMString name, any value);
```

Since: 7.0

Properties available for all optimizers:

| Property name | Property type |
| --- | --- |
| learning_rate | float |

Properties available for SGD and Adam optimizers:

| Property name | Property type |
| --- | --- |
| decay_rate | float |
| decay_steps | float |

Optimizers use exponential decay type.

Properties available for Adam optimizers:

| Property name | Property type |
| --- | --- |
| beta1 | float |
| beta2 | float |
| epsilon | float |

Parameters:

- **name :
 Name of the property. **
- **value :
 The new value of the property. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if the optimizer does not exist anymore.

Code example:

```javascript
var opt = tizen.ml.trainer.createOptimizer("OPTIMIZER_ADAM");
opt.setProperty("learning_rate", "0.0001");
console.log("Optimizer type: " + opt.type);
```

Output example:

```
Optimizer type: OPTIMIZER_ADAM
```

`**dispose **`Destroys optimizer object and releases the resources associated by the optimizer object.

```javascript
void dispose();
```

Since: 7.0

Optimizer will not be destroyed and function will throw exception if optimizer is added to model. Such optimizer will be destroyed on Model disposal.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the optimizer does not exist anymore.

- with error type NoModificationAllowedError, if the optimizer is attached to a model.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
var opt = tizen.ml.trainer.createOptimizer("OPTIMIZER_ADAM");
opt.dispose();
try
{
  m.setOptimizer(opt);
}
catch (e)
{
  console.log("Setting disposed optimizer will fail.");
}
```

Output example:

```
Setting disposed optimizer will fail.
```

### 2.4. Dataset

The *Dataset *interface.

```webidl
  [NoInterfaceObject] interface Dataset {
    readonly attribute  type;
    void setProperty(DOMString name, any value, DatasetMode mode) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
```

Since: 7.0

#### Attributes

- readonly DatasetType type The type of the dataset.

Since: 7.0

#### Methods

`**setProperty **`Sets the value of dataset's property.

```javascript
void setProperty(DOMString name, any value, DatasetMode mode);
```

Since: 7.0

Properties available for all types of dataset:

| Property name | Description |
| --- | --- |
| buffer_size | Buffer size (unsigned long) |

Properties available only for file type dataset:

| Property name | Description |
| --- | --- |
| train_data | Path to training data |
| val_data | Path to validation data |
| test_data | Path to testing data |
| label_data | Path to label data |

Parameters:

- **name :
 Name of the property. **
- **value :
 The new value of the property. **
- **mode :
 The mode of dataset content for which property should be set **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if the dataset does not exist anymore.

Code example:

```javascript
var trainsetFile = "documents/trainingSet.dat";
var validsetFile = "documents/valSet.dat";
var dataset = tizen.ml.trainer.createFileDataset(trainsetFile, validsetFile);
dataset.setProperty("buffer_size", "100", "MODE_TRAIN");
console.log("Type of dataset: " + dataset.type);
```

Output example:

```
Type of dataset: DATASET_FILE
```

`**dispose **`Destroy dataset object and release associated resources

```javascript
void dispose();
```

Since: 7.0

Dataset will not be destroyed and function will throw exception if dataset is added to model. Such dataset will be destroyed on Model disposal.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the dataset does not exist anymore.

- with error type NoModificationAllowedError, if the dataset is attached to a model.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
var trainsetFile = "documents/trainingSet.dat";
var validsetFile = "documents/valSet.dat";
var dataset = tizen.ml.trainer.createFileDataset(trainsetFile, validsetFile);
dataset.dispose();
try
{
  m.setDataset(dataset);
}
catch (e)
{
  console.log("Setting disposed dataset will fail.");
}
```

Output example:

```
Setting disposed dataset will fail.
```

### 2.5. CompileOptions

The CompileOptions dictionary represents options for compiling the model.

```webidl
  dictionary CompileOptions {
    DOMString loss;
    unsigned long batch_size;
  };
```

Since: 7.0

#### Dictionary members

DOMString loss Loss function type. Available loss functions:

| Value | Description |
| --- | --- |
| "mse" | Mean Squared Error |
| "cross" | Cross Entropy (sigmoid/softmax depending of activation function of last layer) |

Since: 7.0

unsigned long batch_size Batch size.

Since: 7.0

Remark: This property can be redefined in run() stage using RunOptions.batch_size .

### 2.6. RunOptions

The RunOptions dictionary represents options for running model training.

```webidl
  dictionary RunOptions {
    unsigned long epochs;
    DOMString save_path;
    unsigned long batch_size;
  };
```

Since: 7.0

#### Dictionary members

unsigned long epochs Maximum epochs.

Since: 7.0

DOMString save_path Path to save trained model.

Since: 7.0

unsigned long batch_size Batch size.

Since: 7.0

Remark: This property can be provided on both compile() and run() stages.

### 2.7. Model

The *Model *interface.

```webidl
  [NoInterfaceObject] interface Model {
    void compile(optional CompileOptions? options) raises(WebAPIException);
    void run(RunOptions? options, SuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    DOMString summarize(optional VerbosityLevel? level) raises(WebAPIException);
    void addLayer(Layer layer) raises(WebAPIException);
    void setDataset(Dataset dataset) raises(WebAPIException);
    void setOptimizer(Optimizer optimizer) raises(WebAPIException);
    void saveToFile(DOMString path, SaveFormat format) raises(WebAPIException);
    void load(DOMString path, SaveFormat format) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
```

Since: 7.0

#### Methods

`**compile **`Compiles the model. Once compiled, any modification to the properties of model or layers/dataset/optimizer in the model will be restricted.
Further addition of layers or changing the optimizer/dataset of the model will not be permitted and will cause NoModificationAllowedError.

```javascript
void compile(optional CompileOptions? options);
```

Since: 7.0

Parameters:

- **options [optional] [nullable] :
 Hyperparameters for model training. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if model does not exist anymore.

- with error type NoModificationAllowedError, if the model is already compiled.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
/* assume that m is a valid model with all options set, not yet compiled */
var compileOpts = {loss: "cross", batch_size: "16"};
m.compile(compileOpts);
console.log("Compilation succeeded");
```

Output example:

```
Compilation succeeded
```

`**run **`Trains the neural network model.

```javascript
void run(RunOptions? options, SuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 7.0

The *ErrorCallback *method is called with an argument of type WebAPIException with an error:

- InvalidValuesError - if options contain an invalid value.
- NotFoundError - if the model does not exist anymore.
- InvalidStateError - if the model is not compiled.
- AbortError - if any other error occurs.

Parameters:

- **options [nullable] :
 Hyperparameters for model training. **
- **successCallback :
 Callback function to invoke when the training along with requested validation and testing completes successfully. **
- **errorCallback [optional] [nullable] :
 Callback function to invoke when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
/* assume that m is a valid, compiled model with all options set */
var runOpts = {epochs: 2, save_path: outputFile};
m.run(runOpts,
    function()
    {
      console.log("Training successful");
    },
    function(e)
    {
      console.log("error " + JSON.stringify(e));
    });
```

Output example:

```
Training successful
```

`**summarize **`Gets summary of the model.

```javascript
DOMString summarize(optional VerbosityLevel? level);
```

Since: 7.0

Parameters:

- **level [optional] [nullable] :
 Verbosity level of the summary.
- **Default value: **SUMMARY_MODEL .
**

Exceptions:

- WebAPIException
- with error type NotFoundError, if the model does not exist anymore.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
/* assume that m is a valid model with all options set */
console.log(m.summarize());
```

Output example:

```
===================<N9nntrainer13NeuralNetworkE at 0xb830b5d8>
graph contains 3 operation nodes
```

`**addLayer **`Adds layer to neural network model.

```javascript
void addLayer(Layer layer);
```

Since: 7.0

The layer is added to the end of the existing layers in the model.

Parameters:

- **layer :
 Layer to add. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if the model or the layer does not exist anymore.

- with error type NoModificationAllowedError, if the model is already compiled or model compilation or training is in progress.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
var l1 = tizen.ml.trainer.createLayer("LAYER_INPUT");
m.addLayer(l1);
console.log("Added layer: " + l1.type);
```

Output example:

```
Added layer: LAYER_INPUT
```

`**setDataset **`Sets the dataset (data provider) for the neural network model.

```javascript
void setDataset(Dataset dataset);
```

Since: 7.0

The dataset will provide training, validation and test data for the model.

Parameters:

- **dataset :
 Dataset to set. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if the model or the dataset does not exist anymore.

- with error type NoModificationAllowedError, if model compilation or training is in progress.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
var trainsetFile = "documents/trainingSet.dat";
var validsetFile = "documents/valSet.dat";
var m = tizen.ml.trainer.createModel();
var dataset = tizen.ml.trainer.createFileDataset(trainsetFile, validsetFile);
m.setDataset(dataset);
console.log("Set dataset: " + dataset.type);
```

Output example:

```
Set dataset: DATASET_FILE
```

`**setOptimizer **`Sets the optimizer for the neural network model.

```javascript
void setOptimizer(Optimizer optimizer);
```

Since: 7.0

Parameters:

- **optimizer :
 Optimizer to set. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotFoundError, if the model or the optimizer does not exist anymore.

- with error type NoModificationAllowedError, if the model is already compiled or model compilation or training is in progress.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
var opt = tizen.ml.trainer.createOptimizer("OPTIMIZER_ADAM");
m.setOptimizer(opt);
console.log("Set optimizer: " + opt.type);
```

Output example:

```
Set optimizer: OPTIMIZER_ADAM
```

`**saveToFile **`Saves model to file in selected format for future reuse

```javascript
void saveToFile(DOMString path, SaveFormat format);
```

Since: 7.0

Remark: Using FORMAT_INI_WITH_BIN creates two files: *.ini (containing parameters of a model) and *.bin (containing data of a learnt model)

Parameters:

- **path :
 Path to output file. If file already exists exception will be thrown **
- **format :
 Selected output format **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NoModificationAllowedError, if a destination file already exists or model compilation or training is in progress.

- with error type NotFoundError, if the model does not exist anymore.

- with error type SecurityError, if the application does not have the privilege to access the storage. For more information, see Storage privileges .

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
/* set all properties, add layers, set optimizer and dataset */
/* compile prepared model before saving */
m.saveToFile("documents/train_model.ini", "FORMAT_INI");
console.log("Successfully saved to file");
```

Output example:

```
Successfully saved to file
```

`**load **`Loads model from a file in selected format.

```javascript
void load(DOMString path, SaveFormat format);
```

Since: 7.0

Remark: Using FORMAT_INI_WITH_BIN requires two files: *.ini (containing parameters of a model) and *.bin (containing data of a learnt model). Loading of binary data is done during compilation of a model.

Parameters:

- **path :
 Path to file storing a model. If file does not exist exception will be thrown **
- **format :
 Selected file format **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotFoundError, if file does not exist or the model does not exist anymore.

- with error type NoModificationAllowedError, if model compilation or training is in progress.

- with error type SecurityError, if the application does not have the privilege to access the storage. For more information, see Storage privileges .

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if any internal error occurs.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
m.load("documents/train_model.ini", "FORMAT_INI_WITH_BIN");
console.log("Successfully loaded a model:");
console.log(m.summarize());
```

Output example:

```
Successfully loaded a model:
===================<N9nntrainer13NeuralNetworkE at 0xb8095df0>
graph contains 3 operation nodes
```

`**dispose **`Destroys model object and releases the resources associated by the model object.

```javascript
void dispose();
```

Since: 7.0

When model is disposed all attached objects (layers, dataset and optimizer) are also destroyed.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the model does not exist anymore.

- with error type NoModificationAllowedError, if model compilation or training is in progress.

Code example:

```javascript
var m = tizen.ml.trainer.createModel();
var l1 = tizen.ml.trainer.createLayer("LAYER_INPUT");
m.dispose();
try
{
  m.addLayer(l1);
}
catch (e)
{
  console.log("Adding layer to disposed model will fail.");
}
```

Output example:

```
Adding layer to disposed model will fail.
```

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the ML application runs on a device with the ML feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/machine_learning
To guarantee that the ML application runs on a device with the ML Trainer feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/machine_learning.training

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module Trainer {
  enum OptimizerType { "OPTIMIZER_ADAM", "OPTIMIZER_SGD", "OPTIMIZER_UNKNOWN" };
  enum DatasetMode { "MODE_TRAIN", "MODE_VALID", "MODE_TEST" };
  enum LayerType { "LAYER_INPUT", "LAYER_FC", "LAYER_BN", "LAYER_CONV2D", "LAYER_POOLING2D", "LAYER_FLATTEN", "LAYER_ACTIVATION",
    "LAYER_ADDITION", "LAYER_CONCAT", "LAYER_MULTIOUT", "LAYER_EMBEDDING", "LAYER_RNN", "LAYER_LSTM", "LAYER_SPLIT", "LAYER_GRU",
    "LAYER_PERMUTE", "LAYER_DROPOUT", "LAYER_BACKBONE_NNSTREAMER", "LAYER_CENTROID_KNN", "LAYER_PREPROCESS_FLIP",
    "LAYER_PREPROCESS_TRANSLATE", "LAYER_PREPROCESS_L2NORM", "LAYER_LOSS_MSE", "LAYER_LOSS_CROSS_ENTROPY_SIGMOID",
    "LAYER_LOSS_CROSS_ENTROPY_SOFTMAX", "LAYER_UNKNOWN" };
  enum VerbosityLevel { "SUMMARY_MODEL", "SUMMARY_LAYER", "SUMMARY_TENSOR" };
  enum SaveFormat { "FORMAT_BIN", "FORMAT_INI", "FORMAT_INI_WITH_BIN" };
  dictionary CompileOptions {
    DOMString loss;
    unsigned long batch_size;
  };
  dictionary RunOptions {
    unsigned long epochs;
    DOMString save_path;
    unsigned long batch_size;
  };
  [NoInterfaceObject] interface MachineLearningTrainer {
    Layer createLayer(LayerType type) raises(WebAPIException);
    Dataset createFileDataset(Path train, optional Path? validate, optional Path test) raises(WebAPIException);
    Optimizer createOptimizer(OptimizerType type) raises(WebAPIException);
    Model createModel(optional Path configPath) raises(WebAPIException);
  };
  [NoInterfaceObject] interface Layer {
    readonly attribute DOMString name;
    readonly attribute LayerType type;
    void setProperty(DOMString name, any value) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
  [NoInterfaceObject] interface Optimizer {
    readonly attribute OptimizerType type;
    void setProperty(DOMString name, any value) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
  [NoInterfaceObject] interface Dataset {
    readonly attribute  type;
    void setProperty(DOMString name, any value, DatasetMode mode) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
  [NoInterfaceObject] interface Model {
    void compile(optional CompileOptions? options) raises(WebAPIException);
    void run(RunOptions? options, SuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    DOMString summarize(optional VerbosityLevel? level) raises(WebAPIException);
    void addLayer(Layer layer) raises(WebAPIException);
    void setDataset(Dataset dataset) raises(WebAPIException);
    void setOptimizer(Optimizer optimizer) raises(WebAPIException);
    void saveToFile(DOMString path, SaveFormat format) raises(WebAPIException);
    void load(DOMString path, SaveFormat format) raises(WebAPIException);
    void dispose() raises(WebAPIException);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
