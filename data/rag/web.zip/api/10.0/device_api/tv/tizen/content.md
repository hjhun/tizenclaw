# Content API

The Content API provides functionality to discover content such as images, videos, music, or others.

It is possible to search for specific content using filters.
The API also supports setting the attributes of specific content.

**Remark: **In order to access files, a proper privilege has to be defined additionally:

- for accessing only internal storage using this API, a privilege http://tizen.org/privilege/mediastorage must be provided,
- for accessing only external storage using this API, a privilege http://tizen.org/privilege/externalstorage must be provided,
- for accessing internal and external storage using this API, privileges ( http://tizen.org/privilege/mediastorage and http://tizen.org/privilege/externalstorage ) must be provided.
For more information on the Content features, see Stored Content Management .

Since: 2.0

## Table of Contents

- 1. Type Definitions
- 1.1. ContentType
- 1.2. AudioContentLyricsType
- 1.3. ImageContentOrientation
- 1.4. ContentId
- 1.5. ContentDirectoryId
- 1.6. PlaylistId
- 2. Interfaces
- 2.1. ContentManagerObject
- 2.2. ContentManager
- 2.3. ContentArraySuccessCallback
- 2.4. ContentDirectoryArraySuccessCallback
- 2.5. ContentScanSuccessCallback
- 2.6. ContentChangeCallback
- 2.7. ContentDirectory
- 2.8. Content
- 2.9. VideoContent
- 2.10. AudioContentLyrics
- 2.11. AudioContent
- 2.12. ImageContent
- 2.13. PlaylistItem
- 2.14. Playlist
- 2.15. PlaylistArraySuccessCallback
- 2.16. PlaylistSuccessCallback
- 2.17. PlaylistItemArraySuccessCallback
- 2.18. ThumbnailSuccessCallback
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| ContentManagerObject |  |
| ContentManager | void getDirectories ( ContentDirectoryArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback) void find ( ContentArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback, optional ContentDirectoryId ? directoryId, optional AbstractFilter ? filter, optional SortMode ? sortMode, optional unsigned long? count, optional unsigned long? offset) void scanFile (DOMString contentURI, optional ContentScanSuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void scanDirectory (DOMString contentDirURI, boolean recursive, optional ContentScanSuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void cancelScanDirectory (DOMString contentDirURI) long addChangeListener ( ContentChangeCallback changeCallback) void removeChangeListener (long listenerId) void createThumbnail ( Content content, ThumbnailSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| ContentArraySuccessCallback | void onsuccess ( Content [] contents) |
| ContentDirectoryArraySuccessCallback | void onsuccess ( ContentDirectory [] directories) |
| ContentScanSuccessCallback | void onsuccess (DOMString uri) |
| ContentChangeCallback | void oncontentadded ( Content content) void oncontentupdated ( Content content) void oncontentremoved ( ContentId id) void oncontentdiradded ( ContentDirectory contentDir) void oncontentdirupdated ( ContentDirectory contentDir) void oncontentdirremoved ( ContentDirectoryId id) |
| ContentDirectory |  |
| Content |  |
| VideoContent |  |
| AudioContentLyrics |  |
| AudioContent |  |
| ImageContent |  |
| ThumbnailSuccessCallback | void onsuccess (DOMString path) |

## 1. Type Definitions

### 1.1. ContentType

Defines the type of content such as an image, video, audio, or any other.

```webidl
  enum ContentType { "IMAGE", "VIDEO", "AUDIO", "OTHER" };
```

Since: 2.0

- IMAGE - corresponds to image content.
- VIDEO - corresponds to video content.
- AUDIO - corresponds to audio content.
- OTHER - corresponds to other content.

Remark: "OTHER" type is added since Tizen 2.1 and since 4.0 it is optional type, related to http://tizen.org/feature/content.scanning.others feature.
One can check "OTHER" type support using systeminfo API with tizen.systeminfo.getCapability( *"http://tizen.org/feature/content.scanning.others" *).

### 1.2. AudioContentLyricsType

Defines whether the lyrics supplied with an audio file is time-synchronized.

```webidl
  enum AudioContentLyricsType { "SYNCHRONIZED", "UNSYNCHRONIZED" };
```

Since: 2.0

- SYNCHRONIZED - corresponds to synchronized audio content lyrics.
- UNSYNCHRONIZED - corresponds to unsynchronized audio content lyrics.

### 1.3. ImageContentOrientation

Defines the orientation of an image.

```webidl
  enum ImageContentOrientation { "NORMAL", "FLIP_HORIZONTAL", "ROTATE_180", "FLIP_VERTICAL", "TRANSPOSE", "ROTATE_90", "TRANSVERSE",
    "ROTATE_270" };
```

Since: 2.0

- NORMAL - corresponds to normal image content orientation.
- FLIP_HORIZONTAL - corresponds to horizontal flip image content orientation.
- ROTATE_180 - corresponds to rotate 180 degrees image content orientation.
- FLIP_VERTICAL - corresponds to vertical flip image content orientation.
- TRANSPOSE - corresponds to transpose image content orientation.
- ROTATE_90 - corresponds to rotate 90 degrees image content orientation.
- TRANSVERSE - corresponds to transverse image content orientation.
- ROTATE_270 - corresponds to rotate 270 degrees image content orientation.

### 1.4. ContentId

Content identifier.

```webidl
  typedef DOMString ContentId;
```

Since: 2.0

### 1.5. ContentDirectoryId

Content directory identifier.

```webidl
  typedef DOMString ContentDirectoryId;
```

Since: 2.0

### 1.6. PlaylistId

Playlist identifier.

**Deprecated. **Deprecated Since 9.0.

```webidl
  typedef DOMString PlaylistId;
```

Since: 2.3

## 2. Interfaces

### 2.1. ContentManagerObject

Defines what is instantiated by the Tizen object.

```webidl
  [NoInterfaceObject] interface ContentManagerObject {
    readonly attribute ContentManager content;
  };
```

```webidl
  Tizen implements ContentManagerObject;
```

Since: 2.0

The *tizen.content *object allows accessing the functionality of the Content module.

#### Attributes

- readonly ContentManager content Object representing a content manager.

Since: 2.0

### 2.2. ContentManager

The ContentManager interface provides operations to retrieve and manipulate content.

```webidl
  [NoInterfaceObject] interface ContentManager {
    void update(Content content) raises(WebAPIException);
    void updateBatch(Content[] contents, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                     raises(WebAPIException);
    void getDirectories(ContentDirectoryArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void find(ContentArraySuccessCallback successCallback, optional ErrorCallback? errorCallback,
              optional ContentDirectoryId? directoryId, optional AbstractFilter? filter, optional SortMode? sortMode,
              optional unsigned long? count, optional unsigned long? offset) raises(WebAPIException);
    void scanFile(DOMString contentURI, optional ContentScanSuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                  raises(WebAPIException);
    void scanDirectory(DOMString contentDirURI, boolean recursive, optional ContentScanSuccessCallback? successCallback,
                       optional ErrorCallback? errorCallback) raises(WebAPIException);
    void cancelScanDirectory(DOMString contentDirURI) raises(WebAPIException);
    long addChangeListener(ContentChangeCallback changeCallback) raises(WebAPIException);
    void removeChangeListener(long listenerId) raises(WebAPIException);
    void getPlaylists(PlaylistArraySuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void createPlaylist(DOMString name, PlaylistSuccessCallback successCallback, optional ErrorCallback? errorCallback,
                        optional Playlist? sourcePlaylist) raises(WebAPIException);
    void removePlaylist(PlaylistId id, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void createThumbnail(Content content, ThumbnailSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
  };
```

Since: 2.0

#### Methods

`**update **`Updates attributes of content in the content database synchronously.

**Deprecated. **Deprecated Since 9.0.

```javascript
void update(Content content);
```

Since: 2.0

When an application has changed some attributes of the content, this method allows
writing it back to the content database.

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Remark: The *editableAttributes *in the *Content *interface indicates
the attributes that can be changed.
This API does not support updating the metadata of a file.

Parameters:

- **content :
 The content to update. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter
is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any of the input parameters
contain an invalid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, in any other error case.

Code example:

```javascript
/* Assume the content is a Content object as a result of find method. */
/* Check if the isFavorite attribute is editable, and then set it as favorite. */
if (content.editableAttributes.indexOf("isFavorite") >= 0)
{
  content.isFavorite = true;
}
tizen.content.update(content);
```

`**updateBatch **`Updates a batch of content attributes in the content database asynchronously.

**Deprecated. **Deprecated Since 9.0.

```javascript
void updateBatch(Content[] contents, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.0

When an application has changed any attributes in the array of content, this method allows writing them
back to the content database.

The errorCallback is launched with these error types:

- InvalidValuesError: If any of the input parameters contain an invalid value.
- UnknownError: In any other error case.

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Remark: The *editableAttributes *in the *Content *interface indicates
the attributes that can be changed.
This API does not support updating the metadata of a file.

Parameters:

- **contents :
 Array of content to change. **
- **successCallback [optional] [nullable] :
 Callback method to be invoked when attributes have been changed. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error has occurred. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* Following example increases rating of a content by 1. */

function errorCB(err)
{
  console.log("The following error occurred: " + err.name);
}

function successCB()
{
  console.log("Attributes set successfully");
}

/* Assume the content is a Content object as a result of find method. */
/* Check if the isFavorite attribute is editable, and then negate it. */
if (content.editableAttributes.indexOf("isFavorite") >= 0)
{
  content.isFavorite = !content.isFavorite;
}
tizen.content.updateBatch([content], successCB, errorCB);
```

`**getDirectories **`Gets a list of content directories.

```javascript
void getDirectories(ContentDirectoryArraySuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.0

This method returns (via callback) a list of content directory objects. To obtain a list of contents
in a specific directory, use the find() method with the directory ID.

The errorCallback is launched with this error type:

- UnknownError: In any other error case.

Parameters:

- **successCallback :
 Callback method to be invoked when content directories have been retrieved successfully. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error has occurred. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

Code example:

```javascript
/* Following example retrieves content directories in the storage. */

function errorCB(err)
{
  console.log("The following error occurred: " + err.name);
}

function printDirectory(directory, index, directories)
{
  console.log("directoryURI: " + directory.directoryURI + " Title: " + directory.title);
}

function getDirectoriesCB(directories)
{
  directories.forEach(printDirectory);
}

tizen.content.getDirectories(getDirectoriesCB, errorCB);
```

`**find **`Finds contents that satisfy the conditions set by a filter.

```javascript
void find(ContentArraySuccessCallback successCallback, optional ErrorCallback? errorCallback,
          optional ContentDirectoryId? directoryId, optional AbstractFilter? filter, optional SortMode? sortMode,
          optional unsigned long? count, optional unsigned long? offset);
```

Since: 2.0

This method allows searching based on a supplied filter. For more details on AbstractFilter, see the Tizen module. The filter allows precise searching such
as "return all songs by artist U2, ordered by name".

The errorCallback is launched with these error types:

- InvalidValuesError: If any of the input parameters contain an invalid value.
- UnknownError: In any other error case.

Privilege level: public

Privilege: http://tizen.org/privilege/content.read

Remark: Attributes available for *Content *objects filtering are listed in Data Filtering and Sorting guide .

Parameters:

- **successCallback :
 Callback method to be invoked when content has been retrieved. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error has occurred. **
- **directoryId [optional] [nullable] :
 Directory ID that is used to select content to retrieve in a specified directory. **
- **filter [optional] [nullable] :
 Filter that is used to select content to retrieve. **
- **sortMode [optional] [nullable] :
 Used to determine the sort order in which the contents are returned. **
- **count [optional] [nullable] :
 Maximum amount of content to return. If *count *is negative, InvalidValuesError is reported through the errorCallback. **
- **offset [optional] [nullable] :
 Offset of the result set. If *offset *is a negative number, InvalidValuesError is reported through the errorCallback. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* Following example retrieves all songs from the album "The Joshua Tree", by artist "U2", ordered */
/* by the name. */
var count = 100;
var offset = 0;
var sortMode = new tizen.SortMode("name", "ASC");
var artistFilter = new tizen.AttributeFilter("artists", "EXACTLY", "U2");
var albumFilter = new tizen.AttributeFilter("album", "EXACTLY", "The Joshua Tree");
var filter = new tizen.CompositeFilter("INTERSECTION", [albumFilter, artistFilter]);

function errorCB(err)
{
  console.log("The following error occurred: " + err.name);
}

function printContent(content, index, contents)
{
  console.log("Name: " + content.name + " Title: " + content.title + "URL: " + content.contentURI +
              "MIME: " + content.mimeType);
}

function findCB(contents)
{
  console.log("The Joshua Tree by U2:");
  contents.forEach(printContent);
  /* Increase the offset as much as the count and then find content again. */
  if (contents.length === count)
  {
    offset += count;
    tizen.content.find(findCB, errorCB, null, filter, sortMode, count, offset);
  }
}

tizen.content.find(findCB, errorCB, null, filter, sortMode, count, offset);
```

`**scanFile **`Scans a file to create or update content in the content database.

```javascript
void scanFile(DOMString contentURI, optional ContentScanSuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.1

When an application creates or updates content, this method allows to scan it
and then insert or update the content in the content database.

The errorCallback is launched with these error types:

- UnknownError: In case of any error detected asynchronously
- NotSupportedError: In case of trying to scan content of not supported type (since 4.0)

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **contentURI :
 URI of content to scan. **
- **successCallback [optional] [nullable] :
 Callback method to be invoked when scanning has been completed. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error has occurred. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter
is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any of the input parameters
contain an invalid value (e.g. given *contentURI *is an empty string).

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

Code example:

```javascript
/* Following example scans "tizen.jpg" in media directory. */

function errorCB(err)
{
  console.log("The following error occurred: " + err.name);
}

function successCB(path)
{
  console.log("Scanning is completed");
}

tizen.filesystem.resolve("images/tizen.jpg", function(imageFile)
{
  tizen.content.scanFile(imageFile.toURI(), successCB, errorCB);
});
```

`**scanDirectory **`Scans a content directory to create or update content in the content database.

```javascript
void scanDirectory(DOMString contentDirURI, boolean recursive, optional ContentScanSuccessCallback? successCallback,
                   optional ErrorCallback? errorCallback);
```

Since: 2.4

When an application creates or updates content in a directory, this method allows
to scan it and then insert or update the content in the content database.
If a directory must not be scanned, the file *.scan_ignore *has to be created in it.

The errorCallback is launched with these error types:

- UnknownError: In case of any error detected asynchronously

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **contentDirURI :
 URI of a content directory to scan. **
- **recursive :
 Used to determine whether the function makes recursive scan or not. 
If set to true , the function makes recursive scan.
- **successCallback [optional] [nullable] :
 Callback method to be invoked when scanning has been completed. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error has occurred. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter
is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any of the input parameters
contain an invalid value (e.g. given *contentDirURI *is an empty string).

- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Following example scans "images" directory. */

function errorCB(err)
{
  console.log("The following error occurred: " + err.name);
}

function successCB(path)
{
  console.log("Scanning is completed");
}

tizen.filesystem.resolve("images", function(directory)
{
  tizen.content.scanDirectory(directory.toURI(), true, successCB, errorCB);
});
```

`**cancelScanDirectory **`Cancels a scan process of a content directory.

```javascript
void cancelScanDirectory(DOMString contentDirURI);
```

Since: 2.4

When a scan of a given directory is running it may be canceled by this function.

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **contentDirURI :
 URI of a content directory with a scan process running which is canceled. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters
contain an invalid value (e.g. given *contentDirURI *is an empty string).

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
tizen.content.cancelScanDirectory(directory.toURI());
```

`**addChangeListener **`Adds a listener which receives notifications when content changes.

```javascript
long addChangeListener(ContentChangeCallback changeCallback);
```

Since: 3.0

Parameters:

- **changeCallback :
 Callback to be invoked when a content change is detected. **

Return value:

long: Identifier of the newly added listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
var listener =
{
  oncontentadded: function(content)
  {
    console.log(content.contentURI + " content is added");
  },
  oncontentupdated: function(content)
  {
    console.log(content.contentURI + " content is updated");
  },
  oncontentremoved: function(id)
  {
    console.log(id + " is removed");
  },
  oncontentdiradded: function(contentDir)
  {
    console.log(contentDir.directoryURI + " content directory is added");
  },
  oncontentdirupdated: function(contentDir)
  {
    console.log(contentDir.directoryURI + " content directory is updated");
  },
  oncontentdirremoved: function(id)
  {
    console.log(id + " directory is removed");
  }
};

/* Adds the listener. */
var listenerId = tizen.content.addChangeListener(listener);

console.log("Listener ID: " + listenerId);
```

Output example:

```
Listener ID: 1
```

`**removeChangeListener **`Removes a listener which receives notifications about content changes.

```javascript
void removeChangeListener(long listenerId);
```

Since: 3.0

Calling this function has no effect if there is no listener with given id.

Parameters:

- **listenerId :
 Identifier of the listener to be removed. It is returned by. addChangeListener() when a listener is successfully added. **

Exceptions:

- WebAPIException
- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
var listener =
{
  oncontentadded: function(content)
  {
    console.log(content.contentURI + " content is added");
  },
  oncontentupdated: function(content)
  {
    console.log(content.contentURI + " content is updated");
  },
  oncontentremoved: function(id)
  {
    console.log(id + " is removed");
  },
  oncontentdiradded: function(contentDir)
  {
    console.log(contentDir.directoryURI + " content directory is added");
  },
  oncontentdirupdated: function(contentDir)
  {
    console.log(contentDir.directoryURI + " content directory is updated");
  },
  oncontentdirremoved: function(id)
  {
    console.log(id + " directory is removed");
  }
};

var listenerId = tizen.content.addChangeListener(listener);

/* Do some job here and when the listener is not needed anymore remove it. */

/* Removes the listener. */
tizen.content.removeChangeListener(listenerId);
```

`**getPlaylists **`Gets all playlists.

**Deprecated. **Deprecated Since 9.0.

```javascript
void getPlaylists(PlaylistArraySuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

The errorCallback is launched with these error types:

- UnknownError: In case of any error

Privilege level: public

Privilege: http://tizen.org/privilege/content.read

Parameters:

- **successCallback :
 Callback method to be invoked when retrieving a list of all playlists completes. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists;

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  var cur, i;
  gPlaylists = playlists;
  for (i = 0; i < gPlaylists.length; ++i)
  {
    cur = gPlaylists[i];
    console.log("[" + i + "] name: " + cur.name + " num tracks: " + cur.numberOfTracks);
  }
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

`**createPlaylist **`Creates a new playlist.

**Deprecated. **Deprecated Since 9.0.

```javascript
void createPlaylist(DOMString name, PlaylistSuccessCallback successCallback, optional ErrorCallback? errorCallback,
                    optional Playlist? sourcePlaylist);
```

Since: 2.3

The errorCallback is launched with these error types:

- InvalidValuesError: If name is empty or is same as the name of an existing playlist
- UnknownError: In case of any other error

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **name :
 Name of the new playlist (case sensitive). **
- **successCallback :
 Callback method to be invoked to provide a created playlist. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **sourcePlaylist [optional] [nullable] :
 Optional existing playlist to clone. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists;
var gPlaylist;

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err.message);
}

function getPlaylistsSuccess(playlists)
{
  var cur, i;
  gPlaylists = playlists;
  for (i = 0; i < gPlaylists.length; ++i)
  {
    cur = gPlaylists[i];
    console.log("[" + i + "] name: " + cur.name + " num tracks: " + cur.numberOfTracks);
  }
}

function findSuccess(contents)
{
  if (contents.length > 0)
  {
    gPlaylist.add(contents[0]);
  }

  tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
}

function findFail(err)
{
  console.log("find FAIL: " + err.message);
}

function createSuccess(playlist)
{
  console.log("create SUCCESS");

  gPlaylist = playlist;
  tizen.content.find(
      findSuccess, findFail, null, new tizen.AttributeFilter("type", "EXACTLY", "AUDIO"));
}

function createFail(err)
{
  console.log("create FAIL: " + err.message);
}

tizen.content.createPlaylist("My new playlist", createSuccess, createFail);
```

`**removePlaylist **`Removes a playlist.

**Deprecated. **Deprecated Since 9.0.

```javascript
void removePlaylist(PlaylistId id, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

The errorCallback is launched with these error types:

- UnknownError: In case of any error

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **id :
 Identifier of a playlist to remove. **
- **successCallback [optional] [nullable] :
 Callback method to be invoked when removing a playlist completes. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists;

function removePlaylistSuccess()
{
  console.log("removePlaylist SUCCESS");
}

function removePlaylistFail(err)
{
  console.log("removePlaylist FAIL: " + err);
}

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  var cur, i;
  gPlaylists = playlists;
  for (i = 0; i < gPlaylists.length; ++i)
  {
    cur = gPlaylists[i];
    console.log("[" + i + "] name: " + cur.name + " num tracks: " + cur.numberOfTracks);
  }

  if (gPlaylists.length < 1)
  {
    console.log("Please add at least 1 playlist");
    return;
  }

  console.log("Will remove playlist at index [0] name: " + gPlaylists[0].name);

  tizen.content.removePlaylist(gPlaylists[0].id, removePlaylistSuccess, removePlaylistFail);
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

`**createThumbnail **`Creates a content's thumbnail.

```javascript
void createThumbnail(Content content, ThumbnailSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

The errorCallback is launched with these error types:

- InvalidValuesError: In case of invalid content object.
- AbortError: In case of any error.

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **content :
 Content object for which a new thumbnail will be created. **
- **successCallback :
 Callback method to be invoked when the thumbnail is created. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
function createCB(path)
{
  console.log("The thumbnail path is " + path);
}

function findCB(contents)
{
  if (contents.length > 0)
  {
    tizen.content.createThumbnail(contents[0], createCB);
  }
}

tizen.content.find(findCB);
```

Output example:

```
The thumbnail path is /home/owner/share/media/.thumb/phone/.jpg-bed1d5f494830f7a52e1217f1e924aff.jpg
```

### 2.3. ContentArraySuccessCallback

The callback function used to return a list of content objects.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ContentArraySuccessCallback {
    void onsuccess(Content[] contents);
  };
```

Since: 2.0

#### Methods

`**onsuccess **`Called when the list of content is retrieved successfully.

```javascript
void onsuccess(Content[] contents);
```

Since: 2.0

Parameters:

- **contents :
 The array of *Content *objects. **

### 2.4. ContentDirectoryArraySuccessCallback

The callback function used to return a list of ContentDirectory objects.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ContentDirectoryArraySuccessCallback {
    void onsuccess(ContentDirectory[] directories);
  };
```

Since: 2.0

#### Methods

`**onsuccess **`Called when the directory list is retrieved successfully.

```javascript
void onsuccess(ContentDirectory[] directories);
```

Since: 2.0

Parameters:

- **directories :
 The array of *ContentDirectory *objects. **

### 2.5. ContentScanSuccessCallback

The callback function used to return content or content directory to scan.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ContentScanSuccessCallback {
    void onsuccess(DOMString uri);
  };
```

Since: 2.1

#### Methods

`**onsuccess **`Called when the scanning has been completed.

```javascript
void onsuccess(DOMString uri);
```

Since: 2.1

Remark: This callback is also invoked upon success of the scanDirectory() method since Tizen 2.4. Therefore, the *uri *parameter may now also be the URI of a *ContentDirectory *object.

Parameters:

- **uri :
 The URI of the Content or the ContentDirectory object. **

### 2.6. ContentChangeCallback

This interface specifies a set of methods that are invoked every time a content change occurs.

```webidl
  [Callback, NoInterfaceObject] interface ContentChangeCallback {
    void oncontentadded(Content content);
    void oncontentupdated(Content content);
    void oncontentremoved(ContentId id);
    void oncontentdiradded(ContentDirectory contentDir);
    void oncontentdirupdated(ContentDirectory contentDir);
    void oncontentdirremoved(ContentDirectoryId id);
  };
```

Since: 2.1

#### Methods

`**oncontentadded **`Called when content is added.

```javascript
void oncontentadded(Content content);
```

Since: 2.1

Parameters:

- **content :
 The content to add. **

`**oncontentupdated **`Called when content is updated.

```javascript
void oncontentupdated(Content content);
```

Since: 2.1

Parameters:

- **content :
 The content to update. **

`**oncontentremoved **`Called when content is removed.

```javascript
void oncontentremoved(ContentId id);
```

Since: 2.1

Parameters:

- **id :
 The ID of removed content. **

`**oncontentdiradded **`Called when a content directory is added.

```javascript
void oncontentdiradded(ContentDirectory contentDir);
```

Since: 2.4

Parameters:

- **contentDir :
 The added content directory. **

`**oncontentdirupdated **`Called when a content directory is updated.

```javascript
void oncontentdirupdated(ContentDirectory contentDir);
```

Since: 2.4

Parameters:

- **contentDir :
 The content directory after the update operation. **

`**oncontentdirremoved **`Called when a content directory is removed.

```javascript
void oncontentdirremoved(ContentDirectoryId id);
```

Since: 2.4

Parameters:

- **id :
 The ID of removed content directory. **

### 2.7. ContentDirectory

The ContentDirectory interface provides access to properties of a content directory.

```webidl
  [NoInterfaceObject] interface ContentDirectory {
    readonly attribute ContentDirectoryId id;
    readonly attribute DOMString directoryURI;
    readonly attribute DOMString title;
    readonly attribute Date? modifiedDate;
  };
```

Since: 2.0

#### Attributes

- readonly ContentDirectoryId id The opaque content directory identifier.

Since: 2.0

- readonly DOMString directoryURI The directory path on the device.

Since: 2.0

- readonly DOMString title The directory name.

Since: 2.0

- readonly Date modifiedDate [nullable] The last modified date for a directory.

Since: 2.0

### 2.8. Content

The Content interface provides access to the properties of a content item.

```webidl
  [NoInterfaceObject] interface Content {
    readonly attribute DOMString[] editableAttributes;
    readonly attribute ContentId id;
    readonly attribute DOMString name;
    readonly attribute ContentType type;
    readonly attribute DOMString mimeType;
    readonly attribute DOMString title;
    readonly attribute DOMString contentURI;
    readonly attribute DOMString[]? thumbnailURIs;
    readonly attribute Date? releaseDate;
    readonly attribute Date? modifiedDate;
    readonly attribute unsigned long size;
    readonly attribute DOMString? description;
    readonly attribute unsigned long rating;
    attribute boolean isFavorite;
  };
```

Since: 2.0

#### Attributes

- readonly DOMString[] editableAttributes The list of attributes that are editable to the local backend using the update() or updateBatch() method.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly ContentId id The opaque content identifier.

Since: 2.0

- readonly DOMString name The content name. The initial value is the file name of the content.

The attribute is marked as read-only since Tizen 5.5.

Since: 2.1

- readonly ContentType type The content type.

Since: 2.0

- readonly DOMString mimeType The content MIME type.

Since: 2.0

- readonly DOMString title The content title.

Since: 2.0

- readonly DOMString contentURI The URI to access the content.

Since: 2.0

- readonly DOMString[] thumbnailURIs [nullable] The array of content thumbnail URIs.

Since: 2.0

- readonly Date releaseDate [nullable] The date when content has been released publicly. If only the release year is known, then the month and date are set to January and 1st respectively.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly Date modifiedDate [nullable] The last modified date for a content item.

Since: 2.0

- readonly unsigned long size The file size of the content in bytes.

Since: 2.0

- readonly DOMString description [nullable] The content description.

**Deprecated. **Deprecated Since 9.0.

The attribute is marked as read-only since Tizen 5.5.

Since: 2.0

- readonly unsigned long rating The content rating. This value can range from 0 to 10 .

**Deprecated. **Deprecated Since 9.0.

The attribute is marked as read-only since Tizen 5.5.

Since: 2.0

- boolean isFavorite Boolean value that indicates whether a content item is marked as a favorite.

**Deprecated. **Deprecated Since 9.0.

Since: 2.3

### 2.9. VideoContent

The VideoContent interface extends a basic *Content *object with video-specific attributes.

```webidl
  [NoInterfaceObject] interface VideoContent : Content {
    readonly attribute SimpleCoordinates? geolocation;
    readonly attribute DOMString? album;
    readonly attribute DOMString[]? artists;
    readonly attribute unsigned long duration;
    readonly attribute unsigned long width;
    readonly attribute unsigned long height;
  };
```

Since: 2.0

#### Attributes

- readonly SimpleCoordinates geolocation [nullable] The geographical location where the video has been made.

**Deprecated. **Deprecated Since 9.0.

The attribute is marked as read-only since Tizen 5.5. Modifying it or its attributes has no effect.

Since: 2.0

- readonly DOMString album [nullable] The album name to which the video belongs.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly DOMString[] artists [nullable] The list of artists who created the video.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly unsigned long duration The video duration in milliseconds.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly unsigned long width The width of a video in pixels.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly unsigned long height The height of the video in pixels.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

### 2.10. AudioContentLyrics

The AudioContentLyrics interface provides lyrics for music.

```webidl
  [NoInterfaceObject] interface AudioContentLyrics {
    readonly attribute AudioContentLyricsType type;
    readonly attribute unsigned long[] timestamps;
    readonly attribute DOMString[] texts;
  };
```

Since: 2.0

#### Attributes

- readonly AudioContentLyricsType type The type of lyrics, that is, whether they are synchronized with the music.

Since: 2.0

- readonly unsigned long[] timestamps The array of timestamps in milliseconds for lyrics.

If the lyrics are not synchronized (if there is no time information for the lyrics) the array is undefined.

Since: 2.0

- readonly DOMString[] texts The array of lyrics snippets.

If the lyrics are not synchronized, the array has only one member with full lyrics.

Since: 2.0

### 2.11. AudioContent

The AudioContent interface extends a basic *Content *object with audio-specific attributes.

```webidl
  [NoInterfaceObject] interface AudioContent : Content {
    readonly attribute DOMString? album;
    readonly attribute DOMString[]? genres;
    readonly attribute DOMString[]? artists;
    readonly attribute DOMString[]? composers;
    readonly attribute AudioContentLyrics? lyrics raises(WebAPIException);
    readonly attribute DOMString? copyright;
    readonly attribute unsigned long bitrate;
    readonly attribute unsigned short? trackNumber;
    readonly attribute unsigned long duration;
  };
```

Since: 2.0

#### Attributes

- readonly DOMString album [nullable] The album name to which the audio belongs.

Since: 2.0

- readonly DOMString[] genres [nullable] The list of genres to which the audio belongs.

Since: 2.0

- readonly DOMString[] artists [nullable] The list of artists who created the audio.

Since: 2.0

- readonly DOMString[] composers [nullable] The list of composers for the music.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly AudioContentLyrics lyrics [nullable] The lyrics of a song in an audio file.

Since: 2.0

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to access the storage. For more information, see Storage privileges .

- readonly DOMString copyright [nullable] The copyright information.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly unsigned long bitrate The audio bitrate in bits per second. By default, this value is 0 .

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

- readonly unsigned short trackNumber [nullable] The track number if the audio belongs to an album.

Since: 2.0

- readonly unsigned long duration The audio duration in milliseconds.

**Deprecated. **Deprecated Since 9.0.

Since: 2.0

### 2.12. ImageContent

The ImageContent interface extends a basic *Content *object with image-specific attributes.

```webidl
  [NoInterfaceObject] interface ImageContent : Content {
    readonly attribute SimpleCoordinates? geolocation;
    readonly attribute unsigned long width;
    readonly attribute unsigned long height;
    readonly attribute ImageContentOrientation orientation;
  };
```

Since: 2.0

#### Attributes

- readonly SimpleCoordinates geolocation [nullable] The geographical location where the image has been made.

**Deprecated. **Deprecated Since 9.0.

The attribute is marked as read-only since Tizen 5.5. Modifying it or its attributes has no effect.

Since: 2.0

- readonly unsigned long width The width of an image in pixels.

Since: 2.0

- readonly unsigned long height The height of an image in pixels.

Since: 2.0

- readonly ImageContentOrientation orientation The image orientation.

The attribute is marked as read-only since Tizen 5.5.

Since: 2.0

### 2.13. PlaylistItem

The PlaylistItem interface represents a playlist item.

**Deprecated. **Deprecated Since 9.0.

```webidl
  [NoInterfaceObject] interface PlaylistItem {
    readonly attribute Content content;
  };
```

Since: 2.3

#### Attributes

- readonly Content content Content contained in this playlist item.

**Deprecated. **Deprecated Since 9.0.

Since: 2.3

### 2.14. Playlist

The Playlist interface represents a playlist.

**Deprecated. **Deprecated Since 9.0.

```webidl
  [NoInterfaceObject] interface Playlist {
    readonly attribute PlaylistId id;
    attribute DOMString name raises(WebAPIException);
    readonly attribute long numberOfTracks;
    attribute DOMString? thumbnailURI raises(WebAPIException);
    void add(Content item) raises(WebAPIException);
    void addBatch(Content[] items, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                  raises(WebAPIException);
    void remove(PlaylistItem item) raises(WebAPIException);
    void removeBatch(PlaylistItem[] items, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                     raises(WebAPIException);
    void get(PlaylistItemArraySuccessCallback successCallback, optional ErrorCallback? errorCallback, optional long? count,
             optional long? offset) raises(WebAPIException);
    void setOrder(PlaylistItem[] items, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                  raises(WebAPIException);
    void move(PlaylistItem item, long delta, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
              raises(WebAPIException);
  };
```

Since: 2.3

#### Attributes

- readonly PlaylistId id Identifier of a playlist.

**Deprecated. **Deprecated Since 9.0.

Since: 2.3

- DOMString name Name of a playlist (case sensitive and unique).

**Deprecated. **Deprecated Since 9.0.

When name is set, the change is recorded in the database.

Since: 2.3

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Exceptions:

- WebAPIException
- with error type InvalidValuesError, when assigning an invalid value (e.g. playlist of the same name already exists).

- with error type SecurityError, if the application does not have the privilege to change this attribute.

- readonly long numberOfTracks Number of playlist items in the playlist.

**Deprecated. **Deprecated Since 9.0.

Since: 2.3

- DOMString thumbnailURI [nullable] Thumbnail URI of a playlist.

**Deprecated. **Deprecated Since 9.0.

By default, this attribute is set to null . 
When thumbnailURI is set, the change is recorded in the database.

Since: 2.3

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Exceptions:

- WebAPIException
- with error type InvalidValuesError, when assigning an invalid value (e.g. if the URI does not start with "file:///").

- with error type SecurityError, if the application does not have the privilege to change this attribute or the application does not have privilege to access the storage. For more information, see Storage privileges .

#### Methods

`**add **`Adds a content item to a playlist.

**Deprecated. **Deprecated Since 9.0.

```javascript
void add(Content item);
```

Since: 2.3

See code example for the *createPlaylist() *method.

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **item :
 Content to add. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

`**addBatch **`Adds tracks to a playlist as a batch, asynchronously.

**Deprecated. **Deprecated Since 9.0.

```javascript
void addBatch(Content[] items, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

The errorCallback is launched with these error types:

- UnknownError: In case of any error

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **items :
 List of tracks (Content objects) to add. **
- **successCallback [optional] [nullable] :
 Callback method to be invoked when adding a list of content items to a playlist completes successfully. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

`**remove **`Removes a track from a playlist.

**Deprecated. **Deprecated Since 9.0.

```javascript
void remove(PlaylistItem item);
```

Since: 2.3

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **item :
 Playlist item to remove. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var gPlaylists, gItems, gCurPlaylist;

function get2Fail(err)
{
  console.log("Get items (after remove) failed: " + err);
}

function get2Success(items)
{
  console.log("Playlist items:");
  for (var i = 0; i < items.length; ++i)
  {
    console.log("[" + i + "]: name: " + items[i].content.name);
  }
}

function getSuccess(items)
{
  gItems = items;

  if (gItems.length < 1)
  {
    console.log("Please add at least 1 tracks to playlist!");
    return;
  }

  console.log("Original playlist:");
  for (var i = 0; i < gItems.length; ++i)
  {
    console.log("[" + i + "]: name: " + gItems[i].content.name);
  }

  console.log("Will remove item at index [0] name: " + gItems[0].content.name);
  gCurPlaylist.remove(gItems[0]);
  gCurPlaylist.get(get2Success, get2Fail);
}

function getFail(err)
{
  console.log("Get items failed: " + err);
}

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  gPlaylists = playlists;
  if (gPlaylists.length === 0)
  {
    console.log("Please create at least 1 playlist!");
    return;
  }

  gCurPlaylist = gPlaylists[0];
  gCurPlaylist.get(getSuccess, getFail);
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

`**removeBatch **`Removes tracks from a playlist as a batch, asynchronously.

**Deprecated. **Deprecated Since 9.0.

```javascript
void removeBatch(PlaylistItem[] items, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

The errorCallback is launched with these error types:

- UnknownError: In case of any other error

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **items :
 List of tracks to remove. **
- **successCallback [optional] [nullable] :
 Callback method to be invoked when removing a list of content items from a playlist completes successfully. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists, gItems, gCurPlaylist;

function get2Fail(err)
{
  console.log("Get items (after remove batch) failed: " + err);
}

function get2Success(items)
{
  console.log("Playlist after remove batch:");
  for (var i = 0; i < items.length; ++i)
  {
    console.log("[" + i + "]: name: " + items[i].content.name);
  }
}

function removeBatchSuccess()
{
  console.log("removeBatch success");
  gCurPlaylist.get(get2Success, get2Fail);
}

function removeBatchFail(err)
{
  console.log("removeBatch failed: " + err);
}

function getSuccess(items)
{
  gItems = items;

  if (gItems.length < 4)
  {
    console.log("Please add at least 4 tracks to playlist!");
    return;
  }

  console.log("Original playlist:");
  for (var i = 0; i < gItems.length; ++i)
  {
    console.log("[" + i + "]: name: " + gItems[i].content.name);
  }

  console.log("Will remove items at index [0] (name: " + gItems[0].content.name +
              ") and at index [2] (name: " + gItems[2].content.name + ")");
  gCurPlaylist.removeBatch([gItems[2], gItems[0]], removeBatchSuccess, removeBatchFail);
}

function getFail(err)
{
  console.log("Get items failed: " + err);
}

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  gPlaylists = playlists;
  if (gPlaylists.length === 0)
  {
    console.log("Please create at least 1 playlist!");
    return;
  }

  gCurPlaylist = gPlaylists[0];
  gCurPlaylist.get(getSuccess, getFail);
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

`**get **`Gets playlist items from a playlist.

**Deprecated. **Deprecated Since 9.0.

```javascript
void get(PlaylistItemArraySuccessCallback successCallback, optional ErrorCallback? errorCallback, optional long? count,
         optional long? offset);
```

Since: 2.3

The errorCallback is launched with these error types:

- InvalidValuesError: If any of the input parameters contain an invalid value (e.g *count *or *offset *is a negative number)
- UnknownError: In case of any error

Privilege level: public

Privilege: http://tizen.org/privilege/content.read

Parameters:

- **successCallback :
 Callback method to be invoked for a list of tracks in the playlist. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **count [optional] [nullable] :
 Number of playlist items to return 
If the count is not passed, all playlist items are retrieved.
- **offset [optional] [nullable] :
 Offset of the track from the beginning of the playlist 
The default value is 0 
It means no offset.
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists, gItems, gCurPlaylist;

function getSuccess(items)
{
  gItems = items;
  console.log("Playlist items:");
  for (var i = 0; i < items.length; ++i)
  {
    console.log("[" + i + "]: name: " + items[i].name);
  }
}

function getFail(err)
{
  console.log("Get items failed: " + err);
}

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  gPlaylists = playlists;
  if (gPlaylists.length === 0)
  {
    console.log("Please create at least 1 playlist!");
    return;
  }

  gCurPlaylist = gPlaylists[0];
  /* To retrieves all playlist items of "gCurPlaylist" playlist. */
  gCurPlaylist.get(getSuccess, getFail);
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

`**setOrder **`Changes the play order of all playlist items in the playlist.

**Deprecated. **Deprecated Since 9.0.

```javascript
void setOrder(PlaylistItem[] items, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

The errorCallback is launched with these error types:

- InvalidValuesError: In case the item in the passed *items *array is not inside this playlist, or the *items *array does not contain all items from the playlist
- UnknownError: In case of any other error

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **items :
 List of playlist items to set in play order 
This list must include all playlist items of this playlist 
If not, InvalidValuesError is thrown.
- **successCallback [optional] [nullable] :
 Callback method to be invoked when changing the positions of items in the playlist is successfully completed. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists, gItems, gCurPlaylist, gExpectedOrder;

function get2Fail(err)
{
  console.log("Get items (after set order) failed: " + err);
}

function get2Success(items)
{
  console.log("Playlist order after setOrder:");
  for (var i = 0; i < items.length; ++i)
  {
    console.log("[" + i + "]: name: " + items[i].content.name);
  }
}

function setOrderSuccess()
{
  console.log("Set items order SUCCESS");
  gCurPlaylist.get(get2Success, get2Fail);
}

function setOrderFail(err)
{
  console.log("Set items order failed: " + err);
}

function getSuccess(items)
{
  gItems = items;

  if (gItems.length < 2)
  {
    console.log("Please add at least 2 tracks to playlist!");
    return;
  }

  console.log("Original order:");
  for (var i = 0; i < gItems.length; ++i)
  {
    console.log("[" + i + "]: name: " + gItems[i].content.name);
  }

  gExpectedOrder = gItems.slice(0);
  gExpectedOrder.reverse();

  console.log("New order:");
  for (var i = 0; i < gExpectedOrder.length; ++i)
  {
    console.log("[" + i + "]: name: " + gExpectedOrder[i].content.name);
  }

  gCurPlaylist.setOrder(gExpectedOrder, setOrderSuccess, setOrderFail);
}

function getFail(err)
{
  console.log("get items failed: " + err);
}

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  gPlaylists = playlists;
  if (gPlaylists.length === 0)
  {
    console.log("Please create at least 1 playlist!");
    return;
  }

  gCurPlaylist = gPlaylists[0];
  gCurPlaylist.get(getSuccess, getFail);
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

`**move **`Moves the specified item up or down a specified amount in the play order.

**Deprecated. **Deprecated Since 9.0.

```javascript
void move(PlaylistItem item, long delta, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

If current index + delta is:

- < 0 then the item is moved to the first position in the playlist
- ≥ number of tracks then the item is moved to the last position in the playlist
The errorCallback is launched with these error types:

- InvalidValuesError: In case the item in the passed *items *array is not inside this playlist or some item of this playlist is not included in *items *
- UnknownError: In case of any other error

Privilege level: public

Privilege: http://tizen.org/privilege/content.write

Parameters:

- **item :
 Playlist item to move. **
- **delta :
 How many positions to move the item, negative value means move up, positive means move down. **
- **successCallback [optional] [nullable] :
 Callback method to be invoked when the playlist item has successfully been moved. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gPlaylists, gItems, gCurPlaylist;

function get2Fail(err)
{
  console.log("Get items (after move item) failed: " + err);
}

function get2Success(items)
{
  console.log("Playlist order after move:");
  for (var i = 0; i < items.length; ++i)
  {
    console.log("[" + i + "]: name: " + items[i].content.name);
  }
}

function moveSuccess()
{
  console.log("Move item SUCCESS");
  gCurPlaylist.get(get2Success, get2Fail);
}

function moveFail(err)
{
  console.log("Move item failed: " + err);
}

function getSuccess(items)
{
  gItems = items;

  if (gItems.length < 2)
  {
    console.log("Please add at least 2 tracks to playlist!");
    return;
  }

  console.log("Original order:");
  for (var i = 0; i < gItems.length; ++i)
  {
    console.log("[" + i + "]: name: " + gItems[i].content.name);
  }

  console.log("Will move item at index [1] (name: " + gItems[1].content.name +
              ") up by one place (to [0])");

  gCurPlaylist.move(gItems[1], -1, moveSuccess, moveFail);
  gItems.unshift(gItems.splice(1, 1)[0]);
}

function getFail(err)
{
  console.log("Get items failed: " + err);
}

function getPlaylistsFail(err)
{
  console.log("getPlaylists failed: " + err);
}

function getPlaylistsSuccess(playlists)
{
  gPlaylists = playlists;
  if (gPlaylists.length === 0)
  {
    console.log("Please create at least 1 playlist!");
    return;
  }

  gCurPlaylist = gPlaylists[0];
  gCurPlaylist.get(getSuccess, getFail);
}

tizen.content.getPlaylists(getPlaylistsSuccess, getPlaylistsFail);
```

### 2.15. PlaylistArraySuccessCallback

The PlaylistArraySuccessCallback interface specifies a success callback that is invoked when all existing playlists are retrieved successfully.

**Deprecated. **Deprecated Since 9.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface PlaylistArraySuccessCallback {
    void onsuccess(Playlist[] playlists);
  };
```

Since: 2.3

It is used in *tizen.content.getPlaylists() *.

#### Methods

`**onsuccess **`Called when the *tizen.content.getPlaylists() *method completes successfully.

```javascript
void onsuccess(Playlist[] playlists);
```

Since: 2.3

Parameters:

- **playlists :
 List of all playlists on a device. **

### 2.16. PlaylistSuccessCallback

The PlaylistSuccessCallback interface specifies a success callback that is invoked when a new playlist is successfully created.

**Deprecated. **Deprecated Since 9.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface PlaylistSuccessCallback {
    void onsuccess(Playlist playlist);
  };
```

Since: 2.3

It is used in *tizen.content.createPlaylist() *.

#### Methods

`**onsuccess **`Called when the *tizen.content.createPlaylist() *method completes successfully.

```javascript
void onsuccess(Playlist playlist);
```

Since: 2.3

Parameters:

- **playlist :
 Newly created playlist. **

### 2.17. PlaylistItemArraySuccessCallback

The PlaylistItemArraySuccessCallback interface specifies a success callback that is invoked when a list of playlist items are successfully retrieved.

**Deprecated. **Deprecated Since 9.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface PlaylistItemArraySuccessCallback {
    void onsuccess(PlaylistItem[] items);
  };
```

Since: 2.3

#### Methods

`**onsuccess **`Called when the *playlist.get() *method completes successfully.

```javascript
void onsuccess(PlaylistItem[] items);
```

Since: 2.3

Parameters:

- **items :
 List of playlist items. **

### 2.18. ThumbnailSuccessCallback

The ThumbnailSuccessCallback interface specifies a success callback that is invoked when a content's thumbnail is successfully created.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ThumbnailSuccessCallback {
    void onsuccess(DOMString path);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when the *tizen.content.createThumbnail() *method completes successfully.

```javascript
void onsuccess(DOMString path);
```

Since: 3.0

Parameters:

- **path :
 Path of the created thumbnail. **

## 3. Full WebIDL

```webidl
module Content {
  typedef DOMString ContentId;
  typedef DOMString ContentDirectoryId;
  enum ContentType { "IMAGE", "VIDEO", "AUDIO", "OTHER" };
  enum AudioContentLyricsType { "SYNCHRONIZED", "UNSYNCHRONIZED" };
  enum ImageContentOrientation { "NORMAL", "FLIP_HORIZONTAL", "ROTATE_180", "FLIP_VERTICAL", "TRANSPOSE", "ROTATE_90", "TRANSVERSE",
    "ROTATE_270" };
  Tizen implements ContentManagerObject;
  [NoInterfaceObject] interface ContentManagerObject {
    readonly attribute ContentManager content;
  };
  [NoInterfaceObject] interface ContentManager {
    void getDirectories(ContentDirectoryArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void find(ContentArraySuccessCallback successCallback, optional ErrorCallback? errorCallback,
              optional ContentDirectoryId? directoryId, optional AbstractFilter? filter, optional SortMode? sortMode,
              optional unsigned long? count, optional unsigned long? offset) raises(WebAPIException);
    void scanFile(DOMString contentURI, optional ContentScanSuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                  raises(WebAPIException);
    void scanDirectory(DOMString contentDirURI, boolean recursive, optional ContentScanSuccessCallback? successCallback,
                       optional ErrorCallback? errorCallback) raises(WebAPIException);
    void cancelScanDirectory(DOMString contentDirURI) raises(WebAPIException);
    long addChangeListener(ContentChangeCallback changeCallback) raises(WebAPIException);
    void removeChangeListener(long listenerId) raises(WebAPIException);
    void createThumbnail(Content content, ThumbnailSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ContentArraySuccessCallback {
    void onsuccess(Content[] contents);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ContentDirectoryArraySuccessCallback {
    void onsuccess(ContentDirectory[] directories);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ContentScanSuccessCallback {
    void onsuccess(DOMString uri);
  };
  [Callback, NoInterfaceObject] interface ContentChangeCallback {
    void oncontentadded(Content content);
    void oncontentupdated(Content content);
    void oncontentremoved(ContentId id);
    void oncontentdiradded(ContentDirectory contentDir);
    void oncontentdirupdated(ContentDirectory contentDir);
    void oncontentdirremoved(ContentDirectoryId id);
  };
  [NoInterfaceObject] interface ContentDirectory {
    readonly attribute ContentDirectoryId id;
    readonly attribute DOMString directoryURI;
    readonly attribute DOMString title;
    readonly attribute Date? modifiedDate;
  };
  [NoInterfaceObject] interface Content {
    readonly attribute ContentId id;
    readonly attribute DOMString name;
    readonly attribute ContentType type;
    readonly attribute DOMString mimeType;
    readonly attribute DOMString title;
    readonly attribute DOMString contentURI;
    readonly attribute DOMString[]? thumbnailURIs;
    readonly attribute Date? modifiedDate;
    readonly attribute unsigned long size;
  };
  [NoInterfaceObject] interface VideoContent : Content {
  };
  [NoInterfaceObject] interface AudioContentLyrics {
    readonly attribute AudioContentLyricsType type;
    readonly attribute unsigned long[] timestamps;
    readonly attribute DOMString[] texts;
  };
  [NoInterfaceObject] interface AudioContent : Content {
    readonly attribute DOMString? album;
    readonly attribute DOMString[]? genres;
    readonly attribute DOMString[]? artists;
    readonly attribute AudioContentLyrics? lyrics raises(WebAPIException);
    readonly attribute unsigned short? trackNumber;
  };
  [NoInterfaceObject] interface ImageContent : Content {
    readonly attribute unsigned long width;
    readonly attribute unsigned long height;
    readonly attribute ImageContentOrientation orientation;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ThumbnailSuccessCallback {
    void onsuccess(DOMString path);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
