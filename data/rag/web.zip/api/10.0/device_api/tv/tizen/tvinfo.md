# TVInfo API

The TVInfo API provides interfaces and methods to get information about the TV settings.

Since: 2.4

## Table of Contents

- 1. Type Definitions
- 1.1. CaptionInfoKey
- 1.2. CaptionState
- 1.3. CaptionMode
- 1.4. CaptionFontSize
- 1.5. CaptionFontStyle
- 1.6. CaptionColor
- 1.7. CaptionOpacity
- 1.8. CaptionEdge
- 1.9. CaptionStyle
- 1.10. CaptionValue
- 2. Interfaces
- 2.1. TVInfoManagerObject
- 2.2. TVInfoManager
- 2.3. CaptionValueChangeCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| TVInfoManagerObject |  |
| TVInfoManager | CaptionValue getCaptionValue ( CaptionInfoKey key) long addCaptionValueChangeListener ( CaptionInfoKey key, CaptionValueChangeCallback callback) void removeCaptionValueChangeListener (long watchId) |
| CaptionValueChangeCallback | void onchanged ( CaptionInfoKey key, CaptionValue value) |

## 1. Type Definitions

### 1.1. CaptionInfoKey

Available keys for the caption menu.

```webidl
  enum CaptionInfoKey { "CAPTION_ONOFF_KEY", "CAPTION_MODE_KEY", "CAPTION_FONT_SIZE_KEY", "CAPTION_FONT_STYLE_KEY",
    "CAPTION_FONT_COLOR_KEY", "CAPTION_FONT_OPACITY_KEY", "CAPTION_BG_COLOR_KEY", "CAPTION_BG_OPACITY_KEY", "CAPTION_EDGE_TYPE_KEY",
    "CAPTION_EDGE_COLOR_KEY", "CAPTION_WINDOW_COLOR_KEY", "CAPTION_WINDOW_OPACITY_KEY", "CAPTION_STYLE_KEY", "CAPTION_LANGUAGE_KEY",
    "CAPTION_LANGUAGE_INDEX_KEY" };
```

Since: 2.4

- CAPTION_ONOFF_KEY - caption state
- CAPTION_MODE_KEY - caption mode
- CAPTION_FONT_SIZE_KEY - caption font size
- CAPTION_FONT_STYLE_KEY - caption font style
- CAPTION_FONT_COLOR_KEY - caption font color
- CAPTION_FONT_OPACITY_KEY - caption font opacity mode
- CAPTION_BG_COLOR_KEY - caption background color
- CAPTION_BG_OPACITY_KEY - caption background opacity mode
- CAPTION_EDGE_TYPE_KEY - caption text edge type
- CAPTION_EDGE_COLOR_KEY - caption edge color
- CAPTION_WINDOW_COLOR_KEY - caption window color (only US)
- CAPTION_WINDOW_OPACITY_KEY - caption window opacity mode (only US)
- CAPTION_STYLE_KEY - style of typographical emphasis of caption font
- CAPTION_LANGUAGE_KEY - The language for captions. The returned value is a string that indicates the selected caption language.
- CAPTION_LANGUAGE_INDEX_KEY - The index determining language for captions. The returned value is a string that indicates the selected caption language, typically represented by its position or identifier in the system's caption language menu.

### 1.2. CaptionState

Available values for the caption state.

```webidl
  enum CaptionState { "CAPTION_OFF", "CAPTION_ON" };
```

Since: 2.4

These values may be returned for key CAPTION_ONOFF_KEY.

- CAPTION_OFF - caption menu is turned off
- CAPTION_ON - caption menu is turned on

### 1.3. CaptionMode

Available values for the caption menu mode.

```webidl
  enum CaptionMode { "CAPTION_MODE_DEFAULT", "CAPTION_MODE_SERVICE1", "CAPTION_MODE_SERVICE2", "CAPTION_MODE_SERVICE3",
    "CAPTION_MODE_SERVICE4", "CAPTION_MODE_SERVICE5", "CAPTION_MODE_SERVICE6", "CAPTION_MODE_CC1", "CAPTION_MODE_CC2", "CAPTION_MODE_CC3",
    "CAPTION_MODE_CC4", "CAPTION_MODE_TEXT1", "CAPTION_MODE_TEXT2", "CAPTION_MODE_TEXT3", "CAPTION_MODE_TEXT4" };
```

Since: 2.4

These values may be returned for key CAPTION_MODE_KEY.

- CAPTION_MODE_DEFAULT - default mode
- CAPTION_MODE_SERVICE1 - standard service 1 (Primary Caption Service)
- CAPTION_MODE_SERVICE2 - standard service 2 (Secondary Language Service)
- CAPTION_MODE_SERVICE3 - standard service 3
- CAPTION_MODE_SERVICE4 - standard service 4
- CAPTION_MODE_SERVICE5 - standard service 5
- CAPTION_MODE_SERVICE6 - standard service 6
- CAPTION_MODE_CC1 - Primary Synchronous Caption Service
- CAPTION_MODE_CC2 - Special Non-Synchronous Service
- CAPTION_MODE_CC3 - Secondary Synchronous Caption Service
- CAPTION_MODE_CC4 - Special Non-Synchronous Service
- CAPTION_MODE_TEXT1 - Text Service 1
- CAPTION_MODE_TEXT2 - Text Service 2
- CAPTION_MODE_TEXT3 - Text Service 3
- CAPTION_MODE_TEXT4 - Text Service 4

### 1.4. CaptionFontSize

Available values for the caption menu font size.

```webidl
  enum CaptionFontSize { "CAPTION_SIZE_DEFAULT", "CAPTION_SIZE_SMALL", "CAPTION_SIZE_STANDARD", "CAPTION_SIZE_LARGE",
    "CAPTION_SIZE_EXTRA_LARGE", "CAPTION_SIZE_EXTRA_SMALL" };
```

Since: 2.4

These values may be returned for key CAPTION_FONT_SIZE_KEY.

- CAPTION_SIZE_DEFAULT - default font size
- CAPTION_SIZE_SMALL - small font size
- CAPTION_SIZE_STANDARD - standard font size
- CAPTION_SIZE_LARGE - large font size
- CAPTION_SIZE_EXTRA_LARGE - extra large font size
- CAPTION_SIZE_EXTRA_SMALL - extra small font size

### 1.5. CaptionFontStyle

Available values for the caption menu font style.

```webidl
  enum CaptionFontStyle { "CAPTION_FONT_DEFAULT", "CAPTION_FONT_STYLE0", "CAPTION_FONT_STYLE1", "CAPTION_FONT_STYLE2",
    "CAPTION_FONT_STYLE3", "CAPTION_FONT_STYLE4", "CAPTION_FONT_STYLE5", "CAPTION_FONT_STYLE6", "CAPTION_FONT_STYLE7" };
```

Since: 2.4

These values may be returned for key CAPTION_FONT_STYLE_KEY.

- CAPTION_FONT_DEFAULT - default font style
- CAPTION_FONT_STYLE1 - Monospaced with serifs (similar to Courier)
- CAPTION_FONT_STYLE2 - Proportionally spaced with serifs (similar to Times New Roman)
- CAPTION_FONT_STYLE3 - Monospaced without serifs (similar to Helvetica Monospaced)
- CAPTION_FONT_STYLE4 - Proportionally spaced without serifs (similar to Arial and Swiss)
- CAPTION_FONT_STYLE5 - Casual font type (similar to Dom and Impress)
- CAPTION_FONT_STYLE6 - Cursive font type (similar to Coronet and Marigold)
- CAPTION_FONT_STYLE7 - Small capitals (similar to Engravers Gothic)

### 1.6. CaptionColor

Available values for the caption menu color.

```webidl
  enum CaptionColor { "CAPTION_COLOR_DEFAULT", "CAPTION_COLOR_WHITE", "CAPTION_COLOR_BLACK", "CAPTION_COLOR_RED", "CAPTION_COLOR_GREEN",
    "CAPTION_COLOR_BLUE", "CAPTION_COLOR_YELLOW", "CAPTION_COLOR_MAGENTA", "CAPTION_COLOR_CYAN" };
```

Since: 2.4

These values may be returned for keys CAPTION_FONT_COLOR_KEY, CAPTION_BG_COLOR_KEY, CAPTION_EDGE_COLOR_KEY and CAPTION_WINDOW_COLOR_KEY.

### 1.7. CaptionOpacity

Available values for the caption menu opacity.

```webidl
  enum CaptionOpacity { "CAPTION_OPACITY_SOLID", "CAPTION_OPACITY_FLASHING", "CAPTION_OPACITY_TRANSLUCENT",
    "CAPTION_OPACITY_HIGHLY_TRANSLUCENT", "CAPTION_OPACITY_SLIGHTLY_TRANSLUCENT", "CAPTION_OPACITY_TRANSPARENT", "CAPTION_OPACITY_DEFAULT" };
```

Since: 2.4

These values may be returned for keys CAPTION_FONT_OPACITY_KEY, CAPTION_BG_OPACITY_KEY and CAPTION_WINDOW_OPACITY_KEY.

Remark: *CAPTION_OPACITY_HIGHLY_TRANSLUCENT *and *CAPTION_OPACITY_SLIGHTLY_TRANSLUCENT *are supported since Tizen 6.5

### 1.8. CaptionEdge

Available values for the caption menu edge type.

```webidl
  enum CaptionEdge { "CAPTION_EDGE_NONE", "CAPTION_EDGE_RAISED", "CAPTION_EDGE_DEPRESSED", "CAPTION_EDGE_UNIFORM",
    "CAPTION_EDGE_DROP_SHADOWED" };
```

Since: 2.4

These values may be returned for key CAPTION_EDGE_TYPE_KEY.

- CAPTION_EDGE_NONE - no edge
- CAPTION_EDGE_RAISED - raised edge
- CAPTION_EDGE_DEPRESSED - depressed edge
- CAPTION_EDGE_UNIFORM - uniform edge
- CAPTION_EDGE_DROP_SHADOWED - drop shadowed edge

### 1.9. CaptionStyle

Available values for the caption style.

```webidl
  enum CaptionStyle { "CAPTION_STYLE_DEFAULT", "CAPTION_STYLE_BOLD", "CAPTION_STYLE_ITALIC" };
```

Since: 2.4

- CAPTION_STYLE_DEFAULT - default style depending on the system configuration
- CAPTION_STYLE_BOLD - bold captions
- CAPTION_STYLE_ITALIC - italic captions

### 1.10. CaptionValue

All available values for the caption menu.

```webidl
  typedef (CaptionState or CaptionMode or CaptionFontSize or CaptionFontStyle or CaptionColor or CaptionOpacity or CaptionEdge or CaptionStyle or DOMString) CaptionValue;
```

Since: 2.4

## 2. Interfaces

### 2.1. TVInfoManagerObject

The TVInfoManagerObject interface defines what is instantiated in the tizen object.

```webidl
  [NoInterfaceObject] interface TVInfoManagerObject {
    readonly attribute TVInfoManager tvinfo;
  };
```

```webidl
  Tizen implements TVInfoManagerObject;
```

Since: 2.4

There is a tizen.tvinfo object that allows accessing the functionality of the TVInfo API.

### 2.2. TVInfoManager

The TVInfoManager interface provides the functionalities to get setting values provided by Tizen TV.

```webidl
  [NoInterfaceObject] interface TVInfoManager {
    CaptionValue getCaptionValue(CaptionInfoKey key) raises(WebAPIException);
    long addCaptionValueChangeListener(CaptionInfoKey key, CaptionValueChangeCallback callback) raises(WebAPIException);
    void removeCaptionValueChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 2.4

#### Methods

`**getCaptionValue **`Method returns the value for corresponding caption menu key.

```javascript
CaptionValue getCaptionValue(CaptionInfoKey key);
```

Since: 2.4

Return value:

CaptionValue: CaptionValue value for given caption menu key

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type UnknownError in any other error case.

Code example:

```javascript
console.log("Caption menu turned on: " +
            (tizen.tvinfo.getCaptionValue("CAPTION_ONOFF_KEY") === "CAPTION_ON"));
```

`**addCaptionValueChangeListener **`Adds a listener to be called when given caption menu key value changes.

```javascript
long addCaptionValueChangeListener(CaptionInfoKey key, CaptionValueChangeCallback callback);
```

Since: 2.4

Parameters:

- **key :
 Caption menu key which changes will be observed by this listener **
- **callback :
 Callback method to be invoked when the value changes **

Return value:

long: long Subscription identifier

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type UnknownError in any other error case.

Code example:

```javascript
var id = tizen.tvinfo.addCaptionValueChangeListener("CAPTION_ONOFF_KEY", function(value)
{
  console.log("Caption menu state changed: " + value);
});
```

`**removeCaptionValueChangeListener **`Removes a listener.

```javascript
void removeCaptionValueChangeListener(long watchId);
```

Since: 2.4

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchId :
 Identifier of the subscription returned by addCaptionValueChangeListener() **

Exceptions:

- WebAPIException
- with error type UnknownError, in any other error case.

Code example:

```javascript
var id = tizen.tvinfo.addCaptionValueChangeListener("CAPTION_ONOFF_KEY", function() {});
tizen.tvinfo.removeCaptionValueChangeListener(id);
```

### 2.3. CaptionValueChangeCallback

The CaptionValueChangeCallback interface specifies event callback for getting notified when event occurs.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface CaptionValueChangeCallback {
    void onchanged(CaptionInfoKey key, CaptionValue value);
  };
```

Since: 2.4

#### Methods

`**onchanged **`Called when the caption menu value changes.

```javascript
void onchanged(CaptionInfoKey key, CaptionValue value);
```

Since: 2.4

Parameters:

- **key :
 Watched key. **
- **value :
 New value of watched key. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee the running of this application on a device with a caption and so on, define the following requirements in the config file:

- http://tizen.org/feature/tv.information

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module TVInfo {
  typedef (CaptionState or CaptionMode or CaptionFontSize or CaptionFontStyle or CaptionColor or CaptionOpacity or CaptionEdge or CaptionStyle or DOMString) CaptionValue;
  enum CaptionInfoKey { "CAPTION_ONOFF_KEY", "CAPTION_MODE_KEY", "CAPTION_FONT_SIZE_KEY", "CAPTION_FONT_STYLE_KEY",
    "CAPTION_FONT_COLOR_KEY", "CAPTION_FONT_OPACITY_KEY", "CAPTION_BG_COLOR_KEY", "CAPTION_BG_OPACITY_KEY", "CAPTION_EDGE_TYPE_KEY",
    "CAPTION_EDGE_COLOR_KEY", "CAPTION_WINDOW_COLOR_KEY", "CAPTION_WINDOW_OPACITY_KEY", "CAPTION_STYLE_KEY", "CAPTION_LANGUAGE_KEY",
    "CAPTION_LANGUAGE_INDEX_KEY" };
  enum CaptionState { "CAPTION_OFF", "CAPTION_ON" };
  enum CaptionMode { "CAPTION_MODE_DEFAULT", "CAPTION_MODE_SERVICE1", "CAPTION_MODE_SERVICE2", "CAPTION_MODE_SERVICE3",
    "CAPTION_MODE_SERVICE4", "CAPTION_MODE_SERVICE5", "CAPTION_MODE_SERVICE6", "CAPTION_MODE_CC1", "CAPTION_MODE_CC2", "CAPTION_MODE_CC3",
    "CAPTION_MODE_CC4", "CAPTION_MODE_TEXT1", "CAPTION_MODE_TEXT2", "CAPTION_MODE_TEXT3", "CAPTION_MODE_TEXT4" };
  enum CaptionFontSize { "CAPTION_SIZE_DEFAULT", "CAPTION_SIZE_SMALL", "CAPTION_SIZE_STANDARD", "CAPTION_SIZE_LARGE",
    "CAPTION_SIZE_EXTRA_LARGE", "CAPTION_SIZE_EXTRA_SMALL" };
  enum CaptionFontStyle { "CAPTION_FONT_DEFAULT", "CAPTION_FONT_STYLE0", "CAPTION_FONT_STYLE1", "CAPTION_FONT_STYLE2",
    "CAPTION_FONT_STYLE3", "CAPTION_FONT_STYLE4", "CAPTION_FONT_STYLE5", "CAPTION_FONT_STYLE6", "CAPTION_FONT_STYLE7" };
  enum CaptionColor { "CAPTION_COLOR_DEFAULT", "CAPTION_COLOR_WHITE", "CAPTION_COLOR_BLACK", "CAPTION_COLOR_RED", "CAPTION_COLOR_GREEN",
    "CAPTION_COLOR_BLUE", "CAPTION_COLOR_YELLOW", "CAPTION_COLOR_MAGENTA", "CAPTION_COLOR_CYAN" };
  enum CaptionOpacity { "CAPTION_OPACITY_SOLID", "CAPTION_OPACITY_FLASHING", "CAPTION_OPACITY_TRANSLUCENT",
    "CAPTION_OPACITY_HIGHLY_TRANSLUCENT", "CAPTION_OPACITY_SLIGHTLY_TRANSLUCENT", "CAPTION_OPACITY_TRANSPARENT", "CAPTION_OPACITY_DEFAULT" };
  enum CaptionEdge { "CAPTION_EDGE_NONE", "CAPTION_EDGE_RAISED", "CAPTION_EDGE_DEPRESSED", "CAPTION_EDGE_UNIFORM",
    "CAPTION_EDGE_DROP_SHADOWED" };
  enum CaptionStyle { "CAPTION_STYLE_DEFAULT", "CAPTION_STYLE_BOLD", "CAPTION_STYLE_ITALIC" };
  Tizen implements TVInfoManagerObject;
  [NoInterfaceObject] interface TVInfoManagerObject {
    readonly attribute TVInfoManager tvinfo;
  };
  [NoInterfaceObject] interface TVInfoManager {
    CaptionValue getCaptionValue(CaptionInfoKey key) raises(WebAPIException);
    long addCaptionValueChangeListener(CaptionInfoKey key, CaptionValueChangeCallback callback) raises(WebAPIException);
    void removeCaptionValueChangeListener(long watchId) raises(WebAPIException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface CaptionValueChangeCallback {
    void onchanged(CaptionInfoKey key, CaptionValue value);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
