# SystemInfo API

This specification defines interfaces and methods that provide web applications with access to various properties of a system.

This API also provides interfaces and methods that can retrieve statuses of hardware devices, get the value of selected properties, and subscribe to asynchronous notifications of changes for selected values.

Web applications can use this API to access the following system properties:

- ADS ( **Since **: 3.0)
- BATTERY
- BUILD
- CAMERA_FLASH ( **Since **: 2.4)
- CELLULAR_NETWORK
- CPU
- DEVICE_ORIENTATION
- DISPLAY
- ETHERNET_NETWORK ( **Since **: 2.4)
- LOCALE ( **Since **: 2.1)
- MEMORY ( **Since **: 2.3)
- NET_PROXY_NETWORK ( **Since **: 3.0)
- NETWORK
- PERIPHERAL ( **Since **: 2.1)
- SERVICE_COUNTRY ( **Since **: 5.5)
- SIM
- STORAGE
- VIDEOSOURCE ( **Since **: 2.3)
- WIFI_NETWORK
Not all above properties may be available on every Tizen device. For instance, a device may not support the telephony feature. In that case, CELLULAR_NETWORK and SIM are not available. 

To check the available SystemInfoPropertyId , getCapability() method can be used.

- BATTERY          - tizen.systeminfo.getCapability( *"http://tizen.org/feature/battery" *)
- CAMERA_FLASH     - tizen.systeminfo.getCapability( *"http://tizen.org/feature/camera.back.flash" *)
- CELLULAR_NETWORK - tizen.systeminfo.getCapability( *"http://tizen.org/feature/network.telephony" *)
- DISPLAY          - tizen.systeminfo.getCapability( *"http://tizen.org/feature/screen" *)
- ETHERNET_NETWORK - tizen.systeminfo.getCapability( *"http://tizen.org/feature/network.ethernet" *)
- NET_PROXY_NETWORK - tizen.systeminfo.getCapability( *"http://tizen.org/feature/network.net_proxy" *)
- SIM              - tizen.systeminfo.getCapability( *"http://tizen.org/feature/network.telephony" *)
- WIFI_NETWORK     - tizen.systeminfo.getCapability( *"http://tizen.org/feature/network.wifi" *)
For more information on the System Information features, see System Information Guide .

Since: 1.0

## Table of Contents

- 1. Type Definitions
- 1.1. SystemInfoPropertyId
- 1.2. SystemInfoNetworkType
- 1.3. SystemInfoWifiSecurityMode
- 1.4. SystemInfoWifiEncryptionType
- 1.5. SystemInfoNetworkIpMode
- 1.6. SystemInfoDeviceOrientationStatus
- 1.7. SystemInfoSimState
- 1.8. SystemInfoProfile
- 1.9. SystemInfoLowMemoryStatus
- 1.10. SystemInfoVideoSourceType
- 2. Interfaces
- 2.1. SystemInfoObject
- 2.2. SystemInfo
- 2.3. SystemInfoOptions
- 2.4. SystemInfoPropertySuccessCallback
- 2.5. SystemInfoPropertyArraySuccessCallback
- 2.6. SystemInfoProperty
- 2.7. SystemInfoBattery
- 2.8. SystemInfoCpu
- 2.9. SystemInfoStorage
- 2.10. SystemInfoStorageUnit
- 2.11. SystemInfoDisplay
- 2.12. SystemInfoPanel
- 2.13. SystemInfoDeviceOrientation
- 2.14. SystemInfoBuild
- 2.15. SystemInfoLocale
- 2.16. SystemInfoNetwork
- 2.17. SystemInfoWifiNetwork
- 2.18. SystemInfoEthernetNetwork
- 2.19. SystemInfoCellularNetwork
- 2.20. SystemInfoNetProxyNetwork
- 2.21. SystemInfoSIM
- 2.22. SystemInfoPeripheral
- 2.23. SystemInfoMemory
- 2.24. SystemInfoVideoSourceInfo
- 2.25. SystemInfoVideoSource
- 2.26. SystemInfoCameraFlash
- 2.27. SystemInfoADS
- 2.28. SystemInfoServiceCountry
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| SystemInfoObject |  |
| SystemInfo | long long getTotalMemory () long long getAvailableMemory () unsigned long long getDeviceUptime () any getCapability (DOMString key) long getCount ( SystemInfoPropertyId property) void getPropertyValue ( SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback, optional ErrorCallback ? errorCallback) void getPropertyValueArray ( SystemInfoPropertyId property, SystemInfoPropertyArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback) unsigned long addPropertyValueChangeListener ( SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback, optional SystemInfoOptions ? options, optional ErrorCallback ? errorCallback) unsigned long addPropertyValueArrayChangeListener ( SystemInfoPropertyId property, SystemInfoPropertyArraySuccessCallback successCallback, optional SystemInfoOptions ? options, optional ErrorCallback ? errorCallback) void removePropertyValueChangeListener (unsigned long listenerId) |
| SystemInfoOptions |  |
| SystemInfoPropertySuccessCallback | void onsuccess ( SystemInfoProperty property) |
| SystemInfoPropertyArraySuccessCallback | void onsuccess ( SystemInfoProperty [] properties) |
| SystemInfoProperty |  |
| SystemInfoBattery |  |
| SystemInfoCpu |  |
| SystemInfoStorage |  |
| SystemInfoStorageUnit |  |
| SystemInfoDisplay |  |
| SystemInfoPanel |  |
| SystemInfoDeviceOrientation |  |
| SystemInfoBuild |  |
| SystemInfoLocale |  |
| SystemInfoNetwork |  |
| SystemInfoWifiNetwork |  |
| SystemInfoEthernetNetwork |  |
| SystemInfoCellularNetwork |  |
| SystemInfoNetProxyNetwork |  |
| SystemInfoSIM |  |
| SystemInfoPeripheral |  |
| SystemInfoMemory |  |
| SystemInfoVideoSourceInfo |  |
| SystemInfoVideoSource |  |
| SystemInfoCameraFlash | void setBrightness (double brightness) |
| SystemInfoADS |  |
| SystemInfoServiceCountry |  |

## 1. Type Definitions

### 1.1. SystemInfoPropertyId

The device property identifier.

```webidl
  enum SystemInfoPropertyId { "BATTERY", "CPU", "STORAGE", "DISPLAY", "DEVICE_ORIENTATION", "BUILD", "LOCALE", "NETWORK", "WIFI_NETWORK",
    "ETHERNET_NETWORK", "CELLULAR_NETWORK", "NET_PROXY_NETWORK", "SIM", "PERIPHERAL", "MEMORY", "VIDEOSOURCE", "CAMERA_FLASH", "ADS",
    "SERVICE_COUNTRY", "SOURCE_INFO", "PANEL" };
```

Since: 2.0

Remark: CAMERA_FLASH is supported since Tizen 2.4

Remark: ETHERNET_NETWORK is supported since Tizen 2.4

Remark: LOCALE and PERIPHERAL are supported since Tizen 2.1

Remark: MEMORY is supported since Tizen 2.3

Remark: NET_PROXY_NETWORK is supported since Tizen 3.0

Remark: VIDEOSOURCE is supported since Tizen 2.3

Remark: ADS is supported since Tizen 3.0

Remark: SERVICE_COUNTRY , SOURCE_INFO and PANEL are supported since Tizen 5.5

### 1.2. SystemInfoNetworkType

Data Network Type.

```webidl
  enum SystemInfoNetworkType { "NONE", "2G", "2.5G", "3G", "4G", "WIFI", "ETHERNET", "NET_PROXY", "UNKNOWN" };
```

Since: 2.0

Remark: NET_PROXY is supported since Tizen 3.0

### 1.3. SystemInfoWifiSecurityMode

Wi-Fi Security Mode.

```webidl
  enum SystemInfoWifiSecurityMode { "NONE", "WEP", "WPA_PSK", "WPA2_PSK", "EAP" };
```

Since: 2.4

- NONE - Open security type
- WEP - Wired Equivalent Privacy
- WPA_PSK - Wi-Fi Protected Access with Pre-Shared Key (PSK)
- WPA2_PSK - Wi-Fi Protected Access version 2 with Pre-Shared Key (PSK)
- EAP - Extensible Authentication Protocol

### 1.4. SystemInfoWifiEncryptionType

Wi-Fi Encryption Type.

```webidl
  enum SystemInfoWifiEncryptionType { "NONE", "WEP", "TKIP", "AES", "TKIP_AES_MIXED" };
```

Since: 2.4

- NONE - No encryption
- WEP - Wired Equivalent Privacy encryption
- TKIP - Temporal Key Integrity Protocol encryption
- AES - Advanced Encryption Standard
- TKIP_AES_MIXED - TKIP and AES are both supported

### 1.5. SystemInfoNetworkIpMode

IP configuration types.

```webidl
  enum SystemInfoNetworkIpMode { "NONE", "STATIC", "DYNAMIC", "AUTO", "FIXED" };
```

Since: 2.4

- NONE - Default value when network connection is not available
- STATIC - Manual IP configuration
- DYNAMIC - Configured IP using DHCP client
- AUTO - Configured IP from Auto IP pool (169.254/16). Later with DHCP client, if available
- FIXED - IP cannot be modified

### 1.6. SystemInfoDeviceOrientationStatus

Device Orientation Status.

```webidl
  enum SystemInfoDeviceOrientationStatus { "PORTRAIT_PRIMARY", "PORTRAIT_SECONDARY", "LANDSCAPE_PRIMARY", "LANDSCAPE_SECONDARY" };
```

Since: 2.0

SystemInfo reports the orientation of the device depending on the type of the device and physical position of the device relative to vertical direction.
A "phone type device" is a device for which the portrait position is the natural orientation.
A "tab type device" is a device for which the landscape position is basic working orientation.

| SystemInfoDeviceOrientationStatus | Phone type device | Tablet type device |
| --- | --- | --- |
| PORTRAIT_PRIMARY | Natural position | Rotated 90 degrees right (clockwise) |
| PORTRAIT_SECONDARY | Upside down, in other words rotated 180 degrees | Rotated 90 degrees left (anticlockwise) |
| LANDSCAPE_PRIMARY | Rotated 90 degrees left (anticlockwise) | Natural position |
| LANDSCAPE_SECONDARY | Rotated 90 degrees right (clockwise) | Upside down, in other words rotated 180 degrees |

### 1.7. SystemInfoSimState

SIM State.

```webidl
  enum SystemInfoSimState { "ABSENT", "INITIALIZING", "READY", "PIN_REQUIRED", "PUK_REQUIRED", "NETWORK_LOCKED", "SIM_LOCKED", "UNKNOWN" };
```

Since: 2.1

### 1.8. SystemInfoProfile

Device profile.

```webidl
  enum SystemInfoProfile { "MOBILE", "WEARABLE", "TV" };
```

Since: 2.2

Remark: MOBILE , WEARABLE and TV are supported since Tizen 2.3.

### 1.9. SystemInfoLowMemoryStatus

The low memory state of a device.

```webidl
  enum SystemInfoLowMemoryStatus { "NORMAL", "WARNING" };
```

Since: 2.3

- NORMAL - indicating the remaining memory is sufficient for an application to run
- WARNING - indicating the remaining memory is insufficient. Low memory warnings may happen differently according to the system

### 1.10. SystemInfoVideoSourceType

An enumerator to indicate the type of video source.

```webidl
  enum SystemInfoVideoSourceType { "TV", "AV", "SVIDEO", "COMP", "PC", "HDMI", "SCART", "DVI", "MEDIA" };
```

Since: 2.3

- TV - The input source from TV
- AV - The input source from Component video, three cables, each with RCA plugs (3 or more channels)
- SVIDEO - S-Video(Super-Video) and Y/C (2 channels)
- COMP - The input source from Composite video (1 channel)
- PC - The input source from personal computer (15-pin VGA connector)
- HDMI - The input source from HDMI(High-Definition Multimedia Interface)
- SCART - The input source from SCART(21-pin connector)
- DVI - The input source from DVI(Digital Visual Interface)
- MEDIA - The input source from media

## 2. Interfaces

### 2.1. SystemInfoObject

Defines what is instantiated by the *Tizen *object from the Tizen Platform.

```webidl
  [NoInterfaceObject] interface SystemInfoObject {
    readonly attribute SystemInfo systeminfo;
  };
```

```webidl
  Tizen implements SystemInfoObject;
```

Since: 1.0

There will be a tizen.systeminfo object that allows accessing the
functionality of the System Information API.

#### Attributes

- readonly SystemInfo systeminfo Object representing a system info module.

Since: 1.0

### 2.2. SystemInfo

This entry interface queries the information of a system.

```webidl
  [NoInterfaceObject] interface SystemInfo {
    long long getTotalMemory() raises(WebAPIException);
    long long getAvailableMemory() raises(WebAPIException);
    unsigned long long getDeviceUptime() raises(WebAPIException);
    any getCapability(DOMString key) raises(WebAPIException);
    long getCount(SystemInfoPropertyId property) raises(WebAPIException);
    void getPropertyValue(SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback,
                          optional ErrorCallback? errorCallback) raises(WebAPIException);
    void getPropertyValueArray(SystemInfoPropertyId property, SystemInfoPropertyArraySuccessCallback successCallback,
                               optional ErrorCallback? errorCallback) raises(WebAPIException);
    unsigned long addPropertyValueChangeListener(SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback,
                                                 optional SystemInfoOptions? options, optional ErrorCallback? errorCallback)
                                                 raises(WebAPIException);
    unsigned long addPropertyValueArrayChangeListener(SystemInfoPropertyId property,
                                                      SystemInfoPropertyArraySuccessCallback successCallback,
                                                      optional SystemInfoOptions? options, optional ErrorCallback? errorCallback)
                                                      raises(WebAPIException);
    void removePropertyValueChangeListener(unsigned long listenerId) raises(WebAPIException);
  };
```

Since: 1.0

This API offers methods for retrieving system information
and for subscribing notifications of system information changes.

#### Methods

`**getTotalMemory **`Gets the total amount of system memory (in bytes).

```javascript
long long getTotalMemory();
```

Since: 2.3

Return value:

long long: Total system memory.

Exceptions:

- WebAPIException
- with error type UnknownError in any error case.

Code example:

```javascript
/* To get total amount of system memory. */
console.log("The total memory size is " + tizen.systeminfo.getTotalMemory() + " bytes.");
```

`**getAvailableMemory **`Gets the amount of memory that is not in use (in bytes).

```javascript
long long getAvailableMemory();
```

Since: 2.3

Return value:

long long: Not used memory in bytes.

Exceptions:

- WebAPIException
- with error type UnknownError in any error case.

Code example:

```javascript
/* To get total amount of system memory. */
console.log("The available memory size is " + tizen.systeminfo.getAvailableMemory() + " bytes.");
```

`**getDeviceUptime **`Gets the time since booting of the device (in seconds).

```javascript
unsigned long long getDeviceUptime();
```

Since: 8.0

Return value:

unsigned long long: Time since boot in seconds.

Exceptions:

- WebAPIException
- with error type AbortError in any error case.

Code example:

```javascript
console.log("The device is " + tizen.systeminfo.getDeviceUptime() + " seconds since boot.");
```

`**getCapability **`Gets a device capability related to a given key.

```javascript
any getCapability(DOMString key);
```

Since: 2.3

See the available device capability keys .
The additional keys for the custom device capability are specified by OEMs and vendors.

Parameters:

- **key :
 The device capability key for the device or additional custom device capability key specified by OEM. **

Return value:

any: The value of the specified device capability.

Exceptions:

- WebAPIException
- with error type UnknownError in any other error case.

Code example:

```javascript
try
{
  /* Checks if a device supports Bluetooth API. */
  var bluetooth = tizen.systeminfo.getCapability("http://tizen.org/feature/network.bluetooth");
  console.log(" Bluetooth = " + bluetooth);
}
catch (error)
{
  console.log("Error name: " + error.name + ", message: " + error.message);
}
```

`**getCount **`Gets the number of system property information provided for a particular system property.

```javascript
long getCount(SystemInfoPropertyId property);
```

Since: 2.3

That is the length of array retrieved by the getPropertyValueArray() method for the given property.

Parameters:

- **property :
 The name of the system property. **

Return value:

long: The number of property values for the given property. If the property is not supported, 0 is returned.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

Code example:

```javascript
var count = tizen.systeminfo.getCount("SIM");
if (count === 0)
{
  console.log("There is no available SIM card.");
}
else
{
  console.log("There is (are) " + count + " SIM card(s) available.");
}
```

`**getPropertyValue **`Gets the current value of a specified system property.

```javascript
void getPropertyValue(SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback,
                      optional ErrorCallback? errorCallback);
```

Since: 1.0

The function must asynchronously acquire the current value of the requested property. If it is successful,
the successCallback must be invoked with an object containing the information provided by the property.

The *ErrorCallback *function can be launched with these error types:

- NotSupportedError - If the given property is not supported (since Tizen 2.3).

Remark: If the given property is not supported, *NotSupportedError *would be passed through a *ErrorCallback() *since Tizen 2.3.

Remark: If system provides more than one value for the system property, the primary (first) system property is returned through SystemInfoSuccessCallback.

Parameters:

- **property :
 The name of the property to retrieve.
- **Conditional privilege: **For using CELLULAR_NETWORK value, privilege **http://tizen.org/privilege/telephony (public level) **is needed since Tizen 2.4.
**
- **successCallback :
 Callback function called when the properties are successfully retrieved. **
- **errorCallback [optional] [nullable] :
 Callback function called when an error occurs while retrieving the properties. **

Exceptions:

- WebAPIException
- with error type SecurityError, this error is only thrown for CELLULAR_NETWORK property when an application does not declare *http://tizen.org/privilege/telephony *privilege in *config.xml *.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type UnknownError in any other error case.

Code example:

```javascript
function onSuccessCallback(cpu)
{
  console.log("The cpu load is " + cpu.load);
}

function onErrorCallback(error)
{
  console.log("An error occurred " + error.message);
}

tizen.systeminfo.getPropertyValue("CPU", onSuccessCallback, onErrorCallback);
```

Code example:

```javascript
function onSuccessCallback(cellular)
{
  console.log("The status of the cellular network is " + cellular.status);
}

function onErrorCallback(error)
{
  console.log("An error occurred " + error.message);
  /* If telephony_capability is false but getPropertyValue("CELLULAR_NETWORK, ...) is called, */
  /* NotSupportedError is passed. */
}

var telephony_capability =
    tizen.systeminfo.getCapability("http://tizen.org/feature/network.telephony");

if (telephony_capability === true)
{
  /* onSuccessCallback will be invoked. */
  tizen.systeminfo.getPropertyValue("CELLULAR_NETWORK", onSuccessCallback, onErrorCallback);
}
else
{
  console.log(
      "Telephony feature is not supported. Cellular network related information cannot be retrieved.");
}
```

`**getPropertyValueArray **`Gets the current values of a specified system property.

```javascript
void getPropertyValueArray(SystemInfoPropertyId property, SystemInfoPropertyArraySuccessCallback successCallback,
                           optional ErrorCallback? errorCallback);
```

Since: 2.3

It is recommended that you check if a device provides one or more than one value for a particular system property via getCount() .

If one particular system property is provided on a device, it returns an array containing one SystemInfoProperty object through *SystemInfoPropertyArraySuccessCallback *method. 
If more than one particular system property is provided, multiple SystemInfoProperty objects are returned.

The *ErrorCallback *function can be launched with these error types:

- NotSupportedError - If the given property is not supported.

Remark: See getCount() .

Parameters:

- **property :
 The name of the property to retrieve.
- **Conditional privilege: **For using CELLULAR_NETWORK value, privilege **http://tizen.org/privilege/telephony (public level) **is needed since Tizen 2.4.
**
- **successCallback :
 Callback function called when the properties are successfully retrieved. **
- **errorCallback [optional] [nullable] :
 Callback function called when an error occurs while retrieving the properties. **

Exceptions:

- WebAPIException
- with error type SecurityError, this error is only thrown for CELLULAR_NETWORK property when an application does not declare *http://tizen.org/privilege/telephony *privilege in *config.xml *.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

Code example:

```javascript
function successCB(property)
{
  console.log("The SIM's current state is " + property.state);
}

function successArrayCB(properties)
{
  console.log("The number of the returned system properties is " + properties.length);
  for (var i = 0; i < properties.length; i++)
  {
    console.log("[" + i + "] SIM's state is " + properties[i].state);
  }
}

var count = tizen.systeminfo.getCount("SIM");
if (count === 0)
{
  console.log("This device does not provide SIM card.");
}
else if (count > 1)
{
  tizen.systeminfo.getPropertyValueArray("SIM", successArrayCB);
}
else
{
  tizen.systeminfo.getPropertyValue("SIM", successCB);
}
```

`**addPropertyValueChangeListener **`Adds a listener to allow tracking changes in one or more system properties.

```javascript
unsigned long addPropertyValueChangeListener(SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback,
                                             optional SystemInfoOptions? options, optional ErrorCallback? errorCallback);
```

Since: 1.0

When called, it immediately returns and then asynchronously starts a watch process defined by the following steps:

1. Register the successCallback to receive system events that the status of the requested properties may have changed.

2. When a system event is successfully received, invoke the associated successCallback with an object containing the property
values.

3. Repeat step 2 until removePropertyValueChangeListener function is called.

There are device properties which are never changed (e.g. "BUILD") and properties which are not changed on some devices
(e.g. "DEVICE_ORIENTATION" in Tizen TV device). The addPropertyValueChangeListener() method accepts
any identifier of these properties, but the listener added for them will not be invoked.

The *errorCallback *can be launched with any of these error types:

- NotSupportedError - If the given property is not supported (since Tizen 2.3). 
For example, monitoring CELLULAR_NETWORK changes is not supported on a device which does not support the telephony feature.

Remark: The *errorCallback() *is newly added as an optional parameter since Tizen 2.3.

Parameters:

- **property :
 The name of the property to retrieve.
- **Conditional privilege: **For using CELLULAR_NETWORK value, privilege **http://tizen.org/privilege/telephony (public level) **is needed since Tizen 2.4.
**
- **successCallback :
 Callback function called when the properties are successfully retrieved. **
- **options [optional] [nullable] :
 An object containing the various options for fetching the properties requested. See details . **
- **errorCallback [optional] [nullable] :
 Callback function called when an error occurs. **

Return value:

unsigned long: An identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contains an invalid value (e.g. the invalid value for *options *).

- with error type SecurityError, this error is only thrown for CELLULAR_NETWORK property when an application does not declare *http://tizen.org/privilege/telephony *privilege in *config.xml *.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type UnknownError in any other error case.

Code example:

```javascript
function onSuccessCallback(cpu)
{
  console.log("The cpu load: " + cpu.load);
}

tizen.systeminfo.addPropertyValueChangeListener("CPU", onSuccessCallback, {lowThreshold: 0.2});
```

`**addPropertyValueArrayChangeListener **`Adds a listener to allow tracking of changes in one or more values of a system property.

```javascript
unsigned long addPropertyValueArrayChangeListener(SystemInfoPropertyId property,
                                                  SystemInfoPropertyArraySuccessCallback successCallback,
                                                  optional SystemInfoOptions? options, optional ErrorCallback? errorCallback);
```

Since: 2.3

The *ErrorCallback *function can be launched with these error types:

- NotSupportedError - If the given property is not supported (since Tizen 2.3). 
For example, monitoring CELLULAR_NETWORK changes is not supported on a device which does not support the telephony feature.
There are device properties which never change (for example "BUILD") and properties which do not change on the current platform
(for example "DEVICE_ORIENTATION" for some platforms). The addPropertyValueChangeListener() method accepts
any identifier of these properties, but the listener added for them will not be invoked.

Parameters:

- **property :
 The name of the property to retrieve.
- **Conditional privilege: **For using CELLULAR_NETWORK value, privilege **http://tizen.org/privilege/telephony (public level) **is needed since Tizen 2.4.
**
- **successCallback :
 Callback function called when the properties are successfully retrieved. **
- **options [optional] [nullable] :
 An object containing the various options for fetching the properties requested. **
- **errorCallback [optional] [nullable] :
 Callback function called when an error occurs. **

Return value:

unsigned long: An identifier used to clear the watch subscription.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contains an invalid value (e.g. the invalid value for *options *).

- with error type SecurityError, this error is only thrown for CELLULAR_NETWORK property when an application does not declare *http://tizen.org/privilege/telephony *privilege in *config.xml *.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type UnknownError in any other error case.

`**removePropertyValueChangeListener **`Unsubscribes notifications for property changes.

```javascript
void removePropertyValueChangeListener(unsigned long listenerId);
```

Since: 1.0

If a valid listenerId argument is passed that corresponds to an existing subscription,
then the watch process must immediately terminate and no further
callback is invoked.

Parameters:

- **listenerId :
 An identifier of the subscription returned by the addPropertyValueChangeListener() or addPropertyValueArrayChangeListener() method. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contains an invalid value.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type UnknownError in any other error case.

Code example:

```javascript
var id = null;
function onSuccessCallback(cpu)
{
  console.log("New value for CPU load is " + cpu.load);
  if (id != null)
  {
    /* After receiving the first notification, clear it. */
    tizen.systeminfo.removePropertyValueChangeListener(id);
  }
}

id = tizen.systeminfo.addPropertyValueChangeListener("CPU", onSuccessCallback);
```

### 2.3. SystemInfoOptions

An object containing the various options for fetching the properties requested.

```webidl
  dictionary SystemInfoOptions {
    unsigned long timeout;
    double highThreshold;
    double lowThreshold;
  };
```

Since: 1.0

The highThreshold and lowThreshold values are only applicable to the following *SystemInfoPropertyId *.

- SystemInfoBattery - level: *from 0 to 1 *
- SystemInfoCpu - load: *from 0 to 1 *
- SystemInfoDisplay - brightness: *from 0 to 1 *
For other cases, it is ignored.

#### Dictionary members

unsigned long timeout The number of milliseconds beyond which the operation must be interrupted.

Since: 1.0

double highThreshold An attribute to indicate that the *successCallback() *method in the watch

operation will be triggered only if the device property is a number and its value is greater than or equal to this number.
This attribute has no effect on the *get() *method.

Since: 1.0

double lowThreshold An attribute to indicate that the *successCallback() *method in the watch operation must be triggered only if the property is a number and its value is lower than or equal to this number.

If both *highThreshold *and *lowThreshold *parameters are specified, the *successCallback() *is triggered if and only if the property value is either lower than the value of *lowThreshold *or higher than the value of *highThreshold *.
This attribute has no effect on the get method.

Since: 1.0

### 2.4. SystemInfoPropertySuccessCallback

Systeminfo specific success callback.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface SystemInfoPropertySuccessCallback {
    void onsuccess(SystemInfoProperty property);
  };
```

Since: 1.0

This callback interface specifies a success callback with SystemInfoProperty as input argument.
It is used in asynchronous
operations, such as getPropertyValue() or addPropertyValueChangeListener() .

#### Methods

`**onsuccess **`Function invoked when the asynchronous call completes successfully.

```javascript
void onsuccess(SystemInfoProperty property);
```

Since: 1.0

Parameters:

- **property :
 The property returned from a successful asynchronous operation. **

### 2.5. SystemInfoPropertyArraySuccessCallback

Systeminfo specific success callback.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface SystemInfoPropertyArraySuccessCallback {
    void onsuccess(SystemInfoProperty[] properties);
  };
```

Since: 2.3

This callback interface specifies a success callback with SystemInfoProperty as input argument.
It is used in asynchronous operations, such as getPropertyValueArray() or addPropertyValueArrayChangeListener() .

#### Methods

`**onsuccess **`Function invoked when the asynchronous call completes successfully.

```javascript
void onsuccess(SystemInfoProperty[] properties);
```

Since: 2.3

Parameters:

- **properties :
 The array of SystemInfoProperty objects returned from a successful asynchronous operation. **

### 2.6. SystemInfoProperty

This is a common abstract interface used by different types of system information objects.

```webidl
  [NoInterfaceObject] interface SystemInfoProperty {
  };
```

Since: 1.0

### 2.7. SystemInfoBattery

This property reflects the general state of the system's battery.

```webidl
  [NoInterfaceObject] interface SystemInfoBattery : SystemInfoProperty {
    readonly attribute double level;
    readonly attribute boolean isCharging;
    readonly attribute long? timeToDischarge;
    readonly attribute long? timeToFullCharge;
  };
```

Since: 1.0

**Listener notice **:

Change listener registered on BATTERY property is triggered on *level *and *isCharging *properties change.

#### Attributes

- readonly double level An attribute to specify the remaining level of an internal battery, scaled from 0 to 1 :

- 0 indicates that the battery level is the lowest and the system is about to enter shutdown mode.
- 1 indicates that the system's charge is maximum.
Any threshold parameter used in a watch operation to monitor this property applies to this attribute.

Since: 1.0

- readonly boolean isCharging Indicates whether the battery source is currently charging.

Since: 1.0

- readonly long timeToDischarge [nullable] Estimated time to discharge, in minutes.

This parameter is mutually exclusive with parameter *timeToFullCharge *.
An attribute *timeToDischarge *becomes null when device is plugged.

This attribute may equal to -1 indicating there is no enough collected data, which means
that the device is still learning device's power usage characteristics and cannot predict the time yet.
This process may take up to few days.

Since: 4.0

- readonly long timeToFullCharge [nullable] Estimated time to finish charging battery, in minutes.

This parameter is mutually exclusive with parameter *timeToDischarge *.
An attribute *timeToFullCharge *becomes null when device is unplugged.

This attribute may equal to -1 indicating there is no enough collected data, which means
that the device is still learning device's power usage characteristics and cannot predict the time yet.
This process may take up to few days.

Since: 4.0

### 2.8. SystemInfoCpu

This property reflects the state of the CPUs available to this system.

```webidl
  [NoInterfaceObject] interface SystemInfoCpu : SystemInfoProperty {
    readonly attribute double load;
  };
```

Since: 1.0

#### Attributes

- readonly double load An attribute to indicate the current CPU load, as a number between 0.0 and 1.0 , representing the minimum and maximum values allowed on this system.

Any threshold parameter used in a watch function to monitor this property applies to this attribute.

Since: 1.0

### 2.9. SystemInfoStorage

This property exposes the data storage devices connected to this system.

```webidl
  [NoInterfaceObject] interface SystemInfoStorage : SystemInfoProperty {
    readonly attribute SystemInfoStorageUnit[] units;
  };
```

Since: 1.0

#### Attributes

- readonly SystemInfoStorageUnit[] units The array of storage units connected to this device.

Since: 1.0

### 2.10. SystemInfoStorageUnit

This property exposes a single storage device connected to this system.

```webidl
  [NoInterfaceObject] interface SystemInfoStorageUnit : SystemInfoProperty {
    readonly attribute DOMString type;
    readonly attribute unsigned long long capacity;
    readonly attribute unsigned long long availableCapacity;
    readonly attribute boolean isRemovable;
  };
```

Since: 1.0

#### Attributes

- readonly DOMString type The type of a storage device. The value is one of the constants defined for this type.

The supported storage unit types are:

- UNKNOWN
- INTERNAL
- USB_DEVICE
- USB_HOST
- MMC

Since: 1.0

- readonly unsigned long long capacity The total amount of space available on the user's storage (excluding system-reserved), in bytes.

Since: 1.0

- readonly unsigned long long availableCapacity The amount of space currently available on the user's storage, in bytes.

Since: 1.0

- readonly boolean isRemovable An attribute to indicate whether a device can be removed or not.

The following values are supported:

- true - If this storage unit can be removed from the system (such as an sdcard unplugged)
- false - If this storage unit cannot be removed from the system

Since: 2.1

### 2.11. SystemInfoDisplay

This property reflects the information of the Display.

```webidl
  [NoInterfaceObject] interface SystemInfoDisplay : SystemInfoProperty {
    readonly attribute unsigned long resolutionWidth;
    readonly attribute unsigned long resolutionHeight;
    readonly attribute unsigned long dotsPerInchWidth;
    readonly attribute unsigned long dotsPerInchHeight;
    readonly attribute double physicalWidth;
    readonly attribute double physicalHeight;
    readonly attribute double brightness;
  };
```

Since: 1.0

**Listener notice **:

Change listener registered on DISPLAY property is triggered on *brightness *property change.

#### Attributes

- readonly unsigned long resolutionWidth The total number of addressable pixels in the horizontal direction of a rectangular entity
(such as Camera, Display, Image, Video, ...) when held in its default orientation.

Since: 1.0

- readonly unsigned long resolutionHeight The total number of addressable pixels in the vertical direction of a rectangular element
(such as Camera, Display, Image, Video, ...) when held in its default orientation.

Since: 1.0

- readonly unsigned long dotsPerInchWidth Resolution of this device, along its width, in dots per inch.

Since: 1.0

- readonly unsigned long dotsPerInchHeight Resolution of this device, along its height, in dots per inch.

Since: 1.0

- readonly double physicalWidth The display's physical width in millimeters.

Since: 1.0

- readonly double physicalHeight The display's physical height in millimeters.

Since: 1.0

- readonly double brightness The current brightness of a display ranging between 0 to 1 .

Since: 1.0

### 2.12. SystemInfoPanel

This property reflects the resolution limits of the panel.

```webidl
  [NoInterfaceObject] interface SystemInfoPanel : SystemInfoProperty {
    readonly attribute unsigned long panelWidth;
    readonly attribute unsigned long panelHeight;
  };
```

Since: 5.5

Remark: Methods addPropertyValueChangeListener() and addPropertyValueArrayChangeListener() triggers
errorCallback with error type NotSupportedError in case of use the PANEL property.

#### Attributes

- readonly unsigned long panelWidth The width of the panel in pixels.

Since: 5.5

- readonly unsigned long panelHeight The height of the panel in pixels.

Since: 5.5

### 2.13. SystemInfoDeviceOrientation

This property reflects the information of the device orientation in this system.

```webidl
  [NoInterfaceObject] interface SystemInfoDeviceOrientation : SystemInfoProperty {
    readonly attribute SystemInfoDeviceOrientationStatus status;
    readonly attribute boolean isAutoRotation;
  };
```

Since: 2.0

#### Attributes

- readonly SystemInfoDeviceOrientationStatus status Represents the status of the current device orientation.

Since: 2.0

- readonly boolean isAutoRotation Indicates whether the device is in autorotation.

Since: 2.2

### 2.14. SystemInfoBuild

This property reflects the information of the current device.

```webidl
  [NoInterfaceObject] interface SystemInfoBuild : SystemInfoProperty {
    readonly attribute DOMString model;
    readonly attribute DOMString manufacturer;
    readonly attribute DOMString buildVersion;
  };
```

Since: 2.0

#### Attributes

- readonly DOMString model Represents the model name of the current device.

Since: 2.0

- readonly DOMString manufacturer Represents the manufacturer of the device.

Since: 2.1

- readonly DOMString buildVersion Represents the build version information of the device.

Since: 2.2

### 2.15. SystemInfoLocale

This property reflects the locale information of the current device.

```webidl
  [NoInterfaceObject] interface SystemInfoLocale : SystemInfoProperty {
    readonly attribute DOMString language;
    readonly attribute DOMString country;
  };
```

Since: 2.1

#### Attributes

- readonly DOMString language Indicates the current language setting in the (LANGUAGE)_(REGION) syntax.

The language setting is in the ISO 639-2 format and the region setting is in the ISO 3166-1 alpha-2 format.
The language setting is case-sensitive.

Since: 2.1

- readonly DOMString country Indicates the current country setting in the (LANGUAGE)_(REGION) syntax.

The language setting is in the ISO 639-2 format and the region setting is in the ISO 3166-1 alpha-2 format.
The country setting is case-sensitive.

Since: 2.1

### 2.16. SystemInfoNetwork

This property reflects the information of the data network in this system.

```webidl
  [NoInterfaceObject] interface SystemInfoNetwork : SystemInfoProperty {
    readonly attribute SystemInfoNetworkType networkType;
  };
```

Since: 2.0

#### Attributes

- readonly SystemInfoNetworkType networkType Represents the network type of the current data network.

Since: 2.0

### 2.17. SystemInfoWifiNetwork

This property reflects the information of the Wi-Fi network in this system.

```webidl
  [NoInterfaceObject] interface SystemInfoWifiNetwork : SystemInfoProperty {
    readonly attribute DOMString status;
    readonly attribute DOMString ssid;
    readonly attribute DOMString ipAddress;
    readonly attribute DOMString ipv6Address;
    readonly attribute DOMString macAddress;
    readonly attribute double signalStrength;
    readonly attribute SystemInfoWifiSecurityMode securityMode;
    readonly attribute SystemInfoWifiEncryptionType encryptionType;
    readonly attribute SystemInfoNetworkIpMode ipMode;
    readonly attribute DOMString subnetMask;
    readonly attribute DOMString gateway;
    readonly attribute DOMString dns;
  };
```

Since: 1.0

**Listener notice **:

Change listener registered on WIFI_NETWORK property is triggered on *ipAddress *and *ipv6Address *properties change (the network layer).
Those changes could be not consistent with physical layer ( *status *or *signalStrength *of physical adapter).

According to above constraints, in specific situation the listener could be
triggered just before network adapter shutdown and the value of *status *returned
by listener would be outdated.

#### Attributes

- readonly DOMString status Represents the status (ON or OFF) of the Wi-Fi connection.

Since: 1.0

- readonly DOMString ssid Represents the SSID of the Wi-Fi network.

Since: 1.0

- readonly DOMString ipAddress Represents the IPv4 address of the Wi-Fi network.

Since: 1.0

- readonly DOMString ipv6Address Represents the IPv6 address of the Wi-Fi network.

Since: 2.0

- readonly DOMString macAddress Represents the MAC address of the Wi-Fi interface.

It is written in MM:MM:MM:SS:SS:SS format.

Since: 2.3

- readonly double signalStrength This connection's signal strength, as a normalized value between 0 (no signal detected) and 1 (the level is at its maximum value).

Since: 1.0

- readonly SystemInfoWifiSecurityMode securityMode Represents this connection's security mode.

Since: 2.4

- readonly SystemInfoWifiEncryptionType encryptionType Represents this connection's encryption type.

Since: 2.4

- readonly SystemInfoNetworkIpMode ipMode Represents this connection's IP configuration type.

Since: 2.4

- readonly DOMString subnetMask Represents the subnet mask of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

- readonly DOMString gateway Represents the gateway of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

- readonly DOMString dns Represents the DNS address of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

### 2.18. SystemInfoEthernetNetwork

This property reflects the information of the Ethernet network in this system.

```webidl
  [NoInterfaceObject] interface SystemInfoEthernetNetwork : SystemInfoProperty {
    readonly attribute DOMString cable;
    readonly attribute DOMString status;
    readonly attribute DOMString ipAddress;
    readonly attribute DOMString ipv6Address;
    readonly attribute DOMString macAddress;
    readonly attribute SystemInfoNetworkIpMode ipMode;
    readonly attribute DOMString subnetMask;
    readonly attribute DOMString gateway;
    readonly attribute DOMString dns;
  };
```

Since: 2.4

**Listener notice **:

Change listener registered on ETHERNET_NETWORK property is triggered on *ipAddress *and *ipv6Address *properties change (the network layer).
Those changes could be not consistent with physical layer ( *status *of physical adapter).

According to above constraints, in specific situation the listener could be
triggered just before network adapter shutdown and the value of *status *returned
by listener would be outdated.

#### Attributes

- readonly DOMString cable Represents the cable status (ATTACHED or DETACHED) of the Ethernet interface.

Since: 2.4

- readonly DOMString status Represents the status (DEACTIVATED, DISCONNECTED or CONNECTED) of the Ethernet interface.

Since: 2.4

- readonly DOMString ipAddress Represents the IPv4 address of the Ethernet network.

Since: 2.4

- readonly DOMString ipv6Address Represents the IPv6 address of the Ethernet network.

Since: 2.4

- readonly DOMString macAddress Represents the MAC address of the Ethernet interface.

It is written in MM:MM:MM:SS:SS:SS format.

Since: 2.4

- readonly SystemInfoNetworkIpMode ipMode Represents this connection's IP configuration type.

Since: 2.4

- readonly DOMString subnetMask Represents the subnet mask of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

- readonly DOMString gateway Represents the gateway of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

- readonly DOMString dns Represents the DNS address of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

### 2.19. SystemInfoCellularNetwork

This property reflects the information of the Cellular network in this system.

```webidl
  [NoInterfaceObject] interface SystemInfoCellularNetwork : SystemInfoProperty {
    readonly attribute DOMString status;
    readonly attribute DOMString apn;
    readonly attribute DOMString ipAddress;
    readonly attribute DOMString ipv6Address;
    readonly attribute unsigned short mcc;
    readonly attribute unsigned short mnc;
    readonly attribute unsigned short cellId;
    readonly attribute unsigned short lac;
    readonly attribute boolean isRoaming;
    readonly attribute boolean isFlightMode;
    readonly attribute DOMString imei raises(WebAPIException);
    readonly attribute SystemInfoNetworkIpMode ipMode;
    readonly attribute DOMString subnetMask;
    readonly attribute DOMString gateway;
    readonly attribute DOMString dns;
  };
```

Since: 1.0

**Listener notice **:

Change listener registered on CELLULAR_NETWORK property is triggered on *ipAddress *, *ipv6Address *(the network layer), *cellId *, *lac *and *isFlightMode *properties change.
Those changes could be not consistent with physical layer ( *status *of physical adapter).

According to above constraints, in specific situation the listener could be
triggered just before network adapter shutdown and the value of *status *returned
by listener would be outdated.

#### Attributes

- readonly DOMString status Represents the status (ON or OFF) of the cellular network.

Since: 1.0

- readonly DOMString apn Represents an Access Point Name of the cellular network.

Since: 1.0

- readonly DOMString ipAddress Represents the IPv4 address of the cellular network.

Since: 1.0

- readonly DOMString ipv6Address Represents the IPv6 address of the cellular network.

Since: 2.0

- readonly unsigned short mcc Represents Mobile Country Code (MCC) of the cellular network.

Since: 1.0

- readonly unsigned short mnc Represents Mobile Network Code (MNC) of the cellular network. MNC is used in combination with MCC (also known as a "MCC / MNC tuple") to uniquely
identify a mobile phone operator/carrier using the GSM, CDMA, iDEN, TETRA and UMTS public land mobile networks and some satellite mobile networks.

Since: 1.0

- readonly unsigned short cellId Represents Cell ID.

Since: 1.0

- readonly unsigned short lac Represents Location Area Code.

Since: 1.0

- readonly boolean isRoaming Indicates whether the connection is set up while the device is roaming.

Since: 1.0

- readonly boolean isFlightMode Indicates whether the device is in flight mode.

Since: 2.1

- readonly DOMString imei Represents the International Mobile Equipment Identity (IMEI).

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/telephony

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly SystemInfoNetworkIpMode ipMode Represents this connection's IP configuration type.

Since: 2.4

- readonly DOMString subnetMask Represents the subnet mask of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

- readonly DOMString gateway Represents the gateway of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

- readonly DOMString dns Represents the DNS address of this connection.

It is written in 255.255.255.255 format.

Since: 2.4

### 2.20. SystemInfoNetProxyNetwork

This property reflects the information of the net_proxy network in this system.

```webidl
  [NoInterfaceObject] interface SystemInfoNetProxyNetwork : SystemInfoProperty {
    readonly attribute DOMString status;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString status Represents the status (ON or OFF) of the net_proxy network.

Since: 3.0

### 2.21. SystemInfoSIM

This property reflects the information of the SIM card information.

```webidl
  [NoInterfaceObject] interface SystemInfoSIM : SystemInfoProperty {
    readonly attribute SystemInfoSimState state raises(WebAPIException);
    readonly attribute DOMString operatorName raises(WebAPIException);
    readonly attribute DOMString msisdn raises(WebAPIException);
    readonly attribute DOMString iccid raises(WebAPIException);
    readonly attribute unsigned short mcc raises(WebAPIException);
    readonly attribute unsigned short mnc raises(WebAPIException);
    readonly attribute DOMString msin raises(WebAPIException);
    readonly attribute DOMString spn raises(WebAPIException);
  };
```

Since: 2.0

#### Attributes

- readonly SystemInfoSimState state Represents the SIM card state.

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/system

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly DOMString operatorName Represents the Operator Name String (ONS) of Common PCN Handset Specification (CPHS) in SIM card.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/system

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly DOMString msisdn Represents the SIM card subscriber number.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/telephony

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly DOMString iccid Represents the Integrated Circuit Card ID.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/system

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly unsigned short mcc Represents the Mobile Country Code (MCC) of SIM provider.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/system

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly unsigned short mnc Represents the Mobile Network Code (MNC) of SIM provider.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/system

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly DOMString msin Represents the Mobile Subscription Identification Number (MSIN) of SIM provider.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/telephony

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

- readonly DOMString spn Represents the Service Provider Name (SPN) of SIM card.

Since: 2.0

Privilege level: public

Privilege: http://tizen.org/privilege/system

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

### 2.22. SystemInfoPeripheral

This property reflects the peripheral information of the current device.

```webidl
  [NoInterfaceObject] interface SystemInfoPeripheral : SystemInfoProperty {
    readonly attribute boolean isVideoOutputOn;
  };
```

Since: 2.1

#### Attributes

- readonly boolean isVideoOutputOn Represents the video out status.

Since: 2.1

### 2.23. SystemInfoMemory

This property represents information about the memory state on the device system.

```webidl
  [NoInterfaceObject] interface SystemInfoMemory : SystemInfoProperty {
    readonly attribute SystemInfoLowMemoryStatus status;
  };
```

Since: 2.3

#### Attributes

- readonly SystemInfoLowMemoryStatus status Represents the low memory state.

Since: 2.3

### 2.24. SystemInfoVideoSourceInfo

This property reflects each input source the current device has.

```webidl
  [NoInterfaceObject] interface SystemInfoVideoSourceInfo {
    readonly attribute SystemInfoVideoSourceType type;
    readonly attribute long number;
    readonly attribute boolean? signal;
    readonly attribute DOMString? editName;
  };
```

Since: 2.3

If there are 2 HDMI inputs on a device, two *SystemInfoVideoSourceInfo *objects must be retrieved through *SystemInfoVideoSource *
{type=HDMI, number=1, signal=null}, {type=HDMI, number=2, signal=null}

#### Attributes

- readonly SystemInfoVideoSourceType type Represents the type of the video input source.

Since: 2.3

- readonly long number Represents the input number of the input source.

If the source is "HDMI 2", the *number *is 2.

Since: 2.3

- readonly boolean signal [nullable] Represents if there is a signal provided on the source.

The *signal *attribute can be null . The null value means that information about signal could not be retrieved at the time of returning this object.
If the value is true , it means that there is signal provided. The value set to false means, that there is no signal.
By default getPropertyValue functions does not support this member, and will return object with *signal *value set to null , it is supported only by TVWindow module. To get data about signal use tizen.tvwindow.getSource() or tizen.tvwindow.setSource() .

Since: 5.5

- readonly DOMString editName [nullable] Represents the name of connected video source.

The *editName *attribute can be null . The null value means that information about *editName *could not be retrieved at the time of returning this object.
Attribute is only supported for connected sources and will be null when source will be disconnected.

Since: 7.0

### 2.25. SystemInfoVideoSource

This property reflects the video sources the device has.

```webidl
  [NoInterfaceObject] interface SystemInfoVideoSource : SystemInfoProperty {
    readonly attribute SystemInfoVideoSourceInfo[] connected;
    readonly attribute SystemInfoVideoSourceInfo[] disconnected;
  };
```

Since: 2.3

#### Attributes

- readonly SystemInfoVideoSourceInfo[] connected Represents a list of video sources that a device is connected with.

Since: 2.3

- readonly SystemInfoVideoSourceInfo[] disconnected Represents a list of video sources that a device is not connected with.

Since: 2.3

### 2.26. SystemInfoCameraFlash

The SystemInfoCameraFlash provides the way to control the attached the camera flash.

```webidl
  [NoInterfaceObject] interface SystemInfoCameraFlash : SystemInfoProperty {
    readonly attribute double brightness raises(WebAPIException);
    readonly attribute DOMString camera;
    readonly attribute long levels raises(WebAPIException);
    void setBrightness(double brightness) raises(WebAPIException);
  };
```

Since: 2.4

#### Attributes

- readonly double brightness Brightness level of the camera flash (0~1).

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/led

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

Code example:

```javascript
tizen.systeminfo.getPropertyValue("CAMERA_FLASH",
    function(flash)
    {
      console.log("Flash brightness is set to: " + (flash.brightness * 100).toFixed(0) + "%");
    },
    function(error)
    {
      console.log("Error, name: " + error.name + ", message: " + error.message);
    });
```

- readonly DOMString camera Specifies camera to which this flash belongs.

- BACK - back camera flash
- FRONT - front camera flash
- EXTERNAL - external camera flash
- OTHER - a flash attached to any other camera

The getPropertyValue() method retrieves the SystemInfoCameraFlash for BACK camera.

Since: 2.4

- readonly long levels Number of brightness levels supported by the flash (other than 0 brightness).

Since: 2.4

Privilege level: public

Privilege: http://tizen.org/privilege/led

Exceptions:

- WebAPIException
- with error type SecurityError, if this attribute is not allowed.

#### Methods

`**setBrightness **`Sets the brightness value of the flash that is located next to the camera.

```javascript
void setBrightness(double brightness);
```

Since: 2.4

If the specified brightness value is not supported by the device, the brightness is rounded down to the nearest supported brightness value.

Privilege level: public

Privilege: http://tizen.org/privilege/led

Parameters:

- **brightness :
 The brightness value of LED (0~1). **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contains an invalid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if the method cannot be completed because of an unknown error.

Code example:

```javascript
tizen.systeminfo.getPropertyValue("CAMERA_FLASH",
    function(flash)
    {
      try
      {
        flash.setBrightness(1);
      }
      catch (error)
      {
        console.log("Setting flash brightness failed: " + error.message);
      }
    },
    function(error)
    {
      console.log("Error, name: " + error.name + ", message: " + error.message);
    });
```

### 2.27. SystemInfoADS

This property represents information about advertisement service - ADS.

```webidl
  [NoInterfaceObject] interface SystemInfoADS : SystemInfoProperty {
    readonly attribute DOMString id;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString id Represents the unique id of advertisement service. It is used to distinguish each device.

Since: 3.0

### 2.28. SystemInfoServiceCountry

This property represents a country of which basic policy of terms and conditions is set.

```webidl
  [NoInterfaceObject] interface SystemInfoServiceCountry : SystemInfoProperty {
    readonly attribute DOMString serviceCountry;
  };
```

Since: 5.5

#### Attributes

- readonly DOMString serviceCountry Represents a country of which basic policy is set.

Since: 5.5

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee the running of the application (e.g. track the battery usage) on a device which has a battery, declare the following feature requirements in the config file:

- http://tizen.org/feature/battery
To guarantee the running of the application on a device which has camera back flash and control it, declare the following feature requirements in the config file:

- http://tizen.org/feature/camera.back.flash
To guarantee the running of the application on a device which supports Ethernet network feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.ethernet
To guarantee the running of the application on a device which supports network proxy for internet connection, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.net_proxy
To guarantee the running of the application on a device which supports telephony feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.telephony
To guarantee the running of the application on a device which supports Wi-Fi, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.wifi

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module SystemInfo {
  enum SystemInfoPropertyId { "BATTERY", "CPU", "STORAGE", "DISPLAY", "DEVICE_ORIENTATION", "BUILD", "LOCALE", "NETWORK", "WIFI_NETWORK",
    "ETHERNET_NETWORK", "CELLULAR_NETWORK", "NET_PROXY_NETWORK", "SIM", "PERIPHERAL", "MEMORY", "VIDEOSOURCE", "CAMERA_FLASH", "ADS",
    "SERVICE_COUNTRY", "SOURCE_INFO", "PANEL" };
  enum SystemInfoNetworkType { "NONE", "2G", "2.5G", "3G", "4G", "WIFI", "ETHERNET", "NET_PROXY", "UNKNOWN" };
  enum SystemInfoWifiSecurityMode { "NONE", "WEP", "WPA_PSK", "WPA2_PSK", "EAP" };
  enum SystemInfoWifiEncryptionType { "NONE", "WEP", "TKIP", "AES", "TKIP_AES_MIXED" };
  enum SystemInfoNetworkIpMode { "NONE", "STATIC", "DYNAMIC", "AUTO", "FIXED" };
  enum SystemInfoDeviceOrientationStatus { "PORTRAIT_PRIMARY", "PORTRAIT_SECONDARY", "LANDSCAPE_PRIMARY", "LANDSCAPE_SECONDARY" };
  enum SystemInfoSimState { "ABSENT", "INITIALIZING", "READY", "PIN_REQUIRED", "PUK_REQUIRED", "NETWORK_LOCKED", "SIM_LOCKED", "UNKNOWN" };
  enum SystemInfoProfile { "MOBILE", "WEARABLE", "TV" };
  enum SystemInfoLowMemoryStatus { "NORMAL", "WARNING" };
  enum SystemInfoVideoSourceType { "TV", "AV", "SVIDEO", "COMP", "PC", "HDMI", "SCART", "DVI", "MEDIA" };
  dictionary SystemInfoOptions {
    unsigned long timeout;
    double highThreshold;
    double lowThreshold;
  };
  Tizen implements SystemInfoObject;
  [NoInterfaceObject] interface SystemInfoObject {
    readonly attribute SystemInfo systeminfo;
  };
  [NoInterfaceObject] interface SystemInfo {
    long long getTotalMemory() raises(WebAPIException);
    long long getAvailableMemory() raises(WebAPIException);
    unsigned long long getDeviceUptime() raises(WebAPIException);
    any getCapability(DOMString key) raises(WebAPIException);
    long getCount(SystemInfoPropertyId property) raises(WebAPIException);
    void getPropertyValue(SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback,
                          optional ErrorCallback? errorCallback) raises(WebAPIException);
    void getPropertyValueArray(SystemInfoPropertyId property, SystemInfoPropertyArraySuccessCallback successCallback,
                               optional ErrorCallback? errorCallback) raises(WebAPIException);
    unsigned long addPropertyValueChangeListener(SystemInfoPropertyId property, SystemInfoPropertySuccessCallback successCallback,
                                                 optional SystemInfoOptions? options, optional ErrorCallback? errorCallback)
                                                 raises(WebAPIException);
    unsigned long addPropertyValueArrayChangeListener(SystemInfoPropertyId property,
                                                      SystemInfoPropertyArraySuccessCallback successCallback,
                                                      optional SystemInfoOptions? options, optional ErrorCallback? errorCallback)
                                                      raises(WebAPIException);
    void removePropertyValueChangeListener(unsigned long listenerId) raises(WebAPIException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface SystemInfoPropertySuccessCallback {
    void onsuccess(SystemInfoProperty property);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface SystemInfoPropertyArraySuccessCallback {
    void onsuccess(SystemInfoProperty[] properties);
  };
  [NoInterfaceObject] interface SystemInfoProperty {
  };
  [NoInterfaceObject] interface SystemInfoBattery : SystemInfoProperty {
    readonly attribute double level;
    readonly attribute boolean isCharging;
    readonly attribute long? timeToDischarge;
    readonly attribute long? timeToFullCharge;
  };
  [NoInterfaceObject] interface SystemInfoCpu : SystemInfoProperty {
    readonly attribute double load;
  };
  [NoInterfaceObject] interface SystemInfoStorage : SystemInfoProperty {
    readonly attribute SystemInfoStorageUnit[] units;
  };
  [NoInterfaceObject] interface SystemInfoStorageUnit : SystemInfoProperty {
    readonly attribute DOMString type;
    readonly attribute unsigned long long capacity;
    readonly attribute unsigned long long availableCapacity;
    readonly attribute boolean isRemovable;
  };
  [NoInterfaceObject] interface SystemInfoDisplay : SystemInfoProperty {
    readonly attribute unsigned long resolutionWidth;
    readonly attribute unsigned long resolutionHeight;
    readonly attribute unsigned long dotsPerInchWidth;
    readonly attribute unsigned long dotsPerInchHeight;
    readonly attribute double physicalWidth;
    readonly attribute double physicalHeight;
    readonly attribute double brightness;
  };
  [NoInterfaceObject] interface SystemInfoPanel : SystemInfoProperty {
    readonly attribute unsigned long panelWidth;
    readonly attribute unsigned long panelHeight;
  };
  [NoInterfaceObject] interface SystemInfoDeviceOrientation : SystemInfoProperty {
    readonly attribute SystemInfoDeviceOrientationStatus status;
    readonly attribute boolean isAutoRotation;
  };
  [NoInterfaceObject] interface SystemInfoBuild : SystemInfoProperty {
    readonly attribute DOMString model;
    readonly attribute DOMString manufacturer;
    readonly attribute DOMString buildVersion;
  };
  [NoInterfaceObject] interface SystemInfoLocale : SystemInfoProperty {
    readonly attribute DOMString language;
    readonly attribute DOMString country;
  };
  [NoInterfaceObject] interface SystemInfoNetwork : SystemInfoProperty {
    readonly attribute SystemInfoNetworkType networkType;
  };
  [NoInterfaceObject] interface SystemInfoWifiNetwork : SystemInfoProperty {
    readonly attribute DOMString status;
    readonly attribute DOMString ssid;
    readonly attribute DOMString ipAddress;
    readonly attribute DOMString ipv6Address;
    readonly attribute DOMString macAddress;
    readonly attribute double signalStrength;
    readonly attribute SystemInfoWifiSecurityMode securityMode;
    readonly attribute SystemInfoWifiEncryptionType encryptionType;
    readonly attribute SystemInfoNetworkIpMode ipMode;
    readonly attribute DOMString subnetMask;
    readonly attribute DOMString gateway;
    readonly attribute DOMString dns;
  };
  [NoInterfaceObject] interface SystemInfoEthernetNetwork : SystemInfoProperty {
    readonly attribute DOMString cable;
    readonly attribute DOMString status;
    readonly attribute DOMString ipAddress;
    readonly attribute DOMString ipv6Address;
    readonly attribute DOMString macAddress;
    readonly attribute SystemInfoNetworkIpMode ipMode;
    readonly attribute DOMString subnetMask;
    readonly attribute DOMString gateway;
    readonly attribute DOMString dns;
  };
  [NoInterfaceObject] interface SystemInfoCellularNetwork : SystemInfoProperty {
    readonly attribute DOMString status;
    readonly attribute DOMString apn;
    readonly attribute DOMString ipAddress;
    readonly attribute DOMString ipv6Address;
    readonly attribute unsigned short mcc;
    readonly attribute unsigned short mnc;
    readonly attribute unsigned short cellId;
    readonly attribute unsigned short lac;
    readonly attribute boolean isRoaming;
    readonly attribute boolean isFlightMode;
    readonly attribute DOMString imei raises(WebAPIException);
    readonly attribute SystemInfoNetworkIpMode ipMode;
    readonly attribute DOMString subnetMask;
    readonly attribute DOMString gateway;
    readonly attribute DOMString dns;
  };
  [NoInterfaceObject] interface SystemInfoNetProxyNetwork : SystemInfoProperty {
    readonly attribute DOMString status;
  };
  [NoInterfaceObject] interface SystemInfoSIM : SystemInfoProperty {
    readonly attribute SystemInfoSimState state raises(WebAPIException);
    readonly attribute DOMString operatorName raises(WebAPIException);
    readonly attribute DOMString msisdn raises(WebAPIException);
    readonly attribute DOMString iccid raises(WebAPIException);
    readonly attribute unsigned short mcc raises(WebAPIException);
    readonly attribute unsigned short mnc raises(WebAPIException);
    readonly attribute DOMString msin raises(WebAPIException);
    readonly attribute DOMString spn raises(WebAPIException);
  };
  [NoInterfaceObject] interface SystemInfoPeripheral : SystemInfoProperty {
    readonly attribute boolean isVideoOutputOn;
  };
  [NoInterfaceObject] interface SystemInfoMemory : SystemInfoProperty {
    readonly attribute SystemInfoLowMemoryStatus status;
  };
  [NoInterfaceObject] interface SystemInfoVideoSourceInfo {
    readonly attribute SystemInfoVideoSourceType type;
    readonly attribute long number;
    readonly attribute boolean? signal;
    readonly attribute DOMString? editName;
  };
  [NoInterfaceObject] interface SystemInfoVideoSource : SystemInfoProperty {
    readonly attribute SystemInfoVideoSourceInfo[] connected;
    readonly attribute SystemInfoVideoSourceInfo[] disconnected;
  };
  [NoInterfaceObject] interface SystemInfoCameraFlash : SystemInfoProperty {
    readonly attribute double brightness raises(WebAPIException);
    readonly attribute DOMString camera;
    readonly attribute long levels raises(WebAPIException);
    void setBrightness(double brightness) raises(WebAPIException);
  };
  [NoInterfaceObject] interface SystemInfoADS : SystemInfoProperty {
    readonly attribute DOMString id;
  };
  [NoInterfaceObject] interface SystemInfoServiceCountry : SystemInfoProperty {
    readonly attribute DOMString serviceCountry;
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
