# Tizen Wearable Web Device API Reference

The Tizen Web Device API, based on JavaScript, provides you advanced access to the device's platform capabilities.

You can develop rich Web applications using the Tizen Web Device APIs. You can, for example, control the application life-cycle, manage your schedules, exchange data, or make payments using NFC.

The APIs listed in this category are created by the Tizen platform to expose device capabilities to Web Applications.

#### Base

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Archive | This API provides interfaces and methods to create an archive file as well as various other kinds of manipulation (e.g. extract files, add a file to an archive file). | 2.3.1 | Mandatory | Yes |
| Filesystem | This API provides access to the file system of a device. This API might be obsolete in the future when W3C File APIs are extended to access system-sensitive files by Web applications. | 1.0 | Mandatory | Yes |
| Tizen | The base object for accessing the Tizen Web Device API. | 1.0 | Mandatory | Yes |

#### Account

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Account | This API provides interfaces and methods for managing accounts (e.g. create an account, change the account information). | 4.0 | Optional | Yes |

#### Application Framework

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Alarm | This API provides functionality for setting and unsetting alarms. | 1.0 | Mandatory | Yes |
| Application | This API provides information about running and installed applications and controls them. | 1.0 | Mandatory | Yes |
| Badge | This API provides a way to display the count of notifications (badge) on home screen. | 2.3 | Mandatory | Yes |
| Data Control | This API provides interfaces and methods for accessing specific data exported by other applications. | 3.0 | Mandatory | Yes |
| Input Device | This API provides interfaces and methods to manage input keys in application. | 3.0 | Optional | No |
| Message Port | This API provides the functionality for communication with other applications. | 2.1 | Mandatory | Yes |
| Notification | This API provides a way to notify the user of events that happen in the application. | 2.3.1 | Mandatory | Yes |
| Package | This API provides information install/uninstall package and get information about installed packages. | 2.1 | Mandatory | Yes |
| Preference | This API provides the functionality to store and retrieve small pieces of data which can be for application preferences. | 3.0 | Mandatory | Yes |
| WidgetService | This API provides information of installed widgets. | 3.0 | Mandatory | Yes |

#### Content

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Content | This API provides functionality to discover multimedia content (such as images, videos or music). | 2.0 | Mandatory | Yes |
| Download | This API provides interfaces and methods for downloading remote objects by HTTP request. | 2.0 | Optional | Yes |

#### Machine Learning

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Machine Learning | This API provides functions for Machine Learning features that help you to handle Neural Network Frameworks. | 6.5 | Mandatory | Yes |
| Single | This API provides functionality for a simple usage scenario of neural network models. | 6.5 | Mandatory | Yes |
| Pipeline | This API provides functionality for managing machine learning inference pipelines. | 6.5 | Mandatory | Yes |
| Trainer | This API provides functionality for creating, controlling, and training a machine learning model. | 7.0 | Mandatory | Yes |

#### Messaging

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Push | This API provides the functionality for receiving push notifications. | 2.3.1 | Optional | Yes |

#### Multimedia

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Exif | This API provides interfaces and methods for manipulating Exif data from JPEG file. | 2.3.1 | Mandatory | Yes |
| Media Controller | This API provides functions for communication between the media controller server and the media controller client. | 2.4 | Mandatory | Yes |
| Player Util | This API provides functionality for managing W3C player latency. | 3.0 | Mandatory | Yes |
| Sound | This API provides a way to control the volume level for several sound types and to check whether a specified sound device type is connected. | 2.3 | Mandatory | Yes |
| Metadata | This API provides interfaces and methods for extracting metadata information from a media file. | 6.0 | Mandatory | Yes |

#### Network

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Bluetooth | This API enables control over Bluetooth. | 2.3.1 | Optional | No |
| NFC | This API allows access to NFC device(s). | 2.3.1 | Optional | Yes |
| Secure Element | This API provides interfaces and methods for access to Secure Elements. | 2.3.1 | Optional | No |

#### Security

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Keymanager | This API provides interfaces and methods for a secure repository for storing, retrieving and removing the sensitive data of users and their applications. | 3.0 | Mandatory | Yes |

#### Social

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Calendar | This API enables the management of calendar information. | 4.0 | Optional | Yes |
| Contact | This API enables the management of contact information. | 4.0 | Optional | Yes |

#### System

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Feedback | This API provides functions to play sound or vibration associated with action. | 3.0 | Optional | Yes |
| Human Activity Monitor | This API provides interfaces and methods for retrieving human activity data from the various sensors on the device. | 2.3 | Optional | Yes Only HRM |
| Media Key | This API provides a way to get notified when a media key has been pressed or released. | 2.3 | Optional | No |
| Power | This API provides interfaces and methods for controlling power resources. | 2.0 | Mandatory | Yes |
| Sensor | This API provides interfaces and methods for getting sensor data from the various sensors on the device. | 2.3 | Optional | Yes |
| System Information | This API provides information about the device's display, network, storage and other capabilities. | 1.0 | Mandatory | Yes |
| System Setting | This API provides system setting functionality. | 2.0 | Mandatory | Yes Only HOME_SCREEN, INCOMING_CALL |
| Time | This API exposes information about date, time and time zones. | 1.0 | Mandatory | Yes |

#### UIX

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Voice Control | This API provides functions for users to set voice commands and to control the web application through their voices. | 4.0 | Mandatory | Yes |

#### Cordova

| API | Description | Version (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- |
| Console | The Console module provides function to access the console. | 3.0 | Mandatory | Yes |
| Cordova | This API provides common Cordova functionality. | 3.0 | Mandatory | Yes |
| Device | This plugin defines a global device object, which describes the device's hardware and software. | 3.0 | Mandatory | Yes |
| Device Motion | This plugin provides access to the device's accelerometer. | 3.0 | Mandatory | Yes |
| Dialogs | This plugin provides the ability to make different types of notifications to the user. | 3.0 | Mandatory | Yes |
| Events | This plugin provides information about events defined in cordova. | 3.0 | Mandatory | Yes |
| File | This plugin implements a File API allowing read/write access to files residing on the device. | 3.0 | Mandatory | Yes |
| File Transfer | This module allows you to upload and download files. | 3.0 | Mandatory | Yes |
| Globalization | This plugin obtains information and performs operations specific to the user's locale, language, and timezone. | 3.0 | Mandatory | Yes |
| Media | This plugin provides the ability to record and play back audio files on a device. | 3.0 | Mandatory | Yes |
| Network Information | This plugin provides information about the device's cellular and wifi connection, and whether the device has an internet connection. | 3.0 | Mandatory | Yes |

#### Deprecated API

| API | Description | Version (Since) | Deprecated (Since) | Wearable | Supported on 
Wearable Emulator |
| --- | --- | --- | --- | --- | --- |
| Iotcon | This API provides functions for IoT (Internet of Things) connectivity. | 3.0 | 10.0 | Optional | Yes |
| LibTeec | This API provides interfaces and methods for a TrustZone. | 4.0 | 6.5 | Mandatory | Yes |
| PrivacyPrivilege | This Privacy Privilege API defines a set of APIs that manage the permissions for using a privacy-related privileges of application. | 4.0 | 8.0 | Mandatory | Yes |

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
