# WidgetService API

The Widget Service API provides information about installed widgets.

For more information on the Widget service features, see the Widget Service Guide .

Do not use "widget" as name for one of your global variables, as it is a global W3C object's name.

Since: 2.3.2

## Table of Contents

- 1. Type Definitions
- 1.1. WidgetId
- 1.2. WidgetInstanceId
- 1.3. WidgetSizeType
- 1.4. WidgetStateType
- 2. Interfaces
- 2.1. WidgetServiceManagerObject
- 2.2. WidgetServiceManager
- 2.3. Widget
- 2.4. WidgetSize
- 2.5. WidgetVariant
- 2.6. WidgetInstance
- 2.7. WidgetArraySuccessCallback
- 2.8. WidgetInstancesCallback
- 2.9. WidgetVariantsCallback
- 2.10. WidgetContentCallback
- 2.11. WidgetChangeCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| WidgetServiceManagerObject |  |
| WidgetServiceManager | Widget getWidget ( WidgetId widgetId) void getWidgets ( WidgetArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback, optional PackageId ? packageId) WidgetId getPrimaryWidgetId (( PackageId or ApplicationId ) id) WidgetSize getSize ( WidgetSizeType sizeType) |
| Widget | DOMString getName (optional DOMString? locale) void getInstances ( WidgetInstancesCallback successCallback, optional ErrorCallback ? errorCallback) WidgetVariant getVariant ( WidgetSizeType sizeType) void getVariants ( WidgetVariantsCallback successCallback, optional ErrorCallback ? errorCallback) long addStateChangeListener ( WidgetChangeCallback listener) void removeStateChangeListener (long watchId) |
| WidgetSize |  |
| WidgetVariant |  |
| WidgetInstance | void changeUpdatePeriod (double seconds) void sendContent (Object data, boolean updateIfPaused) void getContent ( WidgetContentCallback successCallback, ErrorCallback errorCallback) |
| WidgetArraySuccessCallback | void onsuccess ( Widget [] widgets) |
| WidgetInstancesCallback | void onsuccess ( WidgetInstance [] instances) |
| WidgetVariantsCallback | void onsuccess ( WidgetVariant [] instances) |
| WidgetContentCallback | void onsuccess (Object data) |
| WidgetChangeCallback | void onchange ( WidgetInstance instance, WidgetStateType event) |

## 1. Type Definitions

### 1.1. WidgetId

The unique ID of the installed widget.

```webidl
  typedef DOMString WidgetId;
```

Since: 2.3.2

### 1.2. WidgetInstanceId

ID of the widget instance, this value is volatile and may change after reboot.

```webidl
  typedef DOMString WidgetInstanceId;
```

Since: 2.3.2

### 1.3. WidgetSizeType

The WidgetSizeType enumeration lists supported widget size types.

```webidl
  enum WidgetSizeType { "1x1", "2x1", "2x2", "4x1", "4x2", "4x3", "4x4", "4x5", "4x6", "EASY_1x1", "EASY_3x1", "EASY_3x3", "FULL" };
```

Since: 2.3.2

The size types defines the following types (pixel size is given for a 720x1280 resolution):

| Size type | Size in pixels | Supported profile |
| --- | --- | --- |
| 1x1 | 175x175 | This size type is not used. just defined for specifying a default cell size |
| 2x1 | 354x175 | Mobile |
| 2x2 | 354x354 | Mobile, Wearable |
| 4x1 | 712x175 | Mobile |
| 4x2 | 712x354 | Mobile |
| 4x3 | 712x533 | Mobile |
| 4x4 | 712x712 | Mobile |
| 4x5 | 712x891 | Mobile |
| 4x6 | 712x1070 | Mobile |
| EASY_1x1 | 224x215 | Mobile |
| EASY_3x1 | 680x215 | Mobile |
| EASY_3x3 | 680x653 | Mobile |
| FULL | 720x1280 | Mobile |

### 1.4. WidgetStateType

Enumeration for types of lifetime events of a Widget.

```webidl
  enum WidgetStateType { "CREATE", "DESTROY", "PAUSE", "RESUME" };
```

Since: 2.3.2

- CREATE - the widget was created
- DESTROY - the widget was destroyed
- PAUSE - the widget was paused
- RESUME - the widget was resumed
Widget lifetime events can be monitored with the addStateChangeListener() method
of the Widget interface.

## 2. Interfaces

### 2.1. WidgetServiceManagerObject

This interface defines what is instantiated by the *Tizen *object on the Tizen Platform.

```webidl
  [NoInterfaceObject] interface WidgetServiceManagerObject {
    readonly attribute WidgetServiceManager widgetservice;
  };
```

```webidl
  Tizen implements WidgetServiceManagerObject;
```

Since: 2.3.2

The *tizen.widgetservice *object provides access to the Widget Service API's functionality.

#### Attributes

- readonly WidgetServiceManager widgetservice Object representing a widget service manager.

Since: 2.3.2

### 2.2. WidgetServiceManager

The WidgetServiceManager interface provides methods for accessing information about widgets.

```webidl
  [NoInterfaceObject] interface WidgetServiceManager {
    Widget getWidget(WidgetId widgetId) raises(WebAPIException);
    void getWidgets(WidgetArraySuccessCallback successCallback, optional ErrorCallback? errorCallback, optional PackageId? packageId)
                    raises(WebAPIException);
    WidgetId getPrimaryWidgetId((PackageId or ApplicationId) id) raises(WebAPIException);
    WidgetSize getSize(WidgetSizeType sizeType) raises(WebAPIException);
  };
```

Since: 2.3.2

#### Methods

`**getWidget **`Retrieves a Widget object with a given *widgetId *.

```javascript
Widget getWidget(WidgetId widgetId);
```

Since: 2.3.2

Privilege level: public

Privilege: http://tizen.org/privilege/widget.viewer

Parameters:

- **widgetId :
 The ID of the Widget to retrieve. **

Return value:

Widget: The Widget object.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to use this function.

- with error type NotFoundError, if widget with given id does not exist.

- with error type IOError, if a DB operation has failed.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.gallery.widget";
try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  console.log("Widget id is " + myWidget.id);
  console.log("Widget details:");
  console.log("Main application id: " + myWidget.applicationId);
  console.log("Package id: " + myWidget.packageId);
  console.log("Is hidden in the list of widgets: " + myWidget.noDisplay);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Widget id is org.tizen.gallery.widget
Widget details:
Main application id: org.tizen.gallery
Package id: org.tizen.gallery
Is hidden in the list of widgets: false
```

`**getWidgets **`Retrieves a list of all widgets. If package id is provided returned list contains widgets included in a given package only.

```javascript
void getWidgets(WidgetArraySuccessCallback successCallback, optional ErrorCallback? errorCallback, optional PackageId? packageId);
```

Since: 2.3.2

The *errorCallback *is launched with these error types:

- IOError - If a DB operation has failed.
- AbortError - If the operation cannot be finished properly.
- NotFoundError - If the device has no widgets or if a widget with the given id does not exist

Privilege level: public

Privilege: http://tizen.org/privilege/widget.viewer

Parameters:

- **successCallback :
 A function to call when widgets are retrieved successfully. **
- **errorCallback [optional] [nullable] :
 A function to call when an error occurs. **
- **packageId [optional] [nullable] :
 If this parameter is given, then only widgets belonging to the given package are returned. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to use this function.

Code example:

```javascript
tizen.widgetservice.getWidgets(
    function(widgets)
    {
      console.log("There are " + widgets.length + " available widgets");
    },
    function(error)
    {
      console.log("Error: " + error.message);
    });
```

Output example:

```
There are 3 available widgets
```

`**getPrimaryWidgetId **`Returns the primary widget ID of the specified package or application.

```javascript
WidgetId getPrimaryWidgetId((PackageId or ApplicationId) id);
```

Since: 2.3.2

Privilege level: public

Privilege: http://tizen.org/privilege/widget.viewer

Parameters:

- **id :
 Package or Application ID. **

Return value:

WidgetId: The ID of the widget.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to use this function.

- with error type NotFoundError, if widget with given id does not exist.

- with error type IOError, if a DB operation has failed.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
/* Variable id should contain valid id of the application or package. */
var id = "org.tizen.gallery";
try
{
  var widgetId = tizen.widgetservice.getPrimaryWidgetId(id);
  console.log("Widget id is " + widgetId);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Widget id is org.tizen.gallery.widget
```

`**getSize **`Returns the size corresponding to the given sizeType.

```javascript
WidgetSize getSize(WidgetSizeType sizeType);
```

Since: 2.3.2

Parameters:

- **sizeType : *WidgetSizeType *used for retrieving corresponding pixel size object. **

Return value:

WidgetSize: An object which contains width and height.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
/* Variable sizeType should contain supported size type. */
var sizeType = "4x4";
try
{
  var widgetSize = tizen.widgetservice.getSize(sizeType);
  console.log("Widget size width: " + widgetSize.width + ", height: " + widgetSize.height);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Widget size width: 712, height: 712
```

### 2.3. Widget

The Widget interface provides access to a single Widget installed on the system.

```webidl
  [NoInterfaceObject] interface Widget {
    readonly attribute WidgetId id;
    readonly attribute ApplicationId applicationId;
    readonly attribute ApplicationId? setupApplicationId;
    readonly attribute PackageId packageId;
    readonly attribute boolean noDisplay;
    DOMString getName(optional DOMString? locale) raises(WebAPIException);
    void getInstances(WidgetInstancesCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    WidgetVariant getVariant(WidgetSizeType sizeType) raises(WebAPIException);
    void getVariants(WidgetVariantsCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    long addStateChangeListener(WidgetChangeCallback listener) raises(WebAPIException);
    void removeStateChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 2.3.2

#### Attributes

- readonly WidgetId id Widget ID.

Since: 2.3.2

- readonly ApplicationId applicationId Main application ID.

Since: 2.3.2

- readonly ApplicationId setupApplicationId [nullable] Setup application ID.

Since: 2.3.2

- readonly PackageId packageId The ID of the package this widget was installed with.

Since: 2.3.2

- readonly boolean noDisplay true if the widget should be hidden in the list of widgets.

Precondition: Widget tag in the config.xml file includes the "nodisplay" attribute.

Since: 2.3.2

#### Methods

`**getName **`Returns a name of the widget in a given locale.

```javascript
DOMString getName(optional DOMString? locale);
```

Since: 2.3.2

Parameters:

- **locale [optional] [nullable] :
 Locale ("en-us", "ko-kr", ...). If null , then the default system locale is used. **

Return value:

DOMString: The name of the widget.

Exceptions:

- WebAPIException
- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.gallery.widget";

try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  var name = myWidget.getName("en-us");
  console.log("Widget name is " + name);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Widget name is Gallery
```

`**getInstances **`Retrieves Widget instances (elements that have been added to the screen). Widget instance as opposed to the widget interface (which is abstract of application), is a specified application.

```javascript
void getInstances(WidgetInstancesCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.2

The *errorCallback *is launched with these error types:

- AbortError - If the operation cannot be finished properly.
- NotFoundError - If the Web application which is calling this method did not add any widgets to the screen.
- SecurityError - If the widget does not belong to the package of the web application which is calling this method.

Remark: This method can only be used with widgets and applications which belong to the same package. Therefore, the widget should belong to the package of the Web application which calls this method.

Parameters:

- **successCallback :
 A function to call when widgets are retrieved successfully. **
- **errorCallback [optional] [nullable] :
 A function to call when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
widgetSuccessCb = function(instances)
{
  console.log("Instances array size: " + instances.length);
};

widgetErrorCb = function(error)
{
  console.log("Error occurred: " + error.name + ": " + error.message);
};

/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.gallery.widget";

try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  myWidget.getInstances(widgetSuccessCb, widgetErrorCb);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Instances array size: 3
```

`**getVariant **`Returns object representing widget information related to a given sizeType.

```javascript
WidgetVariant getVariant(WidgetSizeType sizeType);
```

Since: 2.3.2

Parameters:

- **sizeType : *WidgetSizeType *value that information will be returned about. **

Return value:

WidgetVariant: Size variant info.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.gallery.widget";

try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  var variant = myWidget.getVariant("4x4");
  console.log("Variant preview image path is " + variant.previewImagePath);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Variant preview image path is /usr/share/icons/default/small/preview_gallery_4x4.png
```

`**getVariants **`Retrieves Widget Variants representing all of the supported widget size types.

```javascript
void getVariants(WidgetVariantsCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.2

The *errorCallback *is launched with these error types:

- AbortError - If the operation cannot be finished properly.

Parameters:

- **successCallback :
 A function to call when widgets are retrieved successfully. **
- **errorCallback [optional] [nullable] :
 A function to call when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
widgetSuccessCb = function(variants)
{
  console.log("Variants array size: " + variants.length);
};

widgetErrorCb = function(error)
{
  console.log("Error occurred: " + error.name + ": " + error.message);
};

/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.gallery.widget";

try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  myWidget.getVariants(widgetSuccessCb, widgetErrorCb);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Variants array size: 4
```

`**addStateChangeListener **`Registers a callback which will be called whenever any of this widget instances state changes.

```javascript
long addStateChangeListener(WidgetChangeCallback listener);
```

Since: 2.3.2

Remark: This method can only be used with widgets and applications which belong to the same package. Therefore, the widget should belong to the package of the Web application which calls this method.

Parameters:

- **listener :
 The callback. **

Return value:

long: The watch ID used to unregister the callback.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
widgetChangeCb = function(instance, event)
{
  console.log("Instance " + instance.id + " is " + event);
};

/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.music-player.widget";

try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  var watchId = myWidget.addStateChangeListener(widgetChangeCb);
  console.log("Listener with id " + watchId + " has been added");
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Listener with id 1 has been added
Instance org.tizen.music-player.widget is RESUME
```

`**removeStateChangeListener **`Unregisters a callback registered under the given watchId.

```javascript
void removeStateChangeListener(long watchId);
```

Since: 2.3.2

Remark: This method can only be used with widgets and applications which belong to the same package. Therefore, the widget should belong to the package of the Web application which calls this method.

Parameters:

- **watchId :
 The ID of the registered listener. **

Exceptions:

- WebAPIException
- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
widgetChangeCb = function(instance, event)
{
  console.log("Instance " + instance.id + " is " + event);
  myWidget.removeStateChangeListener(watchId);
  console.log("Listener with id " + watchId + " has been removed");
};

/* Variable id should contain valid id of the installed widget. */
var id = "org.tizen.music-player.widget";
var watchId;

try
{
  var myWidget = tizen.widgetservice.getWidget(id);
  watchId = myWidget.addStateChangeListener(widgetChangeCb);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Listener with id 1 has been removed
```

### 2.4. WidgetSize

The WidgetSize interface contains width and height of a widget area.

```webidl
  [NoInterfaceObject] interface WidgetSize {
    readonly attribute long width;
    readonly attribute long height;
  };
```

Since: 2.3.2

#### Attributes

- readonly long width The horizontal dimension of the area in pixels.

Since: 2.3.2

- readonly long height The vertical dimension of the area in pixels.

Since: 2.3.2

### 2.5. WidgetVariant

The WidgetVariant interface provides Widget information related to specific sizeType.

```webidl
  [NoInterfaceObject] interface WidgetVariant {
    readonly attribute WidgetSizeType sizeType;
    readonly attribute long width;
    readonly attribute long height;
    readonly attribute DOMString previewImagePath;
    readonly attribute boolean needsMouseEvents;
    readonly attribute boolean needsTouchEffect;
    readonly attribute boolean needsFrame;
  };
```

Since: 2.3.2

#### Attributes

- readonly WidgetSizeType sizeType The WidgetSizeType this WidgetVariant describes.

Since: 2.3.2

- readonly long width Pixel width.

Since: 2.3.2

- readonly long height Pixel height.

Since: 2.3.2

- readonly DOMString previewImagePath The preview image path.

Since: 2.3.2

- readonly boolean needsMouseEvents true if the widget was designed to receive mouse events.

Since: 2.3.2

- readonly boolean needsTouchEffect true if the widget expects the system to show touch effect.

Since: 2.3.2

- readonly boolean needsFrame true if the widget expects the system to draw a frame.

Since: 2.3.2

### 2.6. WidgetInstance

The WidgetInstance interface provides access to a single instance of the Widget.

```webidl
  [NoInterfaceObject] interface WidgetInstance {
    readonly attribute Widget widget;
    readonly attribute WidgetInstanceId id;
    void changeUpdatePeriod(double seconds) raises(WebAPIException);
    void sendContent(Object data, boolean updateIfPaused) raises(WebAPIException);
    void getContent(WidgetContentCallback successCallback, ErrorCallback errorCallback) raises(WebAPIException);
  };
```

Since: 2.3.2

Every visual widget element added to the home screen is a single instance of some Widget.

#### Attributes

- readonly Widget widget The Widget this instance belongs to.

Since: 2.3.2

- readonly WidgetInstanceId id ID of the widget instance, this value is volatile and may change after reboot.

Since: 2.3.2

#### Methods

`**changeUpdatePeriod **`Changes the interval between automatic update of the widget instance data. Minimum value is 1 second.

```javascript
void changeUpdatePeriod(double seconds);
```

Since: 2.3.2

Remark: This method is not supported by Web Widget.

Parameters:

- **seconds :
 The interval in seconds. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any input parameters do not contain a valid value. Minimum value is 1 second.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
/* Variable instance should contain valid WidgetInstance object obtained by getInstances() method. */
var instance;
var period = 2;

try
{
  instance.changeUpdatePeriod(period);
  console.log("Update period has been set to " + period + " seconds");
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Update period has been set to 2 seconds
```

`**sendContent **`Sends a new content data to the Widget Instance.

```javascript
void sendContent(Object data, boolean updateIfPaused);
```

Since: 2.3.2

This function does not wait for a confirmation that the data was updated.

Remark: This method is not supported by Web Widget.

Parameters:

- **data :
 The new content data. **
- **updateIfPaused : true if you want to update your widget even if the provider is paused. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type IOError, if a DB operation has failed.

- with error type AbortError, if the operation cannot be finished properly.

Code example:

```javascript
/* Variable instance should contain valid WidgetInstance object obtained by getInstances() method. */
var instance;

var data = {data1: "test1", data2: "test2"};

try
{
  instance.sendContent(data, true);
  console.log("Data has been successfully sent");
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Data has been successfully sent
```

`**getContent **`Retrieves content data from the Widget Instance.

```javascript
void getContent(WidgetContentCallback successCallback, ErrorCallback errorCallback);
```

Since: 2.3.2

The *errorCallback *is launched with these error types:

- IOError - If a DB operation has failed
- AbortError - If the operation cannot be finished properly.

Remark: This method is not supported by Web Widget.

Parameters:

- **successCallback :
 A function to call when data is retrieved successfully. **
- **errorCallback :
 A function to call when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
/* Variable instance should contain valid WidgetInstance object obtained by getInstances() method. */
var instance;

contentSuccessCb = function(data)
{
  console.log("Data has been obtained successfully");
  for (var prop in data)
  {
    console.log(prop + ": " + data[prop]);
  }
};

contentErrorCb = function(error)
{
  console.log("Error occurred: " + error.name + ": " + error.message);
};

try
{
  instance.getContent(contentSuccessCb, contentErrorCb);
}
catch (error)
{
  console.log("Error: " + error.message);
}
```

Output example:

```
Data has been obtained successfully
data1: test1
data2: test2
```

### 2.7. WidgetArraySuccessCallback

The WidgetArraySuccessCallback interface implements the success callback used in the asynchronous operation to get a list of widgets using the getWidgets() method.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetArraySuccessCallback {
    void onsuccess(Widget[] widgets);
  };
```

Since: 2.3.2

#### Methods

`**onsuccess **`Called when the array of *Widget *objects is retrieved successfully.

```javascript
void onsuccess(Widget[] widgets);
```

Since: 2.3.2

Parameters:

- **widgets :
 Array of *Widget *objects. **

### 2.8. WidgetInstancesCallback

The WidgetInstancesCallback interface implements the success callback used in the asynchronous operation to get a list of widget instances using the getInstances() method.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetInstancesCallback {
    void onsuccess(WidgetInstance[] instances);
  };
```

Since: 2.3.2

#### Methods

`**onsuccess **`Called when the array of *WidgetInstance *objects is retrieved successfully.

```javascript
void onsuccess(WidgetInstance[] instances);
```

Since: 2.3.2

Parameters:

- **instances :
 Array of *WidgetInstance *objects. **

### 2.9. WidgetVariantsCallback

The WidgetVariantsCallback interface implements the success callback used in the asynchronous operation to get a list of widget variant using the getVariants() method.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetVariantsCallback {
    void onsuccess(WidgetVariant[] instances);
  };
```

Since: 2.3.2

#### Methods

`**onsuccess **`Called when the array of *WidgetVariants *objects is retrieved successfully.

```javascript
void onsuccess(WidgetVariant[] instances);
```

Since: 2.3.2

Parameters:

- **instances :
 Array of *WidgetVariants *objects. **

### 2.10. WidgetContentCallback

The WidgetVariantsCallback interface implements the success callback used in the asynchronous operation to get a content data of widget instance using the getContent() method.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetContentCallback {
    void onsuccess(Object data);
  };
```

Since: 2.3.2

#### Methods

`**onsuccess **`Called when the content of the widget instance is retrieved successfully.

```javascript
void onsuccess(Object data);
```

Since: 2.3.2

Parameters:

- **data :
 Content of the given widget instance. **

### 2.11. WidgetChangeCallback

The WidgetChangeCallback describes a callback for the addStateChangeListener() method.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetChangeCallback {
    void onchange(WidgetInstance instance, WidgetStateType event);
  };
```

Since: 2.3.2

#### Methods

`**onchange **`Called when the instance state was changed.

```javascript
void onchange(WidgetInstance instance, WidgetStateType event);
```

Since: 2.3.2

Parameters:

- **instance :
 Widget instance id that change is related to. **
- **event :
 Event of widget life cycle. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the widget application runs on a system which supports Widgets, declare the following feature requirements in the config file:

- http://tizen.org/feature/shell.appwidget

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module WidgetService {
  typedef DOMString WidgetId;
  typedef DOMString WidgetInstanceId;
  enum WidgetSizeType { "1x1", "2x1", "2x2", "4x1", "4x2", "4x3", "4x4", "4x5", "4x6", "EASY_1x1", "EASY_3x1", "EASY_3x3", "FULL" };
  enum WidgetStateType { "CREATE", "DESTROY", "PAUSE", "RESUME" };
  Tizen implements WidgetServiceManagerObject;
  [NoInterfaceObject] interface WidgetServiceManagerObject {
    readonly attribute WidgetServiceManager widgetservice;
  };
  [NoInterfaceObject] interface WidgetServiceManager {
    Widget getWidget(WidgetId widgetId) raises(WebAPIException);
    void getWidgets(WidgetArraySuccessCallback successCallback, optional ErrorCallback? errorCallback, optional PackageId? packageId)
                    raises(WebAPIException);
    WidgetId getPrimaryWidgetId((PackageId or ApplicationId) id) raises(WebAPIException);
    WidgetSize getSize(WidgetSizeType sizeType) raises(WebAPIException);
  };
  [NoInterfaceObject] interface Widget {
    readonly attribute WidgetId id;
    readonly attribute ApplicationId applicationId;
    readonly attribute ApplicationId? setupApplicationId;
    readonly attribute PackageId packageId;
    readonly attribute boolean noDisplay;
    DOMString getName(optional DOMString? locale) raises(WebAPIException);
    void getInstances(WidgetInstancesCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    WidgetVariant getVariant(WidgetSizeType sizeType) raises(WebAPIException);
    void getVariants(WidgetVariantsCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    long addStateChangeListener(WidgetChangeCallback listener) raises(WebAPIException);
    void removeStateChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface WidgetSize {
    readonly attribute long width;
    readonly attribute long height;
  };
  [NoInterfaceObject] interface WidgetVariant {
    readonly attribute WidgetSizeType sizeType;
    readonly attribute long width;
    readonly attribute long height;
    readonly attribute DOMString previewImagePath;
    readonly attribute boolean needsMouseEvents;
    readonly attribute boolean needsTouchEffect;
    readonly attribute boolean needsFrame;
  };
  [NoInterfaceObject] interface WidgetInstance {
    readonly attribute Widget widget;
    readonly attribute WidgetInstanceId id;
    void changeUpdatePeriod(double seconds) raises(WebAPIException);
    void sendContent(Object data, boolean updateIfPaused) raises(WebAPIException);
    void getContent(WidgetContentCallback successCallback, ErrorCallback errorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetArraySuccessCallback {
    void onsuccess(Widget[] widgets);
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetInstancesCallback {
    void onsuccess(WidgetInstance[] instances);
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetVariantsCallback {
    void onsuccess(WidgetVariant[] instances);
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetContentCallback {
    void onsuccess(Object data);
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface WidgetChangeCallback {
    void onchange(WidgetInstance instance, WidgetStateType event);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
