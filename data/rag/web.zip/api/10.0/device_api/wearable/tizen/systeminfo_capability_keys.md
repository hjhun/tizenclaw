# Getting the Device Capabilities through System Information API

The following keys are available to obtain the device capability information using SystemInfo API .

- Device Capability keys:
- Bluetooth API
- CallHistory API
- Content API
- W3C Camera API
- DataSynchronization API
- Download API
- FM Radio API
- HumanActivityMonitor API
- HumanActivityMonitor API - PEDOMETER, WRIST_UP, HRM, SLEEP_MONITOR
- HumanActivityMonitor API - GPS
- MediaKey API
- Messaging SMS API
- Messaging MMS API
- NFC API
- NFC Card Emulation API
- NetworkBearerSelection API
- Push API
- Secure Element API
- Sensor API
- SystemSetting API
- Battery
- Camera
- Database
- Graphics
- Input
- Led
- Location
- Multimedia transcoder
- Microphone
- Multi-point touch
- Network
- OpenGL® ES
- Platform
- Profile
- Screen
- Shell (Dynamic Box)
- Sip
- Speech
- USB
- Web service
- System keys:
- Build Information
- Tizen ID
- Model name
- Platform name
The following table lists the keys to check if W3C Camera API is supported on a Tizen device.

| Table: W3C Camera API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/media.audio_recording | boolean | The platform returns true for this key, if the device supports all APIs which require audio recording feature. If it is true , W3C Camera APIs are supported. | 2.2 |
| http://tizen.org/feature/media.image_capture | boolean | The platform returns true for this key, if the device supports all APIs which require image capturing feature. If it is true , W3C Camera APIs are supported. | 2.2 |
| http://tizen.org/feature/media.video_recording | boolean | The platform returns true for this key, if the device supports all APIs which require video recording feature. If it is true , W3C Camera APIs are supported. | 2.2 |

The following table lists the keys related to Content API features.

| Table: Content API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/content.scanning.others | boolean | The platform returns true for this key, if the device supports the media scanning feature for "OTHER" -type files which are not included in the media content types such as "IMAGE" , "VIDEO" , "SOUND" or "MUSIC" . . | 4.0 |

The following table lists the keys to check if DataSync API is supported on a Tizen device.

| Table: DataSynchronization API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/datasync | boolean | The platform returns true for this key, if the device supports DataSynchronization API . | 2.3 |

The following table lists the keys to check if Download API is supported on a Tizen device.

| Table: Download API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/download | boolean | The platform returns true for this key, if the device supports Download API . | 2.3 |
| http://tizen.org/feature/network.telephony | boolean | The platform returns true for this key, if the device supports all APIs which require telephony feature. If it is true , "CELLULAR" in DownloadNetworkType is supported. | 2.2.1 |
| http://tizen.org/feature/network.wifi | boolean | The platform returns true for this key, if the device supports all APIs which require Wi-Fi. If it is true , "WIFI" in DownloadNetworkType is supported. | 2.2.1 |

The following table lists the keys to check if SystemSetting API is supported on a Tizen device.

| Table: SystemSetting API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/systemsetting | boolean | The platform returns true for this key, if the device supports SystemSetting API . | 2.3 |
| http://tizen.org/feature/systemsetting.home_screen | boolean | The platform returns true for this key and http://tizen.org/feature/systemsetting , if the device supports a way to change/get the picture on home screen. That means that "HOME_SCREEN" in SystemSettingType is supported. | 2.3 |
| http://tizen.org/feature/systemsetting.lock_screen | boolean | The platform returns true for this key and http://tizen.org/feature/systemsetting , if the device supports a way to change/get lock screen wallpaper. That means that "LOCK_SCREEN" in SystemSettingType is supported. | 2.3 |
| http://tizen.org/feature/systemsetting.incoming_call | boolean | The platform returns true for this key and http://tizen.org/feature/systemsetting , if the device supports a way to change/get a ringtone for all incoming calls. That means that "INCOMING_CALL" type in SystemSettingType is supported. | 2.3 |
| http://tizen.org/feature/systemsetting.notification_email | boolean | The platform returns true for this key and http://tizen.org/feature/systemsetting , if the device supports a way to change/get a ringtone for all email notifications. That means that "NOTIFICATION_EMAIL" in SystemSettingType is supported. | 2.3 |

The following table lists the keys to check if MediaKey API is supported on a Tizen device.

| Table: MediaKey API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/network.bluetooth.audio.media | boolean | The platform returns true for this key, if the device supports MediaKey API . | 2.3 |

The following table lists the keys to check if Messaging API is supported on a Tizen device.

| Table: Messaging API key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/network.telephony | boolean | The platform returns true for this key, if the device supports Messaging SMS API. | 2.2.1 |
| http://tizen.org/feature/network.telephony.mms | boolean | The platform returns true for this key, if the device supports Messaging MMS API. | 2.2.1 |

The following table lists the keys to check if a device has a battery.

| Table: battery capability key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/battery | boolean | The platform returns true for this key, if the device has a battery. If it is true , W3C Battery Status API , BATTERY property in SystemInfo API, and Power API must be supported. | 2.3 |

The following table lists the Camera feature keys.

| Table: Camera feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/camera | boolean | The platform returns true for this key, if the device provides any kind of a camera. If it is true , W3C getUserMedia and HTML Media Capture APIs are supported. | 2.2.1 |
| http://tizen.org/feature/camera.back | boolean | The platform returns true for this key and the http://tizen.org/feature/camera key, if the device provides a back-facing camera. | 2.2.1 |
| http://tizen.org/feature/camera.back.flash | boolean | The platform returns true for this key and the http://tizen.org/feature/camera.back key, if the device provides a back-facing camera with a flash. | 2.2.1 |
| http://tizen.org/feature/camera.front | boolean | The platform returns true for this key and the http://tizen.org/feature/camera key, if the device provides a front-facing camera. | 2.2.1 |
| http://tizen.org/feature/camera.front.flash | boolean | The platform returns true for this key and the http://tizen.org/feature/camera.front key, if the device provides a front-facing camera with a flash. | 2.2.1 |

The following table lists the database feature keys.

| Table: Database feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/database.encryption | boolean | The platform returns true for this key, if the device supports database encryption. | 2.2.1 |

The following table lists the FM radio feature keys.

| Table: FM radio feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/fmradio | boolean | The platform returns true for this key, if the device supports an FM radio. If it is true , FM Radio API is supported. | 2.2.1 |

The following table lists the Human Activity Monitor feature keys.

| Table: Human Activity Monitor keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/humanactivitymonitor | boolean | The platform returns true for this key, if the device supports any of the Human Activity Monitor sensors ( http://tizen.org/feature/sensor.heart_rate_monitor, http://tizen.org/feature/sensor.pedometer, http://tizen.org/feature/sensor.wrist_up, http://tizen.org/feature/location.batch ). If it is true , Human Activity Monitor API is supported. | 2.3.0 |

The following table lists the graphics feature keys.

| Table: Graphics feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/graphics.acceleration | boolean | The platform returns true for this key, if the device supports graphics hardware acceleration. | 2.2.1 |

The following table lists the led feature key.

| Table: led feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/led | boolean | The platform returns true for this key, if the device supports led. | 2.3 |

The following table lists the input feature keys.

| Table: Input feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/input.keyboard | boolean | The platform returns true for this key, if the device  provides a built-in keyboard supporting any keyboard layout. | 2.2.1 |
The platform returns the keyboard layout (such as qwerty ) supported by the built-in keyboard for this key and returns true for the http://tizen.org/feature/input.keyboard key. If the device does not provide a built-in keyboard, the platform returns an empty string for this key and returns false for the http://tizen.org/feature/input.keyboard key.

| http://tizen.org/feature/input.keyboard.layout | DOMString |  | 2.2.1 |
| http://tizen.org/feature/input.rotating_bezel | boolean | The platform returns true for this key, if the device provides a built-in rotating bezel. | 2.3.1 |

The following table lists the location feature keys.

| Table: Location feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/location | boolean | The platform returns true for this key, if the device supports location positioning. | 2.2.1 |
| http://tizen.org/feature/location.batch | boolean | The platform returns true for this key and the http://tizen.org/feature/location key, if the device supports GPS batch feature.
         If it is true , HumanActivityMonitor API - GPS API is supported. | 2.3 |
| http://tizen.org/feature/location.gps | boolean | The platform returns true and the http://tizen.org/feature/location ,
         if the device supports the Global Positioning System(GPS). If it is true , W3C GeoLocation API is supported. | 2.2.1 |
| http://tizen.org/feature/location.wps | boolean | The platform returns true for this key and the http://tizen.org/feature/location key, if the device supports  the Wi-Fi-based Positioning System (WPS). | 2.2.1 |

The following table lists the multimedia transcoder feature key.

| Table: multimedia transcoder feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/multimedia.transcoder | boolean | The platform returns true for this key, if the device supports multimedia transcoder. | 2.3 |

The following table lists the microphone feature keys.

| Table: Microphone feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/microphone | boolean | The platform returns true for this key, if the device supports a microphone.
     If it is true , W3C getUserMedia and HTML Media Capture APIs are supported. | 2.2.1 |

The following table lists the multi-point touch feature keys.

| Table: Multi-point touch feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/multi_point_touch.pinch_zoom | boolean | The platform returns true for this key, if the device supports pinch zoom gestures. | 2.2.1 |
The platform returns the maximum number of supported multi-touch points for this key. The platform returns a value less than 2 for this key, if the device does not support multi-point touch.

| http://tizen.org/feature/multi_point_touch.point_count | long | 2.2.1 |

The following table lists the network feature keys.

| Table: Network feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/capability/network.bluetooth.always_on | boolean | The platform returns true for this key, if the device must always enable Bluetooth. It means that an application cannot change the Bluetooth's state (visibility, connectivity, device name). | 2.3 |
| http://tizen.org/feature/network.bluetooth | boolean | The platform returns true for this key, if the device supports Bluetooth API which requires Bluetooth. | 2.2.1 |
| http://tizen.org/feature/network.bluetooth.audio.call | boolean | The platform returns true for this key, if the device supports Bluetooth Handsfree Profile (HFP). | 2.3 |
| http://tizen.org/feature/network.bluetooth.audio.media | boolean | The platform returns true for this key, if the device supports Bluetooth Advanced Audio Distribute Profile (A2DP). | 2.3 |
| http://tizen.org/feature/network.bluetooth.health | boolean | The platform returns true for this key, if the device supports Bluetooth Health Device Profile (HDP). | 2.3 |
| http://tizen.org/feature/network.bluetooth.hid | boolean | The platform returns true for this key, if the device supports Bluetooth Human Input Device (HID). | 2.3 |
| http://tizen.org/feature/network.bluetooth.le | boolean | The platform returns true for this key, if the device supports Bluetooth Low Energy related methods in Bluetooth API. | 2.3 |
| http://tizen.org/feature/network.bluetooth.opp | boolean | The platform returns true for this key, if the device supports Bluetooth Object Push Profile (OPP). | 2.3 |
| http://tizen.org/feature/network.ethernet | boolean | The platform returns true for this key, if the device supports ethernet. If it is true , "ALL" in DownloadNetworkType and SystemInfoEthernetNetwork is supported. | 3.0 |
| http://tizen.org/feature/network.internet | boolean | The platform returns true for this key, if the device supports internet. | 2.3.1 |
| http://tizen.org/feature/network.nfc | boolean | The platform returns true for this key, if the device supports NFC API which requires Near Field Communication (NFC). | 2.2.1 |
| http://tizen.org/feature/network.nfc.card_emulation | boolean | The platform returns true for this key, if the device is recognized by the NFC card readers. | 2.3 |
| http://tizen.org/feature/network.nfc.card_emulation.hce | boolean | The platform returns true for this key, if the device supports NFC Host-based Card Emulation. | 2.3.1 |
| http://tizen.org/feature/network.nfc.p2p | boolean | The platform returns true for this key, if the device supports P2P APIs which require Near Field Communication (NFC). | 2.3.1 |
| http://tizen.org/feature/network.nfc.reserved_push | boolean | The platform returns true for this key and the http://tizen.org/feature/network.nfc key, if the device supports the NFC reserved push feature. | 2.2.1 |
| http://tizen.org/feature/network.nfc.tag | boolean | The platform returns true for this key, if the device supports Tag APIs which require Near Field Communication (NFC). | 2.3.1 |
| http://tizen.org/feature/network.push | boolean | The platform returns true for this key, if the device supports Push API which requires the IP push service provided by
the Tizen reference implementation. | 2.2.1 |
| http://tizen.org/feature/network.secure_element | boolean | The platform returns true for this key, if the device supports secure elements. If it is true , Secure Element API is supported. | 2.2.1 |
| http://tizen.org/feature/network.telephony | boolean | The platform returns true for this key, if the device supports  the telephony related APIs ( CallHistory , Messaging SMS , NetworkBearerSelection APIs). | 2.2.1 |
| http://tizen.org/feature/network.telephony.mms | boolean | The platform returns true for this key and the http://tizen.org/feature/network.telephony key, if the device supports MMS. If it is true , Messaging MMS is supported. | 2.2.1 |
| http://tizen.org/feature/network.wifi | boolean | The platform returns true for this key, if the device supports all APIs which require Wi-Fi. | 2.2.1 |
| http://tizen.org/feature/network.wifi.direct | boolean | The platform returns true for this key and the http://tizen.org/feature/network.wifi key, if the device supports Wi-Fi Direct™. | 2.2.1 |

The following table lists the OpenGL® ES feature keys.

| Table: OpenGL® ES feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/opengles | boolean | The platform returns true for this key, if the device supports any OpenGL® ES version and any texture format. | 2.2.1 |
| http://tizen.org/feature/opengles.texture_format | DOMString | The supported texture formats for the OpenGL® ES. (e.g. "3dc/atc/etc/ptc"). 
The platform returns an empty string for this key if OpenGL® ES or compressed texture formats are not supported. | 2.3 |
| http://tizen.org/feature/opengles.texture_format.3dc | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the 3DC texture format for OpenGL® ES. | 2.2.1 |
| http://tizen.org/feature/opengles.texture_format.atc | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the ATC texture format for OpenGL® ES. | 2.2.1 |
| http://tizen.org/feature/opengles.texture_format.etc | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the ETC texture format for OpenGL® ES. | 2.2.1 |
| http://tizen.org/feature/opengles.texture_format.ptc | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the PTC texture format for OpenGL® ES. | 2.2.1 |
| http://tizen.org/feature/opengles.texture_format.pvrtc | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the PVRTC texture format for OpenGL® ES. | 2.2.1 |
| http://tizen.org/feature/opengles.texture_format.utc | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the UTC texture format for OpenGL® ES. | 2.2.1 |
| http://tizen.org/feature/opengles.version.1_1 | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the OpenGL® ES version 1.1. | 2.2.1 |
| http://tizen.org/feature/opengles.version.2_0 | boolean | The platform returns true for this key and the http://tizen.org/feature/opengles key, if the device supports the OpenGL® ES version 2.0. | 2.2.1 |

The following table lists the platform feature keys.

| Table: Platform feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/platform.core.api.version | DOMString | The version of the Tizen Core API in the [Major].[Minor] format. For example, "1.0" represents a web api version where the major version is 1 and the minor version is 0.
     If a device doesn't provide Tizen Core API, it returns an empty string(""). | 2.3 |
| http://tizen.org/feature/platform.core.cpu.arch | DOMString | The platform returns the CPU architecture (e.g. "armv7", "x86") of a device. | 2.3 |
| http://tizen.org/feature/platform.core.cpu.arch.armv6 | boolean | The platform returns true for this key, if the device runs on the ARMv6 CPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.cpu.arch.armv7 | boolean | The platform returns true for this key, if the device runs on the ARMv7 CPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.cpu.arch.x86 | boolean | The platform returns true for this key, if the device runs on the x86 CPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.cpu.frequency | long | The platform returns the frequency at which a core CPU is running. (unit: MHz) | 2.3 |
| http://tizen.org/feature/platform.core.fpu.arch | DOMString | The platform returns the FPU architecture (e.g. "vfpv3", "ssse3" of a device.) If there is no FPU on a device, it returns an empty string(""). | 2.3 |
| http://tizen.org/feature/platform.core.fpu.arch.sse2 | boolean | The platform returns true for this key, if the device runs on the SSE2 FPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.fpu.arch.sse3 | boolean | The platform returns true for this key, if the device runs on the SSE3 FPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.fpu.arch.ssse3 | boolean | The platform returns true for this key, if the device runs on the SSSE3 FPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.fpu.arch.vfpv2 | boolean | The platform returns true for this key, if the device runs on the VFPV2 FPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.core.fpu.arch.vfpv3 | boolean | The platform returns true for this key, if the device runs on the VFPV3 FPU architecture. | 2.2.1 |
| http://tizen.org/feature/platform.native.api.version | DOMString | The version of the Native API in the [Major].[Minor] format. For example, 1.0 represents a native api version where the major version is 1 and the minor version is 0.
     If a device doesn't provide Tizen Native API, it returns an empty string(""). | 2.2.1 |
| http://tizen.org/feature/platform.native.osp_compatible | boolean | The platform returns true for this key, if the device supports the bada compatibility mode. | 2.2.1 |
| http://tizen.org/feature/platform.version | DOMString | The version of the platform in the [Major].[Minor].[Patch Version] format.
     For example, 1.0.0 represents a platform version where the major version is 1 and the minor and build versions are 0. | 2.2.1 |
| http://tizen.org/feature/platform.web.api.version | DOMString | The version of the Web API in the [Major].[Minor] format. For example, 1.0 represents a web api version where the major version is 1 and the minor version is 0. | 2.2.1 |
| http://tizen.org/feature/platform.version.name | DOMString | The platform return the platform version name. (e.g. Tizen 2.0: magnolia, Tizen 2.1: Nectarine) | 2.3 |

The following table lists the profile feature keys.

| Table: Profile feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/profile | SystemInfoProfile | The platform returns a compliant device profile (such as "MOBILE", "WEARABLE" ) for this key. | 2.2.1 |

The following table lists the screen feature keys.

| Table: Screen feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/screen | boolean | The platform returns true for this key, if the device has a display screen. | 2.3 |
| http://tizen.org/feature/screen.auto_rotation | boolean | The platform returns true for this key, if the device supports screen auto-rotation. | 2.2.1 |
| http://tizen.org/feature/screen.bpp | long | The platform returns the number of bits per pixel supported by the device for this key. The value depends on the screen, and is typically 8, 16, 24, or 32. | 2.2.1 |
| http://tizen.org/feature/screen.coordinate_system.size.large | boolean | The platform returns true for this key, if the device supports the large screen size for the coordinate system. | 2.2.1 |
| http://tizen.org/feature/screen.coordinate_system.size.normal | boolean | The platform returns true for this key, if the device supports the normal screen size for the coordinate system. | 2.2.1 |
| http://tizen.org/feature/screen.dpi | long | The platform returns the number of dots per inch supported by the device for this key. | 2.2.1 |
| http://tizen.org/feature/screen.height | long | The platform returns the height of the screen in pixels supported by the device for this key. | 2.2.1 |
| http://tizen.org/feature/screen.output.hdmi | boolean | The platform returns true for this key, if the device supports HDMI output. | 2.2.1 |
| http://tizen.org/feature/screen.output.rca | boolean | The platform returns true for this key, if the device supports RCA output. | 2.2.1 |
| http://tizen.org/feature/screen.shape.circle | boolean | The platform returns true for this key, if the device supports a circular shaped screen. | 2.3.1 |
| http://tizen.org/feature/screen.shape.rectangle | boolean | The platform returns true for this key, if the device supports a rectangular shaped screen. | 2.3.1 |
| http://tizen.org/feature/screen.size.all | boolean | The platform can return true if the device supports any of screen sizes and resolutions. (If the device has a display screen, it returns true .) | 2.2.1 |
| http://tizen.org/feature/screen.size.large | boolean | The platform can return true if the device supports the large screen size. | 2.2.1 |
| http://tizen.org/feature/screen.size.normal | boolean | The platform can return true the device supports the normal screen size. | 2.2.1 |
The platform returns true for this key, if the device supports the 240 x 400 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.240.400 | boolean |  | 2.2.1 |
The platform returns true for this key, if the device supports the 320 x 320 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.320.320 | boolean |  | 2.3 |
The platform returns true for this key, if the device supports the 320 x 480 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.320.480 | boolean |  | 2.2.1 |
The platform returns true for this key, if the device supports the 360 x 360 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.360.360 | boolean |  | 2.3.2 |
The platform returns true for this key, if the device supports the 360 x 480 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.360.480 | boolean |  | 2.3 |
The platform returns true for this key, if the device supports the 480 x 800 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.480.800 | boolean |  | 2.2.1 |
The platform returns true for this key, if the device supports the 540 x 960 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.540.960 | boolean |  | 2.2.1 |
The platform returns true for this key, if the device supports the 600 x 1024 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.600.1024 | boolean |  | 2.2.1 |
The platform returns true for this key, if the device supports the 720 x 1280 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.720.1280 | boolean |  | 2.2.1 |
The platform returns true for this key, if the device supports the 1080 x 1920 resolution for the normal screen size. The platform can return true for multiple resolution keys.

| http://tizen.org/feature/screen.size.normal.1080.1920 | boolean |  | 2.2.1 |
| http://tizen.org/feature/screen.width | long | The platform returns the width of the screen in pixels supported by the device for this key. | 2.2.1 |

The following table lists the sensor feature keys.

| Table: Sensor feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/sensor.accelerometer | boolean | The platform returns true for this key, if the device supports the acceleration sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.accelerometer.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.accelerometer key, if the device supports the wake-up operation by the acceleration sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.activity_recognition | boolean | The platform returns true for this key, if the device supports HumanActivityMonitor API - Activity Recognition . | 2.3 |
| http://tizen.org/feature/sensor.barometer | boolean | The platform returns true for this key, if the device supports the barometer (Pressure) sensor. If it is true , Pressure Sensor API is supported. | 2.2.1 |
| http://tizen.org/feature/sensor.barometer.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.barometer key, if the device supports the wake-up operation by the barometer sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.gesture_recognition | boolean | The platform returns true for this key, if the device supports the gesture recognition. | 2.3 |
| http://tizen.org/feature/sensor.gravity | boolean | The platform returns true for this key, if the device supports Gravity Sensor API . | 2.3 |
| http://tizen.org/feature/sensor.gyroscope | boolean | The platform returns true for this key, if the device supports Gyroscope Sensor API . | 2.2.1 |
| http://tizen.org/feature/sensor.gyroscope_rotation_vector | boolean | The platform returns true for this key, if the device supports Gyroscope Rotation Vector Sensor API . | 3.0 |
| http://tizen.org/feature/sensor.gyroscope.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.gyroscope key, if the device supports the wake-up operation by the gyro sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.heart_rate_monitor | boolean | The platform returns true for this key if the device supports HumanActivityMonitor API - HRM . | 2.3 |
| http://tizen.org/feature/sensor.heart_rate_monitor.led_green | boolean | The platform returns true for this key if the device supports green light spectrum. If it is true, Sensor API - HRM raw data is supported . | 2.3.1 |
| http://tizen.org/feature/sensor.heart_rate_monitor.led_ir | boolean | The platform returns true for this key if the device supports infrared spectrum. If it is true, Sensor API - HRM raw data is supported . | 2.3.1 |
| http://tizen.org/feature/sensor.heart_rate_monitor.led_red | boolean | The platform returns true for this key if the device supports red light spectrum. If it is true, Sensor API - HRM raw data is supported . | 2.3.1 |
| http://tizen.org/feature/sensor.humidity | boolean | The platform returns true for this key, if the device supports the humidity sensor. | 2.3 |
| http://tizen.org/feature/sensor.linear_acceleration | boolean | The platform returns true for this key, if the device supports the linear acceleration sensor. | 2.3 |
| http://tizen.org/feature/sensor.magnetometer | boolean | The platform returns true for this key, if the device supports the magnetic sensor. If it is true , Magnetic Sensor API and W3C Screen Orientation are supported. | 2.2.1 |
| http://tizen.org/feature/sensor.magnetometer.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.magnetometer key, if the device supports the wake-up operation by the magnetic sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.pedometer | boolean | The platform returns true for this key, if the device supports HumanActivityMonitor API - PEDOMETER . | 2.3 |
| http://tizen.org/feature/sensor.photometer | boolean | The platform returns true for this key, if the device supports the photometer sensor.  If it is true , Light Sensor API is supported. | 2.2.1 |
| http://tizen.org/feature/sensor.photometer.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.photometer key, if the device supports the wake-up operation by the photo sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.proximity | boolean | The platform returns true for this key, if the device supports the proximity sensor. If it is true , Proximity Sensor API is supported. | 2.2.1 |
| http://tizen.org/feature/sensor.proximity.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.proximity key, if the device supports the wake-up operation by the proximity sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.rotation_vector | boolean | The platform returns true for this key, if the device supports the rotation vector sensor. | 2.3 |
| http://tizen.org/feature/sensor.sleep_monitor | boolean | The platform returns true for this key, if the device supports HumanActivityMonitor API - SLEEP_MONITOR . | 3.0 |
| http://tizen.org/feature/sensor.temperature | boolean | The platform returns true for this key, if the device supports the temperature sensor. | 2.3 |
| http://tizen.org/feature/sensor.tiltmeter | boolean | The platform returns true for this key, if the device supports the tilt sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.tiltmeter.wakeup | boolean | The platform returns true for this key and the http://tizen.org/feature/sensor.tiltmeter key, if the device supports the wake-up operation by the tilt sensor. | 2.2.1 |
| http://tizen.org/feature/sensor.ultraviolet | boolean | The platform returns true for this key if the device supports ultraviolet sensor. If it is true , UV Sensor API is supported. | 2.3 |
| http://tizen.org/feature/sensor.wrist_up | boolean | The platform returns true for this key if the device supports HumanActivityMonitor API - WRIST_UP . | 2.3 |

The following table lists the shell(Dynamic Box) feature keys.

| Table: Shell(Dynamic Box) feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/shell.appwidget | boolean | The platform returns true for this key, if the device supports the Widget. Since 2.3.1, this key indicates only Native Widget. | 2.2.1 |

The following table lists the sip feature keys.

| Table: Sip feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/sip.voip | boolean | The platform returns true for this key, if the device supports the Voice over Internet Protocol (VoIP). | 2.2.1 |

The following table lists the speech feature keys.

| Table: Speech feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/speech.recognition | boolean | The platform returns true for this key, if the device supports speech recognition (STT). | 2.2.1 |
| http://tizen.org/feature/speech.synthesis | boolean | The platform returns true for this key, if the device supports speech synthesis (TTS). | 2.2.1 |

The following table lists the USB feature keys.

| Table: USB feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/usb.accessory | boolean | The platform returns true for this key, if the device supports the USB client or accessory mode. | 2.2.1 |
| http://tizen.org/feature/usb.host | boolean | The platform returns true for this key, if the device supports the USB host mode. | 2.2.1 |

The following table lists the web service model feature keys.

| Table: Web Service feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/web.service | boolean | The platform returns true for this key, if the device supports the web service model. | 2.3 |

The following table lists the vision feature keys.

| Table: Vision feature keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/feature/vision.face_recognition | boolean | The platform returns true for this key, if the device supports face recognition. | 2.2.1 |
| http://tizen.org/feature/vision.image_recognition | boolean | The platform returns true for this key, if the device supports image recognition. | 2.2.1 |
| http://tizen.org/feature/vision.qrcode_generation | boolean | The platform returns true for this key, if the device supports QR code generation. | 2.2.1 |
| http://tizen.org/feature/vision.qrcode_recognition | boolean | The platform returns true for this key, if the device supports QR code recognition. | 2.2.1 |

The following table lists the build information key.

| Table: build information system key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/system/build.date | DOMString | The platform returns the build date.(the format : YYYY.MM.DD) | 2.3 |
| http://tizen.org/system/build.string | DOMString | The platform returns the build string including build date and time. | 2.3 |
| http://tizen.org/system/build.time | DOMString | The platform returns the build time. (the format : HH.MM.SS) | 2.3 |
| http://tizen.org/system/manufacturer | DOMString | The platform returns the device manufacturer's name. | 2.3 |
| http://tizen.org/system/build.release | DOMString | The platform returns the build version information. The build version information is made when the platform image is created. | 3.0 |
| http://tizen.org/system/build.type | DOMString | The platform returns the build type, such as "user" or "eng". The build type is made when the platform image is created. | 3.0 |
| http://tizen.org/system/build.variant | DOMString | The platform returns the variant release information. The variant release information is made when the platform image is created. | 3.0 |
| http://tizen.org/system/build.id | DOMString | The platform returns the build ID. The build ID is made when the platform image is created. | 3.0 |

The following table lists the Tizen ID system key.

| Table: Tizen ID system keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/system/tizenid | DOMString | The platform returns the Tizen ID. It is a randomly generated value based on the model name. | 2.3 |

The following table lists the model name key.

| Table: model name key Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/system/model_name | DOMString | The platform returns the model name. | 2.3 |

The following table lists the platform system keys.

| Table: platform system keys Key | Type | Description | Version |
| --- | --- | --- | --- |
| http://tizen.org/system/platform.communication_processor | DOMString | The platform returns the device communication processor name. | 2.3 |
| http://tizen.org/system/platform.name | DOMString | The platform returns the platform name. It must be Tizen | 2.2.1 |
| http://tizen.org/system/platform.processor | DOMString | The platform returns the device processor name. | 2.3 |
| http://tizen.org/system/input.key.volume | boolean | The platform returns true for this key, if the device provides the Volume key event. | 3.0 |
| http://tizen.org/system/input.key.back | boolean | The platform returns true for this key, if the device provides the Back key event. | 3.0 |
| http://tizen.org/system/input.key.menu | boolean | The platform returns true for this key, if the device provides the Menu key event. | 3.0 |

---
Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
