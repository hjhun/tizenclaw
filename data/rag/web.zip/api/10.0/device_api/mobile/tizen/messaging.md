# Messaging API

The Messaging API provides interfaces and methods for managing SMS, MMS, and email messages.

**Deprecated. **Deprecated Since 8.0.

The Messaging API provides access to these capabilities:

- Sending messages through different technologies: SMS, MMS, and email messages
- Retrieving available message services
- Searching for messages
- Managing messages: update, delete, and add
- Subscribing to receive notifications of message storage modifications
- Fetching conversations and subscribing to conversation updates
**Remark: **In order to access files, a proper privilege has to be defined additionally:

- for accessing only internal storage using this API, a privilege http://tizen.org/privilege/mediastorage must be provided,
- for accessing only external storage using this API, a privilege http://tizen.org/privilege/externalstorage must be provided,
- for accessing internal and external storage using this API, privileges ( http://tizen.org/privilege/mediastorage and http://tizen.org/privilege/externalstorage ) must be provided.
- Storage privileges are privacy-related privileges and there is a need of asking user directly with proper pop-up. Please refer to Privacy Privilege API for more details.
For more information on the Messaging features, see Messaging Guide .

Since: 1.0

## Table of Contents

- 1. Type Definitions
- 2. Interfaces
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |

## 1. Type Definitions

## 2. Interfaces

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the sms application runs on a device with telephony(SMS) feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.telephony
To guarantee that the mms application runs on a device with MMS feature, define below in the config file:

- http://tizen.org/feature/network.telephony.mms

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module Messaging {
  Tizen implements MessageManagerObject;
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
