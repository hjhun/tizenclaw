# Feedback API

The Feedback API provides functions to play sounds or vibrations associated with device actions.

For more information on the Feedback features, see Feedback Guide .

Since: 3.0

## Table of Contents

- 1. Type Definitions
- 1.1. FeedbackType
- 1.2. FeedbackPattern
- 2. Interfaces
- 2.1. FeedbackManagerObject
- 2.2. FeedbackManager
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| FeedbackManagerObject |  |
| FeedbackManager | void play ( FeedbackPattern pattern, optional FeedbackType ? type) void stop () boolean isPatternSupported ( FeedbackPattern pattern, FeedbackType type) |

## 1. Type Definitions

### 1.1. FeedbackType

Enumerations of the type for feedback interface.

```webidl
  enum FeedbackType { "TYPE_SOUND", "TYPE_VIBRATION" };
```

Since: 3.0

The states defined by this enumerator are:

- TYPE_SOUND - Feedback type for sound
- TYPE_VIBRATION - Feedback type for vibration

### 1.2. FeedbackPattern

Enumerations of the system predefined media or vibration patterns for feedback interface.

```webidl
  enum FeedbackPattern { "TAP", "SIP", "KEY0", "KEY1", "KEY2", "KEY3", "KEY4", "KEY5", "KEY6", "KEY7", "KEY8", "KEY9", "KEY_STAR",
    "KEY_SHARP", "KEY_BACK", "HOLD", "HW_TAP", "HW_HOLD", "MESSAGE", "EMAIL", "WAKEUP", "SCHEDULE", "TIMER", "GENERAL", "POWERON", "POWEROFF",
    "CHARGERCONN", "CHARGING_ERROR", "FULLCHARGED", "LOWBATT", "LOCK", "UNLOCK", "VIBRATION_ON", "SILENT_OFF", "BT_CONNECTED",
    "BT_DISCONNECTED", "LIST_REORDER", "LIST_SLIDER", "VOLUME_KEY" };
```

Since: 3.0

Each feedback pattern can have a separate media file for each feedback type. However, depending on vendor design, a pattern may not have any media file.

The following values are supported:

- TAP - general touch
- SIP - text key touch
- KEY0 - numeric 0 key touch
- KEY1 - numeric 1 key touch
- KEY2 - numeric 2 key touch
- KEY3 - numeric 3 key touch
- KEY4 - numeric 4 key touch
- KEY5 - numeric 5 key touch
- KEY6 - numeric 6 key touch
- KEY7 - numeric 7 key touch
- KEY8 - numeric 8 key touch
- KEY9 - numeric 9 key touch
- KEY_STAR - star key touch
- KEY_SHARP - sharp key touch
- KEY_BACK - backspace key touch
- HOLD - hold key touch
- HW_TAP - hardware key press
- HW_HOLD - hardware key holding press
- MESSAGE - new message notification
- EMAIL - new email notification
- WAKEUP - wake up alert
- SCHEDULE - scheduled alarm alert
- TIMER - timer alert
- GENERAL - general event alert
- POWERON - power on
- POWEROFF - power off
- CHARGERCONN - charger connection
- CHARGING_ERROR - charging error occurrence
- FULLCHARGED - fully charged
- LOWBATT - low battery
- LOCK - lock
- UNLOCK - unlock
- VIBRATION_ON - vibration mode enable
- SILENT_OFF - silent mode disable
- BT_CONNECTED - bluetooth connection
- BT_DISCONNECTED - bluetooth disconnection
- LIST_REORDER - list reorder
- LIST_SLIDER - list slider sweep
- VOLUME_KEY - volume key press

## 2. Interfaces

### 2.1. FeedbackManagerObject

This interface defines what is instantiated by the *Tizen *object from the Tizen platform.

```webidl
  [NoInterfaceObject] interface FeedbackManagerObject {
    readonly attribute FeedbackManager feedback;
  };
```

```webidl
  Tizen implements FeedbackManagerObject;
```

Since: 3.0

The *tizen.feedback *object allows access to the Feedback API functionality.

#### Attributes

- readonly FeedbackManager feedback Object representing a feedback manager.

Since: 3.0

### 2.2. FeedbackManager

The *FeedbackManager *interface provides the functionalities for playing simple sound and vibration.

```webidl
  [NoInterfaceObject] interface FeedbackManager {
    void play(FeedbackPattern pattern, optional FeedbackType? type) raises(WebAPIException);
    void stop() raises(WebAPIException);
    boolean isPatternSupported(FeedbackPattern pattern, FeedbackType type) raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**play **`Plays various types of reactions that are predefined.

```javascript
void play(FeedbackPattern pattern, optional FeedbackType? type);
```

Since: 3.0

This function can be used to react to predefined actions. It plays various types of system predefined media or vibration patterns.
Currently, there are two types of reactions: sound and vibration. Depending on the settings, some types cause no action.
For example, when set to silent mode, the device does not produce any sound.
If this method is called without the *type *value, the type of played feedback *pattern *depends on device settings.

Parameters:

- **pattern :
 The predefined pattern. **
- **type [optional] [nullable] :
 The pattern type. **

Exceptions:

- WebAPIException
- with error type NotSupportedError, if feature is not supported.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, if the system operation was aborted.

Code example:

```javascript
try
{
  tizen.feedback.play("CHARGERCONN", "TYPE_SOUND");
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**stop **`Stops various of vibration patterns.

```javascript
void stop();
```

Since: 3.0

This function can be used to stop various types of vibration reactions that are predefined.

Remark: This function does not support stopping media sound actions. If an attempt to stop a media sound action is made, stop operation is ignored.

Exceptions:

- WebAPIException
- with error type AbortError, if the system operation was aborted.

Code example:

```javascript
try
{
  tizen.feedback.play("BT_CONNECTED", "TYPE_VIBRATION");
  tizen.feedback.stop();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**isPatternSupported **`Checks if a pattern is supported.

```javascript
boolean isPatternSupported(FeedbackPattern pattern, FeedbackType type);
```

Since: 3.0

Parameters:

- **pattern :
 The predefined pattern. **
- **type :
 The pattern type. **

Return value:

boolean: true if the pattern is supported, false otherwise.

Exceptions:

- WebAPIException
- with error type AbortError, if any system error occurred.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var pattern = "BT_CONNECTED", type = "TYPE_SOUND";
var isPatternSupported = tizen.feedback.isPatternSupported(pattern, type);
var isSupported = "";
if (!isPatternSupported)
{
  isSupported = " not";
}
console.log("Pattern " + pattern + " is" + isSupported + " supported");
```

Output example:

```
Pattern BT_CONNECTED is supported
```

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee the running of the application on a device which supports feedback vibration feature, since 5.0 declare the following feature requirement in the config file:

- http://tizen.org/feature/feedback.vibration

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module Feedback {
  enum FeedbackType { "TYPE_SOUND", "TYPE_VIBRATION" };
  enum FeedbackPattern { "TAP", "SIP", "KEY0", "KEY1", "KEY2", "KEY3", "KEY4", "KEY5", "KEY6", "KEY7", "KEY8", "KEY9", "KEY_STAR",
    "KEY_SHARP", "KEY_BACK", "HOLD", "HW_TAP", "HW_HOLD", "MESSAGE", "EMAIL", "WAKEUP", "SCHEDULE", "TIMER", "GENERAL", "POWERON", "POWEROFF",
    "CHARGERCONN", "CHARGING_ERROR", "FULLCHARGED", "LOWBATT", "LOCK", "UNLOCK", "VIBRATION_ON", "SILENT_OFF", "BT_CONNECTED",
    "BT_DISCONNECTED", "LIST_REORDER", "LIST_SLIDER", "VOLUME_KEY" };
  Tizen implements FeedbackManagerObject;
  [NoInterfaceObject] interface FeedbackManagerObject {
    readonly attribute FeedbackManager feedback;
  };
  [NoInterfaceObject] interface FeedbackManager {
    void play(FeedbackPattern pattern, optional FeedbackType? type) raises(WebAPIException);
    void stop() raises(WebAPIException);
    boolean isPatternSupported(FeedbackPattern pattern, FeedbackType type) raises(WebAPIException);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
