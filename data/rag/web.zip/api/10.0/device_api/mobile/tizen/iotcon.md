# Iotcon API

The Iotcon API provides functions for IoT connectivity.

**Deprecated. **Deprecated Since 10.0.

It allows to register, discover and access to resources via RESTful API.

**Remark: **In order to access files, a proper privilege has to be defined additionally:

- for accessing only internal storage using this API, a privilege http://tizen.org/privilege/mediastorage must be provided,
- for accessing only external storage using this API, a privilege http://tizen.org/privilege/externalstorage must be provided,
- for accessing internal and external storage using this API, privileges ( http://tizen.org/privilege/mediastorage and http://tizen.org/privilege/externalstorage ) must be provided.
- Storage privileges are privacy-related privileges and there is a need of asking user directly with proper pop-up. Please refer to Privacy Privilege API for more details.
For more information on the IoT features, see IoT Guide .

Since: 3.0

## Table of Contents

- 1. Type Definitions
- 1.1. ResourceType
- 1.2. QosLevel
- 1.3. ResponseResult
- 1.4. PresenceResponseResultType
- 1.5. PresenceTriggerType
- 1.6. ConnectivityType
- 1.7. ResourceInterface
- 1.8. ObservePolicy
- 1.9. ObserveType
- 2. Interfaces
- 2.1. IotconObject
- 2.2. Iotcon
- 2.3. Client
- 2.4. Server
- 2.5. RemoteResource
- 2.6. ResourcePolicy
- 2.7. Resource
- 2.8. Representation
- 2.9. PresenceResponse
- 2.10. Query
- 2.11. IotconOption
- 2.12. Request
- 2.13. Response
- 2.14. RemoteResponse
- 2.15. DeviceInfo
- 2.16. PlatformInfo
- 2.17. RequestCallback
- 2.18. FoundResourceSuccessCallback
- 2.19. PresenceEventCallback
- 2.20. FoundDeviceInfoSuccessCallback
- 2.21. FoundPlatformInfoSuccessCallback
- 2.22. RemoteResourceResponseCallback
- 2.23. ResourceStateChangeCallback
- 2.24. CacheUpdatedCallback
- 2.25. GeneratedPinCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |

## 1. Type Definitions

### 1.1. ResourceType

A resource type.

**Deprecated. **Deprecated Since 10.0.

```webidl
  typedef DOMString ResourceType;
```

Since: 3.0

Remark: The length of resource type should be less than or equal to 61. The resource type must start with a lowercase alphabetic character, followed by a sequence
of lowercase alphabetic, numeric, ".", or "-" characters, and contains no white space.

### 1.2. QosLevel

Enumeration for quality of service level.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum QosLevel { "HIGH", "LOW" };
```

Since: 3.0

The following values are supported:

- HIGH - for a high quality of service. acknowledgments are used to confirm delivery.
- LOW - for a low quality of service. packet delivery is best effort

### 1.3. ResponseResult

Enumeration for result of response.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum ResponseResult { "SUCCESS", "ERROR", "RESOURCE_CREATED", "RESOURCE_DELETED", "RESOURCE_CHANGED", "SLOW", "FORBIDDEN" };
```

Since: 3.0

The following values are supported:

- SUCCESS - result of response for success
- ERROR - result of response for something error
- RESOURCE_CREATED - result of response for resource has created
- RESOURCE_DELETED - result of response for resource has deleted
- RESOURCE_CHANGED - result of response for resource has changed
- SLOW - result of response for slow resource
- FORBIDDEN - result of response for accessing unauthorized resource

### 1.4. PresenceResponseResultType

Enumeration for result of presence response.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum PresenceResponseResultType { "OK", "STOPPED", "TIMEOUT" };
```

Since: 3.0

The following values are supported:

- OK - successful action of presence
- STOPPED - stopped action of presence
- TIMEOUT - no response of presence for some time

### 1.5. PresenceTriggerType

Enumeration for trigger type of presence. It is set only if a PresenceResponseResultType is OK.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum PresenceTriggerType { "CREATED", "UPDATED", "DESTROYED" };
```

Since: 3.0

The following values are supported:

- CREATED - resource creation operation of server
- UPDATED - resource update operation of server
- DESTROYED - resource destruction operation of server

### 1.6. ConnectivityType

Enumeration for connectivity types of connection.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum ConnectivityType { "IP", "PREFER_UDP", "PREFER_TCP", "IPV4_ONLY", "IPV6_ONLY", "ALL" };
```

Since: 3.0

The following values are supported:

- IP - Internet Protocol connectivity. IP includes all internet connectivity (UDP, TCP, IPV4, IPV6).
- PREFER_UDP - UDP is preferred
- PREFER_TCP - TCP is preferred
- IPV4_ONLY - Internet Protocol version 4 connectivity only
- IPV6_ONLY - Internet Protocol version 6 connectivity only
- ALL - All connectivities

### 1.7. ResourceInterface

Type of interfaces which can be held in a resource.

**Deprecated. **Deprecated Since 10.0.

```webidl
  typedef DOMString ResourceInterface;
```

Since: 3.0

The following values are allowed:

- "oic.if.baseline" - Interface for default. Applicable methods: GET, UPDATE. All resource has this interface automatically.
- "oic.if.ll" - Interface which is used to list the references to other resources contained in a resource.
- "oic.if.b" - Interface which is used to manipulate (GET, PUT, POST, DELETE) a collection of sub-resources at the same time.
- "oic.mi.grp" - Interface which is used to manipulate (GET, PUT, POST) a group of remote resources.
- "oic.if.r" - Interface which is used to limit the methods that can be applied to a resource to GET only.

### 1.8. ObservePolicy

Enumeration for policy of observation.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum ObservePolicy { "IGNORE_OUT_OF_ORDER", "ACCEPT_OUT_OF_ORDER" };
```

Since: 3.0

The following values are supported:

- IGNORE_OUT_OF_ORDER - observation request for most up-to-date notifications only
- ACCEPT_OUT_OF_ORDER - observation request for all notifications including stale notifications

### 1.9. ObserveType

Enumeration for type of observation.

**Deprecated. **Deprecated Since 10.0.

```webidl
  enum ObserveType { "NO_TYPE", "REGISTER", "DEREGISTER" };
```

Since: 3.0

The following values are supported:

- NO_TYPE - no action of observation
- REGISTER - action of registering observation
- DEREGISTER - action of unregistering observation

## 2. Interfaces

### 2.1. IotconObject

This interface defines what is instantiated by the *Tizen *object from the Tizen platform.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface IotconObject {
    readonly attribute Iotcon iotcon;
  };
```

```webidl
  Tizen implements IotconObject;
```

Since: 3.0

There is a *tizen.iotcon *object that allows access to the Iotcon API.

#### Attributes

- readonly Iotcon iotcon Object representing a exif manager.

Since: 3.0

### 2.2. Iotcon

This interface provides access to the *IotconObject *object.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface Iotcon {
    attribute DOMString deviceName;
    void initialize(DOMString filePath) raises(WebAPIException);
    Client getClient();
    Server getServer();
    long getTimeout();
    void setTimeout(long timeout) raises(WebAPIException);
    long addGeneratedPinListener(GeneratedPinCallback successCallback) raises(WebAPIException);
    void removeGeneratedPinListener(long watchId) raises(WebAPIException);
  };
```

Since: 3.0

#### Attributes

- DOMString deviceName The device name of this application.

Since: 3.0

#### Methods

`**initialize **`Connects to the iotcon service. Call this function to start Iotcon.

```javascript
void initialize(DOMString filePath);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: Recommends to use application local file for CBOR file path. 
If you want to know about IoTivity Architecture in detail, see IoTivity Architecture .

Parameters:

- **filePath :
 The CBOR(Concise Binary Object Representation) file path for handling secure virtual resources. **

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method or the application does not have privilege to access the storage. For more information, see Storage privileges .

- with error type NotSupportedError, if this feature is not supported.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
try
{
  var cborPath = "App_installed_fullpath/iotcon-test.dat";
  tizen.iotcon.initialize(cborPath);
  tizen.iotcon.deviceName = "my_test";
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**getClient **`Returns object of Client singleton, which provides methods for working with remote resources.

```javascript
Client getClient();
```

Since: 3.0

Return value:

Client: The *Client *object.

Code example:

```javascript
try
{
  var cborPath = "App_installed_fullpath/iotcon-test.dat";
  tizen.iotcon.initialize(cborPath);
  tizen.iotcon.deviceName = "my_test";
  var iotClient = tizen.iotcon.getClient();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**getServer **`Returns the Server object, which provides methods for managing resources on current device.

```javascript
Server getServer();
```

Since: 3.0

Return value:

Server: The *Server *object.

Code example:

```javascript
try
{
  var cborPath = "App_installed_fullpath/iotcon-test.dat";
  tizen.iotcon.initialize(cborPath);
  tizen.iotcon.deviceName = "my_test";
  var iotServer = tizen.iotcon.getServer();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**getTimeout **`Returns the number of seconds set as the timeout threshold of asynchronous API.

```javascript
long getTimeout();
```

Since: 3.0

This method returns the common timeout value for methods: 
findDeviceInfo 
findPlatformInfo 
findResource 
methodGet 
methodPut 
methodPost 
methodDelete 
All asynchronous APIs have the same timeout value, there is no way to have different timeout values at each method.
Without a response after the specified time, the mentioned methods would trigger an error callback with TimeoutError .

Return value:

long: The timeout value in seconds.

Code example:

```javascript
tizen.iotcon.setTimeout(60);
var timeout = tizen.iotcon.getTimeout();
console.log("Timeout value is " + timeout);
```

Output example:

```
Timeout value is 60
```

`**setTimeout **`Sets the timeout value, in seconds, of asynchronous APIs.

```javascript
void setTimeout(long timeout);
```

Since: 3.0

The timeout value is common for methods: 
findDeviceInfo 
findPlatformInfo 
findResource 
methodGet 
methodPut 
methodPost 
methodDelete 
All asynchronous APIs have the same timeout value, there is no way to have different timeout values at each method.
Without a response after the specified time, the mentioned methods would trigger an error callback with TimeoutError .

Parameters:

- **timeout :
 Timeout value in seconds (value must range between 1 and 3600 inclusive). The default value is 30 . **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any input parameter does not contain a valid value.

Code example:

```javascript
tizen.iotcon.setTimeout(60);
var timeout = tizen.iotcon.getTimeout();
console.log("Timeout value is " + timeout);
```

Output example:

```
Timeout value is 60
```

`**addGeneratedPinListener **`Adds a listener to receive generated random pin from provisioning tool.

```javascript
long addGeneratedPinListener(GeneratedPinCallback successCallback);
```

Since: 3.0

Remark: Listener's callback only be invoked when provisioning tool tries to register this device using random pin based. 
If you want to know about developer tools, see IoTivity Developer Tools .

Parameters:

- **successCallback :
 The method to be invoked when random pin is generated. **

Return value:

long: The watchID which can be used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError,  if any input parameter is not compatible with the expected type for that parameter.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var watchId;
function RandomPinSuccess(pin)
{
  console.log("Pin code: " + pin);
  tizen.iotcon.removeGeneratedPinListener(watchId);
}

var cborPath = "App_installed_fullpath/iotcon-test.dat";
tizen.iotcon.initialize(cborPath);
watchId = tizen.iotcon.addGeneratedPinListener(RandomPinSuccess);
```

Output example:

```
Pin code: 73883075
```

`**removeGeneratedPinListener **`Unregisters the listener and stops receiving generated random pin.

```javascript
void removeGeneratedPinListener(long watchId);
```

Since: 3.0

Remark: Example of using can be find at addGeneratedPinListener code example.

Parameters:

- **watchId :
 The watchId identifier returned by the addGeneratedPinListener() method. **

Exceptions:

- WebAPIException
- with error type AbortError, if the operation has been stopped or there is no listener with given watchId.

### 2.3. Client

The Client provides API for client side.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface Client {
    void findResource(DOMString? hostAddress, Query? query, ConnectivityType connectivityType,
                      FoundResourceSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    long addPresenceEventListener(DOMString? hostAddress, ResourceType? resourceType, ConnectivityType connectivityType,
                                  PresenceEventCallback successCallback) raises(WebAPIException);
    void removePresenceEventListener(long watchId) raises(WebAPIException);
    void findDeviceInfo(DOMString? hostAddress, Query? query, ConnectivityType connectivityType,
                        FoundDeviceInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void findPlatformInfo(DOMString? hostAddress, Query? query, ConnectivityType connectivityType,
                          FoundPlatformInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                          raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**findResource **`Finds resources using host address and resource type.

```javascript
void findResource(DOMString? hostAddress, Query? query, ConnectivityType connectivityType,
                  FoundResourceSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: If any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: hostAddress should be in the format coap://Address:port. For example "coaps://[fe80::ae5a:14ff:fe24:b8fe]:12345" or "coaps://192.168.1.10:12345".

Parameters:

- **hostAddress [nullable] :
 The address of host, null indicates that this is for all nodes(multicast). **
- **query [nullable] :
 The query specified as a filter for the resource. null means no filter. **
- **connectivityType :
 The connectivity type. **
- **successCallback :
 The method to invoked when a resource is found. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of finding resource. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
function onerror(err)
{
  console.log("Failed to find resource: " + err.message);
}

function foundSuccess(resource)
{
  if (resource)
  {
    console.log("######## Found a resource ########");
    console.log("URI: " + resource.uriPath);
    console.log("Host Address: " + resource.hostAddress);
    console.log("Device ID: " + resource.deviceId);
    var resourceTypes = resource.resourceTypes;
    console.log("Resource Types: ");
    for (var index in resourceTypes)
    {
      console.log("    " + resourceTypes[index]);
    }
    var resourceInterfaces = resource.resourceInterfaces;
    console.log("Resource interfaces: ");
    for (var index in resourceInterfaces)
    {
      console.log("    " + resourceInterfaces[index]);
    }
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
######## Found a resource ########
URI: /door
Host Address: coaps://192.168.0.10:12345
Device ID: 3f58ff10-fc23-444c-9e42-e15b295722a7
Resource types:
    core.door
Resource interfaces:
    oic.if.b
```

`**addPresenceEventListener **`Adds a listener to receive a presence events from the server.
A server sends presence events when starts or stops presence.

```javascript
long addPresenceEventListener(DOMString? hostAddress, ResourceType? resourceType, ConnectivityType connectivityType,
                              PresenceEventCallback successCallback);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **hostAddress [nullable] :
 The address of host, null indicates that this is for all nodes(multicast). **
- **resourceType [nullable] :
 The resource type specified as a filter for the resource. The characters should have length less than or equal to 61 and start with a lowercase alphabetic. followed by a sequence of lowercase alphabetic, numeric, ".", or "-" characters, and contains no white space. **
- **connectivityType :
 The connectivity type. **
- **successCallback :
 The method to invoked when a presence event is received. **

Return value:

long: The watchID which can be used to remove the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
var client;
var watchID;
var connectivityType = "IP";

function presenceSuccess(presenceResponse)
{
  console.log("######## Get a presence response ########");
  if (presenceResponse.resultType != "OK")
  {
    console.log("the result is not OK");
    return;
  }
  console.log("Trigger type: " + presenceResponse.triggerType);
  console.log("Host address: " + presenceResponse.hostAddress);
  console.log("Connectivity type: " + presenceResponse.connectivityType);
  console.log("Presence resource type: " + presenceResponse.resourceType);

  client.removePresenceEventListener(watchID);
}

try
{
  client = tizen.iotcon.getClient();
  watchID = client.addPresenceEventListener(null, null, connectivityType, presenceSuccess);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
######## Get a presence response ########
Trigger type: UPDATED
Host address: coaps://192.168.0.10:12345
Connectivity type: IP
Resource type: oic.wk.ad
```

`**removePresenceEventListener **`Unregisters a presence event listener.

```javascript
void removePresenceEventListener(long watchId);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: Example of using can be find at addPresenceEventListener code example.

Parameters:

- **watchId :
 The watchID identifier returned by the addPresenceEventListener() method. **

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped or listener for given watchId was not found.

`**findDeviceInfo **`Gets the device information of remote server.

```javascript
void findDeviceInfo(DOMString? hostAddress, Query? query, ConnectivityType connectivityType,
                    FoundDeviceInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: If any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: hostAddress should be in the format coap://Address:port. For example "coaps://[fe80::ae5a:14ff:fe24:b8fe]:12345" or "coaps://192.168.1.10:12345".

Parameters:

- **hostAddress [nullable] :
 The address of host, null indicates that this is for all nodes(multicast). **
- **query [nullable] :
 The query specified as a filter. null means no filter. **
- **connectivityType :
 The connectivity type. **
- **successCallback :
 The method to invoked when device information is found. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of getting device information. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
/* hostDeviceIpAddress should be a valid IP address. */
var hostDeviceIpAddress = "coaps://192.168.0.10:12345";
var connectivityType = "IP";
var query = {resourceType: "core.door"};

function onerror(err)
{
  console.log("Failed to find resource: " + err.message);
}

function foundSuccess(deviceInfo)
{
  if (deviceInfo)
  {
    console.log("######## Get a device info ########");
    console.log("Name: " + deviceInfo.deviceName);  /* Human friendly name for device. */
    console.log(
        "Spec version: " + deviceInfo.specVersion);  /* Spec version of the core specification. */
    console.log("ID: " + deviceInfo.oicDeviceId);    /* Unique identifier for OIC device. */
    console.log(
        "Data model version: " +
        deviceInfo
            .dataModelVersion);  /* Version of the specs this device data model is implemented to. */
  }
}

try
{
  var client = tizen.iotcon.getClient();
  client.findDeviceInfo(hostDeviceIpAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
######## Get a device info ########
Name: Tizen
Spec version: core.1.0.0
ID: 3f58ff10-fc23-444c-9e42-e15b295722a7
Data model version: res.1.0.0
```

`**findPlatformInfo **`Gets the platform information of remote server.

```javascript
void findPlatformInfo(DOMString? hostAddress, Query? query, ConnectivityType connectivityType,
                      FoundPlatformInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: In any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: hostAddress should be in the format coap://Address:port. For example "coaps://[fe80::ae5a:14ff:fe24:b8fe]:12345" or "coaps://192.168.1.10:12345".

Parameters:

- **hostAddress [nullable] :
 The address of host, null indicates that this is for all nodes(multicast). **
- **query [nullable] :
 The query specified as a filter. null means no filter. **
- **connectivityType :
 The connectivity type. **
- **successCallback :
 The method to invoked when platform information is found. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of getting platform information. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
var hostDeviceIpAddress = "coaps://192.168.0.10:12345";
var connectivityType = "IP";
var query = {resourceType: "core.door"};

function onerror(err)
{
  console.log("Failed to find resource: " + err.message);
}

function foundSuccess(platformInfo)
{
  console.log("######## Get a platform info ########");
  console.log("ID: " + platformInfo.platformId);
  console.log("Manufacturer name: " + platformInfo.manufacturerName);
  console.log("Manufacturer URL: " + platformInfo.manufacturerUrl);
  console.log("Model number: " + platformInfo.modelNumber);
  console.log("Date of manufacture: " + platformInfo.manufactureDate);
  console.log("Platform version: " + platformInfo.platformVersion);
  console.log("OS version: " + platformInfo.operatingSystemVersion);
  console.log("Hardware version: " + platformInfo.hardwareVersion);
  console.log("Firmware version: " + platformInfo.firmwareVersion);
  console.log("Support URL: " + platformInfo.supportUrl);
  console.log("System time: " + platformInfo.systemTime);
}

try
{
  var client = tizen.iotcon.getClient();
  client.findPlatformInfo(hostDeviceIpAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
######## Get a platform info ########
ID: Tizen
Manufacturer name: Tizen
Manufacturer URL:
Model number: tm1
Date of manufacture:
Platform version: 3.0
OS version:
Hardware version:
Firmware version: tizen-mobile_20160220.2
Support URL:
System time:
```

### 2.4. Server

Provides functions for creating resource, registering a resource, handling request from client.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface Server {
    Resource[] getResources() raises(WebAPIException);
    Resource createResource(DOMString uriPath, ResourceType[] resourceTypes, ResourceInterface[] resourceInterfaces,
                            RequestCallback listener, optional ResourcePolicy policy) raises(WebAPIException);
    void removeResource(Resource resource) raises(WebAPIException);
    void startPresence(unsigned long timeToLive) raises(WebAPIException);
    void stopPresence() raises(WebAPIException);
  };
```

Since: 3.0

A Resource is a component in a server that can be viewed and controlled by another client.
There are different resource types, for example a temperature sensor, a light controller etc.

#### Methods

`**getResources **`Returns an array of resources which are registered on the server.

```javascript
Resource[] getResources();
```

Since: 3.0

Return value:

Resource[]: Array of *Resource *objects registered on server.

Exceptions:

- WebAPIException
- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
var server = tizen.iotcon.getServer();
var resources = server.getResources();
```

`**createResource **`Creates a resource and registers the resource on server.

```javascript
Resource createResource(DOMString uriPath, ResourceType[] resourceTypes, ResourceInterface[] resourceInterfaces,
                        RequestCallback listener, optional ResourcePolicy policy);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **uriPath :
 The resource URI. **
- **resourceTypes :
 A list of types in this resource. **
- **resourceInterfaces :
 A list of interfaces in this resource. **
- **listener :
 The request listener, which is called when server receives request from client. **
- **policy [optional] :
 The policy for new Resource object. **

Return value:

Resource: Instance of *Resource *object.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
var server = tizen.iotcon.getServer();
var doorResource;
var uriPath = "/door";
var resourceTypes = ["core.door"];
var resourceInterfaces = ["oic.if.b"];
var attributes = {openstate: "open"};
var policy = {isObservable: true, isDiscoverable: true};

var requestListener =
{
  onget: function(request)
  {
    console.log("onget");
    var response = new tizen.Response(request);
    try
    {
      var representation = new tizen.Representation(doorResource.uriPath);
      representation.resourceTypes = doorResource.resourceTypes;
      representation.resourceInterfaces = doorResource.resourceInterfaces;
      representation.attributes = attributes;
      response.representation = representation;
      response.result = "SUCCESS";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onput: function(request)
  {
    console.log("onput");
    /* Add request handler code. */
  },
  onpost: function(request)
  {
    console.log("onpost");
    /* Add request handler code. */
  },
  ondelete: function(request)
  {
    console.log("ondelete");
    /* Add request handler code. */
  },
  onobserving: function(request, observeType, observeId)
  {
    console.log("onobserving");
    /* Add request handler code. */
  }
};

doorResource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);
```

`**removeResource **`Removes the resource and unregisters it from server.

```javascript
void removeResource(Resource resource);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **resource :
 The resource object to delete. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
var resource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);
server.removeResource(resource);
```

`**startPresence **`Starts sending presence event of server. Server can send presence event to client when become online for the first time or come back from offline to online.

```javascript
void startPresence(unsigned long timeToLive);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: If Server does not call startPresence(), client cannot get presence event with addPresenceEventListener().

Remark: If timeToLive is 0, server will set default value as 60 seconds. If timeToLive is bigger than maximum seconds, server will set maximum value as (60 * 60 * 24) seconds (24 hours).

Parameters:

- **timeToLive :
 The interval of announcing presence in seconds(value must range between 1 and 60 * 60 * 24 inclusive). default value is 60 seconds. **

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

Code example:

```javascript
var server = tizen.iotcon.getServer();
server.startPresence(60);

/* Do something. */

server.stopPresence();
```

`**stopPresence **`Stops sending presence announcement of a server.

```javascript
void stopPresence();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: Example of using can be find at startPresence code example.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if the operation has been stopped.

### 2.5. RemoteResource

This interface provides API to manage remote resource for client side.

**Deprecated. **Deprecated Since 10.0.

```webidl
  interface RemoteResource {
    readonly attribute DOMString uriPath;
    readonly attribute ConnectivityType connectivityType;
    readonly attribute DOMString hostAddress;
    readonly attribute ResourceType[] resourceTypes;
    readonly attribute ResourceInterface[] resourceInterfaces;
    readonly attribute boolean isObservable;
    readonly attribute boolean isDiscoverable;
    readonly attribute boolean isActive;
    readonly attribute boolean isSlow;
    readonly attribute boolean isSecure;
    readonly attribute boolean isExplicitDiscoverable;
    readonly attribute DOMString deviceId;
    readonly attribute DOMString deviceName;
    attribute IotconOption[]? options;
    readonly attribute Representation? cachedRepresentation;
    attribute long timeInterval;
    void methodGet(RemoteResourceResponseCallback responseCallback, optional Query? query, optional ErrorCallback? errorCallback)
                   raises(WebAPIException);
    void methodPut(Representation representation, RemoteResourceResponseCallback responseCallback, optional Query? query,
                   optional ErrorCallback? errorCallback) raises(WebAPIException);
    void methodPost(Representation representation, RemoteResourceResponseCallback responseCallback, optional Query? query,
                    optional ErrorCallback? errorCallback) raises(WebAPIException);
    void methodDelete(RemoteResourceResponseCallback responseCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void startObserving(ObservePolicy observePolicy, RemoteResourceResponseCallback successCallback, optional Query? query)
                        raises(WebAPIException);
    void stopObserving() raises(WebAPIException);
    void startCaching(optional CacheUpdatedCallback? updatedCallback) raises(WebAPIException);
    void stopCaching() raises(WebAPIException);
    void setResourceStateChangeListener(ResourceStateChangeCallback successCallback) raises(WebAPIException);
    void unsetResourceStateChangeListener() raises(WebAPIException);
  };
```

Since: 3.0

#### Attributes

- readonly DOMString uriPath The resource URI.

Since: 3.0

- readonly ConnectivityType connectivityType It is connectivity type.

Since: 3.0

- readonly DOMString hostAddress The host address

Since: 3.0

- readonly ResourceType[] resourceTypes A list of types in this resource

Since: 3.0

- readonly ResourceInterface[] resourceInterfaces A list of interfaces in the resource.

Since: 3.0

- readonly boolean isObservable Indicates if the resource is observable or not

Since: 3.0

- readonly boolean isDiscoverable Indicates if the resource is discoverable or not

Since: 3.0

- readonly boolean isActive Indicates if the resource is initialized and activated or not

Since: 3.0

- readonly boolean isSlow Indicates if the resource takes some delay to respond or not

Since: 3.0

- readonly boolean isSecure Indicates if the resource is secure or not

Since: 3.0

- readonly boolean isExplicitDiscoverable Indicates if the resource is allowed to be discovered only if discovery request contains an explicit query string or not

Since: 3.0

- readonly DOMString deviceId The device unique id. this is unique per-server independent on how it was discovered.

Since: 3.0

- readonly DOMString deviceName The device name of the remote resource.

Since: 3.0

- IotconOption[] options [nullable] The option for managing vendor specific option of COAP packet.

Since: 3.0

Remark: Options can have up to 2 IotconOption.

- readonly Representation cachedRepresentation [nullable] The cached representation of remote resource.

Since: 3.0

- long timeInterval The time interval in seconds for monitoring state (registered with setResourceStateChangeListener() ) and caching (registered with startCaching() ). Provided value must be in range from 1 to 3600 inclusive. The default value is 10 seconds.

Since: 3.0

#### Methods

`**methodGet **`Gets the attributes of a resource.

```javascript
void methodGet(RemoteResourceResponseCallback responseCallback, optional Query? query, optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: In any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **responseCallback :
 The method to invoked when a client receive get response. **
- **query [optional] [nullable] :
 The query to send to server. The resource request handler should handle this value. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of getting response. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var query = {};

function onerror(err)
{
  console.log("Error occurred: " + err.message);
}

function onresponse(remoteResponse)
{
  if (remoteResponse.result != "SUCCESS")
  {
    console.log("The result is not SUCCESS");
    return;
  }
  var repr = remoteResponse.representation;
  console.log("Resource attributes: ");
  for (var key in repr.attributes)
  {
    console.log("key: " + key + ", value: " + repr.attributes[key]);
  }
}

function foundSuccess(resource)
{
  if (resource)
  {
    query["filter"] = {openstate: "open"};
    resource.methodGet(onresponse, query, onerror);
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Resource attributes:
key: openstate, value: open
```

`**methodPut **`Puts the representation of a resource for update.

```javascript
void methodPut(Representation representation, RemoteResourceResponseCallback responseCallback, optional Query? query,
               optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: In any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **representation :
 The payload of a request or a response. **
- **responseCallback :
 The method to invoked when a client receive get response. **
- **query [optional] [nullable] :
 The query to send to server. The resource request handler should handle this value. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of getting response. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var query = {};
var representation;
var uriPath = "/door";

function onerror(err)
{
  console.log("Error occurred: " + err.message);
}

function onresponse(remoteResponse)
{
  console.log("Result is " + remoteResponse.result);
  var repr = remoteResponse.representation;
  console.log("representation attributes: ");
  for (var key in repr.attributes)
  {
    console.log("key: " + key + ", value: " + repr.attributes[key]);
  }
}

function foundSuccess(resource)
{
  if (resource)
  {
    query["filter"] = {openstate: "open"};
    representation = new tizen.Representation(uriPath);
    representation.resourceTypes = ["core.door"];
    representation.attributes = {openstate: "closed"};
    resource.methodPut(representation, onresponse, query, onerror);
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Result is RESOURCE_CHANGED
representation attributes:
key: openstate, value: closed
```

`**methodPost **`Posts the representation of a resource for create.

```javascript
void methodPost(Representation representation, RemoteResourceResponseCallback responseCallback, optional Query? query,
                optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: In any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **representation :
 The payload of a request or a response. **
- **responseCallback :
 The method to invoked when a client receive get response. **
- **query [optional] [nullable] :
 The query to send to server. The resource request handler should handle this value. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of getting response. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var representation;
var uriPath = "/door";

function onerror(err)
{
  console.log("Error occurred: " + err.message);
}

function onresponse(remoteResponse)
{
  console.log("Result is " + remoteResponse.result);
  var repr = remoteResponse.representation;
  console.log("representation attributes: ");
  for (var key in repr.attributes)
  {
    console.log("key: " + key + ", value: " + repr.attributes[key]);
  }
}

function foundSuccess(resource)
{
  if (resource)
  {
    representation = new tizen.Representation(uriPath);
    representation.resourceTypes = ["core.door"];
    representation.attributes = {openstate: "closed"};
    resource.methodPost(representation, onresponse, null, onerror);
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Result is RESOURCE_CHANGED
representation attributes:
key: openstate, value: closed
```

`**methodDelete **`Deletes the remote resource.

```javascript
void methodDelete(RemoteResourceResponseCallback responseCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

The ErrorCallback is launched with these error types:

- TimeoutError: If there is no resource or response within timeout value.
- AbortError: In any system error is invoked

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **responseCallback :
 The method to invoked when a client receive get response. **
- **errorCallback [optional] [nullable] :
 The method to invoke on failure of getting response. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
function onerror(err)
{
  console.log("Error occurred: " + err.message);
}

function onresponse(remoteResponse)
{
  if (remoteResponse.result == "RESOURCE_DELETED" || remoteResponse.result == "SUCCESS")
  {
    console.log("Successfully deleted");
  }
}

function foundSuccess(resource)
{
  if (resource)
  {
    resource.methodDelete(onresponse, onerror);
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Successfully deleted
```

`**startObserving **`Sets the listener to receive notification about attribute change of remote resource. When server sends notification message, successCallback will be called.

```javascript
void startObserving(ObservePolicy observePolicy, RemoteResourceResponseCallback successCallback, optional Query? query);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **observePolicy :
 The policy of observation. **
- **successCallback :
 The method to invoked when the resource receive notification message. **
- **query [optional] [nullable] :
 The query to send to server. The resource request handler should handle this value. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var doorResource;

function onchanged(remoteResponse)
{
  if (remoteResponse.result == "SUCCESS")
  {
    var attributes = remoteResponse.representation.attributes;
    console.log("Start observing, door is " + attributes["openstate"]);
  }
  doorResource.stopObserving();
}

function foundSuccess(resource)
{
  if (resource)
  {
    if (resource.uriPath == "/door")
    {
      doorResource = resource;
      try
      {
        doorResource.startObserving("IGNORE_OUT_OF_ORDER", onchanged);
      }
      catch (err)
      {
        console.log(err.name + ": " + err.message);
      }
    }
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Start observing, door is open
```

`**stopObserving **`Unregisters the listener. so stop receiving notification about attribute change of remote resource.

```javascript
void stopObserving();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: Example of using can be find at startObserving code example.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

`**startCaching **`Starts caching of a remote resource. cached representation is updated when remote resource is changed.

```javascript
void startCaching(optional CacheUpdatedCallback? updatedCallback);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **updatedCallback [optional] [nullable] :
 The method to invoked when the remote resource is changed. **

Exceptions:

- WebAPIException
- with error type InvalidStateError, this error occur when already started.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var resource;

function onerror(err)
{
  console.log("Error occurred: " + err.message);
}

function onupdated(representation)
{
  console.log("######## updated representation ########");
  for (var key in representation.attributes)
  {
    console.log("key: " + key + ", value: " + representation.attributes[key]);
  }
  resource.stopCaching();
}

function foundSuccess(remoteResource)
{
  if (remoteResource)
  {
    resource = remoteResource;
    remoteResource.startCaching(onupdated);  /* Start caching. */
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
######## updated representation ########
key: openstate, value: open
```

`**stopCaching **`Stops caching of a remote resource.

```javascript
void stopCaching();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: Example of using can be find at startCaching code example.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped

`**setResourceStateChangeListener **`Sets a listener to monitor the state of the remote resource.

```javascript
void setResourceStateChangeListener(ResourceStateChangeCallback successCallback);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **successCallback :
 The method to invoked when remote resource's state is changed, registered callbacks will be called in turn. Internally, it checks the state of resource, periodically. Thus, it may not receive the state, immediately. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var doorResource;

function onchanged(isAlive)
{
  if (isAlive == true)
  {
    console.log("Remote resource is alive");
  }
  else
  {
    console.log("Remote resource is lost");
  }
  doorResource.unsetResourceStateChangeListener();
}

function foundSuccess(resource)
{
  if (resource)
  {
    if (resource.uriPath == "/door")
    {
      try
      {
        resource.setResourceStateChangeListener(onchanged);
      }
      catch (err)
      {
        console.log(err.name + ": " + err.message);
      }
    }
  }
}

try
{
  var client = tizen.iotcon.getClient();
  var hostAddress = null;
  var query = {resourceType: "core.door"};
  var connectivityType = "IP";
  client.findResource(hostAddress, query, connectivityType, foundSuccess, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
Remote resource is alive
```

`**unsetResourceStateChangeListener **`Unsets the listener to stop monitoring the state of the remote resource.

```javascript
void unsetResourceStateChangeListener();
```

Since: 3.0

Calling this function has no effect if listener is not set.

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Remark: Example of using can be find at setResourceStateChangeListener code example.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

### 2.6. ResourcePolicy

The ResourcePolicy dictionary specifies resource attributes upon resource creation.

**Deprecated. **Deprecated Since 10.0.

```webidl
  dictionary ResourcePolicy {
    boolean isObservable;
    boolean isDiscoverable;
    boolean isActive;
    boolean isSlow;
    boolean isSecure;
    boolean isExplicitDiscoverable;
  };
```

Since: 3.0

This dictionary is used to input parameters when resources are created.

#### Dictionary members

boolean isObservable Indicates resource that is allowed to be observed.

The default value is false

Since: 3.0

boolean isDiscoverable Indicates resource that is allowed to be discovered.

The default value is true

Since: 3.0

boolean isActive Indicates resource initialized and activated.

The default value is false

Since: 3.0

boolean isSlow Indicates resource which takes some delay to respond.

The default value is false

Since: 3.0

boolean isSecure Indicates secure resource.

The default value is false

Since: 3.0

boolean isExplicitDiscoverable When this value is set true , the resource is allowed to be discovered only if discovery request contains an explicit query string.

The default value is false

Since: 3.0

### 2.7. Resource

This interface provides API to manage resource for server side.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface Resource {
    readonly attribute DOMString uriPath;
    readonly attribute ResourceType[] resourceTypes;
    readonly attribute ResourceInterface[] resourceInterfaces;
    readonly attribute boolean isObservable;
    readonly attribute boolean isDiscoverable;
    readonly attribute boolean isActive;
    readonly attribute boolean isSlow;
    readonly attribute boolean isSecure;
    readonly attribute boolean isExplicitDiscoverable;
    readonly attribute Resource[] resources;
    readonly attribute long[] observerIds;
    attribute object? attributes;
    void notify(QosLevel qosLevel, optional long[]? observerIds) raises(WebAPIException);
    void addResourceTypes(ResourceType[] types) raises(WebAPIException);
    void addResourceInterface(ResourceInterface interface) raises(WebAPIException);
    void addChildResource(Resource resource) raises(WebAPIException);
    void removeChildResource(Resource resource) raises(WebAPIException);
    void setRequestListener(RequestCallback listener) raises(WebAPIException);
    void unsetRequestListener();
  };
```

Since: 3.0

#### Attributes

- readonly DOMString uriPath The resource URI.

Since: 3.0

- readonly ResourceType[] resourceTypes A list of types in this resource.

Since: 3.0

- readonly ResourceInterface[] resourceInterfaces A list of interfaces in the resource.

Since: 3.0

- readonly boolean isObservable Indicates if the resource is observable or not

Since: 3.0

- readonly boolean isDiscoverable Indicates if the resource is discoverable or not

Since: 3.0

- readonly boolean isActive Indicates if the resource is initialized and activated or not

Since: 3.0

- readonly boolean isSlow Indicates if the resource takes some delay to respond or not

Since: 3.0

- readonly boolean isSecure Indicates if the resource is secure or not

Since: 3.0

- readonly boolean isExplicitDiscoverable Indicates if the resource is allowed to be discovered only if discovery request contains an explicit query string or not

Since: 3.0

- readonly Resource[] resources A list of children of this resource.

Since: 3.0

- readonly long[] observerIds A list of observation IDs of this resource.

Since: 3.0

- object attributes [nullable] A lists of attributes of this resource.

Since: 3.0

#### Methods

`**notify **`Notifies specific clients that resource's attributes have been changed.

```javascript
void notify(QosLevel qosLevel, optional long[]? observerIds);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **qosLevel :
 The quality of service level. **
- **observerIds [optional] [nullable] :
 A list of observer id. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any input parameter does not contain a valid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
resource.attributes =
{
  openstate: "open"
};
resource.notify("LOW", resource.observerIds);
```

`**addResourceTypes **`Adds resource type to this resource.

```javascript
void addResourceTypes(ResourceType[] types);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **types :
 An array of types to be added to resource. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var server = tizen.iotcon.getServer();
var uriPath = "/door";
var resourceTypes = ["core.door"];
var resourceInterfaces = ["oic.if.b"];
var resource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);

var types = ["org.tizen.door"];
resource.addResourceTypes(types);
```

`**addResourceInterface **`Adds resource interface to this resource.

```javascript
void addResourceInterface(ResourceInterface interface);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **interface :
 The interface to be added to resource. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var resource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);

var interface = "oic.if.ll";
resource.addResourceInterface(interface);
```

`**addChildResource **`Adds child resource into the parent resource.

```javascript
void addChildResource(Resource resource);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **resource :
 The child resource to be added to the parent resource. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var doorResource;
var lockResource;

var uriPath = "/door";
var resourceTypes = ["core.door"];
var resourceInterfaces: ["oic.if.b"];
var doorAttributes = {openstate: "open"};
var requestListener =
{
  onget: function(request)
  {
    console.log("onget");
    var response = new tizen.Response(request);
    try
    {
      var representation = new tizen.Representation(doorResource.uriPath);
      representation.resourceTypes = doorResource.resourceTypes;
      representation.resourceInterfaces = doorResource.resourceInterfaces;
      representation.attributes = doorResource.attributes;
      response.representation = representation;
      response.result = "SUCCESS";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onput: function(request)
  {
    console.log("onput");
    /* Add request handler code. */
  },
  onpost: function(request)
  {
    console.log("onpost");
    /* Add request handler code. */
  },
  ondelete: function(request)
  {
    console.log("ondelete");
    /* Add request handler code. */
  },
  onobserving: function(request, observeType, observeId)
  {
    console.log("onobserving");
    /* Add request handler code. */
  }
};

doorResource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);
doorResource.attributes = doorAttributes;

uriPath = "/door/lock";
resourceTypes = ["core.lock"];
resourceInterfaces: ["oic.if.baseline"];
var lockAttributes = {lockstate: "closed"};
policy =
{
  isObservable: true,
  isDiscoverable: true
};
var lockRequestListener =
{
  onget: function(request)
  {
    console.log("onget");
    var response = new tizen.Response(request);
    try
    {
      var representation = new tizen.Representation(lockResource.uriPath);
      representation.resourceTypes = lockResource.resourceTypes;
      representation.resourceInterfaces = lockResource.resourceInterfaces;
      representation.attributes = lockResource.attributes;
      response.representation = representation;
      response.result = "SUCCESS";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onput: function(request)
  {
    console.log("onput");
    /* Add request handler code. */
  },
  onpost: function(request)
  {
    console.log("onpost");
    /* Add request handler code. */
  },
  ondelete: function(request)
  {
    console.log("ondelete");
    /* Add request handler code. */
  },
  onobserving: function(request, observeType, observeId)
  {
    console.log("onobserving");
    /* Add request handler code. */
  }
};

lockResource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, lockRequestListener, policy);
lockResource.attributes = lockAttributes;

doorResource.addChildResource(lockResource);
```

`**removeChildResource **`Removes child resource from the parent resource.

```javascript
void removeChildResource(Resource resource);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Parameters:

- **resource :
 The child resource to be removed from the parent resource. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if the resource does not have the input child resource.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
var lockResource =
    server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);
doorResource.addChildResource(lockResource);
doorResource.removeChildResource(lockResource);
```

`**setRequestListener **`Sets the listener for request from client.

```javascript
void setRequestListener(RequestCallback listener);
```

Since: 3.0

Parameters:

- **listener :
 Request listener to set. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var server;
var doorResource;

var requestListener =
{
  onget: function(request)
  {
    console.log("onget");
    var response = new tizen.Response(request);
    try
    {
      var representation = new tizen.Representation(doorResource.uriPath);
      representation.resourceTypes = doorResource.resourceTypes;
      representation.resourceInterfaces = doorResource.resourceInterfaces;
      representation.attributes = doorResource.attributes;
      response.representation = representation;
      response.result = "SUCCESS";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onput: function(request)
  {
    console.log("onput");
    /* Add request handler code. */
  },
  onpost: function(request)
  {
    console.log("onpost");
    /* Add request handler code. */
  },
  ondelete: function(request)
  {
    console.log("ondelete");
    /* Add request handler code. */
  },
  onobserving: function(request, observeType, observeId)
  {
    console.log("onobserving");
    /* Add request handler code. */
  }
};

var newRequestListener =
{
  onget: function(request)
  {
    console.log("onget");
    var response = new tizen.Response(request);
    try
    {
      var representation = new tizen.Representation(doorResource.uriPath);
      representation.resourceTypes = doorResource.resourceTypes;
      representation.resourceInterfaces = doorResource.resourceInterfaces;
      representation.attributes = doorResource.attributes;
      response.representation = representation;
      response.result = "SUCCESS";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onput: function(request)
  {
    console.log("onput");
    var response = new tizen.Response(request);
    try
    {
      doorResource.attributes = request.representation.attributes;
      response.representation = request.representation;
      response.result = "RESOURCE_CHANGED";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onpost: function(request)
  {
    console.log("onpost");
    /* Add request handler code. */
  },
  ondelete: function(request)
  {
    console.log("ondelete");
    try
    {
      var representation = new tizen.Representation(doorResource.uriPath);
      representation.resourceTypes = doorResource.resourceTypes;
      representation.resourceInterfaces = doorResource.resourceInterfaces;
      representation.attributes = doorResource.attributes;
      response.representation = representation;
      response.result = "RESOURCE_DELETED";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
    server.removeResource(doorResource);
  },
  onobserving: function(request, observeType, observeId)
  {
    console.log("onobserving observeType:" + observeType + ", observeId:" + observeId);
  }
};

try
{
  server = tizen.iotcon.getServer();
  var uriPath = "/door";
  var resourceTypes = ["core.door"];
  var resourceInterfaces = ["oic.if.b"];
  var attributes = {openstate: "open"};
  var policy = {isObservable: true, isDiscoverable: true};

  doorResource =
      server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);
  doorResource.attributes = attributes;
  doorResource.setRequestListener(newRequestListener);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**unsetRequestListener **`Remove the listener.

```javascript
void unsetRequestListener();
```

Since: 3.0

Calling this function has no effect if listener was not set.

Remark: Example of using can be find at setRequestListener code example.

### 2.8. Representation

The Representation Interface contains information of a resource. It can be used to communicate between a client and a server.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Constructor(DOMString uriPath)]
  interface Representation {
    attribute DOMString uriPath;
    attribute ResourceType[] resourceTypes;
    attribute ResourceInterface[] resourceInterfaces;
    attribute object? attributes;
    attribute Representation[]? children;
  };
```

Since: 3.0

Code example:

```javascript
var uriPath = "/door";

/* Construct a Representation object with uriPath. */
var representation = new tizen.Representation(uriPath);
```

#### Constructors

`**Constructor (DOMString) **`
```webidl
Representation(DOMString uriPath);
```

#### Attributes

- DOMString uriPath The resource URI.

Since: 3.0

- ResourceType[] resourceTypes A list of types in this resource

Since: 3.0

- ResourceInterface[] resourceInterfaces A list of interfaces in the resource.

Since: 3.0

- object attributes [nullable] A lists of attribute in this resource.

Since: 3.0

- Representation[] children [nullable] Representations belonging to this representation.

Since: 3.0

### 2.9. PresenceResponse

This interface provides API to manage remote resource for client side.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface PresenceResponse {
    readonly attribute DOMString hostAddress;
    readonly attribute ConnectivityType connectivityType;
    readonly attribute ResourceType? resourceType;
    readonly attribute PresenceResponseResultType resultType;
    readonly attribute PresenceTriggerType? triggerType;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString hostAddress The host address of the presence.

Since: 3.0

- readonly ConnectivityType connectivityType The connectivity type of the presence.

Since: 3.0

- readonly ResourceType resourceType [nullable] The resource type of the presence.

Since: 3.0

- readonly PresenceResponseResultType resultType The results type of presence.

Since: 3.0

- readonly PresenceTriggerType triggerType [nullable] The trigger type of presence. It is set only if a response result type is "OK".

Since: 3.0

### 2.10. Query

The Query dictionary provides a query.

**Deprecated. **Deprecated Since 10.0.

```webidl
  dictionary Query {
    ResourceType? resourceType;
    ResourceInterface? resourceInterface;
    object? filter;
  };
```

Since: 3.0

Code example:

```javascript
var filter = {"openstate": "open"};
var query = {resourceType: "core.door", resourceInterface: "oic.if.b"};
query["filter"] = filter;
```

#### Dictionary members

ResourceType ? resourceType The resource type specified as a filter for the resource.

Since: 3.0

ResourceInterface ? resourceInterface The resource interface specified as a filter for the resource.

Since: 3.0

object? filter The query filter consists of key and string data.

Since: 3.0

### 2.11. IotconOption

The IotconOption Interface provides vendor specific options of COAP packet.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Constructor(unsigned long id, DOMString data)]
  interface IotconOption {
    attribute unsigned long id;
    attribute DOMString data;
  };
```

Since: 3.0

Code example:

```javascript
var option = new tizen.IotconOption(3000, "12345");
```

#### Constructors

`**Constructor (unsigned long, DOMString) **`
```webidl
IotconOption(unsigned long id, DOMString data);
```

#### Attributes

- unsigned long id The ID of the option. id is always situated between 2048 and 3000.

Since: 3.0

- DOMString data The string data to add. Length of data is less than or equal to 15.

Since: 3.0

### 2.12. Request

The Request interface represents a details from client.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface Request {
    readonly attribute DOMString hostAddress;
    readonly attribute ConnectivityType connectivityType;
    readonly attribute Representation? representation;
    readonly attribute IotconOption[] options;
    readonly attribute Query query;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString hostAddress The address of host of the request.

Since: 3.0

- readonly ConnectivityType connectivityType Connectivity type of connection.

Since: 3.0

- readonly Representation representation [nullable] The request representation.

Since: 3.0

- readonly IotconOption[] options The option which was sent from client.

Since: 3.0

Remark: Options can have up to 2 IotconOption.

- readonly Query query The query parameters from the request.

Since: 3.0

### 2.13. Response

The Response Interface holds response from server for specified request of client. It is server-side object, Response on client-side is hold as RemoteResponse object.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Constructor(Request request)]
  interface Response {
    readonly attribute Request request;
    attribute ResponseResult result;
    attribute Representation representation;
    attribute IotconOption[]? options;
    void send() raises(WebAPIException);
  };
```

Since: 3.0

Code example:

```javascript
var server;
var doorResource;

var requestListener =
{
  onget: function(request)
  {
    console.log("onget");
    var response = new tizen.Response(request);
    try
    {
      var representation = new tizen.Representation(doorResource.uriPath);
      representation.resourceTypes = doorResource.resourceTypes;
      representation.resourceInterfaces = doorResource.resourceInterfaces;
      representation.attributes = doorResource.attributes;
      response.representation = representation;
      response.result = "SUCCESS";
    }
    catch (err)
    {
      console.log(err.name + ": " + err.message);
      response.result = "ERROR";
    }
    response.send();
  },
  onput: function(request)
  {
    console.log("onput");
    /* Add request handler code. */
  },
  onpost: function(request)
  {
    console.log("onpost");
    /* Add request handler code. */
  },
  ondelete: function(request)
  {
    console.log("ondelete");
    /* Add request handler code. */
  },
  onobserving: function(request, observeType, observeId)
  {
    console.log("onobserving");
    /* Add request handler code. */
  }
};

try
{
  server = tizen.iotcon.getServer();
  var uriPath = "/door";
  var resourceTypes = ["core.door"];
  var resourceInterfaces = ["oic.if.b"];
  var policy = {isObservable: true, isDiscoverable: true};

  doorResource =
      server.createResource(uriPath, resourceTypes, resourceInterfaces, requestListener, policy);
  doorResource.attributes = {openstate: "open"};
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

#### Constructors

`**Constructor ( Request ) **`
```webidl
Response(Request request);
```

#### Attributes

- readonly Request request The request, that server responded.

Since: 3.0

Code example:

```javascript
var response = new tizen.Response(request);
```

- ResponseResult result The result indicates the detailed information about the result of the response to request.

Since: 3.0

Code example:

```javascript
var result = "SUCCESS";
var response = new tizen.Response(request);
response.result = result;
```

- Representation representation The representation indicates the information of the resource.

Since: 3.0

Code example:

```javascript
var uriPath = "/door";
var representation = new tizen.Representation(uriPath);
representation.resourceTypes = ["core.door"];
representation.resourceInterfaces = ["oic.if.b"];
representation.attributes =
{
  openstate: "open"
};

var response = new tizen.Response(request);
response.representation = representation;
```

- IotconOption[] options [nullable] The options indicates the vendor specific options of COAP packet.

Since: 3.0

Remark: Options can have up to 2 IotconOption.

#### Methods

`**send **`Sends the response.

```javascript
void send();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/internet

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, If the operation has been stopped.

Code example:

```javascript
try
{
  var uriPath = "/door";
  var representation = new tizen.Representation(uriPath);
  representation.resourceTypes = ["core.door"];
  representation.resourceInterfaces = ["oic.if.b"];
  representation.attributes = {"openstate": "open"};

  var response = new tizen.Response(request);
  response.representation = representation;
  response.result = "SUCCESS";
}
catch (err)
{
  console.log(err.name + ": " + err.message);
  response.result = "ERROR";
}
response.send();
```

### 2.14. RemoteResponse

The RemoteResponse Interface holds response from server for specified request of client, this is client-side version of Response object.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface RemoteResponse {
    readonly attribute ResponseResult result;
    readonly attribute Representation representation;
    readonly attribute IotconOption[]? options;
  };
```

Since: 3.0

#### Attributes

- readonly ResponseResult result The result indicates the detailed information about the result of the response to request.

Since: 3.0

- readonly Representation representation The representation indicates the information of the resource.

Since: 3.0

- readonly IotconOption[] options [nullable] The options indicates the vendor specific options of COAP packet.

Since: 3.0

### 2.15. DeviceInfo

The DeviceInfo interface describes device properties.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface DeviceInfo {
    readonly attribute DOMString? deviceName;
    readonly attribute DOMString? specVersion;
    readonly attribute DOMString? oicDeviceId;
    readonly attribute DOMString? dataModelVersion;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString deviceName [nullable] The device name

Since: 3.0

- readonly DOMString specVersion [nullable] The version of core specification.

Since: 3.0

- readonly DOMString oicDeviceId [nullable] The unique identifier for OIC device.

Since: 3.0

- readonly DOMString dataModelVersion [nullable] The version of specification which the device's data model is implemented

Since: 3.0

### 2.16. PlatformInfo

The PlatformInfo interface describes platform properties.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [NoInterfaceObject] interface PlatformInfo {
    readonly attribute DOMString? platformId;
    readonly attribute DOMString? manufacturerName;
    readonly attribute DOMString? manufacturerUrl;
    readonly attribute DOMString? modelNumber;
    readonly attribute DOMString? manufactureDate;
    readonly attribute DOMString? platformVersion;
    readonly attribute DOMString? operatingSystemVersion;
    readonly attribute DOMString? hardwareVersion;
    readonly attribute DOMString? firmwareVersion;
    readonly attribute DOMString? supportUrl;
    readonly attribute DOMString? systemTime;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString platformId [nullable] The platform identifier

Since: 3.0

- readonly DOMString manufacturerName [nullable] The name of manufacturer.

Since: 3.0

- readonly DOMString manufacturerUrl [nullable] The URL of manufacturer.

Since: 3.0

- readonly DOMString modelNumber [nullable] The model number is designated by manufacturer.

Since: 3.0

- readonly DOMString manufactureDate [nullable] The manufacture date of device.

Since: 3.0

- readonly DOMString platformVersion [nullable] The platform version is defined by manufacturer.

Since: 3.0

- readonly DOMString operatingSystemVersion [nullable] The operating system version.

Since: 3.0

- readonly DOMString hardwareVersion [nullable] The hardware version.

Since: 3.0

- readonly DOMString firmwareVersion [nullable] The firmware version.

Since: 3.0

- readonly DOMString supportUrl [nullable] The URL that points to support information from manufacturer.

Since: 3.0

- readonly DOMString systemTime [nullable] The System time.

Since: 3.0

### 2.17. RequestCallback

The RequestCallback interface that defines the success method to be invoked when a client request is received.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface RequestCallback {
    void onget(Request request);
    void onput(Request request);
    void onpost(Request request);
    void ondelete(Request request);
    void onobserving(Request request, ObserveType observeType, unsigned long observeId);
  };
```

Since: 3.0

Remark: Example of using can be find at setRequestListener code example.

#### Methods

`**onget **`Called when GET request was received.

```javascript
void onget(Request request);
```

Since: 3.0

Parameters:

- **request :
 That is request from server side. **

`**onput **`Called when PUT request was received.

```javascript
void onput(Request request);
```

Since: 3.0

Parameters:

- **request :
 That is request from server side. **

`**onpost **`Called when POST request was received.

```javascript
void onpost(Request request);
```

Since: 3.0

Parameters:

- **request :
 That is request from server side. **

`**ondelete **`Called when DELETE request was received.

```javascript
void ondelete(Request request);
```

Since: 3.0

Parameters:

- **request :
 That is request from server side. **

`**onobserving **`Called when OBSERVE request was received.

```javascript
void onobserving(Request request, ObserveType observeType, unsigned long observeId);
```

Since: 3.0

Parameters:

- **request :
 That is request from server side. **
- **observeType :
 The observation type of the request. **
- **observeId :
 The observation id of the request. **

### 2.18. FoundResourceSuccessCallback

The FoundResourceSuccessCallback interface that defines the success method
for *Client.findResource() *.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface FoundResourceSuccessCallback {
    void onfound(RemoteResource remoteResource);
  };
```

Since: 3.0

Remark: Example of using can be find at findResource code example.

#### Methods

`**onfound **`Called when request was received.

```javascript
void onfound(RemoteResource remoteResource);
```

Since: 3.0

Parameters:

- **remoteResource :
 Remote resource for client side. **

### 2.19. PresenceEventCallback

The PresenceEventCallback interface defines the success method to be invoked when client receive presence events from the server.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface PresenceEventCallback {
    void onreceived(PresenceResponse presenceResponse);
  };
```

Since: 3.0

Remark: Example of using can be find at addPresenceEventListener code example.

#### Methods

`**onreceived **`Called when client receive presence events.

```javascript
void onreceived(PresenceResponse presenceResponse);
```

Since: 3.0

Parameters:

- **presenceResponse :
 Presence events. **

### 2.20. FoundDeviceInfoSuccessCallback

The FoundDeviceInfoSuccessCallback interface defines the success method to be invoked when getting the device information is successful.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface FoundDeviceInfoSuccessCallback {
    void onsuccess(DeviceInfo info);
  };
```

Since: 3.0

Remark: Example of using can be find at findDeviceInfo code example.

#### Methods

`**onsuccess **`Called when the device information is received.

```javascript
void onsuccess(DeviceInfo info);
```

Since: 3.0

Parameters:

- **info :
 Device information. **

### 2.21. FoundPlatformInfoSuccessCallback

The FoundPlatformInfoSuccessCallback interface defines the success method to be invoked when getting the platform information is successful.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface FoundPlatformInfoSuccessCallback {
    void onsuccess(PlatformInfo info);
  };
```

Since: 3.0

Remark: Example of using can be find at findPlatformInfo code example.

#### Methods

`**onsuccess **`Called when the platform information is received.

```javascript
void onsuccess(PlatformInfo info);
```

Since: 3.0

Parameters:

- **info :
 Platform information. **

### 2.22. RemoteResourceResponseCallback

The RemoteResourceResponseCallback interface defines the success method to be invoked when a client received response.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface RemoteResourceResponseCallback {
    void onsuccess(RemoteResponse response);
  };
```

Since: 3.0

Remark: Example of using can be find at methodGet code example.

#### Methods

`**onsuccess **`Called when the response is received.

```javascript
void onsuccess(RemoteResponse response);
```

Since: 3.0

Parameters:

- **response :
 Received for client site. **

### 2.23. ResourceStateChangeCallback

The ResourceStateChangeCallback interface defines the success method to be invoked when remote resource's state is changed.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ResourceStateChangeCallback {
    void onchanged(boolean isAlive);
  };
```

Since: 3.0

Remark: Example of using can be find at setResourceStateChangeListener code example.

#### Methods

`**onchanged **`Called when connection change appeared.

```javascript
void onchanged(boolean isAlive);
```

Since: 3.0

Parameters:

- **isAlive :
 State of the remote resource. **

### 2.24. CacheUpdatedCallback

The CacheUpdatedCallback interface defines the success method to be invoked when remote resource is changed.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface CacheUpdatedCallback {
    void onupdated(Representation representation);
  };
```

Since: 3.0

Remark: Example of using can be find at startCaching code example.

#### Methods

`**onupdated **`Called when caching is successfully started.

```javascript
void onupdated(Representation representation);
```

Since: 3.0

Parameters:

- **representation :
 State of the remote resource. **

### 2.25. GeneratedPinCallback

The GeneratedPinCallback interface defines the success method to be invoked when random pin is generated.

**Deprecated. **Deprecated Since 10.0.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface GeneratedPinCallback {
    void onsuccess(DOMString pin);
  };
```

Since: 3.0

Remark: Example of using can be find at addGeneratedPinListener code example.

#### Methods

`**onsuccess **`Called when random pin is successfully generated.

```javascript
void onsuccess(DOMString pin);
```

Since: 3.0

Parameters:

- **pin :
 Generated random pin. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee this application will run on a device with a Iotcon, add the below feature declaration to the config file

- http://tizen.org/feature/iot.ocf

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module Iotcon {
  Tizen implements IotconObject;
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
