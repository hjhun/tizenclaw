# DataSynchronization API

This API provides methods to synchronize contact and event data to the server using the OMA DS 1.2 protocol.
To know the details of this specification, visit OMA web page . And for more information on the Data Synchronization features, see Data Synchronization Guide .

Since: 2.1

## Table of Contents

- 1. Type Definitions
- 1.1. SyncProfileId
- 1.2. SyncMode
- 1.3. SyncType
- 1.4. SyncInterval
- 1.5. SyncServiceType
- 1.6. SyncStatus
- 2. Interfaces
- 2.1. DataSynchronizationManagerObject
- 2.2. SyncInfo
- 2.3. SyncServiceInfo
- 2.4. SyncProfileInfo
- 2.5. SyncStatistics
- 2.6. DataSynchronizationManager
- 2.7. SyncProgressCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| DataSynchronizationManagerObject |  |
| SyncInfo |  |
| SyncServiceInfo |  |
| SyncProfileInfo |  |
| SyncStatistics |  |
| DataSynchronizationManager | void add ( SyncProfileInfo profile) void update ( SyncProfileInfo profile) void remove ( SyncProfileId profileId) long getMaxProfilesNum () unsigned long getProfilesNum () SyncProfileInfo get ( SyncProfileId profileId) SyncProfileInfo [] getAll () void startSync ( SyncProfileId profileId, optional SyncProgressCallback ? progressCallback) void stopSync ( SyncProfileId profileId) SyncStatistics [] getLastSyncStatistics ( SyncProfileId profileId) |
| SyncProgressCallback | void onprogress ( SyncProfileId profileId, SyncServiceType serviceType, boolean isFromServer, unsigned long totalPerService, unsigned long syncedPerService) void oncompleted ( SyncProfileId profileId) void onstopped ( SyncProfileId profileId) void onfailed ( SyncProfileId profileId, WebAPIError error) |

## 1. Type Definitions

### 1.1. SyncProfileId

An attribute to uniquely identify a sync profile.

```webidl
  typedef DOMString SyncProfileId;
```

Since: 2.1

### 1.2. SyncMode

An enumerator that indicates the supported synchronization modes.

```webidl
  enum SyncMode { "MANUAL", "PERIODIC", "PUSH" };
```

Since: 2.1

The following values are supported:

- MANUAL - Indicates that the synchronization starts by manual trigger. The sync type should be specified. The default value is TWO_WAY .
- PERIODIC - Indicates that the synchronization starts automatically by a preset period. The sync interval should be provided.
- PUSH - Indicates that the synchronization starts automatically when changes are made. The sync type is set to TWO_WAY . The synchronization can be triggered by the server based on the standard SAN(Server Alerted Notification) sync type.

### 1.3. SyncType

An enumerator that indicates the supported synchronization types.

```webidl
  enum SyncType { "TWO_WAY", "SLOW", "ONE_WAY_FROM_CLIENT", "REFRESH_FROM_CLIENT", "ONE_WAY_FROM_SERVER", "REFRESH_FROM_SERVER" };
```

Since: 2.1

The following values are supported:

- TWO_WAY - Indicates a normal sync type in which the client and the server exchange information about modified data in these devices.
- SLOW - Indicates a form of two-way sync in which the client and the server exchange all the data from their database. This type of sync is used for the first sync, or after a synchronization failure.
- ONE_WAY_FROM_CLIENT - Indicates a sync type in which the client sends its modifications to the server but the server does not send its modifications back to the client.
- REFRESH_FROM_CLIENT - Indicates a sync type in which the client sends all its data from a database to the server (backup). The server is then expected to replace all data in the target database with the data received from the client.
- ONE_WAY_FROM_SERVER - Indicates a sync type in which the client gets all modifications from the server but the client does not send its modifications to the server.
- REFRESH_FROM_SERVER - Indicates a sync type in which the server sends all its data from a database to the client (restore). The client is then expected to replace all data in the target database with the data received from the server.

### 1.4. SyncInterval

An enumerator that indicates the supported synchronization intervals.

```webidl
  enum SyncInterval { "5_MINUTES", "15_MINUTES", "1_HOUR", "4_HOURS", "12_HOURS", "1_DAY", "1_WEEK", "1_MONTH" };
```

Since: 2.1

The following values are supported:

- 5_MINUTES - Indicates a time period of 5 minutes.
- 15_MINUTES - Indicates a time period of 15 minutes.
- 1_HOUR - Indicates a time period of 1 hour.
- 4_HOURS - Indicates a time period of 4 hours.
- 12_HOURS - Indicates a time period of 12 hours.
- 1_DAY - Indicates a time period of 1 day.
- 1_WEEK - Indicates a time period of 1 week.
- 1_MONTH - Indicates a time period of 1 month.

### 1.5. SyncServiceType

An enumerator that indicates the supported synchronization service type of the device.

```webidl
  enum SyncServiceType { "CONTACT", "EVENT" };
```

Since: 2.1

The following values are supported:

- CONTACT - Indicates the device contact records.
- EVENT - Indicates the device calendar event records.

### 1.6. SyncStatus

An enumerator that indicates the last sync status.

```webidl
  enum SyncStatus { "SUCCESS", "FAIL", "STOP", "NONE" };
```

Since: 2.1

The following values are supported:

- SUCCESS - Indicates the sync is successful.
- FAIL - Indicates the sync has failed.
- STOP - Indicates the sync has been stopped by the user's action.
- NONE - Indicates the sync had never been performed.

## 2. Interfaces

### 2.1. DataSynchronizationManagerObject

This interface defines the default data synchronization manager that is instantiated by the *Tizen *object.
The *tizen.datasync *object allows access to the functionality of the Data Synchronization API.

```webidl
  [NoInterfaceObject] interface DataSynchronizationManagerObject {
    readonly attribute DataSynchronizationManager datasync;
  };
```

```webidl
  Tizen implements DataSynchronizationManagerObject;
```

Since: 2.1

#### Attributes

- readonly DataSynchronizationManager datasync Object representing a data synchronization manager.

Since: 2.1

### 2.2. SyncInfo

The SyncInfo interface defines the sync information.

```webidl
  [Constructor(DOMString url, DOMString id, DOMString password, SyncMode mode),
   Constructor(DOMString url, DOMString id, DOMString password, SyncMode mode, SyncType type),
   Constructor(DOMString url, DOMString id, DOMString password, SyncMode mode, SyncInterval interval)]
  interface SyncInfo {
    attribute DOMString url;
    attribute DOMString id;
    attribute DOMString password;
    attribute SyncMode mode;
    attribute SyncType? type;
    attribute SyncInterval? interval;
  };
```

Since: 2.1

Remark: The *MANUAL *sync mode accepts the sync type and the *PERIODIC *mode accepts the sync interval, whereas the *PUSH *mode does not accept any additional parameters.

#### Constructors

`**Constructor (DOMString, DOMString, DOMString, SyncMode ) **`
```webidl
SyncInfo(DOMString url, DOMString id, DOMString password, SyncMode mode);
```

`**Constructor (DOMString, DOMString, DOMString, SyncMode , SyncType ) **`
```webidl
SyncInfo(DOMString url, DOMString id, DOMString password, SyncMode mode, SyncType type);
```

`**Constructor (DOMString, DOMString, DOMString, SyncMode , SyncInterval ) **`
```webidl
SyncInfo(DOMString url, DOMString id, DOMString password, SyncMode mode, SyncInterval interval);
```

#### Attributes

- DOMString url An attribute to store the URL of the sync server.

Since: 2.1

- DOMString id An attribute to store the login ID for the sync server.

When an attempt to retrieve the saved value is made, it returns null to prevent any compromise on the privacy of the login ID.

Since: 2.1

- DOMString password An attribute to store the login password to the sync server.

When an attempt to retrieve the saved value is made, it returns null to prevent any compromise on the privacy of the login password.

Since: 2.1

- SyncMode mode An attribute to store the sync mode.

Since: 2.1

- SyncType type [nullable] An attribute to store the sync type.

This attribute is used when the sync mode is set to the *MANUAL *option.

Since: 2.1

- SyncInterval interval [nullable] An attribute to store the sync interval.

This attribute is used when the sync mode is set to the *PERIODIC *option.

Since: 2.1

### 2.3. SyncServiceInfo

The SyncServiceInfo interface defines the sync service information.

```webidl
  [Constructor(boolean enable, SyncServiceType serviceType, DOMString serverDatabaseUri, optional DOMString? id,
               optional DOMString? password)]
  interface SyncServiceInfo {
    attribute boolean enable;
    attribute SyncServiceType serviceType;
    attribute DOMString serverDatabaseUri;
    attribute DOMString? id;
    attribute DOMString? password;
  };
```

Since: 2.1

#### Constructors

`**Constructor (boolean, SyncServiceType , DOMString, DOMString?, DOMString?) **`
```webidl
SyncServiceInfo(boolean enable, SyncServiceType serviceType, DOMString serverDatabaseUri, optional DOMString? id,
                optional DOMString? password);
```

#### Attributes

- boolean enable An attribute to enable or disable a service category for sync.

Since: 2.1

- SyncServiceType serviceType An attribute to indicate the sync service type.

Since: 2.1

- DOMString serverDatabaseUri An attribute to store the sync service DB URI of the server.

Since: 2.1

- DOMString id [nullable] An attribute to store the sync service DB access ID to the server.

This is used only when the server requires a separate access right to each DB.
When an attempt to retrieve the saved value is made, it returns null to prevent any compromise on the privacy of the ID.

Since: 2.1

- DOMString password [nullable] An attribute to store the sync service DB access password to the server.

This is used only when the server requires a separate access right to each DB.
When an attempt to retrieve the saved value is made, it returns null to prevent any compromise on the privacy of the password.

Since: 2.1

### 2.4. SyncProfileInfo

The SyncProfileInfo interface defines the sync profile information, based on which synchronization is performed.

```webidl
  [Constructor(DOMString profileName, SyncInfo syncInfo, optional SyncServiceInfo[]? serviceInfo)]
  interface SyncProfileInfo {
    readonly attribute SyncProfileId profileId;
    attribute DOMString profileName;
    attribute SyncInfo syncInfo;
    attribute SyncServiceInfo[]? serviceInfo;
  };
```

Since: 2.1

#### Constructors

`**Constructor (DOMString, SyncInfo , SyncServiceInfo []?) **`
```webidl
SyncProfileInfo(DOMString profileName, SyncInfo syncInfo, optional SyncServiceInfo[]? serviceInfo);
```

#### Attributes

- readonly SyncProfileId profileId An attribute to store the unique identifier provided by the platform for a profile that has been successfully added.

Since: 2.1

- DOMString profileName An attribute to store the profile name.

Since: 2.1

- SyncInfo syncInfo An attribute to store sync info.

Since: 2.1

- SyncServiceInfo[] serviceInfo [nullable] An attribute to indicate service info.

Since: 2.1

### 2.5. SyncStatistics

The SyncStatistics interface defines the sync statistics for a profile service.

```webidl
  [NoInterfaceObject] interface SyncStatistics {
    readonly attribute SyncStatus syncStatus;
    readonly attribute SyncServiceType serviceType;
    readonly attribute Date lastSyncTime;
    readonly attribute unsigned long serverToClientTotal;
    readonly attribute unsigned long serverToClientAdded;
    readonly attribute unsigned long serverToClientUpdated;
    readonly attribute unsigned long serverToClientRemoved;
    readonly attribute unsigned long clientToServerTotal;
    readonly attribute unsigned long clientToServerAdded;
    readonly attribute unsigned long clientToServerUpdated;
    readonly attribute unsigned long clientToServerRemoved;
  };
```

Since: 2.1

#### Attributes

- readonly SyncStatus syncStatus An attribute to store the last sync status for a corresponding service category.

Since: 2.1

- readonly SyncServiceType serviceType An attribute to indicate the sync service type.

Since: 2.1

- readonly Date lastSyncTime An attribute to store the last sync time.

Since: 2.1

- readonly unsigned long serverToClientTotal An attribute to indicate the total number of items sent from the server to the client.

Since: 2.1

- readonly unsigned long serverToClientAdded An attribute to indicate the number of added items from the server to the client.

Since: 2.1

- readonly unsigned long serverToClientUpdated An attribute to indicate the number of updated items from the server to the client.

Since: 2.1

- readonly unsigned long serverToClientRemoved An attribute to indicate the number of removed items from the server to the client.

Since: 2.1

- readonly unsigned long clientToServerTotal An attribute to indicate the total number of items from the client to the server.

Since: 2.1

- readonly unsigned long clientToServerAdded An attribute to indicate the number of added items from the client to the server.

Since: 2.1

- readonly unsigned long clientToServerUpdated An attribute to indicate the number of updated items from the client to the server.

Since: 2.1

- readonly unsigned long clientToServerRemoved An attribute to indicate the number of removed items from the client to the server.

Since: 2.1

### 2.6. DataSynchronizationManager

The DataSynchronizationManager interface allows managing profiles and synchronizing data between the server and the client device based on stored profile information.

```webidl
  [NoInterfaceObject] interface DataSynchronizationManager {
    void add(SyncProfileInfo profile) raises(WebAPIException);
    void update(SyncProfileInfo profile) raises(WebAPIException);
    void remove(SyncProfileId profileId) raises(WebAPIException);
    long getMaxProfilesNum() raises(WebAPIException);
    unsigned long getProfilesNum() raises(WebAPIException);
    SyncProfileInfo get(SyncProfileId profileId) raises(WebAPIException);
    SyncProfileInfo[] getAll() raises(WebAPIException);
    void startSync(SyncProfileId profileId, optional SyncProgressCallback? progressCallback) raises(WebAPIException);
    void stopSync(SyncProfileId profileId) raises(WebAPIException);
    SyncStatistics[] getLastSyncStatistics(SyncProfileId profileId) raises(WebAPIException);
  };
```

Since: 2.1

#### Methods

`**add **`Adds a sync profile.

```javascript
void add(SyncProfileInfo profile);
```

Since: 2.1

The profile ID is provided when the profile is successfully added.

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profile :
 The sync profile information to add. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type QuotaExceededError, if the platform has already reached the maximum number of profiles.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Creates a sync info. */
var syncInfo =
    new tizen.SyncInfo("http://example.com/sync", "myId", "myPassword", "MANUAL", "TWO_WAY");

/* Syncs both contacts and events. */
var contactInfo = new tizen.SyncServiceInfo(true, "CONTACT", "serverContact");
var eventInfo = new tizen.SyncServiceInfo(true, "EVENT", "serverEvent");
var serviceInfo = [contactInfo, eventInfo];

/* Adds a profile to sync. */
var profile = new tizen.SyncProfileInfo("MyProfile", syncInfo, serviceInfo);
tizen.datasync.add(profile);
```

`**update **`Updates an existing sync profile.

```javascript
void update(SyncProfileInfo profile);
```

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profile :
 The sync profile information to update. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Retrieves and updates a profile. */
var profile = tizen.datasync.get(profileId);

profile.profileName = "newProfileName";

tizen.datasync.update(profile);
```

`**remove **`Removes an existing sync profile.

```javascript
void remove(SyncProfileId profileId);
```

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profileId :
 The sync profile ID to remove. **

Exceptions:

- WebAPIException
- with error type NotFoundError, if the identifier does not match any saved profile.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Removes a profile. */
tizen.datasync.remove(profileId);
```

`**getMaxProfilesNum **`Gets the maximum number of supported sync profiles on a platform.
Normally the platform sets a limitation on the number of supported profiles. It returns 0 or a negative value if no limitation is set.

```javascript
long getMaxProfilesNum();
```

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Return value:

long: The number of supported profiles on a platform.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Gets the maximum number of supported profiles on the platform. */
var numMaxProfiles = tizen.datasync.getMaxProfilesNum();
```

`**getProfilesNum **`Gets the current number of sync profiles on a device.

```javascript
unsigned long getProfilesNum();
```

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Return value:

unsigned long: The current number of profiles on a device.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Gets the present number of profiles on the device. */
var numProfiles = tizen.datasync.getProfilesNum();
```

`**get **`Gets the *SyncProfileInfo *object from a given profile ID.

```javascript
SyncProfileInfo get(SyncProfileId profileId);
```

Since: 2.1

The attempt to retrieve *SyncProfileInfo *doesn't get any confidential information such as the *password *of *SyncInfo *or *SyncServiceInfo *but instead it returns null .

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profileId :
 The ID used to get profile information. **

Return value:

SyncProfileInfo: The profile information of the given ID.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the identifier does not match any saved profile.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Gets the profile information with the given ID. */
var profile = tizen.datasync.get(profileId);
```

`**getAll **`Gets the information of all sync profiles saved in a device.

```javascript
SyncProfileInfo[] getAll();
```

Since: 2.1

An attempt to retrieve *SyncProfileInfo *doesn't get any confidential information such as the *password *of *SyncInfo *or *SyncServiceInfo *but instead it returns null .

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Return value:

SyncProfileInfo[]: The profile information array.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Gets all the profile information. */
var profiles = tizen.datasync.getAll();
```

`**startSync **`Starts a sync operation with a given profile ID.

```javascript
void startSync(SyncProfileId profileId, optional SyncProgressCallback? progressCallback);
```

Since: 2.1

If the sync mode is set to *MANUAL *, the synchronization does not start automatically until this method is called. This method works even in the *PUSH *or *PERIODIC *mode.

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profileId :
 The profile ID with which to initiate the sync operation. **
- **progressCallback [optional] [nullable] :
 The method to invoke when the sync operation progresses or an error occurs. **

Exceptions:

- WebAPIException
- with error type NotFoundError, if the identifier does not match any saved profile.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Variable profileId obtained from SyncProfileInfo. */
var syncCallback =
{
  onprogress: function(profileId, serviceType, isFromServer, totalPerType, syncedPerType)
  {
    console.log("Total: " + totalPerType + ", synced: " + syncedPerType + " for the sync type: " +
                serviceType);
  },
  onfailed: function(profileId, error)
  {
    console.log("Failed with id: " + profileId + ", error name: " + error.name);
  }
};

/* Starts the sync operation with the corresponding callbacks. */
tizen.datasync.startSync(profileId, syncCallback);
```

`**stopSync **`Stops an ongoing sync operation that is specified by the *profileId *parameter.

```javascript
void stopSync(SyncProfileId profileId);
```

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profileId :
 The ID of the ongoing sync operation to stop. **

Exceptions:

- WebAPIException
- with error type NotFoundError, if the identifier does not match any saved profile.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Variable profileId obtained from SyncProfileInfo. */
/* Stops the ongoing sync operation. */
tizen.datasync.stopSync(profileId);
```

`**getLastSyncStatistics **`Gets the sync statistics of a given profile ID.

```javascript
SyncStatistics[] getLastSyncStatistics(SyncProfileId profileId);
```

Since: 2.1

Privilege level: public

Privilege: http://tizen.org/privilege/datasync

Parameters:

- **profileId :
 The ID used to get the sync statistics. **

Return value:

SyncStatistics[]: The sync statistics information of a given ID.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the identifier does not match any saved profile.

- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
/* Variable profileId obtained from SyncProfileInfo. */
/* Gets the sync statistics information with the given ID. */
var statistics = tizen.datasync.getLastSyncStatistics(profileId);
```

### 2.7. SyncProgressCallback

The SyncProgressCallback defines progress notification callbacks for the ongoing sync operation.

```webidl
  [Callback, NoInterfaceObject] interface SyncProgressCallback {
    void onprogress(SyncProfileId profileId, SyncServiceType serviceType, boolean isFromServer, unsigned long totalPerService,
                    unsigned long syncedPerService);
    void oncompleted(SyncProfileId profileId);
    void onstopped(SyncProfileId profileId);
    void onfailed(SyncProfileId profileId, WebAPIError error);
  };
```

Since: 2.1

#### Methods

`**onprogress **`Called when a synchronization operation is started and progress is made.

```javascript
void onprogress(SyncProfileId profileId, SyncServiceType serviceType, boolean isFromServer, unsigned long totalPerService,
                unsigned long syncedPerService);
```

Since: 2.1

The frequency of this callback invocation is dependent on the platform implementation.
Normally the packet size from a server affects it, that is, if the server sends a bigger packet containing many records in it, the platform processes it at once and invokes this callback less frequently.

Parameters:

- **profileId :
 The ID of the corresponding sync operation. **
- **serviceType :
 The sync service category type. **
- **isFromServer :
 The direction of the operation. 
If the direction of the operation is from the server to the client, then the value is true .
- **totalPerService :
 The total number of records to synchronize for the current sync service type aggregating all operations. **
- **syncedPerService :
 The number of synchronized records for the current sync service type aggregating all operations. **

`**oncompleted **`Called when the sync operation has completed.

```javascript
void oncompleted(SyncProfileId profileId);
```

Since: 2.1

Parameters:

- **profileId :
 The ID of the corresponding sync operation. **

`**onstopped **`Called when the sync operation is stopped by the user.

```javascript
void onstopped(SyncProfileId profileId);
```

Since: 2.1

Parameters:

- **profileId :
 The ID of the corresponding sync operation. **

`**onfailed **`Called when the sync operation fails.

```javascript
void onfailed(SyncProfileId profileId, WebAPIError error);
```

Since: 2.1

Parameters:

- **profileId :
 The ID of the corresponding sync operation. **
- **error :
 The reason for sync failure. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that data synch application runs on a device, declare the following feature requirements in the config file:

- http://tizen.org/feature/datasync

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module DataSynchronization {
  typedef DOMString SyncProfileId;
  enum SyncMode { "MANUAL", "PERIODIC", "PUSH" };
  enum SyncType { "TWO_WAY", "SLOW", "ONE_WAY_FROM_CLIENT", "REFRESH_FROM_CLIENT", "ONE_WAY_FROM_SERVER", "REFRESH_FROM_SERVER" };
  enum SyncInterval { "5_MINUTES", "15_MINUTES", "1_HOUR", "4_HOURS", "12_HOURS", "1_DAY", "1_WEEK", "1_MONTH" };
  enum SyncServiceType { "CONTACT", "EVENT" };
  enum SyncStatus { "SUCCESS", "FAIL", "STOP", "NONE" };
  Tizen implements DataSynchronizationManagerObject;
  [NoInterfaceObject] interface DataSynchronizationManagerObject {
    readonly attribute DataSynchronizationManager datasync;
  };
  [Constructor(DOMString url, DOMString id, DOMString password, SyncMode mode),
   Constructor(DOMString url, DOMString id, DOMString password, SyncMode mode, SyncType type),
   Constructor(DOMString url, DOMString id, DOMString password, SyncMode mode, SyncInterval interval)]
  interface SyncInfo {
    attribute DOMString url;
    attribute DOMString id;
    attribute DOMString password;
    attribute SyncMode mode;
    attribute SyncType? type;
    attribute SyncInterval? interval;
  };
  [Constructor(boolean enable, SyncServiceType serviceType, DOMString serverDatabaseUri, optional DOMString? id,
               optional DOMString? password)]
  interface SyncServiceInfo {
    attribute boolean enable;
    attribute SyncServiceType serviceType;
    attribute DOMString serverDatabaseUri;
    attribute DOMString? id;
    attribute DOMString? password;
  };
  [Constructor(DOMString profileName, SyncInfo syncInfo, optional SyncServiceInfo[]? serviceInfo)]
  interface SyncProfileInfo {
    readonly attribute SyncProfileId profileId;
    attribute DOMString profileName;
    attribute SyncInfo syncInfo;
    attribute SyncServiceInfo[]? serviceInfo;
  };
  [NoInterfaceObject] interface SyncStatistics {
    readonly attribute SyncStatus syncStatus;
    readonly attribute SyncServiceType serviceType;
    readonly attribute Date lastSyncTime;
    readonly attribute unsigned long serverToClientTotal;
    readonly attribute unsigned long serverToClientAdded;
    readonly attribute unsigned long serverToClientUpdated;
    readonly attribute unsigned long serverToClientRemoved;
    readonly attribute unsigned long clientToServerTotal;
    readonly attribute unsigned long clientToServerAdded;
    readonly attribute unsigned long clientToServerUpdated;
    readonly attribute unsigned long clientToServerRemoved;
  };
  [NoInterfaceObject] interface DataSynchronizationManager {
    void add(SyncProfileInfo profile) raises(WebAPIException);
    void update(SyncProfileInfo profile) raises(WebAPIException);
    void remove(SyncProfileId profileId) raises(WebAPIException);
    long getMaxProfilesNum() raises(WebAPIException);
    unsigned long getProfilesNum() raises(WebAPIException);
    SyncProfileInfo get(SyncProfileId profileId) raises(WebAPIException);
    SyncProfileInfo[] getAll() raises(WebAPIException);
    void startSync(SyncProfileId profileId, optional SyncProgressCallback? progressCallback) raises(WebAPIException);
    void stopSync(SyncProfileId profileId) raises(WebAPIException);
    SyncStatistics[] getLastSyncStatistics(SyncProfileId profileId) raises(WebAPIException);
  };
  [Callback, NoInterfaceObject] interface SyncProgressCallback {
    void onprogress(SyncProfileId profileId, SyncServiceType serviceType, boolean isFromServer, unsigned long totalPerService,
                    unsigned long syncedPerService);
    void oncompleted(SyncProfileId profileId);
    void onstopped(SyncProfileId profileId);
    void onfailed(SyncProfileId profileId, WebAPIError error);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
