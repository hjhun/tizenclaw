# Sensor API

The Sensor API defines interfaces and methods to manage sensor data from various sensors on the device.

The following sensor functionality is provided:

- Start and stop sensor
- Set and unset notification of the sensor data change
- Get current sensor data
For more information about how to use Sensor API, see Device Sensors Guide .

Since: 2.3

## Table of Contents

- 1. Type Definitions
- 1.1. MagneticSensorAccuracy
- 1.2. ProximityState
- 1.3. SensorType
- 2. Interfaces
- 2.1. SensorServiceManagerObject
- 2.2. SensorService
- 2.3. Sensor
- 2.4. AccelerationSensor
- 2.5. GravitySensor
- 2.6. GyroscopeSensor
- 2.7. GyroscopeRotationVectorSensor
- 2.8. GyroscopeUncalibratedSensor
- 2.9. HRMRawSensor
- 2.10. LightSensor
- 2.11. LinearAccelerationSensor
- 2.12. MagneticSensor
- 2.13. MagneticUncalibratedSensor
- 2.14. PressureSensor
- 2.15. ProximitySensor
- 2.16. UltravioletSensor
- 2.17. SensorData
- 2.18. SensorAccelerationData
- 2.19. SensorGravityData
- 2.20. SensorGyroscopeData
- 2.21. SensorGyroscopeRotationVectorData
- 2.22. SensorGyroscopeUncalibratedData
- 2.23. SensorHRMRawData
- 2.24. SensorLightData
- 2.25. SensorLinearAccelerationData
- 2.26. SensorMagneticData
- 2.27. SensorMagneticUncalibratedData
- 2.28. SensorPressureData
- 2.29. SensorProximityData
- 2.30. SensorUltravioletData
- 2.31. SensorHardwareInfo
- 2.32. SensorDataSuccessCallback
- 2.33. SensorHardwareInfoSuccessCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| SensorServiceManagerObject |  |
| SensorService | Sensor getDefaultSensor ( SensorType type) SensorType [] getAvailableSensors () |
| Sensor | void start ( SuccessCallback successCallback, optional ErrorCallback ? errorCallback) void stop () void setChangeListener ( SensorDataSuccessCallback successCallback, optional long? interval, optional long batchLatency) void unsetChangeListener () void getSensorHardwareInfo ( SensorHardwareInfoSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| AccelerationSensor | void getAccelerationSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| GravitySensor | void getGravitySensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| GyroscopeSensor | void getGyroscopeSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| GyroscopeRotationVectorSensor | void getGyroscopeRotationVectorSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| GyroscopeUncalibratedSensor | void getGyroscopeUncalibratedSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| HRMRawSensor | void getHRMRawSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| LightSensor | void getLightSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| LinearAccelerationSensor | void getLinearAccelerationSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| MagneticSensor | void getMagneticSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| MagneticUncalibratedSensor | void getMagneticUncalibratedSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| PressureSensor | void getPressureSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| ProximitySensor | void getProximitySensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| UltravioletSensor | void getUltravioletSensorData ( SensorDataSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| SensorData |  |
| SensorAccelerationData |  |
| SensorGravityData |  |
| SensorGyroscopeData |  |
| SensorGyroscopeRotationVectorData |  |
| SensorGyroscopeUncalibratedData |  |
| SensorHRMRawData |  |
| SensorLightData |  |
| SensorLinearAccelerationData |  |
| SensorMagneticData |  |
| SensorMagneticUncalibratedData |  |
| SensorPressureData |  |
| SensorProximityData |  |
| SensorUltravioletData |  |
| SensorHardwareInfo |  |
| SensorDataSuccessCallback | void onsuccess (optional SensorData ? sensorData) |
| SensorHardwareInfoSuccessCallback | void onsuccess ( SensorHardwareInfo hardwareInfo) |

## 1. Type Definitions

### 1.1. MagneticSensorAccuracy

Specifies the accuracy of magnetic sensor data.

```webidl
  enum MagneticSensorAccuracy { "ACCURACY_UNDEFINED", "ACCURACY_BAD", "ACCURACY_NORMAL", "ACCURACY_GOOD", "ACCURACY_VERYGOOD" };
```

Since: 2.3

- ACCURACY_UNDEFINED - Corresponds to undefined magnetic sensor accuracy.
- ACCURACY_BAD - Corresponds to bad magnetic sensor accuracy.
- ACCURACY_NORMAL - Corresponds to normal magnetic sensor accuracy.
- ACCURACY_GOOD - Corresponds to good magnetic sensor accuracy.
- ACCURACY_VERYGOOD - Corresponds to very good magnetic sensor accuracy.

### 1.2. ProximityState

Specifies the proximity state.

```webidl
  enum ProximityState { "FAR", "NEAR" };
```

Since: 2.3

- FAR - Corresponds to far proximity state.
- NEAR - corresponds to near proximity state.

### 1.3. SensorType

Specifies the sensor type available to the API.

```webidl
  enum SensorType { "ACCELERATION", "GRAVITY", "GYROSCOPE", "GYROSCOPE_ROTATION_VECTOR", "GYROSCOPE_UNCALIBRATED", "HRM_RAW", "LIGHT",
    "LINEAR_ACCELERATION", "MAGNETIC", "MAGNETIC_UNCALIBRATED", "PRESSURE", "PROXIMITY", "ULTRAVIOLET" };
```

Since: 2.3

The sensor types defined by this enumerator are:

- ACCELERATION - Acceleration sensor
- GRAVITY - Gravity sensor
- GYROSCOPE - Gyroscope sensor
- GYROSCOPE_ROTATION_VECTOR - Gyroscope rotation vector sensor
- GYROSCOPE_UNCALIBRATED - Uncalibrated gyroscope sensor
- HRM_RAW - HRM sensor
- LIGHT - Light sensor
- LINEAR_ACCELERATION - Linear acceleration sensor
- MAGNETIC - Magnetic sensor
- MAGNETIC_UNCALIBRATED - Uncalibrated magnetic sensor
- PRESSURE - Pressure sensor
- PROXIMITY - Proximity sensor
- ULTRAVIOLET - Ultraviolet sensor

Remark: *HRM_RAW *is supported since Tizen 2.3.1

Remark: *GRAVITY *, *GYROSCOPE *, *GYROSCOPE_ROTATION_VECTOR *and *LINEAR ACCELERATION *are supported since Tizen 3.0

Remark: *ACCELERATION *, *GYROSCOPE_UNCALIBRATED *and *MAGNETIC_UNCALIBRATED *are supported since Tizen 4.0

## 2. Interfaces

### 2.1. SensorServiceManagerObject

The SensorServiceManagerObject interface defines what is instantiated by the *Tizen *object.
The *tizen.sensorservice *object allows access to various sensors of the Tizen device.

```webidl
  [NoInterfaceObject] interface SensorServiceManagerObject {
    readonly attribute SensorService sensorservice;
  };
```

```webidl
  Tizen implements SensorServiceManagerObject;
```

Since: 2.3

#### Attributes

- readonly SensorService sensorservice Object representing a sensor service.

Since: 2.3

### 2.2. SensorService

The SensorService interface provides methods to access the sensor.

```webidl
  [NoInterfaceObject] interface SensorService {
    Sensor getDefaultSensor(SensorType type) raises(WebAPIException);
    SensorType[] getAvailableSensors() raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getDefaultSensor **`Gets the default sensor of the device for the given sensor type.

```javascript
Sensor getDefaultSensor(SensorType type);
```

Since: 2.3

The supported sensor types are hardware-dependent. 

To check if the given type is supported or not, System Info API can be used.

- ACCELERATION - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.accelerometer" *)
- GRAVITY     - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.gravity" *)
- GYROSCOPE   - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.gyroscope" *)
- GYROSCOPE_ROTATION_VECTOR - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.gyroscope_rotation_vector" *)
- GYROSCOPE_UNCALIBRATED - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.gyroscope.uncalibrated" *)
- HRM_RAW     - HRM_RAW is supported, if at least one HRM LED sensor type is supported: 
tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.heart_rate_monitor.led_green" *), 
tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.heart_rate_monitor.led_ir" *), 
tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.heart_rate_monitor.led_red" *)
- LIGHT       - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.photometer" *)
- LINEAR_ACCELERATION - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.linear_acceleration" *)
- MAGNETIC    - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.magnetometer" *)
- MAGNETIC_UNCALIBRATED - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.magnetometer.uncalibrated" *)
- PRESSURE    - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.barometer" *)
- PROXIMITY   - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.proximity" *)
- ULTRAVIOLET - tizen.systeminfo.getCapability( *"http://tizen.org/feature/sensor.ultraviolet" *)
Parameters:

- **type :
 Sensor type to access.
- **Conditional privilege: **For using HRM_RAW value, privilege **http://tizen.org/privilege/healthinfo (public level) **is needed since Tizen 2.3.1.
**

Return value:

Sensor: Default sensor object.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if accessing a given sensor type fails because of an unknown error.

- with error type NotSupportedError, if the given type is not supported on the device.

- with error type SecurityError, this error is only thrown for *HRM_RAW *sensor type when an application does not have http://tizen.org/privilege/healthinfo privilege in config.xml.

Code example:

```javascript
var proximityCapability =
    tizen.systeminfo.getCapability("http://tizen.org/feature/sensor.proximity");

if (proximityCapability === true)
{
  /* Device supports proximity sensor and you can get proximity sensor's data. */
  var proximitySensor = tizen.sensorservice.getDefaultSensor("PROXIMITY");
}
else
{
  /* If tizen.sensorservice.getDefaultSensor("PROXIMITY") is used, NotSupportedError is thrown. */
  console.log("Proximity sensor is not supported on this device");
}
```

`**getAvailableSensors **`Gets the available sensor types.

```javascript
SensorType[] getAvailableSensors();
```

Since: 2.3

Return value:

SensorType[]: All available sensor types.

Exceptions:

- WebAPIException
- with error type UnknownError, if getting available sensor type fails because of an unknown error.

Code example:

```javascript
var sensorCapabilities = tizen.sensorservice.getAvailableSensors();

console.log("Capable sensor: " + sensorCapabilities[0]);
```

### 2.3. Sensor

The Sensor interface is a base interface for specific sensor interfaces. It provides methods common to all sensor types.

```webidl
  [NoInterfaceObject] interface Sensor {
    readonly attribute SensorType sensorType;
    void start(SuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void stop() raises(WebAPIException);
    void setChangeListener(SensorDataSuccessCallback successCallback, optional long? interval, optional long batchLatency)
                           raises(WebAPIException);
    void unsetChangeListener() raises(WebAPIException);
    void getSensorHardwareInfo(SensorHardwareInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
  };
```

Since: 2.3

#### Attributes

- readonly SensorType sensorType Sensor type to monitor the changes.

Since: 2.3

#### Methods

`**start **`Starts the sensor.

```javascript
void start(SuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

The *SuccessCallback *will be invoked when the first event from the sensor is fired.

The *ErrorCallback *method is launched with these error types:

- NotSupportedError - if the sensor is not supported on the device.
- UnknownError - if starting the sensor fails because of an unknown error.

Parameters:

- **successCallback :
 Callback method to be invoked when sensor has been successfully started. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var proximitySensor = tizen.sensorservice.getDefaultSensor("PROXIMITY");

function onsuccessCB()
{
  console.log("The proximity sensor started successfully");
}

proximitySensor.start(onsuccessCB);
```

`**stop **`Stops the sensor.

```javascript
void stop();
```

Since: 2.3

Exceptions:

- WebAPIException
- with error type UnknownError, if stopping the sensor fails because of an unknown error.

Code example:

```javascript
var proximitySensor = tizen.sensorservice.getDefaultSensor("PROXIMITY");

function onsuccessCB()
{
  console.log("Proximity sensor start");
  proximitySensor.stop();
}

proximitySensor.start(onsuccessCB);
```

`**setChangeListener **`Registers a listener to retrieve sensor data periodically.

```javascript
void setChangeListener(SensorDataSuccessCallback successCallback, optional long? interval, optional long batchLatency);
```

Since: 2.3

Note that the setChangeListener() method only registers the listener.
The start() method must be called to turn on the sensor, or the sensor data will not change.

Remark: *interval *, *batchLatency *are supported since Tizen 3.0

Remark: The specified interval is only a suggested interval between sensor measurements. You will get at least one sensor measurement within the interval you specify, but the actual interval between sensor measurements can be affected by other applications and the system. To reduce the system overhead, it is recommended to set the longest interval that you can, because the system usually chooses the shortest interval among all intervals specified.

Parameters:

- **successCallback :
 Callback method to be invoked periodically. **
- **interval [optional] [nullable] :
 The interval in milliseconds (ms) at which sensor data will be sent to the Web Application which calls this method since Tizen 3.0 
*interval *can be between 10ms and 1000ms inclusive, however, if it is null or zero, it is set to the default value of 100ms. 
For the PROXIMITY sensor type, *interval *will be ignored.
- **batchLatency [optional] :
 The batch latency time in milliseconds (ms) at which sensor events are stored or delivered when processor stay on sleep or suspend status since Tizen 3.0 
*batchLatency *has hardware dependency. You can calculate maximum batchLatency value using maxBatchCount (e.g. interval x maxBatchCount) . If maxBatchCount is zero, device doesn't support batch latency time.
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if registering the listener fails because of an unknown error.

- with error type NotSupportedError, if the batchLatency is not supported on the sensor hardware.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

Code example:

```javascript
var lightSensor = tizen.sensorservice.getDefaultSensor("LIGHT");

function onsuccessCB()
{
  console.log("Light sensor start");
}

function onchangedCB(sensorData)
{
  console.log("Light level: " + sensorData.lightLevel);
}

/* Interval and batchLatency can be omitted. */
lightSensor.setChangeListener(onchangedCB, 200, 2000);

lightSensor.start(onsuccessCB);
```

`**unsetChangeListener **`Unregisters the sensor data change listener.

```javascript
void unsetChangeListener();
```

Since: 2.3

Calling this function has no effect if listener is not set.

Exceptions:

- WebAPIException
- with error type UnknownError, if unregistering the listener fails because of an unknown error.

Code example:

```javascript
var proximitySensor = tizen.sensorservice.getDefaultSensor("PROXIMITY");

function onchangedCB(sensorData)
{
  console.log("Proximity distance: " + sensorData.proximityState);
}

proximitySensor.setChangeListener(onchangedCB);

proximitySensor.unsetChangeListener();
```

`**getSensorHardwareInfo **`Gets hardware information of the sensor.

```javascript
void getSensorHardwareInfo(SensorHardwareInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

The *ErrorCallback *method is launched with these error types:

- AbortError - If operation failed.
- IOError - If the platform fails to internally prepare a socket for IPC communication.

Parameters:

- **successCallback :
 Callback method to be invoked when sensor has been successfully gotten hardware information. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var gravitySensor = tizen.sensorservice.getDefaultSensor("GRAVITY");
gravitySensor.getSensorHardwareInfo(onsuccessCB);

function onsuccessCB(hardwareInfo)
{
  console.log("name: " + hardwareInfo.name);
  console.log("type: " + hardwareInfo.type);
  console.log("vendor: " + hardwareInfo.vendor);
  console.log("minValue: " + hardwareInfo.minValue);
  console.log("maxValue: " + hardwareInfo.maxValue);
  console.log("resolution: " + hardwareInfo.resolution);
  console.log("minInterval: " + hardwareInfo.minInterval);
  console.log("maxBatchCount: " + hardwareInfo.maxBatchCount);
}
```

Output example:

```
 name: Gravity Sensor
 type: GRAVITY
 vendor: Samsung Electronics
 minValue: -19.6
 maxValue: 19.6
 resolution: 0.01
 minInterval: 1
 maxBatchCount: 0
```

### 2.4. AccelerationSensor

The AccelerationSensor interface provides methods to access accelerometer data.

```webidl
  [NoInterfaceObject] interface AccelerationSensor : Sensor {
    void getAccelerationSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                   raises(WebAPIException);
  };
```

Since: 4.0

#### Methods

`**getAccelerationSensorData **`Gets the current acceleration sensor data. You can refer to SensorAccelerationData interface.

```javascript
void getAccelerationSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 4.0

Note that before calling the getAccelerationSensorData() method, the start() method should be called to turn the sensor on.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getAccelerationSensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var accelerationSensor = tizen.sensorservice.getDefaultSensor("ACCELERATION");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get acceleration sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
}

function onerrorCB(error)
{
  console.log("Error occurred: " + error.message);
}

function onsuccessCB()
{
  console.log("Acceleration sensor start");
  accelerationSensor.getAccelerationSensorData(onGetSuccessCB, onerrorCB);
}

accelerationSensor.start(onsuccessCB);
```

Output example:

```
acceleration sensor start
######## Get acceleration sensor data ########
x: -4.311866283416748
y: 8.6243314743042
z: 2.841476917266846
```

### 2.5. GravitySensor

The GravitySensor interface provides methods to access gravity sensor data.

```webidl
  [NoInterfaceObject] interface GravitySensor : Sensor {
    void getGravitySensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                              raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**getGravitySensorData **`Gets the current gravity sensor data. You can refer to the SensorGravityData interface.

```javascript
void getGravitySensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

Note that before calling the getGravitySensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getGravitySensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var gravitySensor = tizen.sensorservice.getDefaultSensor("GRAVITY");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get the gravity sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Sensor start");
  gravitySensor.getGravitySensorData(onGetSuccessCB, onerrorCB);
}

gravitySensor.start(onsuccessCB);
```

Output example:

```
sensor start
######## Get the gravity sensor data ########
x: -0.477486
y: -0.132515
z: -9.794124
```

### 2.6. GyroscopeSensor

The GyroscopeSensor interface provides methods to access gyroscope sensor data.

```webidl
  [NoInterfaceObject] interface GyroscopeSensor : Sensor {
    void getGyroscopeSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**getGyroscopeSensorData **`Gets the current gyroscope sensor data. You can refer to the SensorGyroscopeData interface.

```javascript
void getGyroscopeSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

Note that before calling the getGyroscopeSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getGyroscopeSensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var gyroscopeSensor = tizen.sensorservice.getDefaultSensor("GYROSCOPE");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get the gyroscope sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Sensor start");
  gyroscopeSensor.getGyroscopeSensorData(onGetSuccessCB, onerrorCB);
}

gyroscopeSensor.start(onsuccessCB);
```

Output example:

```
Sensor start
######## Get the gyroscope sensor data ########
x: 186
y: -296
z: -113
```

### 2.7. GyroscopeRotationVectorSensor

The GyroscopeRotationVectorSensor interface provides methods to access gyroscope rotation vector sensor data.

```webidl
  [NoInterfaceObject] interface GyroscopeRotationVectorSensor : Sensor {
    void getGyroscopeRotationVectorSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                              raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**getGyroscopeRotationVectorSensorData **`Gets the current gyroscope rotation vector sensor data. You can refer to the SensorGyroscopeRotationVectorData interface.

```javascript
void getGyroscopeRotationVectorSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

Note that before calling the getGyroscopeRotationVectorSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getGyroscopeRotationVectorSensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var gyroscopeRotationVectorSensor =
    tizen.sensorservice.getDefaultSensor("GYROSCOPE_ROTATION_VECTOR");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get the gyroscope rotation vector sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
  console.log("w: " + sensorData.w);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Sensor start");
  gyroscopeRotationVectorSensor.getGyroscopeRotationVectorSensorData(onGetSuccessCB, onerrorCB);
}

gyroscopeRotationVectorSensor.start(onsuccessCB);
```

Output example:

```
Sensor start
######## Get the gyroscope rotation vector sensor data ########
x: 0
y: 0
z: 0
w: 0
```

### 2.8. GyroscopeUncalibratedSensor

The GyroscopeUncalibratedSensor interface provides methods to access uncalibrated gyroscope sensor data.

```webidl
  [NoInterfaceObject] interface GyroscopeUncalibratedSensor : Sensor {
    void getGyroscopeUncalibratedSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                            raises(WebAPIException);
  };
```

Since: 4.0

#### Methods

`**getGyroscopeUncalibratedSensorData **`Gets the current sensor data.

```javascript
void getGyroscopeUncalibratedSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 4.0

Note that before calling the getGyroscopeUncalibratedSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getGyroscopeUncalibratedSensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var gyroscopeUncalibratedSensor = tizen.sensorservice.getDefaultSensor("GYROSCOPE_UNCALIBRATED");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get uncalibrated gyroscope sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
  console.log("x drift: " + sensorData.xAxisDrift);
  console.log("y drift: " + sensorData.yAxisDrift);
  console.log("z drift: " + sensorData.zAxisDrift);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Gyroscope uncalibrated sensor start");
  gyroscopeUncalibratedSensor.getGyroscopeUncalibratedSensorData(onGetSuccessCB, onerrorCB);
}

gyroscopeUncalibratedSensor.start(onsuccessCB);
```

### 2.9. HRMRawSensor

The HRMRawSensor interface provides methods to access HRM sensor raw data.

```webidl
  [NoInterfaceObject] interface HRMRawSensor : Sensor {
    void getHRMRawSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 2.3.1

#### Methods

`**getHRMRawSensorData **`Gets the current sensor data.

```javascript
void getHRMRawSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

Note that before calling the getHRMRawSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the getHRMRawSensorData method is called without calling the start method.
- UnknownError : An unknown error has occurred.

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if retrieving the sensor data fails because of an unknown error.

- with error type SecurityError, if the application does not have the privilege to use this function.

Code example:

```javascript
var HRMrawsensor = tizen.sensorservice.getDefaultSensor("HRM_RAW");

function onGetSuccessCB(sensorData)
{
  console.log("HRMRaw light intensity: " + sensorData.lightIntensity);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("HRMRaw sensor start");
  HRMrawsensor.getHRMRawSensorData(onGetSuccessCB, onerrorCB);
}

HRMrawsensor.start(onsuccessCB);
```

### 2.10. LightSensor

The LightSensor interface provides methods to access light sensor data.

```webidl
  [NoInterfaceObject] interface LightSensor : Sensor {
    void getLightSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getLightSensorData **`Gets the current sensor data.

```javascript
void getLightSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

Note that before calling the getLightSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getLightSensorData() *method is called without first calling the *start() *method
- UnknownError : An unknown error has occurred

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var lightSensor = tizen.sensorservice.getDefaultSensor("LIGHT");

function onGetSuccessCB(sensorData)
{
  console.log("Light level: " + sensorData.lightLevel);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Sensor start");
  lightSensor.getLightSensorData(onGetSuccessCB, onerrorCB);
}

lightSensor.start(onsuccessCB);
```

### 2.11. LinearAccelerationSensor

The LinearAccelerationSensor interface provides methods to access linear acceleration sensor data.

```webidl
  [NoInterfaceObject] interface LinearAccelerationSensor : Sensor {
    void getLinearAccelerationSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                         raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**getLinearAccelerationSensorData **`Gets the current sensor data.

```javascript
void getLinearAccelerationSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

Note that before calling the getLinearAccelerationSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getLinearAccelerationSensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var linearAccelerationSensor = tizen.sensorservice.getDefaultSensor("LINEAR_ACCELERATION");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get the linear acceleration sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Linear acceleration sensor start");
  linearAccelerationSensor.getLinearAccelerationSensorData(onGetSuccessCB, onerrorCB);
}

linearAccelerationSensor.start(onsuccessCB);
```

Output example:

```
Linear acceleration sensor start
######## Get the linear acceleration sensor data ########
x: 7.639427
y: -2.909304
z: -3.379018
```

### 2.12. MagneticSensor

The MagneticSensor interface provides methods to access magnetic sensor data.

```webidl
  [NoInterfaceObject] interface MagneticSensor : Sensor {
    void getMagneticSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getMagneticSensorData **`Gets the current sensor data.

```javascript
void getMagneticSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

Note that before calling the getMagneticSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getMagneticSensorData() *method is called without first calling the *start() *method
- UnknownError : An unknown error has occurred

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var magneticSensor = tizen.sensorservice.getDefaultSensor("MAGNETIC");

function onGetSuccessCB(sensorData)
{
  console.log("Magnetic field of the X axis: " + sensorData.x);
  console.log("Magnetic field of the Y axis: " + sensorData.y);
  console.log("Magnetic field of the Z axis: " + sensorData.z);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Sensor start");
  magneticSensor.getMagneticSensorData(onGetSuccessCB, onerrorCB);
}

magneticSensor.start(onsuccessCB);
```

### 2.13. MagneticUncalibratedSensor

The MagneticUncalibratedSensor interface provides methods to access uncalibrated magnetic sensor data.

```webidl
  [NoInterfaceObject] interface MagneticUncalibratedSensor : Sensor {
    void getMagneticUncalibratedSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                           raises(WebAPIException);
  };
```

Since: 4.0

#### Methods

`**getMagneticUncalibratedSensorData **`Gets the current sensor data.

```javascript
void getMagneticUncalibratedSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 4.0

Note that before calling the getMagneticUncalibratedSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getMagneticUncalibratedSensorData() *method is called without first calling the *start() *method
- AbortError : If the system operation was aborted

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var magneticUncalibratedSensor = tizen.sensorservice.getDefaultSensor("MAGNETIC_UNCALIBRATED");

function onGetSuccessCB(sensorData)
{
  console.log("######## Get uncalibrated magnetic sensor data ########");
  console.log("x: " + sensorData.x);
  console.log("y: " + sensorData.y);
  console.log("z: " + sensorData.z);
  console.log("x bias: " + sensorData.xAxisBias);
  console.log("y bias: " + sensorData.yAxisBias);
  console.log("z bias: " + sensorData.zAxisBias);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Magnetic uncalibrated sensor start");
  magneticUncalibratedSensor.getMagneticUncalibratedSensorData(onGetSuccessCB, onerrorCB);
}

magneticUncalibratedSensor.start(onsuccessCB);
```

### 2.14. PressureSensor

The PressureSensor interface provides methods to access pressure sensor data.

```webidl
  [NoInterfaceObject] interface PressureSensor : Sensor {
    void getPressureSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getPressureSensorData **`Gets the current sensor data.

```javascript
void getPressureSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

Note that the start() method should be called before calling the getPressureSensorData() method to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getPressureSensorData() *method is called without first calling the *start() *method
- UnknownError : An unknown error has occurred

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var pressureSensor = tizen.sensorservice.getDefaultSensor("PRESSURE");

function onGetSuccessCB(sensorData)
{
  console.log("Pressure: " + sensorData.pressure);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Sensor start");
  pressureSensor.getPressureSensorData(onGetSuccessCB, onerrorCB);
}

pressureSensor.start(onsuccessCB);
```

### 2.15. ProximitySensor

The ProximitySensor interface provides methods to access proximity sensor data.

```webidl
  [NoInterfaceObject] interface ProximitySensor : Sensor {
    void getProximitySensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getProximitySensorData **`Gets the current sensor data.

```javascript
void getProximitySensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

Note that before calling the getProximitySensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getProximitySensorData() *method is called without first calling the *start() *method
- UnknownError : An unknown error has occurred

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var proximitySensor = tizen.sensorservice.getDefaultSensor("PROXIMITY");

function onGetSuccessCB(sensorData)
{
  console.log("Proximity state: " + sensorData.proximityState);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Proximity sensor start");
  proximitySensor.getProximitySensorData(onGetSuccessCB, onerrorCB);
}

proximitySensor.start(onsuccessCB);
```

### 2.16. UltravioletSensor

The UltravioletSensor interface provides methods to access ultraviolet sensor data.

```webidl
  [NoInterfaceObject] interface UltravioletSensor : Sensor {
    void getUltravioletSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                  raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getUltravioletSensorData **`Gets the current sensor data.

```javascript
void getUltravioletSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3

Note that before calling the getUltravioletSensorData() method, the start() method should be called to turn on the sensor.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError : If the *getUltravioletSensorData() *method is called without first calling the *start() *method
- UnknownError : An unknown error has occurred

Parameters:

- **successCallback :
 Callback method to be invoked when the sensor data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var ultravioletSensor = tizen.sensorservice.getDefaultSensor("ULTRAVIOLET");

function onGetSuccessCB(sensorData)
{
  console.log("Ultraviolet level: " + sensorData.ultravioletLevel);
}

function onerrorCB(error)
{
  console.log("Error occurred");
}

function onsuccessCB()
{
  console.log("Ultraviolet sensor start");
  ultravioletSensor.getUltravioletSensorData(onGetSuccessCB, onerrorCB);
}

ultravioletSensor.start(onsuccessCB);
```

### 2.17. SensorData

The SensorData interface is a common abstract interface used by different types of sensor data objects.

```webidl
  [NoInterfaceObject] interface SensorData {
  };
```

Since: 2.3

### 2.18. SensorAccelerationData

The SensorAccelerationData interface represents acceleration sensor data. You can refer to this guide to learn more about acceleration sensor data.

```webidl
  [NoInterfaceObject] interface SensorAccelerationData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
```

Since: 4.0

The acceleration sensor data represents the sum of acceleration of the device and an acceleration component representing forces opposing the gravity.

Remark: An example of how to access and use this interface can be found in the getAccelerationSensorData() code example.

#### Attributes

- readonly double x The result of acceleration sensor measurement in the device's X axis in m/s². 
The value can be between -19.6 and 19.6 inclusive. Since: 4.0

- readonly double y The result of acceleration sensor measurement in the device's Y axis in m/s². 
The value can be between -19.6 and 19.6 inclusive. Since: 4.0

- readonly double z The result of acceleration sensor measurement in the device's Z axis in m/s². 
The value can be between -19.6 and 19.6 inclusive. Since: 4.0

### 2.19. SensorGravityData

The SensorGravityData interface represents gravity sensor data. You can refer to this guide to learn more about gravity sensor data.

```webidl
  [NoInterfaceObject] interface SensorGravityData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
```

Since: 3.0

Remark: An example of how to access and use this interface can be found in the getGravitySensorData() code example.

#### Attributes

- readonly double x Value of the Earth's gravity in the device's X axis in m/s². 
The value can be between -9.8 and 9.8 inclusive. Since: 3.0

- readonly double y Value of the Earth's gravity in the device's Y axis in m/s². 
The value can be between -9.8 and 9.8 inclusive. Since: 3.0

- readonly double z Value of the Earth's gravity in the device's Z axis in m/s². 
The value can be between -9.8 and 9.8 inclusive. Since: 3.0

### 2.20. SensorGyroscopeData

The SensorGyroscopeData interface represents gyroscope sensor data. You can refer to this guide to learn more about gyroscope sensor data.

```webidl
  [NoInterfaceObject] interface SensorGyroscopeData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
```

Since: 3.0

Remark: An example of how to access and use this interface can be found in the getGyroscopeSensorData() code example.

#### Attributes

- readonly double x The angular velocity about the device's X axis in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 3.0

- readonly double y The angular velocity about the device's Y axis in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 3.0

- readonly double z The angular velocity about the device's Z axis in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 3.0

### 2.21. SensorGyroscopeRotationVectorData

The SensorGyroscopeRotationVectorData interface represents gyroscope rotation vector sensor data. You can refer to this guide to learn more about gyroscope sensor data.

```webidl
  [NoInterfaceObject] interface SensorGyroscopeRotationVectorData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute double w;
  };
```

Since: 3.0

A gyroscope rotation vector sensor data represents the orientation of the device as a combination of an angle and an axis when the device has rotated through an angle about an axis (X, Y, or Z).
It is equal to the components of a unit quaternion (cos(θ/2), x * sin(θ/2), y * sin(θ/2), z * sin(θ/2)).

Remark: An example of how to access and use this interface can be found in the getGyroscopeRotationVectorSensorData() code example.

#### Attributes

- readonly double x The X direction component of the rotation vector (x * sin(θ/2)). 
The value can be between -1 and 1 inclusive. Since: 3.0

- readonly double y The Y direction component of the rotation vector (y * sin(θ/2)). 
The value can be between -1 and 1 inclusive. Since: 3.0

- readonly double z The Z direction component of the rotation vector (z * sin(θ/2)). 
The value can be between -1 and 1 inclusive. Since: 3.0

- readonly double w The scalar component of the rotation vector (cos(θ/2)). 
The value can be between -1 and 1 inclusive. Since: 3.0

### 2.22. SensorGyroscopeUncalibratedData

The SensorGyroscopeUncalibratedData interface represents uncalibrated gyroscope sensor data.

```webidl
  [NoInterfaceObject] interface SensorGyroscopeUncalibratedData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute double xAxisDrift;
    readonly attribute double yAxisDrift;
    readonly attribute double zAxisDrift;
  };
```

Since: 4.0

The uncalibrated gyroscope sensor data represents the angular velocity of the device measured by the sensor and the stated measurement drift values.

Stated drift values are attached to the data, but the drift compensation of measurement results is not performed.

#### Attributes

- readonly double x The result of measurement of angular velocity around the device's X axis, without measurement drift compensation, in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 4.0

- readonly double y The result of measurement of angular velocity around the device's Y axis, without measurement drift compensation, in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 4.0

- readonly double z The result of measurement of angular velocity around the device's Z axis, without measurement drift compensation, in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 4.0

- readonly double xAxisDrift Stated drift of angular velocity measurement result around the device's X axis, in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 4.0

- readonly double yAxisDrift Stated drift of angular velocity measurement result around the device's Y axis, in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 4.0

- readonly double zAxisDrift Stated drift of angular velocity measurement result around the device's Z axis, in °/s. 
The value can be between -573.0 and 573.0 inclusive. Since: 4.0

### 2.23. SensorHRMRawData

The SensorHRMRawData interface represents HRM sensor raw data.

```webidl
  [NoInterfaceObject] interface SensorHRMRawData : SensorData {
    readonly attribute DOMString lightType;
    readonly attribute unsigned long lightIntensity;
  };
```

Since: 2.3.1

#### Attributes

- readonly DOMString lightType HRM sensor light type.

The following values are supported:

- LED_IR - The infrared spectrum
- LED_RED - The red light spectrum
- LED_GREEN - The green light spectrum

Since: 2.3.1

- readonly unsigned long lightIntensity HRM sensor light intensity measures the light intensity that is reflected from a blood vessel. The changes in the reported value represent blood volume changes in the microvascular bed of the tissue, and can be used to estimate heart rate.

Since: 2.3.1

### 2.24. SensorLightData

The SensorLightData interface represents light sensor data.

```webidl
  [NoInterfaceObject] interface SensorLightData : SensorData {
    readonly attribute double lightLevel;
  };
```

Since: 2.3

#### Attributes

- readonly double lightLevel Ambient light level in lux.

Since: 2.3

### 2.25. SensorLinearAccelerationData

The SensorLinearAccelerationData interface represents linear acceleration sensor data.

```webidl
  [NoInterfaceObject] interface SensorLinearAccelerationData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
```

Since: 3.0

#### Attributes

- readonly double x Value of the linear acceleration in the device's X axis in m/s². 
The value can be between -19.6 and 19.6 inclusive. Since: 3.0

- readonly double y Value of the linear acceleration in the device's Y axis in m/s². 
The value can be between -19.6 and 19.6 inclusive. Since: 3.0

- readonly double z Value of the linear acceleration in the device's Z axis in m/s². 
The value can be between -19.6 and 19.6 inclusive. Since: 3.0

### 2.26. SensorMagneticData

The SensorMagneticData interface represents magnetic sensor data.

```webidl
  [NoInterfaceObject] interface SensorMagneticData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute MagneticSensorAccuracy accuracy;
  };
```

Since: 2.3

#### Attributes

- readonly double x Ambient magnetic field of the X axis in microtesla (µT).

Since: 2.3

- readonly double y Ambient magnetic field of the Y axis in microtesla (µT).

Since: 2.3

- readonly double z Ambient magnetic field of the Z axis in microtesla (µT).

Since: 2.3

- readonly MagneticSensorAccuracy accuracy Accuracy of magnetic sensor data.

For increasing the accuracy, wave the device around in the air in figure-eight patterns.

Since: 2.3

### 2.27. SensorMagneticUncalibratedData

The SensorMagneticUncalibratedData interface represents uncalibrated magnetic sensor data.

```webidl
  [NoInterfaceObject] interface SensorMagneticUncalibratedData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute double xAxisBias;
    readonly attribute double yAxisBias;
    readonly attribute double zAxisBias;
  };
```

Since: 4.0

The uncalibrated magnetic sensor data represents the magnetic field measured by the sensor and the stated measurement bias.

Factory calibration and temperature compensation are applied to the measurement results. Stated measurement bias added by other factors is attached to the data, but the bias compensation of measurement results is not performed.

#### Attributes

- readonly double x The result of measurement of magnetic field strength of the X axis, without measurement bias compensation, in microtesla (µT).

Since: 4.0

- readonly double y The result of measurement of magnetic field strength of the Y axis, without measurement bias compensation, in microtesla (µT).

Since: 4.0

- readonly double z The result of measurement of magnetic field strength of the Z axis, without measurement bias compensation, in microtesla (µT).

Since: 4.0

- readonly double xAxisBias Stated measurement bias of the value of magnetic field strength of the X axis in microtesla (µT).

Since: 4.0

- readonly double yAxisBias Stated measurement bias of the value of magnetic field strength of the Y axis in microtesla (µT).

Since: 4.0

- readonly double zAxisBias Stated measurement bias of the value of magnetic field strength of the Z axis in microtesla (µT).

Since: 4.0

### 2.28. SensorPressureData

The SensorPressureData interface represents pressure sensor data.

```webidl
  [NoInterfaceObject] interface SensorPressureData : SensorData {
    readonly attribute double pressure;
  };
```

Since: 2.3

#### Attributes

- readonly double pressure Pressure in hectopascal (hPa).

Since: 2.3

### 2.29. SensorProximityData

The SensorProximityData interface represents proximity sensor data.

```webidl
  [NoInterfaceObject] interface SensorProximityData : SensorData {
    readonly attribute ProximityState proximityState;
  };
```

Since: 2.3

#### Attributes

- readonly ProximityState proximityState Proximity state.

Since: 2.3

### 2.30. SensorUltravioletData

The SensorUltravioletData interface represents ultraviolet sensor data.

```webidl
  [NoInterfaceObject] interface SensorUltravioletData : SensorData {
    readonly attribute long ultravioletLevel;
  };
```

Since: 2.3

#### Attributes

- readonly long ultravioletLevel Ultraviolet index.

The ultraviolet index is an international standard measurement of the strength of ultraviolet radiation from the sun. The *ultravioletLevel *ranges from 0 to 15.

Since: 2.3

### 2.31. SensorHardwareInfo

The SensorHardwareInfo interface represents information about the sensor requested by the getSensorHardwareInfo method

```webidl
  [NoInterfaceObject] interface SensorHardwareInfo {
    readonly attribute DOMString name;
    readonly attribute SensorType type;
    readonly attribute DOMString vendor;
    readonly attribute double minValue;
    readonly attribute double maxValue;
    readonly attribute double resolution;
    readonly attribute long minInterval;
    readonly attribute long maxBatchCount;
  };
```

Since: 3.0

Remark: This interface returns hardware information provided by the sensor manufacture.

#### Attributes

- readonly DOMString name Name of the sensor.

Since: 3.0

- readonly SensorType type Type of the sensor . 
Since: 3.0

- readonly DOMString vendor Vendor of the sensor.

Since: 3.0

- readonly double minValue Minimum reading value that can be received from the sensor. 

The units for the minimum value depends on the sensor type:
- ACCELERATION - m/s 2 (meters per second squared)
- GRAVITY - m/s 2 (meters per second squared)
- GYROSCOPE - °/s (Degrees/s)
- GYROSCOPE_ROTATION_VECTOR - None
- GYROSCOPE_UNCALIBRATED - °/s (Degrees/s)
- HRM_RAW - None
- LIGHT - lux
- LINEAR_ACCELERATION -  m/s 2 (meters per second squared)
- MAGNETIC - μT (microtesla)
- MAGNETIC_UNCALIBRATED - μT (microtesla)
- PRESSURE - hPa (hectopascal)
- PROXIMITY - None
- ULTRAVIOLET - UV index (ultraviolet index)
For more information about sensor, see Sensor Guide .

Since: 3.0

- readonly double maxValue Maximum reading value that can be received from the sensor. 

The units for the maximum value depends on the sensor type:
- ACCELERATION - m/s 2 (meters per second squared)
- GRAVITY - m/s 2 (meters per second squared)
- GYROSCOPE - °/s (Degrees/s)
- GYROSCOPE_ROTATION_VECTOR - None
- GYROSCOPE_UNCALIBRATED - °/s (Degrees/s)
- HRM_RAW - None
- LIGHT - lux
- LINEAR_ACCELERATION -  m/s 2 (meters per second squared)
- MAGNETIC - μT (microtesla)
- MAGNETIC_UNCALIBRATED - μT (microtesla)
- PRESSURE - hPa (hectopascal)
- PROXIMITY - None
- ULTRAVIOLET - UV index (ultraviolet index)
For more information about sensor, see Sensor Guide .

Since: 3.0

- readonly double resolution The smallest change which the sensor can detect. 

The units of the resolution depends on the sensor type:
- ACCELERATION - m/s 2 (meters per second squared)
- GRAVITY - m/s 2 (meters per second squared)
- GYROSCOPE - °/s (Degrees/s)
- GYROSCOPE_ROTATION_VECTOR - None
- GYROSCOPE_UNCALIBRATED - °/s (Degrees/s)
- HRM_RAW - None
- LIGHT - lux
- LINEAR_ACCELERATION -  m/s 2 (meters per second squared)
- MAGNETIC - μT (microtesla)
- MAGNETIC_UNCALIBRATED - μT (microtesla)
- PRESSURE - hPa (hectopascal)
- PROXIMITY - None
- ULTRAVIOLET - UV index (ultraviolet index)
For more information about sensor, see Sensor Guide .

Since: 3.0

- readonly long minInterval Minimum interval of the sensor which means a period between two events.

Since: 3.0

- readonly long maxBatchCount Maximum batch count of sensor, batch means storing a sensors event in a hardware FIFO register when processor stay on sleep or suspend status.

Since: 3.0

### 2.32. SensorDataSuccessCallback

The SensorDataSuccessCallback interface is a callback interface that is invoked periodically. For example, see the Sensor interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface SensorDataSuccessCallback {
    void onsuccess(optional SensorData? sensorData);
  };
```

Since: 2.3

#### Methods

`**onsuccess **`Called periodically.

```javascript
void onsuccess(optional SensorData? sensorData);
```

Since: 2.3

Parameters:

- **sensorData [optional] [nullable] :
 Current sensor data. **

### 2.33. SensorHardwareInfoSuccessCallback

The SensorHardwareInfoSuccessCallback callback interface specifies a success callback with SensorHardwareInfo object as an input argument.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface SensorHardwareInfoSuccessCallback {
    void onsuccess(SensorHardwareInfo hardwareInfo);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when sensor hardware information is successfully retrieved.

```javascript
void onsuccess(SensorHardwareInfo hardwareInfo);
```

Since: 3.0

Parameters:

- **hardwareInfo :
 Current sensor Hardware Info. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the acceleration sensor application runs on a device with an acceleration sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.accelerometer
To guarantee that the gravity sensor application runs on a device with a gravity sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.gravity
To guarantee that the uncalibrated gyroscope sensor application runs on a device with a gyroscope sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.gyroscope
To guarantee that the gyroscope sensor application runs on a device with a gyroscope sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.gyroscope_rotation_vector
To guarantee that the gyroscope rotation vector sensor application runs on a device with a gyroscope rotation vector sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.gyroscope.uncalibrated
To guarantee that the Heart Rate Monitor application runs on a device with a heart rate monitor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.heart_rate_monitor
To guarantee that the light sensor application runs on a device with a photometer (light) sensor, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.photometer
To guarantee that the linear acceleration sensor application runs on a device with a linear acceleration sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.linear_acceleration
To guarantee that the magnetic sensor application runs on a device with a magnetic sensor, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.magnetometer
To guarantee that the uncalibrated magnetic sensor application runs on a device with a magnetic sensor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.magnetometer.uncalibrated
To guarantee that the barometer(pressure) sensor application runs on a device with a barometric (pressure) sensor, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.barometer
To guarantee that the proximity sensor application runs on a device with a proximity sensor, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.proximity
To guarantee that the UV sensor application runs on a device with a UV sensor, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.ultraviolet

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module Sensor {
  enum MagneticSensorAccuracy { "ACCURACY_UNDEFINED", "ACCURACY_BAD", "ACCURACY_NORMAL", "ACCURACY_GOOD", "ACCURACY_VERYGOOD" };
  enum ProximityState { "FAR", "NEAR" };
  enum SensorType { "ACCELERATION", "GRAVITY", "GYROSCOPE", "GYROSCOPE_ROTATION_VECTOR", "GYROSCOPE_UNCALIBRATED", "HRM_RAW", "LIGHT",
    "LINEAR_ACCELERATION", "MAGNETIC", "MAGNETIC_UNCALIBRATED", "PRESSURE", "PROXIMITY", "ULTRAVIOLET" };
  Tizen implements SensorServiceManagerObject;
  [NoInterfaceObject] interface SensorServiceManagerObject {
    readonly attribute SensorService sensorservice;
  };
  [NoInterfaceObject] interface SensorService {
    Sensor getDefaultSensor(SensorType type) raises(WebAPIException);
    SensorType[] getAvailableSensors() raises(WebAPIException);
  };
  [NoInterfaceObject] interface Sensor {
    readonly attribute SensorType sensorType;
    void start(SuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void stop() raises(WebAPIException);
    void setChangeListener(SensorDataSuccessCallback successCallback, optional long? interval, optional long batchLatency)
                           raises(WebAPIException);
    void unsetChangeListener() raises(WebAPIException);
    void getSensorHardwareInfo(SensorHardwareInfoSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
  };
  [NoInterfaceObject] interface AccelerationSensor : Sensor {
    void getAccelerationSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                   raises(WebAPIException);
  };
  [NoInterfaceObject] interface GravitySensor : Sensor {
    void getGravitySensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                              raises(WebAPIException);
  };
  [NoInterfaceObject] interface GyroscopeSensor : Sensor {
    void getGyroscopeSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                raises(WebAPIException);
  };
  [NoInterfaceObject] interface GyroscopeRotationVectorSensor : Sensor {
    void getGyroscopeRotationVectorSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                              raises(WebAPIException);
  };
  [NoInterfaceObject] interface GyroscopeUncalibratedSensor : Sensor {
    void getGyroscopeUncalibratedSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                            raises(WebAPIException);
  };
  [NoInterfaceObject] interface HRMRawSensor : Sensor {
    void getHRMRawSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface LightSensor : Sensor {
    void getLightSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface LinearAccelerationSensor : Sensor {
    void getLinearAccelerationSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                         raises(WebAPIException);
  };
  [NoInterfaceObject] interface MagneticSensor : Sensor {
    void getMagneticSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
  };
  [NoInterfaceObject] interface MagneticUncalibratedSensor : Sensor {
    void getMagneticUncalibratedSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                           raises(WebAPIException);
  };
  [NoInterfaceObject] interface PressureSensor : Sensor {
    void getPressureSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
  };
  [NoInterfaceObject] interface ProximitySensor : Sensor {
    void getProximitySensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                raises(WebAPIException);
  };
  [NoInterfaceObject] interface UltravioletSensor : Sensor {
    void getUltravioletSensorData(SensorDataSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                                  raises(WebAPIException);
  };
  [NoInterfaceObject] interface SensorData {
  };
  [NoInterfaceObject] interface SensorAccelerationData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
  [NoInterfaceObject] interface SensorGravityData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
  [NoInterfaceObject] interface SensorGyroscopeData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
  [NoInterfaceObject] interface SensorGyroscopeRotationVectorData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute double w;
  };
  [NoInterfaceObject] interface SensorGyroscopeUncalibratedData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute double xAxisDrift;
    readonly attribute double yAxisDrift;
    readonly attribute double zAxisDrift;
  };
  [NoInterfaceObject] interface SensorHRMRawData : SensorData {
    readonly attribute DOMString lightType;
    readonly attribute unsigned long lightIntensity;
  };
  [NoInterfaceObject] interface SensorLightData : SensorData {
    readonly attribute double lightLevel;
  };
  [NoInterfaceObject] interface SensorLinearAccelerationData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
  };
  [NoInterfaceObject] interface SensorMagneticData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute MagneticSensorAccuracy accuracy;
  };
  [NoInterfaceObject] interface SensorMagneticUncalibratedData : SensorData {
    readonly attribute double x;
    readonly attribute double y;
    readonly attribute double z;
    readonly attribute double xAxisBias;
    readonly attribute double yAxisBias;
    readonly attribute double zAxisBias;
  };
  [NoInterfaceObject] interface SensorPressureData : SensorData {
    readonly attribute double pressure;
  };
  [NoInterfaceObject] interface SensorProximityData : SensorData {
    readonly attribute ProximityState proximityState;
  };
  [NoInterfaceObject] interface SensorUltravioletData : SensorData {
    readonly attribute long ultravioletLevel;
  };
  [NoInterfaceObject] interface SensorHardwareInfo {
    readonly attribute DOMString name;
    readonly attribute SensorType type;
    readonly attribute DOMString vendor;
    readonly attribute double minValue;
    readonly attribute double maxValue;
    readonly attribute double resolution;
    readonly attribute long minInterval;
    readonly attribute long maxBatchCount;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface SensorDataSuccessCallback {
    void onsuccess(optional SensorData? sensorData);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface SensorHardwareInfoSuccessCallback {
    void onsuccess(SensorHardwareInfo hardwareInfo);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
