# PlayerUtil API

The Player Util API provides functionality for managing features related to the W3C Player.

You can change the audio latency mode using this API.

For more information on the Player Util features, see Player Util Guide .

Since: 3.0

## Table of Contents

- 1. Type Definitions
- 1.1. LatencyMode
- 2. Interfaces
- 2.1. PlayerUtilManagerObject
- 2.2. PlayerUtilManager
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| PlayerUtilManagerObject |  |
| PlayerUtilManager | LatencyMode getLatencyMode () void setLatencyMode ( LatencyMode mode) |

## 1. Type Definitions

### 1.1. LatencyMode

Specifies the latency mode for the W3C Player.

```webidl
  enum LatencyMode { "LOW", "MID", "HIGH" };
```

Since: 3.0

- LOW - Low audio latency mode.
- MID - Middle audio latency mode.
- HIGH - High audio latency mode.

## 2. Interfaces

### 2.1. PlayerUtilManagerObject

The PlayerUtilManagerObject interface defines what is instantiated by the *Tizen *object from the Tizen Platform.
The *tizen.playerutil *object allows access to the functionality of the Player Util API.

```webidl
  [NoInterfaceObject] interface PlayerUtilManagerObject {
    readonly attribute PlayerUtilManager playerutil;
  };
```

```webidl
  Tizen implements PlayerUtilManagerObject;
```

Since: 3.0

#### Attributes

- readonly PlayerUtilManager playerutil Object representing a player utilities manager.

Since: 3.0

### 2.2. PlayerUtilManager

The PlayerUtilManager interface provides methods to manage the W3C Player features.

```webidl
  [NoInterfaceObject] interface PlayerUtilManager {
    LatencyMode getLatencyMode() raises(WebAPIException);
    void setLatencyMode(LatencyMode mode) raises(WebAPIException);
  };
```

Since: 3.0

#### Methods

`**getLatencyMode **`Gets the latency mode of the W3C Player.

```javascript
LatencyMode getLatencyMode();
```

Since: 3.0

Return value:

LatencyMode: Latency mode, which is currently set on device.

Exceptions:

- WebAPIException
- with error type AbortError, if any error occurs.

Code example:

```javascript
var mode = tizen.playerutil.getLatencyMode();
console.log("Current latency mode is: " + mode);
```

Output example:

```
Current latency mode is: LOW
```

`**setLatencyMode **`Sets the latency mode of the W3C Player.

```javascript
void setLatencyMode(LatencyMode mode);
```

Since: 3.0

Parameters:

- **mode :
 Latency mode to set. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if value to be set has incorrect type.

- with error type AbortError, if the method cannot be completed because of an unknown error.

Code example:

```javascript
console.log("Current latency mode is: " + tizen.playerutil.getLatencyMode());
tizen.playerutil.setLatencyMode("HIGH");
console.log("Changed latency mode is: " + tizen.playerutil.getLatencyMode());
```

Output example:

```
Current latency mode is: LOW
Changed latency mode is: HIGH
```

## 3. Full WebIDL

```webidl
module PlayerUtil {
  enum LatencyMode { "LOW", "MID", "HIGH" };
  Tizen implements PlayerUtilManagerObject;
  [NoInterfaceObject] interface PlayerUtilManagerObject {
    readonly attribute PlayerUtilManager playerutil;
  };
  [NoInterfaceObject] interface PlayerUtilManager {
    LatencyMode getLatencyMode() raises(WebAPIException);
    void setLatencyMode(LatencyMode mode) raises(WebAPIException);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
