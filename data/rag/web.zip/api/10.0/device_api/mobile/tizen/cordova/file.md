# File API

This plugin implements a File API allowing read/write access to files residing on the device.

Original documentation: Cordova File .

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

**Remark: **In order to access files, a proper privilege has to be defined additionally:

- for accessing only internal storage using this API, a privilege http://tizen.org/privilege/mediastorage must be provided,
- for accessing only external storage using this API, a privilege http://tizen.org/privilege/externalstorage must be provided,
- for accessing internal and external storage using this API, privileges ( http://tizen.org/privilege/mediastorage and http://tizen.org/privilege/externalstorage ) must be provided.
- Storage privileges are privacy-related privileges and there is a need of asking user directly with proper pop-up. Please refer to Privacy Privilege API for more details.

Since: 3.0

## Table of Contents

- 1. Type Definitions
- 1.1. Blob
- 1.2. WriteData
- 1.3. ReadResultData
- 2. Interfaces
- 2.1. FilePropertyBag
- 2.2. ProgressEventInit
- 2.3. ProgressEvent
- 2.4. FileSystemManagerObject
- 2.5. FileSystemManager
- 2.6. FileSystem
- 2.7. Metadata
- 2.8. FileError
- 2.9. File
- 2.10. LocalFileSystem
- 2.11. Entry
- 2.12. DirectoryEntry
- 2.13. DirectoryReader
- 2.14. FileEntry
- 2.15. FileReader
- 2.16. FileWriter
- 2.17. ProgressCallback
- 2.18. FileSystemCallback
- 2.19. EntryCallback
- 2.20. EntriesCallback
- 2.21. MetadataCallback
- 2.22. FileWriterCallback
- 2.23. FileCallback
- 2.24. VoidCallback
- 2.25. ErrorCallback
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| FilePropertyBag |  |
| ProgressEventInit |  |
| ProgressEvent |  |
| FileSystemManagerObject |  |
| FileSystemManager |  |
| FileSystem |  |
| Metadata |  |
| FileError |  |
| File |  |
| LocalFileSystem | void requestFileSystem (short type, long long size, optional FileSystemCallback ? successCallback, optional ErrorCallback ? errorCallback) void resolveLocalFileSystemURL (DOMString uri, optional EntryCallback ? successCallback, optional ErrorCallback ? errorCallback) |
| Entry | void getMetadata ( MetadataCallback onsuccess, optional ErrorCallback ? onerror) void moveTo ( DirectoryEntry parent, optional DOMString? newName, optional EntryCallback ? onsuccess, optional ErrorCallback ? onerror) void copyTo ( DirectoryEntry parent, optional DOMString? newName, optional EntryCallback ? onsuccess, optional ErrorCallback ? onerror) void getParent ( EntryCallback onsuccess, optional ErrorCallback ? onerror) void remove ( VoidCallback onsuccess, optional ErrorCallback ? onerror) DOMString toURL () |
| DirectoryEntry | DirectoryReader createReader () void getDirectory (DOMString path, optional ? options, optional EntryCallback ? onsuccess, optional ErrorCallback ? onerror) void getFile (DOMString path, optional ? options, optional EntryCallback ? onsuccess, optional ErrorCallback ? onerror) void removeRecursively ( VoidCallback onsuccess, optional ErrorCallback ? onerror) |
| DirectoryReader | void readEntries ( EntriesCallback onsuccess, optional ErrorCallback ? onerror) |
| FileEntry | void createWriter ( FileWriterCallback onsuccess, optional ErrorCallback ? onerror) void file ( FileCallback onsuccess, optional ErrorCallback onerror) |
| FileReader | void abort () void readAsDataURL ( Blob blob) void readAsText ( Blob blob, optional DOMString? label) void readAsBinaryString ( Blob blob) void readAsArrayBuffer ( Blob blob) |
| FileWriter | void abort () void seek (long offset) void truncate (long size) void write ( WriteData data) |
| ProgressCallback | void onsuccess ( ProgressEvent event) |
| FileSystemCallback | void handleEvent ( FileSystem filesystem) |
| EntryCallback | void handleEvent ( Entry entry) |
| EntriesCallback | void handleEvent ( Entry [] entries) |
| MetadataCallback | void handleEvent ( Metadata metadata) |
| FileWriterCallback | void handleEvent ( FileWriter fileWriter) |
| FileCallback | void handleEvent ( File file) |
| VoidCallback | void handleEvent () |
| ErrorCallback | void handleEvent ( FileError err) |

## 1. Type Definitions

### 1.1. Blob

Specifies the Blob object defined in W3C File API .
See The Blob Interface and Binary Data .

```webidl
  typedef Blob Blob;
```

Since: 3.0

### 1.2. WriteData

Specifies the user or system defined event data.

```webidl
  typedef (Blob or DOMString) WriteData;
```

Since: 3.0

### 1.3. ReadResultData

Specifies the result data of *FileReader *object.

```webidl
  typedef (DOMString or byte[]) ReadResultData;
```

Since: 3.0

## 2. Interfaces

### 2.1. FilePropertyBag

FilePropertyBag.

```webidl
  dictionary FilePropertyBag {
    DOMString type;
    long long lastModified;
  };
```

Since: 3.0

#### Dictionary members

DOMString type The ASCII-encoded string in lower case representing the media type of the File. Normative conditions for this member are provided in the File constructor steps.

Since: 3.0

long long lastModified conditions for this member are provided in the File constructor steps.

Since: 3.0

### 2.2. ProgressEventInit

A dictionary used to initialize ProgressEvent object.

```webidl
  dictionary ProgressEventInit {
    unsigned long long loaded = false;
    unsigned long long total = false;
    EventTarget target = null;
  };
```

Since: 3.0

### 2.3. ProgressEvent

The interface that indicates progression event.

```webidl
  [Constructor(DOMString type, optional ProgressEventInit eventInitDict)]
  interface ProgressEvent {
    readonly attribute DOMString type;
    readonly attribute boolean bubbles;
    readonly attribute boolean cancelBubble;
    readonly attribute boolean cancelable;
    readonly attribute boolean lengthComputable;
    readonly attribute unsigned long long loaded;
    readonly attribute unsigned long long total;
    readonly attribute EventTarget target;
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
var eventInit = {loaded: 128, total: 1024};
var event = new ProgressEvent("submit", eventInit);
```

#### Constructors

`**Constructor (DOMString, ProgressEventInit ) **`
```webidl
ProgressEvent(DOMString type, optional ProgressEventInit eventInitDict);
```

#### Attributes

- readonly DOMString type The type of event, e.g. "click", "hashchange", or "submit".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly boolean bubbles True if event's goes through its target attribute value's ancestors in reverse tree order, and false otherwise.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly boolean cancelBubble Cancel bubble

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly boolean cancelable Its return value does not always carry meaning, but true can indicate that part of the operation during which event was dispatched, can be canceled.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly boolean lengthComputable True when the length of the transferred content is known.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly unsigned long long loaded Number of bytes transferred.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly unsigned long long total The total length of the content.  This attribute is set when lengthComputable is true.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly EventTarget target The object to which event is dispatched.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 2.4. FileSystemManagerObject

The FileSystemManagerObject interface defines what is instantiated by the Cordova object.

```webidl
  [NoInterfaceObject] interface FileSystemManagerObject {
    readonly attribute FileSystemManager file;
  };
```

```webidl
  Cordova implements FileSystemManagerObject;
```

Since: 3.0

There is a *cordova.file *object that allows accessing the functionality of the Filesystem API.

### 2.5. FileSystemManager

The FileSystemManager interface provides access to the Filesystem API.

```webidl
  [NoInterfaceObject] interface FileSystemManager {
    readonly attribute DOMString? applicationDirectory;
    readonly attribute DOMString? applicationStorageDirectory;
    readonly attribute DOMString? dataDirectory;
    readonly attribute DOMString? cacheDirectory;
    readonly attribute DOMString? externalApplicationStorageDirectory;
    readonly attribute DOMString? externalDataDirectory;
    readonly attribute DOMString? externalCacheDirectory;
    readonly attribute DOMString? externalRootDirectory;
    readonly attribute DOMString? tempDirectory;
    readonly attribute DOMString? syncedDataDirectory;
    readonly attribute DOMString? documentsDirectory;
    readonly attribute DOMString? sharedDirectory;
  };
```

Since: 3.0

This manager interface exposes the Filesystem base API constants.

#### Attributes

- readonly DOMString applicationDirectory [nullable] Read-only directory where the application is installed.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(
    "The directory where the application is installed " + cordova.file.applicationDirectory);
```

Output example:

```
The directory where the application is installed file:///opt/usr/apps/WfigBlWDyf/res/wgt/
```

- readonly DOMString applicationStorageDirectory [nullable] Root directory of the application's sandbox.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(
    "Root directory of the application's sandbox " + cordova.file.applicationStorageDirectory);
```

Output example:

```
Root directory of the application's sandbox file:///opt/usr/apps/WfigBlWDyf/
```

- readonly DOMString dataDirectory [nullable] Persistent and private data storage within the application's sandbox using internal memory

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Data directory " + cordova.file.dataDirectory);
```

Output example:

```
Data directory file:///opt/usr/apps/WfigBlWDyf/data/
```

- readonly DOMString cacheDirectory [nullable] Directory for cached data files or any files that your app can re-create easily. The OS may delete these files when the device runs low on storage, nevertheless, apps should not rely on the OS to delete files in here.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Cache directory " + cordova.file.cacheDirectory);
```

Output example:

```
Cache directory file:///opt/usr/apps/WfigBlWDyf/tmp/
```

- readonly DOMString externalApplicationStorageDirectory [nullable] Application space on external storage.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Space on external storage " + cordova.file.externalApplicationStorageDirectory);
```

Output example:

```
Space on external storage null
```

- readonly DOMString externalDataDirectory [nullable] Where to put app-specific data files on external storage.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Data files on external storage " + cordova.file.externalDataDirectory);
```

Output example:

```
Data files on external storage null
```

- readonly DOMString externalCacheDirectory [nullable] Application cache on external storage.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Cache on external storage " + cordova.file.externalCacheDirectory);
```

Output example:

```
Cache on external storage null
```

- readonly DOMString externalRootDirectory [nullable] External storage root.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Root on external storage " + cordova.file.externalRootDirectory);
```

Output example:

```
Root on external storage file:///usr/storage/sdcard/
```

- readonly DOMString tempDirectory [nullable] Temp directory that the OS can clear at will. Do not rely on the OS to clear this directory; your app should always remove files as applicable.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Temp directory " + cordova.file.tempDirectory);
```

Output example:

```
Temp directory null
```

- readonly DOMString syncedDataDirectory [nullable] Holds app-specific files that should be synced.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Synced data directory " + cordova.file.syncedDataDirectory);
```

Output example:

```
Synced data directory null
```

- readonly DOMString documentsDirectory [nullable] Files private to the app, but that are meaningful to other application (e.g. Office files).

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Documents directory " + cordova.file.documentsDirectory);
```

Output example:

```
Documents directory null
```

- readonly DOMString sharedDirectory [nullable] Files globally available to all applications.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log("Files globally available to all applications " + cordova.file.sharedDirectory);
```

Output example:

```
Files globally available to all applications file:///opt/usr/media/
```

### 2.6. FileSystem

This interface provides object that represents a file system.

```webidl
  [NoInterfaceObject] interface FileSystem {
    readonly attribute DOMString name;
    readonly attribute DirectoryEntry root;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString name This is the name of the file system.

The specifics of naming filesystems is unspecified, but a name must be unique across the list of exposed file systems.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fileSystem)
{
  console.log("Name of the filesystem: " + fileSystem.name);
});
```

Output example:

```
Name of the filesystem: temporary
```

- readonly DirectoryEntry root The root directory of the file system.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 2.7. Metadata

This interface supplies information about the state of a file or directory.

```webidl
  interface Metadata {
    readonly attribute Date modificationTime;
    readonly attribute unsigned long long size;
  };
```

Since: 3.0

#### Attributes

- readonly Date modificationTime This is the time at which the file or directory was last modified.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly unsigned long long size The size of the file, in bytes. This must return 0 for directories.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 2.8. FileError

File Error

```webidl
  [NoInterfaceObject] interface FileError {
    const unsigned short NOT_FOUND_ERR = 1;
    const unsigned short SECURITY_ERR = 2;
    const unsigned short ABORT_ERR = 3;
    const unsigned short NOT_READABLE_ERR = 4;
    const unsigned short ENCODING_ERR = 5;
    const unsigned short NO_MODIFICATION_ALLOWED_ERR = 6;
    const unsigned short INVALID_STATE_ERR = 7;
    const unsigned short SYNTAX_ERR = 8;
    const unsigned short INVALID_MODIFICATION_ERR = 9;
    const unsigned short QUOTA_EXCEEDED_ERR = 10;
    const unsigned short TYPE_MISMATCH_ERR = 11;
    const unsigned short PATH_EXISTS_ERR = 12;
    attribute unsigned short code;
  };
```

Since: 3.0

### 2.9. File

The File interface provides access to file's properties. File object could be created with using of *FileEntry.file() *method.

```webidl
  [NoInterfaceObject] interface File {
    readonly attribute DOMString name;
    readonly attribute DOMString localURL;
    readonly attribute DOMString type;
    readonly attribute Date lastModified;
    readonly attribute long long size;
  };
```

Since: 3.0

#### Attributes

- readonly DOMString name The name of the file.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly DOMString localURL The full path of the file, including the name.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly DOMString type The mime type of the file.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly Date lastModified The last modified date of the file.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly long long size The size of the file in bytes.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 2.10. LocalFileSystem

This interface provides a way to obtain *Entry *and *FileSystem *objects.

```webidl
  [NoInterfaceObject] interface LocalFileSystem {
    const short TEMPORARY = 0;
    const short PERSISTENT = 1;
    void requestFileSystem(short type, long long size, optional FileSystemCallback? successCallback,
                           optional ErrorCallback? errorCallback) raises(TypeError);
    void resolveLocalFileSystemURL(DOMString uri, optional EntryCallback? successCallback, optional ErrorCallback? errorCallback)
                                   raises(TypeError);
  };
```

```webidl
  Window implements LocalFileSystem;
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Constants

- TEMPORARY Used for storage with no guarantee of persistence.

Since: 3.0

- PERSISTENT Used for storage that should not be removed by the user agent without application or user permission.

Since: 3.0

#### Methods

`**requestFileSystem **`Request a file system in which to store application data.

```javascript
void requestFileSystem(short type, long long size, optional FileSystemCallback? successCallback,
                       optional ErrorCallback? errorCallback);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **type :
 Local file system type, either TEMPORARY or PERSISTENT. **
- **size :
 Indicates how much storage space, in bytes, the application expects to need. **
- **successCallback [optional] [nullable] :
 Invoked with a *FileSystem *object. **
- **errorCallback [optional] [nullable] :
 Invoked if error occurs retrieving file system. **

Exceptions:

- TypeError
- if any of the input parameters has incorrect type.

Code example:

```javascript
successCallback = function(fs)
{
  console.log("File system name: " + fs.name);
};

errorCallback = function(err)
{
  console.log(err.code);
};

requestFileSystem(TEMPORARY, 1024 * 1024, successCallback, errorCallback);
```

Output example:

```
File system name: temporary
```

`**resolveLocalFileSystemURL **`Retrieves a *DirectoryEntry *or *FileEntry *using local URI.

```javascript
void resolveLocalFileSystemURL(DOMString uri, optional EntryCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **uri :
 URI referring to a local file or directory. **
- **successCallback [optional] [nullable] :
 Invoked with *Entry *object corresponding to URI. **
- **errorCallback [optional] [nullable] :
 Invoked if error occurs retrieving file system entry. **

Exceptions:

- TypeError
- if any of the input parameters has incorrect type.

Code example:

```javascript
successCallback = function(entry)
{
  console.log("Entry name: " + entry.name);
};

errorCallback = function(err)
{
  console.log(err.code);
};

var uri = "file:///home/owner/content/Documents/example.txt";
resolveLocalFileSystemURL(uri, successCallback, errorCallback);
```

Output example:

```
Entry name: example.txt
```

### 2.11. Entry

The Entry interface.

```webidl
  [NoInterfaceObject] interface Entry {
    readonly attribute boolean isFile;
    readonly attribute boolean isDirectory;
    readonly attribute DOMString fullPath;
    readonly attribute DOMString name;
    readonly attribute FileSystem filesystem;
    void getMetadata(MetadataCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
    void moveTo(DirectoryEntry parent, optional DOMString? newName, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                raises(FileException);
    void copyTo(DirectoryEntry parent, optional DOMString? newName, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                raises(FileException);
    void getParent(EntryCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
    void remove(VoidCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
    DOMString toURL();
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Attributes

- readonly boolean isFile True if the entry is a file.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly boolean isDirectory True if the entry is a directory.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly DOMString fullPath The full absolute path from the root to the entry. An absolute path is a relative path from the root directory, prepended with a "/".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly DOMString name The name of the entry, excluding the path leading to it.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly FileSystem filesystem The file system where the entry resides.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**getMetadata **`Look up metadata about this entry.

```javascript
void getMetadata(MetadataCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 A callback that is called with the time of the last modification. **
- **onerror [optional] [nullable] :
   A callback that is called when errors happen. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getMetadata(function(metadata)
  {
    console.log(
        "Last modification time: " + metadata.modificationTime);  /* Gets metadata successfully. */
  });
});
```

Output example:

```
Last modification time: Fri Jan 02 2015 03:58:08 GMT+0900 (KST)
```

`**moveTo **`Move an entry to a different location on the file system.

```javascript
void moveTo(DirectoryEntry parent, optional DOMString? newName, optional EntryCallback? onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

It is an error to try to:

- move a directory inside itself or to any child at any depth
- move an entry into its parent if a name different from its current one isn't provided
- move a file to a path occupied by a directory
- move a directory to a path occupied by a file
- move any element to a path occupied by a directory which is not empty
A move of a file on top of an existing file must attempt to delete and replace that file.
A move of a directory on top of an existing empty directory must attempt to delete and replace that directory.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **parent :
    The directory to which to move the entry. **
- **newName [optional] [nullable] :
   The new name of the entry. Defaults to the Entry's current name if unspecified. **
- **onsuccess [optional] [nullable] :
 A callback that is called with the Entry for the new location. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
successCallback = function(entry)
{
  console.log("Full path to the moved file: " + entry.fullPath);
};
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getDirectory("testDirectory", {create: true}, function(direntry)
  {
    fs.root.getFile("aa.txt", {create: true}, function(fileentry)
    {
      console.log("Full path before move: " + fileentry.fullPath);
      fileentry.moveTo(direntry, "newname.txt", successCallback);
    });
  });
});
```

Output example:

```
Full path before move: /aa.txt
Full path to the moved file: /testDirectory/newname.txt
```

`**copyTo **`Copy an entry to a different location on the file system.

```javascript
void copyTo(DirectoryEntry parent, optional DOMString? newName, optional EntryCallback? onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

It is an error to try to:

- copy a directory inside itself or to any child at any depth
- copy an entry into its parent if a name different from its current one isn't provided
- copy a file to a path occupied by a directory
- copy a directory to a path occupied by a file
- copy any element to a path occupied by a directory which is not empty
A copy of a file on top of an existing file must attempt to delete and replace that file.
A copy of a directory on top of an existing empty directory must attempt to delete and replace that directory.
Directory copies are always recursive--that is, they copy all contents of the directory.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **parent :
    The directory to which to copy the entry. **
- **newName [optional] [nullable] :
   The new name of the entry. Defaults to the Entry's current name if unspecified. **
- **onsuccess [optional] [nullable] :
 A callback that is called with the Entry for the new location. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
successCallback = function(entry)
{
  console.log("Full path to the copied file: " + entry.fullPath);
};
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getDirectory("testDirectory", {create: true}, function(direntry)
  {
    fs.root.getFile("test.txt", {create: true}, function(fileentry)
    {
      fileentry.copyTo(direntry, "newname.txt", successCallback);
    });
  });
});
```

Output example:

```
Full path to the copied file: /testDirectory/newname.txt
```

`**getParent **`Look up the parent DirectoryEntry containing this Entry. If this Entry is the root of its filesystem, its parent is itself.

```javascript
void getParent(EntryCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 A callback that is called to return the parent Entry. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getParent(function(entry)
  {
    console.log("Success");
  });
});
```

Output example:

```
Success
```

`**remove **`Deletes a file or directory. It is an error to attempt to delete a directory that is not empty. It is an error to attempt to delete the root directory of a filesystem.

```javascript
void remove(VoidCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **onsuccess :
 A callback that is called on success. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getFile("test.txt", {create: true}, function(fileEntry)
  {
    fileEntry.remove(function()
    {
      console.log("Success");
    });
  });
});
```

Output example:

```
Success
```

`**toURL **`Returns a URL that can be used to identify this entry. Unlike the URN defined in [FILE-API-ED], it has no specific expiration; as it describes a location on disk, it should be valid at least as long as that location exists.

```javascript
DOMString toURL();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Return value:

DOMString: URL that can be used to identify this entry.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getDirectory("testDirectory", {create: true}, function(entry)
  {
    var url = entry.toURL();
    console.log("URL: " + url);
  });
});
```

Output example:

```
URL: file:///home/owner/apps_rw/WfigBlWDyf/tmp/testDirectory/
```

### 2.12. DirectoryEntry

The DirectoryEntry interface provides access to the Filesystem API.

```webidl
  interface DirectoryEntry : Entry {
    DirectoryReader createReader();
    void getDirectory(DOMString path, optional ? options, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                      raises(FileException);
    void getFile(DOMString path, optional ? options, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                 raises(FileException);
    void removeRecursively(VoidCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
  };
```

Since: 3.0

#### Methods

`**createReader **`Creates a new DirectoryReader to read Entries from this Directory.

```javascript
DirectoryReader createReader();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Return value:

DirectoryReader: DirectoryReader.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(entry)
{
  entry.root.getDirectory("MyDocument", {create: true}, function(dirEntry)
  {
    var directoryReader = dirEntry.createReader();
  });
});
```

`**getDirectory **`Creates or looks up a directory.

```javascript
void getDirectory(DOMString path, optional ? options, optional EntryCallback? onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

- If create and exclusive are both true and the path already exists, getDirectory must fail.
- If create is true, the path doesn't exist, and no other error occurs, getDirectory must create and return a corresponding DirectoryEntry.
- If create is not true and the path doesn't exist, getDirectory must fail.
- If create is not true and the path exists, but is a file, getDirectory must fail.
- Otherwise, if no other error occurs, getDirectory must return a DirectoryEntry corresponding to path.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **path :
 Either an absolute path or a relative path from this DirectoryEntry to the directory to be looked up or created. It is an error to attempt to create a directory whose immediate parent does not yet exist. **
- **options [optional] [nullable] :
 Flags. **
- **onsuccess [optional] [nullable] :
 A callback that is called to return the DirectoryEntry selected or created. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getDirectory("ert", {create: true}, function(dir)
  {
    console.log("Created dir: " + dir.name);
  });
});
```

Output example:

```
Created dir: ert
```

`**getFile **`Creates or looks up a file.

```javascript
void getFile(DOMString path, optional ? options, optional EntryCallback? onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

- If create and exclusive are both true, and the path already exists, getFile must fail.
- If create is true, the path doesn't exist, and no other error occurs, getFile must create it as a zero-length file and return a corresponding FileEntry.
- If create is not true and the path doesn't exist, getFile must fail.
- If create is not true and the path exists, but is a directory, getFile must fail.
- Otherwise, if no other error occurs, getFile must return a FileEntry corresponding to path.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **path :
 Either an absolute path or a relative path from this DirectoryEntry to the file to be looked up or created. It is an error to attempt to create a file whose immediate parent does not yet exist. **
- **options [optional] [nullable] :
 Flags. **
- **onsuccess [optional] [nullable] :
 A callback that is called to return the File selected or created. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getFile("qa.txt", {create: true}, function(file)
  {
    console.log("Created file: " + file.name);
  });
});
```

Output example:

```
Created file: qa.txt
```

`**removeRecursively **`Deletes a directory and all of its contents, if any. In the event of an error [e.g. trying to delete a directory that contains a file that cannot be removed], some of the contents of the directory may be deleted. It is an error to attempt to delete the root directory of a filesystem.

```javascript
void removeRecursively(VoidCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **onsuccess :
 A callback that is called on success. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getDirectory("testDirectory", {create: true}, function(directoryEntry)
  {
    directoryEntry.removeRecursively(function()
    {
      console.log("Success");
    });
  });
});
```

Output example:

```
Success
```

### 2.13. DirectoryReader

The DirectoryReader interface provides access to the Filesystem API.

```webidl
  [NoInterfaceObject] interface DirectoryReader {
    void readEntries(EntriesCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**readEntries **`Read the next block of entries from this directory.

```javascript
void readEntries(EntriesCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 Called once per successful call to readEntries to deliver the next previously-unreported set of Entries in the associated Directory. If all Entries have already been returned from previous invocations of readEntries, successCallback must be called with a zero-length array as an argument. **
- **onerror [optional] [nullable] :
   A callback indicating that there was an error reading from the Directory. **

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  var a = fs.root.createReader();
  a.readEntries(function successCallback(entries)
  {
    console.log("Success");
  });
});
```

Output example:

```
Success
```

### 2.14. FileEntry

The FileEntry interface provides access to the Filesystem API.

```webidl
  [NoInterfaceObject] interface FileEntry : Entry {
    void createWriter(FileWriterCallback onsuccess, optional ErrorCallback? onerror);
    void file(FileCallback onsuccess, optional ErrorCallback onerror);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**createWriter **`Creates a new FileWriter associated with the file that this FileEntry represents.

```javascript
void createWriter(FileWriterCallback onsuccess, optional ErrorCallback? onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **onsuccess :
 A callback that is called with the new FileWriter. **
- **onerror [optional] [nullable] :
   Callback method to be invoked when an error has occurred. **

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getFile("logFile.txt", {create: true}, function(f)
  {
    f.createWriter(function(fileWriter)
    {
      fileWriter.write(new Blob(["hello"]));
      fileWriter.onerror = function(e)
      {
        console.log("Write file failed:" + e);
      };
      fileWriter.onwriteend = function()
      {
        console.log("Success");
      };
    });
  });
});
```

Output example:

```
Success
```

`**file **`Returns a File that represents the current state of the file that this FileEntry represents.

```javascript
void file(FileCallback onsuccess, optional ErrorCallback onerror);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 A callback that is called with the File. **
- **onerror [optional] :
   Callback method to be invoked when an error has occurred. **

Code example:

```javascript
requestFileSystem(TEMPORARY, 100, function(fs)
{
  fs.root.getFile("abcdz.txt", {create: true}, function(f)
  {
    f.file(function(file)
    {
      console.log("Success");
    });
  });
});
```

Output example:

```
Success
```

### 2.15. FileReader

The FileReader interface provides access to capabilities of reading *Blob *objects.

```webidl
  [Constructor()]
  interface FileReader {
    const short EMPTY = 0;
    const short LOADING = 1;
    const short DONE = 2;
    readonly attribute short readyState;
    readonly attribute ReadResultData? result;
    readonly attribute FileError? error;
    attribute ProgressCallback? onloadstart;
    attribute ProgressCallback? onload;
    attribute ProgressCallback? onabort;
    attribute ProgressCallback? onerror;
    attribute ProgressCallback? onloadend;
    void abort();
    void readAsDataURL(Blob blob) raises(TypeError, FileError);
    void readAsText(Blob blob, optional DOMString? label) raises(TypeError, FileError);
    void readAsBinaryString(Blob blob) raises(TypeError, FileError);
    void readAsArrayBuffer(Blob blob) raises(TypeError, FileError);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
var deviceReady, fileReader;
deviceReady = function()
{
  fileReader = new FileReader();
};
document.addEventListener("deviceready", deviceReady, true);
```

#### Constructors

`**Constructor () **`
```webidl
FileReader();
```

#### Constants

- EMPTY The FileReader object has been constructed, and there are no pending reads. None of the read methods have been called.
This is the default state of a newly minted FileReader object, until one of the read methods have been called on it.

Since: 3.0

- LOADING A File or Blob is being read. One of the read methods is being processed, and no error has occurred during the read.

Since: 3.0

- DONE The entire File or Blob has been read into memory, OR a file error occurred during read, OR the read was aborted using abort().
The FileReader is no longer reading a File or Blob. If readyState is set to DONE it means at least one of the read methods have been called on this FileReader.

Since: 3.0

#### Attributes

- readonly short readyState The state of FileReader. Possible values are *FileReader.EMPTY *, *FileReader.LOADING *or *FileReader.DONE *.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly ReadResultData result [nullable] The contents of the file, that have been read.
Returns a Blob's data as a DOMString, or byte[], or null, depending on the read method that has been called on the FileReader. It is *null *if any errors occurred.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly FileError error [nullable] An object describing error, if any occurred.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onloadstart [nullable] Callback, which is triggered, when the read starts.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onload [nullable] Callback, which is triggered, when the read has successfully completed.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onabort [nullable] Callback, which is triggered, when the read has been aborted. For instance, by invoking the abort() method.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onerror [nullable] Callback, which is triggered, when the read has failed.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onloadend [nullable] Callback, which is triggered, when the request has completed (either in success or failure).

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**abort **`Aborts current operation of reading file.

```javascript
void abort();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
var blob = new Blob(["abc"]);
var fileReader = new FileReader();
fileReader.onload = function()
{
  console.log("Loaded");
};
fileReader.onabort = function()
{
  console.log("Aborted");
};
fileReader.readAsDataURL(blob);
fileReader.abort();
```

Output example:

```
Aborted
```

`**readAsDataURL **`Reads file and return data as a base64-encoded data URL.

```javascript
void readAsDataURL(Blob blob);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **blob :
 The *Blob *object to be read as data URL. **

Exceptions:

- TypeError
- if input parameter is missing.

- FileError
- with error type INVALID_STATE_ERR, if it is already reading a file.

Code example:

```javascript
var blob = new Blob(["abc"]);
var fileReader = new FileReader();
fileReader.onload = function()
{
  console.log("Loaded, result = " + fileReader.result);
};
fileReader.readAsDataURL(blob);
```

Output example:

```
Loaded, result = data:;base64,YWJj
```

`**readAsText **`Reads text file.

```javascript
void readAsText(Blob blob, optional DOMString? label);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **blob :
 The *Blob *object to be read as text. **
- **label [optional] [nullable] :
 An optional argument, that represents the label of an encoding. **

Exceptions:

- TypeError
- if input parameter is missing.

- FileError
- with error type INVALID_STATE_ERR, if it is already reading a file.

Code example:

```javascript
var blob = new Blob(["abc"]);
var fileReader = new FileReader();
fileReader.onload = function()
{
  console.log("Loaded, result = " + fileReader.result);
};
fileReader.readAsText(blob);
```

Output example:

```
Loaded, result = abc
```

`**readAsBinaryString **`Reads file as binary and returns a binary string.

```javascript
void readAsBinaryString(Blob blob);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **blob :
 The *Blob *object to be read as binary. **

Exceptions:

- TypeError
- if input parameter is missing.

- FileError
- with error type INVALID_STATE_ERR, if it is already reading a file.

Code example:

```javascript
var blob = new Blob(["abc"]);
var fileReader = new FileReader();
fileReader.onload = function()
{
  console.log("Loaded, result = " + fileReader.result);
};
fileReader.readAsBinaryString(blob);
```

Output example:

```
Loaded, result = abc
```

`**readAsArrayBuffer **`Reads file as an array buffer and result would be *byte[] *.

```javascript
void readAsArrayBuffer(Blob blob);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **blob :
 The *Blob *object to be read as array buffer. **

Exceptions:

- TypeError
- if input parameter is missing.

- FileError
- with error type INVALID_STATE_ERR, if it is already reading a file.

Code example:

```javascript
var blob = new Blob(["abc"]);
var fileReader = new FileReader();
fileReader.onload = function()
{
  resultValue = fileReader.result;
  console.log("Result: " + resultValue.toString() + "
" +
              "ByteLength: " + resultValue.byteLength);
};
fileReader.readAsArrayBuffer(blob);
```

Output example:

```
Result: [object ArrayBuffer]
ByteLength: 3
```

### 2.16. FileWriter

FileWriter interface allows to create and write data to file.

```webidl
  [NoInterfaceObject] interface FileWriter {
    const short INIT = 0;
    const short WRITING = 1;
    const short DONE = 2;
    attribute short readyState;
    attribute DOMString fileName;
    attribute long length;
    attribute long position;
    attribute FileError? error;
    attribute ProgressCallback? onwritestart;
    attribute ProgressCallback? onwrite;
    attribute ProgressCallback? onabort;
    attribute ProgressCallback? onerror;
    attribute ProgressCallback? onwriteend;
    void abort() raises(FileException);
    void seek(long offset) raises(FileException);
    void truncate(long size) raises(FileException);
    void write(WriteData data) raises(FileException);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Constants

- INIT
- WRITING
- DONE Above constants describe current state of FileWriter object.

Since: 3.0

#### Attributes

- short readyState One of the three possible states, either INIT, WRITING, or DONE.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- DOMString fileName The name of the file to be written.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- long length The length of the file to be written.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- long position The current position of the file pointer.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- FileError error [nullable] An object containing errors.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onwritestart [nullable] Called when the write starts.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onwrite [nullable] Called when the request has completed successfully.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onabort [nullable] Called when the write has been aborted. For instance, by invoking the abort() method.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onerror [nullable] Called when the write has failed.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- ProgressCallback onwriteend [nullable] Called when the request has completed (either in success or failure).

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**abort **`Aborts writing the file.

```javascript
void abort();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Exceptions:

- FileException
- with error type TYPE_MISMATCH_ERR, if any of the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
successCallback = function(writer)
{
  writer.onwrite = function(evt)
  {
    console.log("Write success");
  };
  writer.onabort = function(e)
  {
    console.log("Abort");
  };
  writer.write("some sample text");
  writer.abort();
};

errorCallback = function(err)
{
  console.log(err.code);
};

/* entry is FileEntry object retrieved by getFile() method of DirectoryEntry interface. */
entry.createWriter(successCallback, errorCallback);
```

Output example:

```
Abort
```

`**seek **`Moves the file pointer to the specified byte.

```javascript
void seek(long offset);
```

Since: 3.0

If the offset is a negative number the position of the file pointer is rewound. If the offset is greater than the file size the position is set to the end of the file.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **offset :
 Location to move the file pointer to. **

Exceptions:

- FileException
- with error type INVALID_STATE_ERR, if it is already writing a file.

Code example:

```javascript
successCallback = function(writer)
{
  /* Fast forwards file pointer to the end of file. */
  writer.seek(writer.length);
};

errorCallback = function(err)
{
  console.log(err.code);
};

/* entry is FileEntry object retrieved by getFile() method of DirectoryEntry interface. */
entry.createWriter(successCallback, errorCallback);
```

`**truncate **`Shortens the file to the specified length.

```javascript
void truncate(long size);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **size :
 Size to chop the file at. **

Exceptions:

- FileException
- with error type INVALID_STATE_ERR, if it is already writing a file.

Code example:

```javascript
successCallback = function(writer)
{
  writer.onwrite = function(evt)
  {
    console.log("truncate success");
  };

  writer.truncate(10);
};

errorCallback = function(err)
{
  console.log(err.code);
};

/* entry is FileEntry object retrieved by getFile() method of DirectoryEntry interface. */
entry.createWriter(successCallback, errorCallback);
```

Output example:

```
truncate success
```

`**write **`Writes data to the file.

```javascript
void write(WriteData data);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Privilege: http://tizen.org/privilege/filesystem.write

Parameters:

- **data :
 Text or Blob to be written. **

Exceptions:

- FileException
- with error type INVALID_STATE_ERR, if it is already writing a file.

Code example:

```javascript
successCallback = function(writer)
{
  writer.onwrite = function(evt)
  {
    console.log("Write success");
  };

  writer.write("some sample text");
};

errorCallback = function(err)
{
  console.log(err.code);
};

/* entry is FileEntry object retrieved by getFile() method of DirectoryEntry interface. */
entry.createWriter(successCallback, errorCallback);
```

Output example:

```
Write success
```

### 2.17. ProgressCallback

The interface that defines a callback function which is called with the ProgressEvent object.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ProgressCallback {
    void onsuccess(ProgressEvent event);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called with a ProgressEvent object.

```javascript
void onsuccess(ProgressEvent event);
```

Since: 3.0

Parameters:

- **event :
 A progress event. **

### 2.18. FileSystemCallback

The FileSystemCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface FileSystemCallback {
    void handleEvent(FileSystem filesystem);
  };
```

Since: 3.0

Remark: Example of using can be find at FileSystem code example.

#### Methods

`**handleEvent **`Called when the file system was successfully obtained.

```javascript
void handleEvent(FileSystem filesystem);
```

Since: 3.0

Parameters:

- **filesystem :
 FileSystem The file systems to which the app is granted access. **

### 2.19. EntryCallback

The EntryCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface EntryCallback {
    void handleEvent(Entry entry);
  };
```

Since: 3.0

Remark: Example of using can be find at DirectoryEntry::getDirectory code example.

#### Methods

`**handleEvent **`Used to supply an Entry as a response to a user query.

```javascript
void handleEvent(Entry entry);
```

Since: 3.0

Parameters:

- **entry :
 Entry. **

### 2.20. EntriesCallback

The EntriesCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface EntriesCallback {
    void handleEvent(Entry[] entries);
  };
```

Since: 3.0

Remark: Example of using can be find at DirectoryReader::readEntries code example.

#### Methods

`**handleEvent **`Used to supply an array of Entries as a response to a user query.

```javascript
void handleEvent(Entry[] entries);
```

Since: 3.0

Parameters:

- **entries :
 Entry[]. **

### 2.21. MetadataCallback

The MetadataCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface MetadataCallback {
    void handleEvent(Metadata metadata);
  };
```

Since: 3.0

Remark: Example of using can be find at Entry::getMetadata code example.

#### Methods

`**handleEvent **`Used to supply file or directory metadata as a response to a user query.

```javascript
void handleEvent(Metadata metadata);
```

Since: 3.0

Parameters:

- **metadata :
 Metadata. **

### 2.22. FileWriterCallback

The FileWriterCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface FileWriterCallback {
    void handleEvent(FileWriter fileWriter);
  };
```

Since: 3.0

Remark: Example of using can be find at FileEntry::createWriter code example.

#### Methods

`**handleEvent **`Used to supply a FileWriter as a response to a user query.

```javascript
void handleEvent(FileWriter fileWriter);
```

Since: 3.0

Parameters:

- **fileWriter :
 FileWriter. **

### 2.23. FileCallback

The FileCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface FileCallback {
    void handleEvent(File file);
  };
```

Since: 3.0

Remark: Example of using can be find at FileEntry::file code example.

#### Methods

`**handleEvent **`Used to supply a File as a response to a user query.

```javascript
void handleEvent(File file);
```

Since: 3.0

Parameters:

- **file :
 File. **

### 2.24. VoidCallback

The VoidCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface VoidCallback {
    void handleEvent();
  };
```

Since: 3.0

Remark: Example of using can be find at Entry::remove code example.

#### Methods

`**handleEvent **`.

```javascript
void handleEvent();
```

Since: 3.0

### 2.25. ErrorCallback

The ErrorCallback interface.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void handleEvent(FileError err);
  };
```

Since: 3.0

Remark: Example of using can be find at Entry::getMetadata code example.

#### Methods

`**handleEvent **`There was an error with the request. Details are provided by the FileError parameter.

```javascript
void handleEvent(FileError err);
```

Since: 3.0

Parameters:

- **err :
 FileError. **

## 3. Full WebIDL

```webidl
module File {
  typedef Blob Blob;
  typedef (Blob or DOMString) WriteData;
  typedef (DOMString or byte[]) ReadResultData;
  dictionary FilePropertyBag {
    DOMString type;
    long long lastModified;
  };
  dictionary ProgressEventInit {
    unsigned long long loaded = false;
    unsigned long long total = false;
    EventTarget target = null;
  };
  Cordova implements FileSystemManagerObject;
  Window implements LocalFileSystem;
  [Constructor(DOMString type, optional ProgressEventInit eventInitDict)]
  interface ProgressEvent {
    readonly attribute DOMString type;
    readonly attribute boolean bubbles;
    readonly attribute boolean cancelBubble;
    readonly attribute boolean cancelable;
    readonly attribute boolean lengthComputable;
    readonly attribute unsigned long long loaded;
    readonly attribute unsigned long long total;
    readonly attribute EventTarget target;
  };
  [NoInterfaceObject] interface FileSystemManagerObject {
    readonly attribute FileSystemManager file;
  };
  [NoInterfaceObject] interface FileSystemManager {
    readonly attribute DOMString? applicationDirectory;
    readonly attribute DOMString? applicationStorageDirectory;
    readonly attribute DOMString? dataDirectory;
    readonly attribute DOMString? cacheDirectory;
    readonly attribute DOMString? externalApplicationStorageDirectory;
    readonly attribute DOMString? externalDataDirectory;
    readonly attribute DOMString? externalCacheDirectory;
    readonly attribute DOMString? externalRootDirectory;
    readonly attribute DOMString? tempDirectory;
    readonly attribute DOMString? syncedDataDirectory;
    readonly attribute DOMString? documentsDirectory;
    readonly attribute DOMString? sharedDirectory;
  };
  [NoInterfaceObject] interface FileSystem {
    readonly attribute DOMString name;
    readonly attribute DirectoryEntry root;
  };
  interface Metadata {
    readonly attribute Date modificationTime;
    readonly attribute unsigned long long size;
  };
  [NoInterfaceObject] interface FileError {
    const unsigned short NOT_FOUND_ERR = 1;
    const unsigned short SECURITY_ERR = 2;
    const unsigned short ABORT_ERR = 3;
    const unsigned short NOT_READABLE_ERR = 4;
    const unsigned short ENCODING_ERR = 5;
    const unsigned short NO_MODIFICATION_ALLOWED_ERR = 6;
    const unsigned short INVALID_STATE_ERR = 7;
    const unsigned short SYNTAX_ERR = 8;
    const unsigned short INVALID_MODIFICATION_ERR = 9;
    const unsigned short QUOTA_EXCEEDED_ERR = 10;
    const unsigned short TYPE_MISMATCH_ERR = 11;
    const unsigned short PATH_EXISTS_ERR = 12;
    attribute unsigned short code;
  };
  [NoInterfaceObject] interface File {
    readonly attribute DOMString name;
    readonly attribute DOMString localURL;
    readonly attribute DOMString type;
    readonly attribute Date lastModified;
    readonly attribute long long size;
  };
  [NoInterfaceObject] interface LocalFileSystem {
    const short TEMPORARY = 0;
    const short PERSISTENT = 1;
    void requestFileSystem(short type, long long size, optional FileSystemCallback? successCallback,
                           optional ErrorCallback? errorCallback) raises(TypeError);
    void resolveLocalFileSystemURL(DOMString uri, optional EntryCallback? successCallback, optional ErrorCallback? errorCallback)
                                   raises(TypeError);
  };
  [NoInterfaceObject] interface Entry {
    readonly attribute boolean isFile;
    readonly attribute boolean isDirectory;
    readonly attribute DOMString fullPath;
    readonly attribute DOMString name;
    readonly attribute FileSystem filesystem;
    void getMetadata(MetadataCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
    void moveTo(DirectoryEntry parent, optional DOMString? newName, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                raises(FileException);
    void copyTo(DirectoryEntry parent, optional DOMString? newName, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                raises(FileException);
    void getParent(EntryCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
    void remove(VoidCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
    DOMString toURL();
  };
  interface DirectoryEntry : Entry {
    DirectoryReader createReader();
    void getDirectory(DOMString path, optional ? options, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                      raises(FileException);
    void getFile(DOMString path, optional ? options, optional EntryCallback? onsuccess, optional ErrorCallback? onerror)
                 raises(FileException);
    void removeRecursively(VoidCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
  };
  [NoInterfaceObject] interface DirectoryReader {
    void readEntries(EntriesCallback onsuccess, optional ErrorCallback? onerror) raises(FileException);
  };
  [NoInterfaceObject] interface FileEntry : Entry {
    void createWriter(FileWriterCallback onsuccess, optional ErrorCallback? onerror);
    void file(FileCallback onsuccess, optional ErrorCallback onerror);
  };
  [Constructor()]
  interface FileReader {
    const short EMPTY = 0;
    const short LOADING = 1;
    const short DONE = 2;
    readonly attribute short readyState;
    readonly attribute ReadResultData? result;
    readonly attribute FileError? error;
    attribute ProgressCallback? onloadstart;
    attribute ProgressCallback? onload;
    attribute ProgressCallback? onabort;
    attribute ProgressCallback? onerror;
    attribute ProgressCallback? onloadend;
    void abort();
    void readAsDataURL(Blob blob) raises(TypeError, FileError);
    void readAsText(Blob blob, optional DOMString? label) raises(TypeError, FileError);
    void readAsBinaryString(Blob blob) raises(TypeError, FileError);
    void readAsArrayBuffer(Blob blob) raises(TypeError, FileError);
  };
  [NoInterfaceObject] interface FileWriter {
    const short INIT = 0;
    const short WRITING = 1;
    const short DONE = 2;
    attribute short readyState;
    attribute DOMString fileName;
    attribute long length;
    attribute long position;
    attribute FileError? error;
    attribute ProgressCallback? onwritestart;
    attribute ProgressCallback? onwrite;
    attribute ProgressCallback? onabort;
    attribute ProgressCallback? onerror;
    attribute ProgressCallback? onwriteend;
    void abort() raises(FileException);
    void seek(long offset) raises(FileException);
    void truncate(long size) raises(FileException);
    void write(WriteData data) raises(FileException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ProgressCallback {
    void onsuccess(ProgressEvent event);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface FileSystemCallback {
    void handleEvent(FileSystem filesystem);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface EntryCallback {
    void handleEvent(Entry entry);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface EntriesCallback {
    void handleEvent(Entry[] entries);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface MetadataCallback {
    void handleEvent(Metadata metadata);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface FileWriterCallback {
    void handleEvent(FileWriter fileWriter);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface FileCallback {
    void handleEvent(File file);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface VoidCallback {
    void handleEvent();
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void handleEvent(FileError err);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
