# NetworkInformation API

This plugin provides information about the device's cellular and wifi connection, and whether the device has an internet connection.

Original documentation: Cordova Network Information .

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. NetworkInformationManagerObject
- 1.2. NetworkInformationManager
- 1.3. Connection
- 1.4. OnlineEventCallback
- 1.5. OfflineEventCallback
- 2. Related Feature
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| NetworkInformationManagerObject |  |
| NetworkInformationManager |  |
| Connection |  |
| OnlineEventCallback | void online () |
| OfflineEventCallback | void offline () |

## 1. Interfaces

### 1.1. NetworkInformationManagerObject

The *NetworkInformationManagerObject *interface defines what is instantiated in the *Navigator *object.

```webidl
  [NoInterfaceObject] interface NetworkInformationManagerObject {
    readonly attribute NetworkInformationManager connection;
  };
```

```webidl
  Navigator implements NetworkInformationManagerObject;
```

Since: 3.0

The *navigator.connection *object allows access to the NetworkInformation API.

### 1.2. NetworkInformationManager

The *NetworkInformationManager *interface provides methods for global operations related to notifications to the user.

```webidl
  [NoInterfaceObject] interface NetworkInformationManager {
    readonly attribute DOMString type;
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Attributes

- readonly DOMString type Returns the current connection type. The value returned is one of the following strings, case-sensitively: unknown, ethernet, wifi, 2g, 3g, 4g, none.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/telephony

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
function checkConnection()
{
  var networkState = navigator.connection.type;

  var states = {};
  states[Connection.UNKNOWN] = "Unknown connection";
  states[Connection.ETHERNET] = "Ethernet connection";
  states[Connection.WIFI] = "WiFi connection";
  states[Connection.CELL_2G] = "Cell 2G connection";
  states[Connection.CELL_3G] = "Cell 3G connection";
  states[Connection.CELL_4G] = "Cell 4G connection";
  states[Connection.CELL] = "Cell generic connection";
  states[Connection.NONE] = "No network connection";
  alert("Connection type: " + states[networkState]);
}

checkConnection();
```

Output example:

```
Connection type: Cell 3G connection
```

### 1.3. Connection

The *Connection *is available as window attribute.

```webidl
  interface Connection {
    readonly attribute DOMString UNKNOWN;
    readonly attribute DOMString ETHERNET;
    readonly attribute DOMString WIFI;
    readonly attribute DOMString CELL_2G;
    readonly attribute DOMString CELL_3G;
    readonly attribute DOMString CELL_4G;
    readonly attribute DOMString CELL;
    readonly attribute DOMString NONE;
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Attributes

- readonly DOMString UNKNOWN The value returned is "unknown".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.UNKNOWN);
```

Output example:

```
unknown
```

- readonly DOMString ETHERNET The value returned is "ethernet".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.ETHERNET);
```

Output example:

```
ethernet
```

- readonly DOMString WIFI The value returned is "wifi".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.WIFI);
```

Output example:

```
wifi
```

- readonly DOMString CELL_2G The value returned is "2g".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.CELL_2G);
```

Output example:

```
2g
```

- readonly DOMString CELL_3G The value returned is "3g".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.CELL_3G);
```

Output example:

```
3g
```

- readonly DOMString CELL_4G The value returned is "4g".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.CELL_4G);
```

Output example:

```
4g
```

- readonly DOMString CELL The value returned is "cellular".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.CELL);
```

Output example:

```
cellular
```

- readonly DOMString NONE The value returned is "none".

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
console.log(Connection.NONE);
```

Output example:

```
none
```

### 1.4. OnlineEventCallback

Callback for the event when an application goes online, and the device becomes connected to the Internet.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface OnlineEventCallback {
    void online();
  };
```

Since: 3.0

The online event fires when an application goes online, and the device becomes connected to the Internet.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova online event

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("online", onOnline, false);
}

function onOnline()
{
  /* Handle the online event. */
}
```

#### Methods

`**online **`Called when an application goes online.

```javascript
void online();
```

Since: 3.0

### 1.5. OfflineEventCallback

Callback for the event when an application goes offline, and the device is not connected to the Internet.

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface OfflineEventCallback {
    void offline();
  };
```

Since: 3.0

The online event fires when an application goes online, and the device becomes connected to the Internet.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova offline event

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("offline", onOffline, false);
}

function onOffline()
{
  /* Handle the offline event. */
}
```

#### Methods

`**offline **`Called when an application goes offline.

```javascript
void offline();
```

Since: 3.0

## 2. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the NetworkInformation application runs on a device with the NetworkInformation feature declare the following feature requirements in the config file:

- http://tizen.org/feature/network.telephony

For more information, see Application Filtering.
## 3. Full WebIDL

```webidl
module NetworkInformation {
  Navigator implements NetworkInformationManagerObject;
  [NoInterfaceObject] interface NetworkInformationManagerObject {
    readonly attribute NetworkInformationManager connection;
  };
  [NoInterfaceObject] interface NetworkInformationManager {
    readonly attribute DOMString type;
  };
  interface Connection {
    readonly attribute DOMString UNKNOWN;
    readonly attribute DOMString ETHERNET;
    readonly attribute DOMString WIFI;
    readonly attribute DOMString CELL_2G;
    readonly attribute DOMString CELL_3G;
    readonly attribute DOMString CELL_4G;
    readonly attribute DOMString CELL;
    readonly attribute DOMString NONE;
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface OnlineEventCallback {
    void online();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface OfflineEventCallback {
    void offline();
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
