# Time API

The Time API provides information regarding date/time and time zones.

The JavaScript Date object does not have full timezone support.
Date objects allow only simple representations to denote a particular location's
offset from Universal Coordinated Time (UTC). This is typically provided as a +/-
offset from UTC-0 (also known as Greenwich Mean Time, or GMT) for example, +05:30 denotes
that a location is 5 hours and 30 minutes ahead of UTC +00:00.
The issue with this method is not getting the correct
local time for a given date. The existing methods are sufficient for this purpose.
The issue is correctly converting to and from local time and UTC for all points in
time - in any of the past, present, and future - based on an initial time provided.
This is important for defining relative dates, where a time in a given location may
observe different UTC offsets, according to any Daylight Savings Rules (DST) in effect
or any other changes that may occur to a location's time zone over time.
Without the communication of the explicit time zone rules governing a given date and
time, the ability to effectively calculate the offset of the local time to UTC or to
any other time zone at any point in the past or future is lost.

This API can be used to get TZDate objects with full time zone support, convert them
between timezones, retrieve available timezones.

For more information on the Time features, see Time Guide .

Since: 1.0

## Table of Contents

- 1. Type Definitions
- 1.1. TimeDurationUnit
- 2. Interfaces
- 2.1. TimeManagerObject
- 2.2. TimeUtil
- 2.3. TZDate
- 2.4. TimeDuration
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| TimeManagerObject |  |
| TimeUtil | TZDate getCurrentDateTime () DOMString getLocalTimezone () DOMString[] getAvailableTimezones () DOMString getDateFormat (optional boolean? shortformat) DOMString getTimeFormat () boolean isLeapYear (long year) void setDateTimeChangeListener ( SuccessCallback changeCallback) void unsetDateTimeChangeListener () void setTimezoneChangeListener ( SuccessCallback changeCallback) void unsetTimezoneChangeListener () |
| TZDate | long getDate () void setDate (long date) long getDay () long getFullYear () void setFullYear (long year) long getHours () void setHours (long hours) long getMilliseconds () void setMilliseconds (long ms) long getMinutes () void setMinutes (long minutes) long getMonth () void setMonth (long month) long getSeconds () void setSeconds (long seconds) long getUTCDate () void setUTCDate (long date) long getUTCDay () long getUTCFullYear () void setUTCFullYear (long year) long getUTCHours () void setUTCHours (long hours) long getUTCMilliseconds () void setUTCMilliseconds (long ms) long getUTCMinutes () void setUTCMinutes (long minutes) long getUTCMonth () void setUTCMonth (long month) long getUTCSeconds () void setUTCSeconds (long seconds) DOMString getTimezone () TZDate toTimezone (DOMString tzid) TZDate toLocalTimezone () TZDate toUTC () TimeDuration difference ( TZDate other) boolean equalsTo ( TZDate other) boolean earlierThan ( TZDate other) boolean laterThan ( TZDate other) TZDate addDuration ( TimeDuration duration) DOMString toLocaleDateString () DOMString toLocaleTimeString () DOMString toLocaleString () DOMString toDateString () DOMString toTimeString () DOMString toString () long secondsFromUTC () boolean isDST () TZDate ? getPreviousDSTTransition () TZDate ? getNextDSTTransition () |
| TimeDuration | TimeDuration difference ( TimeDuration other) boolean equalsTo ( TimeDuration other) boolean lessThan ( TimeDuration other) boolean greaterThan ( TimeDuration other) |

## 1. Type Definitions

### 1.1. TimeDurationUnit

Specifies the TimeDuration unit (milliseconds, seconds, minutes, hours or days).

```webidl
  enum TimeDurationUnit { "MSECS", "SECS", "MINS", "HOURS", "DAYS" };
```

Since: 1.0

At least the following values must be supported:

- MSECS - Indicates a duration in milliseconds
- SECS - Indicates a duration in seconds
- MINS - Indicates a duration in minutes
- HOURS - Indicates a duration in hours
- DAYS - Indicates a duration in days

## 2. Interfaces

### 2.1. TimeManagerObject

The TimeManagerObject interface defines what is instantiated in the tizen object by the Tizen Platform.

```webidl
  [NoInterfaceObject] interface TimeManagerObject {
    readonly attribute TimeUtil time;
  };
```

```webidl
  Tizen implements TimeManagerObject;
```

Since: 1.0

There will be a *tizen.time *object that allows accessing the
functionality of the Time API.

#### Attributes

- readonly TimeUtil time Object representing a time manager.

Since: 1.0

### 2.2. TimeUtil

The TimeUtil interface that provides access to the time API.

```webidl
  [NoInterfaceObject] interface TimeUtil {
    TZDate getCurrentDateTime() raises(WebAPIException);
    DOMString getLocalTimezone() raises(WebAPIException);
    DOMString[] getAvailableTimezones() raises(WebAPIException);
    DOMString getDateFormat(optional boolean? shortformat) raises(WebAPIException);
    DOMString getTimeFormat() raises(WebAPIException);
    boolean isLeapYear(long year) raises(WebAPIException);
    void setDateTimeChangeListener(SuccessCallback changeCallback) raises(WebAPIException);
    void unsetDateTimeChangeListener() raises(WebAPIException);
    void setTimezoneChangeListener(SuccessCallback changeCallback) raises(WebAPIException);
    void unsetTimezoneChangeListener() raises(WebAPIException);
  };
```

Since: 1.0

This interface offers methods to manage date/time as well as timezones such as:

- Get the current date/time using getCurrentDateTime().
- Get timezones using getLocalTimezone() and getAvailableTimezones().

#### Methods

`**getCurrentDateTime **`Gets the current date/time.

```javascript
TZDate getCurrentDateTime();
```

Since: 1.0

Return value:

TZDate: The current TZDate object.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var current_dt = tizen.time.getCurrentDateTime();
console.log("current date/time is " + current_dt.toLocaleString());
```

`**getLocalTimezone **`Gets the identifier of the local system timezone.

```javascript
DOMString getLocalTimezone();
```

Since: 1.0

Return value:

DOMString: The local timezone.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
console.log("The local time zone is " + tizen.time.getLocalTimezone());
```

Code example:

```javascript
/* Note that it is possible to get the time zone description in other formats, e.g. by calling: */
now = new tizen.TZDate(new Date(), "Asia/Manila");
console.log(now.toString());
```

Output example:

```
Wednesday, January 27, 2016, 8:46:00 PM GMT+0800 Philippines Time
```

`**getAvailableTimezones **`Gets synchronously the identifiers of the timezones supported by the device.

```javascript
DOMString[] getAvailableTimezones();
```

Since: 1.0

Zero or more slashes separate different components of a timezone identifier,
with the most general descriptor first and the most specific one last. For example,
"Europe/Berlin", "America/Argentina/Buenos_Aires".

Return value:

DOMString[]: Array of time zone identifiers.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var tzids = tizen.time.getAvailableTimezones();
console.log("The device supports " + tzids.length + " time zones.");
```

Code example:

```javascript
var tzids = tizen.time.getAvailableTimezones();
var currentLocation = "Europe/Berlin";

/* Checks whether an entry "Europe/Berlin" exists in the array. */
if (tzids.indexOf(currentLocation) > -1)
{
  console.log("The device supports " + currentLocation + " timezone.");
}
else
{
  console.log("The device does not support " + currentLocation + " timezone.");
}
```

`**getDateFormat **`Gets the date format according to the system's locale settings.

```javascript
DOMString getDateFormat(optional boolean? shortformat);
```

Since: 1.0

These expressions may be used in the returned string:

- "d" = day number (1 to 31)
- "D" = day name
- "m" = month number (1 to 12)
- "M" = month name
- "y" = year
Examples of string formats include: "d/m/y", "y-d-m", "D, M d y".

Parameters:

- **shortformat [optional] [nullable] :
 The flag indicating whether the user is interested in the short.
date format (23/10/2011) instead of a long date format ("Monday, October 23 2011") 
By default, this attribute is set to false.
Return value:

DOMString: The date format according to the system's locale settings.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Gets the long date format, e.g. "D, M d y". */
var dateFormat = tizen.time.getDateFormat();

/* Gets the short date format, e.g. "d/m/y". */
var shortDateFormat = tizen.time.getDateFormat(true);

console.log("Long date format: " + dateFormat);
```

`**getTimeFormat **`Gets the time format according to the system's locale settings.

```javascript
DOMString getTimeFormat();
```

Since: 1.0

These expressions may be used in the returned string:

- "h" = hours (0 to 23 or 1 to 12 if AM/PM display)
- "m" = minutes (0 to 59)
- "s" = seconds (0 to 59)
- "ap" = AM/PM display
Examples of string formats include: "h:m:s ap", "h:m:s".

Return value:

DOMString: The time format according to the system's locale settings.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Gets the time format, e.g. "h:m:s ap". */
var timeFormat = tizen.time.getTimeFormat();

console.log(timeFormat);
```

`**isLeapYear **`Checks whether the given year is a leap year.

```javascript
boolean isLeapYear(long year);
```

Since: 1.0

Parameters:

- **year :
 The year to check. **

Return value:

boolean: true , if the year is a leap year.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if any of the input
parameters contain an invalid value.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var current_dt = tizen.time.getCurrentDateTime();
var is_leap = tizen.time.isLeapYear(current_dt.getFullYear());
if (is_leap)
{
  console.log("This year is a leap year.");
}
```

`**setDateTimeChangeListener **`Sets a listener to receive notification of changes to the time/date on a device.

```javascript
void setDateTimeChangeListener(SuccessCallback changeCallback);
```

Since: 2.3

Listener set with *setTimezoneChangeListener() *method is called when device time was set by the user.

Parameters:

- **changeCallback :
 Callback method to be invoked when device time was set 
It is not invoked when time passes naturally.
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var changedCallback = function()
{
  try
  {
    var current_dt = tizen.time.getCurrentDateTime();
    console.log("current date/time is " + current_dt.toLocaleString());
  }
  catch (err)
  {
    console.log(err.name + ": " + err.message);
  }
};

tizen.time.setDateTimeChangeListener(changedCallback);
```

`**unsetDateTimeChangeListener **`Unsets the listener to stop receiving notification of changes to the time/date on a device.

```javascript
void unsetDateTimeChangeListener();
```

Since: 2.3

Calling this function has no effect if listener is not set.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var changedCallback = function()
{
  try
  {
    var current_dt = tizen.time.getCurrentDateTime();
    console.log("current date/time is " + current_dt.toLocaleString());
    tizen.time.unsetDateTimeChangeListener();
  }
  catch (err)
  {
    console.log(err.name + ": " + err.message);
  }
};

tizen.time.setDateTimeChangeListener(changedCallback);
```

`**setTimezoneChangeListener **`Sets a listener to receive notification of changes to the time zone on a device.

```javascript
void setTimezoneChangeListener(SuccessCallback changeCallback);
```

Since: 2.3

Listener set with *setTimezoneChangeListener() *method is called when device time zone has changed.

Parameters:

- **changeCallback :
 Callback method that is invoked when the time zone has changed. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var changedCallback = function()
{
  try
  {
    /* New time zone can be retrieved through tizen.time.getLocalTimezone(). */
    var zone = tizen.time.getLocalTimezone();
    console.log("current time zone is " + zone);
  }
  catch (err)
  {
    console.log(err.name + ": " + err.message);
  }
};

tizen.time.setTimezoneChangeListener(changedCallback);
```

`**unsetTimezoneChangeListener **`Unsets the listener to stop receiving notification of changes to the time zone on a device.

```javascript
void unsetTimezoneChangeListener();
```

Since: 2.3

Calling this function has no effect if listener is not set.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var changedCallback = function()
{
  try
  {
    var zone = tizen.time.getLocalTimezone();
    console.log("current time zone is " + zone);
    tizen.time.unsetTimezoneChangeListener();
  }
  catch (err)
  {
    console.log(err.name + ": " + err.message);
  }
};

tizen.time.setTimezoneChangeListener(changedCallback);
```

### 2.3. TZDate

The TZDate interface represents information regarding a given date/time in a predefined timezone.
If its date/time exceeds the platform limit, TZDate will be invalid.

```webidl
  [Constructor(optional Date? datetime, optional DOMString? timezone),
   Constructor(long year, long month, long day, optional long? hours, optional long? minutes, optional long? seconds,
               optional long? milliseconds, optional DOMString? timezone)]
  interface TZDate {
    long getDate();
    void setDate(long date);
    long getDay();
    long getFullYear();
    void setFullYear(long year);
    long getHours();
    void setHours(long hours);
    long getMilliseconds();
    void setMilliseconds(long ms);
    long getMinutes();
    void setMinutes(long minutes);
    long getMonth();
    void setMonth(long month);
    long getSeconds();
    void setSeconds(long seconds);
    long getUTCDate();
    void setUTCDate(long date);
    long getUTCDay();
    long getUTCFullYear();
    void setUTCFullYear(long year);
    long getUTCHours();
    void setUTCHours(long hours);
    long getUTCMilliseconds();
    void setUTCMilliseconds(long ms);
    long getUTCMinutes();
    void setUTCMinutes(long minutes);
    long getUTCMonth();
    void setUTCMonth(long month);
    long getUTCSeconds();
    void setUTCSeconds(long seconds);
    DOMString getTimezone();
    TZDate toTimezone(DOMString tzid) raises(WebAPIException);
    TZDate toLocalTimezone() raises(WebAPIException);
    TZDate toUTC() raises(WebAPIException);
    TimeDuration difference(TZDate other) raises(WebAPIException);
    boolean equalsTo(TZDate other) raises(WebAPIException);
    boolean earlierThan(TZDate other) raises(WebAPIException);
    boolean laterThan(TZDate other) raises(WebAPIException);
    TZDate addDuration(TimeDuration duration) raises(WebAPIException);
    DOMString toLocaleDateString();
    DOMString toLocaleTimeString();
    DOMString toLocaleString();
    DOMString toDateString();
    DOMString toTimeString();
    DOMString toString();
    long secondsFromUTC() raises(WebAPIException);
    boolean isDST() raises(WebAPIException);
    TZDate? getPreviousDSTTransition() raises(WebAPIException);
    TZDate? getNextDSTTransition() raises(WebAPIException);
  };
```

Since: 1.0

Code example:

```javascript
/* Creates a new TZDate object with current date/time and timezone. */
var now = new tizen.TZDate();

/* Creates a new TZDate object with date set to 1st of January 2016 in time zone for Germany. */
var newYear = new tizen.TZDate(new Date("2016-01-01"), "Europe/Berlin");

/* Creates a new TZDate object with values set explicitly. */
var myDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/Berlin");
```

#### Constructors

`**Constructor (Date?, DOMString?) **`
```webidl
TZDate(optional Date? datetime, optional DOMString? timezone);
```

Parameters:

- **datetime [optional] [nullable] :
 Date and time passed as a javascript Date object. If this parameter is omitted, current date and time will be used. **
- **timezone [optional] [nullable] :
 The time zone identifier, e.g. "Seoul/Korea" or "Europe/Berlin". If this parameter is omitted, the device's default time zone will be used. **

`**Constructor (long, long, long, long?, long?, long?, long?, DOMString?) **`
```webidl
TZDate(long year, long month, long day, optional long? hours, optional long? minutes, optional long? seconds,
       optional long? milliseconds, optional DOMString? timezone);
```

#### Methods

`**getDate **`Gets the day of the month (from 1-31).

```javascript
long getDate();
```

Since: 1.0

Return value:

long: The day of the month.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getDate());  /* Outputs 31. */
```

`**setDate **`Sets the day of the month (from 1-31).

```javascript
void setDate(long date);
```

Since: 1.0

If the value passed as a parameter is greater than the last day of current month or smaller than 1, the TZDate will be automatically recalculated to reflect this.
For example, if TZDate's month is May and parameter is 32, it will be set to June 1.

Parameters:

- **date :
 Date to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setDate(1);              /* Changes the day of month to 1. */
console.log(someDate.getDate());  /* Outputs 1. */
```

`**getDay **`Gets the day of the week (from 0-6). 0 denotes Sunday, 1 denotes Monday and so on.

```javascript
long getDay();
```

Since: 1.0

Return value:

long: The day of the week.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getDay());  /* Outputs "5", because 31st of December 1999 was Friday. */
```

`**getFullYear **`Gets the year.

```javascript
long getFullYear();
```

Since: 1.0

Positive values indicate AD(Anno Domini) years. 0 and negative values indicate BC(Before Christ) years.
For example, 1 = AD 1, 0 = BC 1, -1 = BC 2.

Return value:

long: The year.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getFullYear());  /* Outputs 1999. */
```

`**setFullYear **`Sets the year.

```javascript
void setFullYear(long year);
```

Since: 1.0

Parameters:

- **year :
 Year to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setFullYear(2099);           /* Changes the year to 2099. */
console.log(someDate.getFullYear());  /* Outputs 2099. */
```

`**getHours **`Gets the hour (0-23).

```javascript
long getHours();
```

Since: 1.0

Return value:

long: The hour.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getHours());  /* Outputs 23. */
```

`**setHours **`Sets the hour (0-23).

```javascript
void setHours(long hours);
```

Since: 1.0

If the value passed as a parameter is greater than 23 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setHours(24) results in setting hour to 00:00 and date to the next day.

Parameters:

- **hours :
 Hours to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setHours(15);             /* Sets the hour to 3 PM. */
console.log(someDate.getHours());  /* Outputs 15. */
```

`**getMilliseconds **`Gets the milliseconds (from 0-999).

```javascript
long getMilliseconds();
```

Since: 1.0

Return value:

long: The milliseconds.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getMilliseconds());  /* Outputs 999. */
```

`**setMilliseconds **`Sets the milliseconds (from 0-999).

```javascript
void setMilliseconds(long ms);
```

Since: 1.0

If the value passed as a parameter is greater than 999 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setMilliseconds(1000) results in setting milliseconds to 0 and adding one second.

Parameters:

- **ms :
 Milliseconds to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setMilliseconds(42);
console.log(someDate.getMilliseconds());  /* Outputs 42. */
```

`**getMinutes **`Gets the minutes (from 0-59).

```javascript
long getMinutes();
```

Since: 1.0

Return value:

long: The minutes.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getMinutes());  /* Outputs 59. */
```

`**setMinutes **`Sets the minutes.

```javascript
void setMinutes(long minutes);
```

Since: 1.0

If the value passed as a parameter is greater than 59 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setMinutes(60) results in setting minutes to 0 and adding one hour.

Parameters:

- **minutes :
 Minutes to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setMinutes(58);
console.log(someDate.getMinutes());  /* Outputs 58. */
```

`**getMonth **`Gets the month (from 0-11). 
Note: January is denoted as 0, February as 1, and so on till December, which is denoted as 11.
```javascript
long getMonth();
```

Since: 1.0

Return value:

long: The month.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getMonth());  /* Outputs 11. */
```

`**setMonth **`Sets the month (from 0-11).

```javascript
void setMonth(long month);
```

Since: 1.0

If the value passed as a parameter is greater than 11 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setMonth(12) results in setting month to 0 and adding one year.

Parameters:

- **month :
 Month to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setMonth(2);              /* Changes the month to March. */
console.log(someDate.getMonth());  /* Outputs 2. */
```

`**getSeconds **`Gets the seconds (from 0-59).

```javascript
long getSeconds();
```

Since: 1.0

Return value:

long: The seconds.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getSeconds());  /* Outputs 59. */
```

`**setSeconds **`Sets the seconds (from 0-59).

```javascript
void setSeconds(long seconds);
```

Since: 1.0

If the value passed as a parameter is greater than 59 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setSeconds(60) results in setting seconds to 0 and adding one minute.

Parameters:

- **seconds :
 Seconds to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setSeconds(23);
console.log(someDate.getSeconds());  /* Outputs 23. */
```

`**getUTCDate **`Gets the day of the month, according to universal time (from 1-31).

```javascript
long getUTCDate();
```

Since: 1.0

Return value:

long: The day of the month, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCDate());  /* Outputs 31. */
```

`**setUTCDate **`Sets the day of the month, according to universal time (from 1-31).

```javascript
void setUTCDate(long date);
```

Since: 1.0

If the value passed as a parameter is greater than the last day of current month or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setUTCDate(32) when TZDate's month is May results in setting it to June 1.

Parameters:

- **date :
 Date to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCDate(5);              /* Change the day of month to 5th. */
console.log(someDate.getUTCDate());  /* Outputs 5. */
```

`**getUTCDay **`Gets the day of the week, according to universal time (from 0-6).

```javascript
long getUTCDay();
```

Since: 1.0

Return value:

long: The day of the week, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCDay());  /* Outputs 5, since 31st of December 1999 was Friday. */
```

`**getUTCFullYear **`Gets the year, according to universal time.

```javascript
long getUTCFullYear();
```

Since: 1.0

Positive values indicate AD(Anno Domini) years. 0 and negative values indicate BC(Before Christ) years.
For example, 1 = AD 1, 0 = BC 1, -1 = BC 2.

Return value:

long: The year, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCFullYear());  /* Outputs 1999. */
```

`**setUTCFullYear **`Sets the year, according to universal time.

```javascript
void setUTCFullYear(long year);
```

Since: 1.0

Parameters:

- **year :
 Year to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCFullYear(2099);           /* Change the year to 2099, universal time. */
console.log(someDate.getUTCFullYear());  /* Outputs 2099. */
```

`**getUTCHours **`Gets the hour, according to universal time (0-23).

```javascript
long getUTCHours();
```

Since: 1.0

Return value:

long: The hour, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCHours());  /* Outputs 23. */
```

`**setUTCHours **`Sets the hour, according to universal time (0-23).

```javascript
void setUTCHours(long hours);
```

Since: 1.0

If the value passed as a parameter is greater than 23 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setUTCHours(24) results in setting hour to 0 and adding one day.

Parameters:

- **hours :
 Hours to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCHours(15);
console.log(someDate.getUTCHours());  /* Outputs 15. */
```

`**getUTCMilliseconds **`Gets the milliseconds, according to universal time (from 0-999).

```javascript
long getUTCMilliseconds();
```

Since: 1.0

Return value:

long: The milliseconds, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCMilliseconds());  /* Outputs 999. */
```

`**setUTCMilliseconds **`Sets the milliseconds, according to universal time (from 0-999).

```javascript
void setUTCMilliseconds(long ms);
```

Since: 1.0

If the value passed as a parameter is greater than 999 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setUTCMilliseconds(1000) results in setting milliseconds to 0 and adding one second.

Parameters:

- **ms :
 Milliseconds to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCMillisecond(42);
console.log(someDate.getUTCMilliseconds());  /* Outputs 42. */
```

`**getUTCMinutes **`Gets the minutes, according to universal time (from 0-59).

```javascript
long getUTCMinutes();
```

Since: 1.0

Return value:

long: The minutes, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCMinutes());  /* Outputs 59. */
```

`**setUTCMinutes **`Sets the minutes, according to universal time (from 0-59).

```javascript
void setUTCMinutes(long minutes);
```

Since: 1.0

If the value passed as a parameter is greater than 59 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setUTCMinutes(60) results in setting minutes to 0 and adding one hour.

Parameters:

- **minutes :
 Minutes to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCMinutes(58);
console.log(someDate.getUTCMinutes());  /* Outputs 58. */
```

`**getUTCMonth **`Gets the month, according to universal time (from 0-11). 
Note: January is denoted as 0, February as 1 and so on till December, which is denoted as 11.
```javascript
long getUTCMonth();
```

Since: 1.0

Return value:

long: The month, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCMonth());  /* Outputs 11. */
```

`**setUTCMonth **`Sets the month, according to universal time (from 0-11).

```javascript
void setUTCMonth(long month);
```

Since: 1.0

If the value passed as a parameter is greater than 11 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setUTCMonth(12) results in setting month to 0 and adding one year.

Parameters:

- **month :
 Month to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCMonth(2);              /* Sets the month to March, according to the universal time. */
console.log(someDate.getUTCMonth());  /* Outputs 2. */
```

`**getUTCSeconds **`Gets the seconds, according to universal time (from 0-59).

```javascript
long getUTCSeconds();
```

Since: 1.0

Return value:

long: The seconds, according to universal time.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getUTCSeconds());  /* Outputs 59. */
```

`**setUTCSeconds **`Sets the seconds, according to universal time (from 0-59).

```javascript
void setUTCSeconds(long seconds);
```

Since: 1.0

If the value passed as a parameter is greater than 59 or smaller than 0, the TZDate will be automatically recalculated to reflect this.
For example, calling setUTCSeconds(60) results in setting seconds to 0 and adding one minute.

Parameters:

- **seconds :
 Seconds to set. **

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
someDate.setUTCSeconds(23);
console.log(someDate.getUTCSeconds());  /* Outputs 23. */
```

`**getTimezone **`Gets the timezone identifier.

```javascript
DOMString getTimezone();
```

Since: 1.0

Zero or more slashes separate different components, with the most general
descriptor first and the most specific one last. For example,
"Europe/Berlin", "America/Argentina/Buenos_Aires".

This attribute uniquely identifies the timezone.

Return value:

DOMString: The string timezone identifier. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.getTimezone());
```

Output example:

```
Europe/London
```

`**toTimezone **`Gets a copy of the TZDate converted to a given time zone.

```javascript
TZDate toTimezone(DOMString tzid);
```

Since: 1.0

Parameters:

- **tzid :
 Timezone identifier to set. **

Return value:

TZDate: The new TZDate in given Timezone.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type InvalidValuesError, if the provided TZID
is not recognized as a valid timezone identifier.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
var koreanDate = someDate.toTimezone("Asia/Seoul");
console.log(someDate.toString());
```

Output example:

```
Saturday, January 1, 2000, 8:59:59 AM GMT+0900 South Korea Time
```

`**toLocalTimezone **`Gets a copy of the TZDate converted to the local time zone.

```javascript
TZDate toLocalTimezone();
```

Since: 1.0

Return value:

TZDate: The new TZDate in local Timezone.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* This example assumes that the device's local time zone is set to Asia/Seoul. */
/* You may get different results depending on your local time zone settings. */
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
var localDate = someDate.toLocalTimezone();
console.log(localDate.toString());
```

Output example:

```
Saturday, January 1, 2000, 8:59:59 AM GMT+0900 South Korea Time
```

`**toUTC **`Gets a copy of the TZDate converted to Coordinated Universal Time (UTC).

```javascript
TZDate toUTC();
```

Since: 1.0

Return value:

TZDate: The Date/Time in UTC.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Asia/Seoul");
var utcDate = someDate.toUTC();
console.log(utcDate.toString());
```

Output example:

```
Friday, December 31, 1999, 2:59:59 PM GMT+0000 GMT
```

`**difference **`Calculates the difference with another TZDate object.

```javascript
TimeDuration difference(TZDate other);
```

Since: 1.0

Calculates the difference in time between *this *and the other object.
This comparison method takes timezones into consideration for the comparison.

The TimeDuration that is returned is effectively *this *- other.
The return value is a duration in milliseconds both TZDate objects have a time component, in days, otherwise.
The result value will be:

- Negative, if other is in the future
- 0 if the two date/times are equal
- Positive, if other is in the past

Parameters:

- **other :
 The other Date/Time to compare to. **

Return value:

TimeDuration: The duration in milliseconds between the two date/time objects
(or in days for comparison between dates with no time component).

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Prepares two TZDates pointing at new year eves in 2011 and 2012, respectively. */
var newYearEve2011 = new tizen.TZDate(2011, 0, 0, 0, 0, 0, 0, "Europe/London");
var newYearEve2012 = new tizen.TZDate(2012, 0, 0, 0, 0, 0, 0, "Europe/London");

/* Calculates how much is the difference between those two dates. */
var difference = newYearEve2012.difference(newYearEve2011);
console.log("The difference is " + difference.length + " " + difference.unit);
```

Output example (since none of those dates have time component):

```
The difference is 365 DAYS
```

Code example:

```javascript
/* Prepares two TZDates pointing at 6:00 PM and 8:00 PM on the same day. */
var joggingStart = new tizen.TZDate(2015, 6, 6, 18, 0, 0, 0, "Europe/London");
var joggingEnd = new tizen.TZDate(2015, 6, 6, 20, 0, 0, 0, "Europe/London");

/* Calculates how much is the difference between those two dates. */
var difference = joggingEnd.difference(joggingStart);
console.log("The difference is " + difference.length + " " + difference.unit);
```

Output example (since both of those dates do have time component):

```
The difference is 7200000 MSECS
```

`**equalsTo **`Checks whether the TZDate is equal to another.

```javascript
boolean equalsTo(TZDate other);
```

Since: 1.0

This method takes the timezones into consideration and will return true if
the two TZDate objects represent the same instant in different timezones.

Parameters:

- **other :
 Other Date/Time to compare to. **

Return value:

boolean: true if the 2 date/times are the same.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var noonInEngland = new tizen.TZDate(2016, 0, 27, 12, 0, 0, 0, "Europe/London");
var sameTimeInKorea = noonInEngland.toTimezone("Asia/Seoul");
var isTheSame = noonInEngland.equalsTo(sameTimeInKorea);

/* Those are the same dates (in different time zones), so the output should be "Those dates are */
/* equal.". */
if (isTheSame)
{
  console.log("Those dates are equal.");
}
else
{
  console.log("Those dates are not equal.");
}
```

Code example:

```javascript
var noonInEngland = new tizen.TZDate(2016, 0, 27, 12, 0, 0, 0, "Europe/London");
var noonInKorea = new tizen.TZDate(2016, 0, 27, 12, 0, 0, 0, "Asia/Seoul");
var isTheSame = noonInEngland.equalsTo(noonInKorea);

/* Those are not the same dates (obviously, noon in London is not noon in Seoul), */
/* so the output should be "Those dates are not equal.". */
if (isTheSame)
{
  console.log("Those dates are equal.");
}
else
{
  console.log("Those dates are not equal.");
}
```

`**earlierThan **`Checks whether the TZDate is earlier than another.

```javascript
boolean earlierThan(TZDate other);
```

Since: 1.0

This method takes the timezones into consideration.

Parameters:

- **other :
 The other Date/Time to compare to. **

Return value:

boolean: true , if the Date/Time is earlier than the one passed in argument.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Create a new TZDate object pointing to noon in London. */
var tzd1 = new tizen.TZDate(2016, 0, 1, 12, 0, 0, 0, "Europe/London");

/* Create a new TZDate object pointing to 6 PM in Seoul on the same day. */
var tzd2 = new tizen.TZDate(2016, 0, 1, 18, 0, 0, 0, "Asia/Seoul");

/* Is 12:00 local time in London earlier than 18:00 local time in Seoul?. */
var isEarlier = tzd1.earlierThan(tzd2);

/* Outputs "false", since local time in Seoul is GMT (London) + 9 hours. */
console.log(isEarlier);
```

`**laterThan **`Checks whether the TZDate is later than another.

```javascript
boolean laterThan(TZDate other);
```

Since: 1.0

This method takes the timezones into consideration.

Parameters:

- **other :
 The other Date/Time to compare to. **

Return value:

boolean: true , if the Date/Time is later than the one passed in argument.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Create a new TZDate object pointing to noon in London. */
var tzd1 = new tizen.TZDate(2016, 0, 1, 12, 0, 0, 0, "Europe/London");

/* Create a new TZDate object pointing to 6 PM in Seoul on the same day. */
var tzd2 = new tizen.TZDate(2016, 0, 1, 18, 0, 0, 0, "Asia/Seoul");

/* Is 12:00 local time in London earlier than 18:00 local time in Seoul?. */
var isLater = tzd1.laterThan(tzd2);

/* Outputs "true", since local time in Seoul is GMT (London) + 9 hours. */
console.log(isLater);
```

`**addDuration **`Gets a new date by adding a duration to the current TZDate object.

```javascript
TZDate addDuration(TimeDuration duration);
```

Since: 1.0

If the length of duration is negative, the new date/time will be
earlier than it used to.

Note that calling this method does not alter the current object.

Parameters:

- **duration :
 TimeDuration to add. **

Return value:

TZDate: The new TZDate by adding a duration.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var now = tizen.time.getCurrentDateTime();
var in_one_week = now.addDuration(new tizen.TimeDuration(7, "DAYS"));
```

`**toLocaleDateString **`Gets the date portion of a TZDate object as a string, using locale conventions.

```javascript
DOMString toLocaleDateString();
```

Since: 1.0

Return value:

DOMString: The date portion of the TZDate object as a string, using locale conventions. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.toLocaleDateString());
```

Output example (depending on locale settings):

```
Friday, December 31, 1999
```

`**toLocaleTimeString **`Gets the time portion of a TZDate object as a string, using locale conventions.

```javascript
DOMString toLocaleTimeString();
```

Since: 1.0

Return value:

DOMString: The time portion of the TZDate object as a string, using locale conventions. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.toLocaleTimeString());
```

Output example (depending on locale settings):

```
11:59:59 PM
```

`**toLocaleString **`Converts a TZDate object to a string, using locale conventions.

```javascript
DOMString toLocaleString();
```

Since: 1.0

Return value:

DOMString: The string representation of the TZDate object, using locale conventions. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");
console.log(someDate.toLocaleString());
```

Output example (depending on locale settings):

```
Friday, December 31, 1999, 11:59:59 PM
```

`**toDateString **`Gets the date portion of a TZDate object as a string.

```javascript
DOMString toDateString();
```

Since: 1.0

Return value:

DOMString: The date portion of the TZDate object as a string. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");

/* Output: "Friday, December 31, 1999". */
console.log(someDate.toDateString());
```

`**toTimeString **`Gets the time portion of a TZDate object as a string.

```javascript
DOMString toTimeString();
```

Since: 1.0

Return value:

DOMString: The time portion of the TZDate object as a string. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");

/* Output: "11:59:59 PM GMT+0000 United Kingdom Time". */
console.log(someDate.toTimeString());
```

`**toString **`Converts a TZDate object to a string.

```javascript
DOMString toString();
```

Since: 1.0

Return value:

DOMString: The string representation of the TZDate object. If TZDate is invalid, it will return "Invalid Date".

Code example:

```javascript
var someDate = new tizen.TZDate(1999, 11, 31, 23, 59, 59, 999, "Europe/London");

/* Output: "Friday, December 31, 1999, 11:59:59 PM GMT+0000 United Kingdom Time". */
console.log(someDate.toString());
```

`**secondsFromUTC **`Gets the number of seconds from Coordinated Universal Time (UTC) offset for the timezone.

```javascript
long secondsFromUTC();
```

Since: 1.0

Returns the offset (in seconds) from UTC of the timezone, accounting for daylight
savings if it is in the timezone. For example, if time zone is GMT+8, it will return -32,400.

Return value:

long: The offset from UTC in seconds.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var offset = tizen.time.getCurrentDateTime().secondsFromUTC();
var myDate = new Date();
var exp_offset = myDate.getTimezoneOffset() * 60;
/* offset is equals to exp_offset. */
```

`**isDST **`Checks whether Daylight Saving Time(DST) is active for this TZDate.

```javascript
boolean isDST();
```

Since: 1.0

Indicates if daylight savings are in effect for the time zone and instant
identified by the TZDate object.

Return value:

boolean: The flag indicating whether the daylight saving are in effect.

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var summertime = new tizen.TZDate(2015, 6, 1, 10, 0, 0, 0, "Europe/London");
var wintertime = new tizen.TZDate(2015, 0, 1, 10, 0, 0, 0, "Europe/London");

var isDstActiveInSummer = summertime.isDST();  /* true. */
var isDstActiveInWinter = wintertime.isDST();  /* false. */
```

`**getPreviousDSTTransition **`Gets the date of the previous daylight saving time transition for the timezone.

```javascript
TZDate? getPreviousDSTTransition();
```

Since: 1.0

Return value:

TZDate [nullable] : The date of the previous daylight saving transition (before the instant identified by the TZDate).

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Creates the TZDate object pointing to January 2016. */
var winter16 = new tizen.TZDate(2016, 0, 1, 10, 0, 0, 0, "Europe/London");

/* Gets the date of previous DST transition. */
var previousDstTransition = winter16.getPreviousDSTTransition();

/* Output: "Sunday, October 25, 2015, 1:00:00 AM GMT+0000 United Kingdom Time". */
console.log(previousDstTransition.toString());
```

`**getNextDSTTransition **`Gets the date of the next daylight saving time transition for the timezone.

```javascript
TZDate? getNextDSTTransition();
```

Since: 1.0

Return value:

TZDate [nullable] : The date of the next daylight saving transition (after the instant identified by the TZDate).

Exceptions:

- WebAPIException
- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Creates the TZDate object pointing to January 2016. */
var winter16 = new tizen.TZDate(2016, 0, 1, 10, 0, 0, 0, "Europe/London");

/* Gets the date of next DST transition. */
var nextDstTransition = winter16.getNextDSTTransition();

/* Output: "Sunday, March 27, 2016, 2:00:00 AM GMT+0100 United Kingdom Time". */
console.log(nextDstTransition.toString());
```

### 2.4. TimeDuration

The TimeDuration interface that contains the length and its associated time unit.

```webidl
  [Constructor(long long length, optional TimeDurationUnit? unit)]
  interface TimeDuration {
    attribute long long length;
    attribute TimeDurationUnit unit;
    TimeDuration difference(TimeDuration other) raises(WebAPIException);
    boolean equalsTo(TimeDuration other) raises(WebAPIException);
    boolean lessThan(TimeDuration other) raises(WebAPIException);
    boolean greaterThan(TimeDuration other) raises(WebAPIException);
  };
```

Since: 1.0

#### Constructors

`**Constructor (long long, TimeDurationUnit ?) **`The TimeDuration interface that contains the length and its associated time unit.

```webidl
TimeDuration(long long length, optional TimeDurationUnit? unit);
```

Since: 1.0

Code example:

```javascript
var now = tizen.time.getCurrentDateTime();
var tomorrow = now.addDuration(new tizen.TimeDuration(1, "DAYS"));  /* Becomes tomorrow, same time. */
```

#### Attributes

- long long length The duration length.

The unit of the duration length (milliseconds, seconds, minutes, hours, or days)
is determined by the duration unit attribute.

Since: 1.0

- TimeDurationUnit unit The duration unit (milliseconds, seconds, minutes, hours, or days).

The default value is "MSECS" (milliseconds unit).

Since: 1.0

Code example:

```javascript
/* Changing both length and unit of existing TimeDuration objects is possible. */

var now = tizen.time.getCurrentDateTime();
var threeHours = new tizen.TimeDuration();
threeHours.length = 3;
threeHours.unit = "HOURS";
var later = now.addDuration(threeHours);  /* later points to a time three hours from now. */
```

#### Methods

`**difference **`Calculates the difference between two TimeDuration objects.

```javascript
TimeDuration difference(TimeDuration other);
```

Since: 1.0

Calculates the difference in time between *this *and *other *.
The TimeDuration that is returned is effectively *first *- *other *(that is: positive if the first parameter is larger).

The returned TimeDuration is the biggest possible unit without losing the precision.

Parameters:

- **other :
 Other TimeDuration object to compare to. **

Return value:

TimeDuration: New TimeDuration object corresponding to the result of *this *- *other *.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
/* Assumes that event1 and event2 are tizen.CalendarEvent objects. */
/* Computes event1.duration - event2.duration. */
var diff = event1.duration.difference(event2.duration);
if (diff.length > 0)
  console.log("The event1 is longer than event2.");
else if (diff.length == 0)
  console.log("The duration of two events is same.");
else
  console.log("The event1 is shorter than the event2.");
```

`**equalsTo **`Checks whether the TimeDuration is equal to another.

```javascript
boolean equalsTo(TimeDuration other);
```

Since: 1.0

This method takes the units into consideration and will return true
if the two TimeDuration objects represent the same duration in different units.

Parameters:

- **other :
 Other TimeDuration object to compare to. **

Return value:

boolean: true if the two TimeDuration object represent the same duration.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var d1 = new tizen.TimeDuration(60, "MINS");  /* 60 minutes. */
var d2 = new tizen.TimeDuration(1, "HOURS");  /* 1 hour. */
var ret = d1.equalsTo(d2);                    /* Returns true. */
```

`**lessThan **`Checks whether the TimeDuration is lower than another.

```javascript
boolean lessThan(TimeDuration other);
```

Since: 1.0

This method takes the units into consideration when doing the comparison.

Parameters:

- **other :
 Other TimeDuration object to compare to. **

Return value:

boolean: true if the TimeDuration is less than *other *.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var d1 = new tizen.TimeDuration(1, "HOURS");   /* 1 hour. */
var d2 = new tizen.TimeDuration(120, "MINS");  /* 120 minutes. */
var ret = d1.lessThan(d2);                     /* Returns true. */
```

`**greaterThan **`Checks whether the TimeDuration is greater than another.

```javascript
boolean greaterThan(TimeDuration other);
```

Since: 1.0

This method takes the units into consideration when doing the comparison.

Parameters:

- **other :
 Other TimeDuration object to compare to. **

Return value:

boolean: true if the TimeDuration is greater than *other *.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter
is not compatible with the expected type for that parameter.

- with error type UnknownError, if the call failed due to an unknown error.

Code example:

```javascript
var d1 = new tizen.TimeDuration(120, "MINS");  /* 120 minutes. */
var d2 = new tizen.TimeDuration(1, "HOURS");   /* 1 hour. */
var ret = d1.greaterThan(d2);                  /* Returns true. */
```

## 3. Full WebIDL

```webidl
module Time {
  enum TimeDurationUnit { "MSECS", "SECS", "MINS", "HOURS", "DAYS" };
  Tizen implements TimeManagerObject;
  [NoInterfaceObject] interface TimeManagerObject {
    readonly attribute TimeUtil time;
  };
  [NoInterfaceObject] interface TimeUtil {
    TZDate getCurrentDateTime() raises(WebAPIException);
    DOMString getLocalTimezone() raises(WebAPIException);
    DOMString[] getAvailableTimezones() raises(WebAPIException);
    DOMString getDateFormat(optional boolean? shortformat) raises(WebAPIException);
    DOMString getTimeFormat() raises(WebAPIException);
    boolean isLeapYear(long year) raises(WebAPIException);
    void setDateTimeChangeListener(SuccessCallback changeCallback) raises(WebAPIException);
    void unsetDateTimeChangeListener() raises(WebAPIException);
    void setTimezoneChangeListener(SuccessCallback changeCallback) raises(WebAPIException);
    void unsetTimezoneChangeListener() raises(WebAPIException);
  };
  [Constructor(optional Date? datetime, optional DOMString? timezone),
   Constructor(long year, long month, long day, optional long? hours, optional long? minutes, optional long? seconds,
               optional long? milliseconds, optional DOMString? timezone)]
  interface TZDate {
    long getDate();
    void setDate(long date);
    long getDay();
    long getFullYear();
    void setFullYear(long year);
    long getHours();
    void setHours(long hours);
    long getMilliseconds();
    void setMilliseconds(long ms);
    long getMinutes();
    void setMinutes(long minutes);
    long getMonth();
    void setMonth(long month);
    long getSeconds();
    void setSeconds(long seconds);
    long getUTCDate();
    void setUTCDate(long date);
    long getUTCDay();
    long getUTCFullYear();
    void setUTCFullYear(long year);
    long getUTCHours();
    void setUTCHours(long hours);
    long getUTCMilliseconds();
    void setUTCMilliseconds(long ms);
    long getUTCMinutes();
    void setUTCMinutes(long minutes);
    long getUTCMonth();
    void setUTCMonth(long month);
    long getUTCSeconds();
    void setUTCSeconds(long seconds);
    DOMString getTimezone();
    TZDate toTimezone(DOMString tzid) raises(WebAPIException);
    TZDate toLocalTimezone() raises(WebAPIException);
    TZDate toUTC() raises(WebAPIException);
    TimeDuration difference(TZDate other) raises(WebAPIException);
    boolean equalsTo(TZDate other) raises(WebAPIException);
    boolean earlierThan(TZDate other) raises(WebAPIException);
    boolean laterThan(TZDate other) raises(WebAPIException);
    TZDate addDuration(TimeDuration duration) raises(WebAPIException);
    DOMString toLocaleDateString();
    DOMString toLocaleTimeString();
    DOMString toLocaleString();
    DOMString toDateString();
    DOMString toTimeString();
    DOMString toString();
    long secondsFromUTC() raises(WebAPIException);
    boolean isDST() raises(WebAPIException);
    TZDate? getPreviousDSTTransition() raises(WebAPIException);
    TZDate? getNextDSTTransition() raises(WebAPIException);
  };
  [Constructor(long long length, optional TimeDurationUnit? unit)]
  interface TimeDuration {
    attribute long long length;
    attribute TimeDurationUnit unit;
    TimeDuration difference(TimeDuration other) raises(WebAPIException);
    boolean equalsTo(TimeDuration other) raises(WebAPIException);
    boolean lessThan(TimeDuration other) raises(WebAPIException);
    boolean greaterThan(TimeDuration other) raises(WebAPIException);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
