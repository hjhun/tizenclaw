# Tizen API

This API provides common Tizen functionality.

The API provides the basic definitions that are used in the Tizen Web Device API.
These include generic callbacks that are invoked when the operations succeed or fail,
WebAPIError and WebAPIException that give information of the platform's error and
filter interfaces that are used to make query statements for searching.

Additionally, this API specifies the location in the ECMAScript hierarchy in which
the Tizen Web Device API is instantiated ( *window.tizen *).

For more information on the Tizen features, see Tizen Guide .

Since: 1.0

## Table of Contents

- 1. Type Definitions
- 1.1. ByteStream
- 1.2. FilterMatchFlag
- 1.3. SortModeOrder
- 1.4. CompositeFilterType
- 1.5. BundleValueType
- 2. Interfaces
- 2.1. TizenObject
- 2.2. Tizen
- 2.3. Bundle
- 2.4. AbstractFilter
- 2.5. AttributeFilter
- 2.6. AttributeRangeFilter
- 2.7. CompositeFilter
- 2.8. SortMode
- 2.9. SimpleCoordinates
- 2.10. WebAPIException
- 2.11. WebAPIError
- 2.12. SuccessCallback
- 2.13. ErrorCallback
- 2.14. BundleItemCallback
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| TizenObject |  |
| Tizen |  |
| Bundle | any get (DOMString key) void set (DOMString key, any value) BundleValueType typeOf (DOMString key) void forEach ( BundleItemCallback callback) object toJSON () DOMString toString () |
| AbstractFilter |  |
| AttributeFilter |  |
| AttributeRangeFilter |  |
| CompositeFilter |  |
| SortMode |  |
| SimpleCoordinates |  |
| WebAPIException |  |
| WebAPIError |  |
| SuccessCallback | void onsuccess () |
| ErrorCallback | void onerror ( WebAPIError error) |
| BundleItemCallback | void onitem (DOMString key, any value, BundleValueType type) |

## 1. Type Definitions

### 1.1. ByteStream

Representation of raw data as a sequence of values in range 0 - 255.

```webidl
  typedef octet[] ByteStream;
```

Since: 5.5

Remark: This is equivalent to Uint8Array in JavaScript.

### 1.2. FilterMatchFlag

Filter match flags.

```webidl
  enum FilterMatchFlag { "EXACTLY", "FULLSTRING", "CONTAINS", "STARTSWITH", "ENDSWITH", "EXISTS" };
```

Since: 1.0

These values are supported:

- EXACTLY - Indicates that an attribute value should match exactly with the specified default value.
For strings, this type of comparison is case-sensitive.
- FULLSTRING - Indicates String-based comparison and that the attribute value should match the whole string (case insensitive).
- CONTAINS - Indicates that an attribute value should contain the specified string. This type of comparison works only on strings and is case insensitive.
- STARTSWITH - Indicates that an attribute value should start with the specified string.
This type of comparison works only on strings and is case insensitive.
- ENDSWITH - Indicates that an attribute value should end with the specified string. This type of comparison works only on strings and is case insensitive.
- EXISTS - Indicates that a filter comparison should match if the specified attribute exists.

### 1.3. SortModeOrder

An enumerator that indicates the sorting order.

```webidl
  enum SortModeOrder { "ASC", "DESC" };
```

Since: 1.0

Following values are supported:

- ASC - Indicates that the sorting order is ascending
- DESC - Indicates that the sorting order is descending

### 1.4. CompositeFilterType

An enumerator that indicates the type of composite filter.

```webidl
  enum CompositeFilterType { "UNION", "INTERSECTION" };
```

Since: 1.0

Following values are supported:

- UNION - Indicates that the composite is a union of filters ("OR" operator)
- INTERSECTION - Indicates that the composite is an intersection of filters ("AND" operator)

### 1.5. BundleValueType

Bundle item value types.

```webidl
  enum BundleValueType { "STRING", "STRING_ARRAY", "BYTES", "BYTES_ARRAY" };
```

Since: 5.5

The following value types are supported by Bundle objects:

- STRING - string value type
- STRING_ARRAY - array of strings value type
- BYTES - ByteStream
- BYTES_ARRAY - array of ByteStream

Remark: Empty array will be assigned STRING_ARRAY type.

## 2. Interfaces

### 2.1. TizenObject

Defines the tizen interface as a part of the window global object.

```webidl
  [NoInterfaceObject] interface TizenObject {
    readonly attribute Tizen tizen;
  };
```

```webidl
  Window implements TizenObject;
```

Since: 1.0

The *Tizen *interface is always available within the *Window *object in the ECMAScript hierarchy.

#### Attributes

- readonly Tizen tizen Object representing a tizen manager.

Since: 1.0

### 2.2. Tizen

The root of the Tizen Web Device API.

```webidl
  [NoInterfaceObject] interface Tizen {
  };
```

Since: 1.0

This is the Tizen root interface.
It is a property of the ECMAScript global object, as specified by the *TizenObject *interface.

### 2.3. Bundle

Key-value pair container.

```webidl
  [Constructor(optional object? json)]
  interface Bundle {
    any get(DOMString key) raises(WebAPIException);
    void set(DOMString key, any value);
    BundleValueType typeOf(DOMString key) raises(WebAPIException);
    void forEach(BundleItemCallback callback);
    object toJSON();
    DOMString toString();
  };
```

Since: 5.5

Bundle keys are always strings.
All supported value types are specified in the BundleValueType enum.

Plain dictionary will be implicitly converted to the Bundle object in every
Bundle context within WebAPI.

#### Constructors

`**Constructor (object?) **`
```webidl
Bundle(optional object? json);
```

#### Methods

`**get **`Gets value stored under given key.

```javascript
any get(DOMString key);
```

Since: 5.5

Parameters:

- **key :
 Bundle entry key. **

Return value:

any: Bundle entry value for a given key.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the key could not be found.

Code example:

```javascript
var bundle = new tizen.Bundle();
bundle.set("array", ["hello", "world"]);
console.log(bundle.get("array"));

try
{
  bundle.get("unknownKey");
}
catch (err)
{
  console.log(err.name);
}
```

Output example:

```
["hello", "world"]
NotFoundError
```

`**set **`Inserts the key-value pair.

```javascript
void set(DOMString key, any value);
```

Since: 5.5

Remark: Any value type not specified in the BundleValueType enum will be converted to a string.

Remark: Empty array value will be treated like STRING_ARRAY.

Parameters:

- **key :
 Entry key. **
- **value :
 Entry value. **

Code example:

```javascript
var bundle = new tizen.Bundle();

bundle.set("array", ["hello", "world"]);
bundle.set("empty", []);

console.log(bundle.get("array"));
console.log(bundle.get("empty"));
```

Output example:

```
["hello", "world"]
[]
```

`**typeOf **`Gets type of the value for a given key.

```javascript
BundleValueType typeOf(DOMString key);
```

Since: 5.5

Remark: If the value for the given key is an empty array this function returns STRING_ARRAY.

Parameters:

- **key :
 Entry key. **

Return value:

BundleValueType: Entry value type.

Exceptions:

- WebAPIException
- with error type NotFoundError, if the key could not be found.

Code example:

```javascript
var bundle = new tizen.Bundle();

bundle.set("string", "hello, world");
bundle.set("string-array", ["hello", "world"]);
bundle.set("bytes", new Uint8Array([1, 2, 3]));
bundle.set("bytes-array", [new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6])]);
bundle.set("empty-array", []);

console.log(bundle.typeOf("string"));
console.log(bundle.typeOf("string-array"));
console.log(bundle.typeOf("bytes"));
console.log(bundle.typeOf("bytes-array"));
console.log(bundle.typeOf("empty-array"));
```

Output example:

```
STRING
STRING_ARRAY
BYTES
BYTES_ARRAY
STRING_ARRAY
```

`**forEach **`Calls the callback function for each item stored in the bundle.

```javascript
void forEach(BundleItemCallback callback);
```

Since: 5.5

If bundle is empty the callback function will not be called.

Remark: Empty arrays are treated like string arrays.

Parameters:

- **callback :
 Function to be called for each entry. **

Code example:

```javascript
var bundle = new tizen.Bundle();
bundle.set("string-array", ["hello", "world"]);
bundle.set("string", "hello, world");

/* order in which items will be printed is unspecified. */
bundle.forEach(function(key, value, type)
{
  console.log("key: " + key);
  console.log("value: " + value);
  console.log("type: " + type);
  console.log("---");
});
```

Output example:

```
key: string-array
value: ["hello", "world"]
type: STRING_ARRAY
---
key: string
value: "hello, world"
type: STRING
---
```

`**toJSON **`Converts bundle to JSON-compatible object.

```javascript
object toJSON();
```

Since: 5.5

Return value:

object: JSON-compatible object.

Code example:

```javascript
var bundle = new tizen.Bundle({"array": ["hello", "world"]});
var json = bundle.toJSON();
console.log(JSON.stringify(json));
```

Output example:

```
{"array": ["hello", "world"]}
```

`**toString **`Returns string representation of the bundle's data.

```javascript
DOMString toString();
```

Since: 5.5

Return value:

DOMString: JSON string representation of the bundle's data.

### 2.4. AbstractFilter

This is a common interface used by different types of
object filters.

```webidl
  [NoInterfaceObject] interface AbstractFilter {
  };
```

Since: 1.0

Never use this base interface directly, instead use *AbstractFilter *subtypes,
such as *AttributeFilter *, *AttributeRangeFilter *, and *CompositeFilter *.

### 2.5. AttributeFilter

This interface represents a set of filters.

```webidl
  [Constructor(DOMString attributeName, optional FilterMatchFlag? matchFlag, optional any matchValue)]
  interface AttributeFilter : AbstractFilter {
    attribute DOMString attributeName;
    attribute FilterMatchFlag matchFlag;
    attribute any matchValue;
  };
```

Since: 1.0

It represents the query statement for the specified value of *matchValue *by the rule of *matchFlag *.

If no *matchValue *is defined, the filter matches all objects that have the attribute
defined (same as the "EXISTS" filter works), otherwise, it only matches objects which have an attribute that match
the specified value.

Code example:

```javascript
/* Following example retrieves all songs from the album "The Joshua Tree". */
var count = 100;
var offset = 0;
var albumFilter = new tizen.AttributeFilter("album", "EXACTLY", "The Joshua Tree");

function errorCB(err)
{
  console.log("Following error occurred: " + err.name);
}

function findCB(contents)
{
  console.log("The Joshua Tree: " + contents.length);
}

tizen.content.find(findCB, errorCB, null, albumFilter, null, count, offset);
```

#### Constructors

`**Constructor (DOMString, FilterMatchFlag ?, any) **`
```webidl
AttributeFilter(DOMString attributeName, optional FilterMatchFlag? matchFlag, optional any matchValue);
```

#### Attributes

- DOMString attributeName The name of the object attribute used for filtering.

This is the name of the object attribute exactly as it is defined in
the object's interface. For attributes of complex type, use fully-qualified names
(such as "geolocation.latitude" to filter a video or image content's latitude in a geolocation).

For attributes of an array type, the filter will match if any value in the array
matches.

Since: 1.0

- FilterMatchFlag matchFlag The match flag used for attribute-based filtering.

By default, this attribute is set to "EXACTLY".

Since: 1.0

- any matchValue The value used for matching.

The filter will match if the attribute value matches the given matchValue.

This value is not used if the *matchFlag *is set to "EXISTS".
By default, this attribute is set to null .

Since: 1.0

### 2.6. AttributeRangeFilter

*AttributeRangeFilter *represents a filter based on an object attribute
which has values that are within a particular range.

```webidl
  [Constructor(DOMString attributeName, optional any initialValue, optional any endValue)]
  interface AttributeRangeFilter : AbstractFilter {
    attribute DOMString attributeName;
    attribute any initialValue;
    attribute any endValue;
  };
```

Since: 1.0

Range filters, where only one boundary is set, are available.

Code example:

```javascript
var count = 100;
var offset = 0;
/* Use the modifiedDate attribute with a range that starts today and ends in 1 day */
/* (meaning that you search for all contents modified today). */
var today = new Date();
var today_begin = new Date(today.getFullYear(), today.getMonth(), today.getDate());
var today_end = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
var dateRangeFilter = new tizen.AttributeRangeFilter("modifiedDate", today_begin, today_end);

function errorCB(err)
{
  console.log("Following error occurred: " + err.name);
}

function findCB(contents)
{
  console.log("The contents modified today: " + contents.length);
}

tizen.content.find(findCB, errorCB, null, dateRangeFilter, null, count, offset);
```

#### Constructors

`**Constructor (DOMString, any, any) **`
```webidl
AttributeRangeFilter(DOMString attributeName, optional any initialValue, optional any endValue);
```

#### Attributes

- DOMString attributeName The name of the object attribute used for filtering.

The value of this attribute is exactly as it is defined in the object's interface. For attributes of complex type, use fully-qualified names
(such as "geolocation.latitude" to filter a video or image content's latitude in a geolocation).

For attributes of array type, the filter will match if any value in the array
matches.

Since: 1.0

- any initialValue Objects with an attribute that is greater than or equal to *initialValue *will match.

By default, this attribute is set to null .

Since: 1.0

- any endValue Objects with an attribute that is strictly lower than or equal to *endValue *will match.

By default, this attribute is set to null .

Since: 1.0

### 2.7. CompositeFilter

*CompositeFilter *represents a set of filters.

```webidl
  [Constructor(CompositeFilterType type, optional AbstractFilter[]? filters)]
  interface CompositeFilter : AbstractFilter {
    attribute CompositeFilterType type;
    attribute AbstractFilter[] filters;
  };
```

Since: 1.0

The composite filters can be one of the following 2 types:

- The union - used to filter objects that match any of the filters it includes.
- The intersection - used to filter objects that match all the filters it includes.

Code example:

```javascript
/* Following example retrieves all songs from the album "The Joshua Tree", by artist "U2". */
var count = 100;
var offset = 0;
var artistFilter = new tizen.AttributeFilter("artists", "EXACTLY", "U2");
var albumFilter = new tizen.AttributeFilter("album", "EXACTLY", "The Joshua Tree");
var filter = new tizen.CompositeFilter("INTERSECTION", [albumFilter, artistFilter]);

function errorCB(err)
{
  console.log("Following error occurred: " + err.name);
}

function findCB(contents)
{
  console.log("The Joshua Tree by U2: " + contents.length);
}

tizen.content.find(findCB, errorCB, null, filter, null, count, offset);
```

Code example:

```javascript
/* Following example retrieves all songs from the album "Tormato" and all songs by artist "Rush". */
var count = 100;
var offset = 0;
var artistFilter = new tizen.AttributeFilter("artists", "EXACTLY", "Rush");
var albumFilter = new tizen.AttributeFilter("album", "EXACTLY", "Tormato");
var filter = new tizen.CompositeFilter("UNION", [albumFilter, artistFilter]);

function errorCB(err)
{
  console.log("Following error occurred: " + err.name);
}

function findCB(contents)
{
  console.log("Songs found: " + contents.length);
}

tizen.content.find(findCB, errorCB, null, filter, null, count, offset);
```

#### Constructors

`**Constructor ( CompositeFilterType , AbstractFilter []?) **`
```webidl
CompositeFilter(CompositeFilterType type, optional AbstractFilter[]? filters);
```

#### Attributes

- CompositeFilterType type The composite filter type.

Since: 1.0

- AbstractFilter[] filters The list of filters in the composite filter.

Since: 1.0

### 2.8. SortMode

*SortMode *is a common interface used for sorting of queried data.

```webidl
  [Constructor(DOMString attributeName, optional SortModeOrder? order)]
  interface SortMode {
    attribute DOMString attributeName;
    attribute SortModeOrder order;
  };
```

Since: 1.0

Note that the sorting result of list type attributes is not determined.

Code example:

```javascript
/* Following example retrieves all songs from the album "The Joshua Tree", by artist "U2", ordered */
/* by the track number. */
var count = 100;
var offset = 0;
var sortMode = new tizen.SortMode("trackNumber", "ASC");
var artistFilter = new tizen.AttributeFilter("artists", "EXACTLY", "U2");
var albumFilter = new tizen.AttributeFilter("album", "EXACTLY", "The Joshua Tree");
var filter = new tizen.CompositeFilter("INTERSECTION", [albumFilter, artistFilter]);

function errorCB(err)
{
  console.log("Following error occurred: " + err.name);
}

function printContent(content, index, contents)
{
  console.log("Track: " + content.trackNumber + " Title: " + content.title + " Duration: " +
              content.duration + " URL: " + content.contentURI + " MIME: " + content.mimeType);
}

function findCB(contents)
{
  console.log("The Joshua Tree by U2:");
  contents.forEach(printContent);
  /* Increase the offset as much as the count and then find content again. */
  if (contents.length == count)
  {
    offset += count;
    tizen.content.find(findCB, errorCB, null, filter, sortMode, count, offset);
  }
}

tizen.content.find(findCB, errorCB, null, filter, sortMode, count, offset);
```

#### Constructors

`**Constructor (DOMString, SortModeOrder ?) **`
```webidl
SortMode(DOMString attributeName, optional SortModeOrder? order);
```

#### Attributes

- DOMString attributeName The name of the object attribute used for sorting.

Since: 1.0

- SortModeOrder order The type of the sorting.

By default, this attribute is set to ASC .

Since: 1.0

### 2.9. SimpleCoordinates

*SimpleCoordinates *represents a point (latitude and longitude) in the map coordinate system.

```webidl
  [Constructor(double latitude, double longitude)]
  interface SimpleCoordinates {
    attribute double latitude;
    attribute double longitude;
  };
```

Since: 1.0

Latitude and longitude are of the WGS84 datum.

Code example:

```javascript
/* This example utilizes methods from Tizen's HAM module to get current latitude and longitude. */
var myPosition;

/* Reads current position from the GPS module. */
function onChangedCB(info)
{
  var latitude, longitude;
  latitude = info.gpsInfo[0].latitude;
  longitude = info.gpsInfo[0].longitude;

  /* Packs these values in one variable. */
  myPosition = new SimpleCoordinates(latitude, longitude);
}

/* Starts monitoring GPS info periodically. */
try
{
  tizen.humanactivitymonitor.start(
      "GPS", onChangedCB, {callbackInterval: 120000, sampleInterval: 60000});
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

#### Constructors

`**Constructor (double, double) **`
```webidl
SimpleCoordinates(double latitude, double longitude);
```

#### Attributes

- double latitude Latitude.

Since: 1.0

- double longitude Longitude.

Since: 1.0

### 2.10. WebAPIException

Generic exception interface.

```webidl
  [NoInterfaceObject] interface WebAPIException {
    const unsigned short INDEX_SIZE_ERR = 1;
    const unsigned short DOMSTRING_SIZE_ERR = 2;
    const unsigned short HIERARCHY_REQUEST_ERR = 3;
    const unsigned short WRONG_DOCUMENT_ERR = 4;
    const unsigned short INVALID_CHARACTER_ERR = 5;
    const unsigned short NO_DATA_ALLOWED_ERR = 6;
    const unsigned short NO_MODIFICATION_ALLOWED_ERR = 7;
    const unsigned short NOT_FOUND_ERR = 8;
    const unsigned short NOT_SUPPORTED_ERR = 9;
    const unsigned short INUSE_ATTRIBUTE_ERR = 10;
    const unsigned short INVALID_STATE_ERR = 11;
    const unsigned short SYNTAX_ERR = 12;
    const unsigned short INVALID_MODIFICATION_ERR = 13;
    const unsigned short NAMESPACE_ERR = 14;
    const unsigned short INVALID_ACCESS_ERR = 15;
    const unsigned short VALIDATION_ERR = 16;
    const unsigned short TYPE_MISMATCH_ERR = 17;
    const unsigned short SECURITY_ERR = 18;
    const unsigned short NETWORK_ERR = 19;
    const unsigned short ABORT_ERR = 20;
    const unsigned short URL_MISMATCH_ERR = 21;
    const unsigned short QUOTA_EXCEEDED_ERR = 22;
    const unsigned short TIMEOUT_ERR = 23;
    const unsigned short INVALID_NODE_TYPE_ERR = 24;
    const unsigned short DATA_CLONE_ERR = 25;
    readonly attribute unsigned short code;
    readonly attribute DOMString name;
    readonly attribute DOMString message;
  };
```

Since: 2.0

This interface will be used by the APIs to throw errors synchronously.

The attempt to set an attribute value may or may not raise WebAPIException synchronously with error type TypeMismatchError or InvalidValuesError.

#### Constants

- INDEX_SIZE_ERR The index is not in the allowed range.

Since: 2.0

- DOMSTRING_SIZE_ERR The specified range of text is too large.

Since: 2.0

- HIERARCHY_REQUEST_ERR The operation would yield an incorrect node tree.

Since: 2.0

- WRONG_DOCUMENT_ERR The object is in the wrong document.

Since: 2.0

- INVALID_CHARACTER_ERR The string contains invalid characters.

Since: 2.0

- NO_DATA_ALLOWED_ERR Data is specified for a node that does not support data.

Since: 2.0

- NO_MODIFICATION_ALLOWED_ERR The object cannot be modified.

Since: 2.0

- NOT_FOUND_ERR The object cannot be found here.

Since: 2.0

- NOT_SUPPORTED_ERR The operation is not supported.

Since: 2.0

- INUSE_ATTRIBUTE_ERR The specified attribute is already in use elsewhere.

Since: 2.0

- INVALID_STATE_ERR The object is in an invalid state.

Since: 2.0

- SYNTAX_ERR The string did not match the expected pattern.

Since: 2.0

- INVALID_MODIFICATION_ERR The object cannot be modified in this way.

Since: 2.0

- NAMESPACE_ERR The operation is not allowed by Namespaces in XML.

Since: 2.0

- INVALID_ACCESS_ERR The object does not support the operation or argument.

Since: 2.0

- VALIDATION_ERR The operation would cause the node to fail validation.

Since: 2.0

- TYPE_MISMATCH_ERR The type of the object does not match the expected type.

Since: 2.0

- SECURITY_ERR The operation is insecure.

Since: 2.0

- NETWORK_ERR A network error occurred.

Since: 2.0

- ABORT_ERR The operation has been aborted.

Since: 2.0

- URL_MISMATCH_ERR The given URL does not match another URL.

Since: 2.0

- QUOTA_EXCEEDED_ERR The quota has been exceeded.

Since: 2.0

- TIMEOUT_ERR The operation has timed out.

Since: 2.0

- INVALID_NODE_TYPE_ERR The supplied node is incorrect or has an incorrect ancestor for this operation.

Since: 2.0

- DATA_CLONE_ERR The object cannot be cloned.

Since: 2.0

#### Attributes

- readonly unsigned short code 16-bit error code.

For the possible values of this attribute, see DOMException .

Since: 2.0

- readonly DOMString name An error type. The name attribute must return the value it had been initialized with.

This attribute can have one of the following values:

- UnknownError - An unknown error has occurred.
- InvalidValuesError - The content of an object does not contain valid values.
- IOError - An error occurred in communication with the underlying implementation and so the requested method cannot be completed.
- ServiceNotAvailableError - The requested service is not available.
- VerificationError - An error occurred in authentication and so the requested method cannot be completed.
For other possible values of this attribute, see the values defined in DOM error names

Since: 2.0

- readonly DOMString message An error message that describes the details of an encountered error.

This attribute is mainly intended to be used for developers rather than end users, so it should not be used directly in the user interfaces as it is.

Since: 2.0

### 2.11. WebAPIError

Generic error interface.

```webidl
  [NoInterfaceObject] interface WebAPIError {
    readonly attribute unsigned short code;
    readonly attribute DOMString name;
    readonly attribute DOMString message;
  };
```

Since: 2.0

This interface will be used by the APIs in order to return them in the error callback of asynchronous methods.

#### Attributes

- readonly unsigned short code 16-bit error code.

Possible values are defined in DOMException .

Since: 2.0

- readonly DOMString name An error type. The name attribute must return the value it had been initialized with.

This attribute can have one of the following values:

- UnknownError - An unknown error has occurred.
- InvalidValuesError - The content of an object does not contain valid values.
- IOError - An error occurred in communication with the underlying implementation and so the requested method cannot be completed.
- ServiceNotAvailableError - The requested service is not available.
- VerificationError - An error occurred in authentication and so the requested method cannot be completed.
For other possible values of this attribute, see the values defined in DOM error names

Since: 2.0

- readonly DOMString message An error message that describes the details of the error encountered.

This attribute is not intended to be used directly in the user interfaces
as it is mainly intended to be useful for developers rather than end users.

Since: 2.0

### 2.12. SuccessCallback

This interface is used in methods that do not require any return value in the success callback.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface SuccessCallback {
    void onsuccess();
  };
```

Since: 1.0

In case of successful execution of an asynchronous call, *SuccessCallback *or an API defined callback must be called immediately to notify the user.

Code example:

```javascript
/* This example assumes that the application "MyFiles" */
/* has been installed correctly and can be launched. */

function onSuccess()
{
  console.log("Application launched successfully");
}

/* The ID of launched application. */
var otherAppID = "0pnxz8hbsr.MyFiles";

tizen.application.launch(otherAppID, onSuccess);
```

#### Methods

`**onsuccess **`Method invoked when the asynchronous call completes successfully.

```javascript
void onsuccess();
```

Since: 1.0

### 2.13. ErrorCallback

This interface is used in methods that require only an error as an input parameter in the error callback.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void onerror(WebAPIError error);
  };
```

Since: 1.0

If an invalid function (such as null) is passed to the API that accepts ErrorCallback,
it silently fails and there is no further action.

Code example:

```javascript
/* This example assumes that the application "NonexistentApp" */
/* has not been installed and can not be launched. */

/* Define the error callback. */
function onError(error)
{
  console.log(error.message);
}
function onSuccess()
{
  console.log("The application has launched successfully");
}

/* The ID of non-existing application. */
var bogusAppID = "NonexistentApp.main";

tizen.application.launch(bogusAppID, onSuccess, onError);
```

#### Methods

`**onerror **`Method that is invoked when an error occurs.

```javascript
void onerror(WebAPIError error);
```

Since: 1.0

Parameters:

- **error :
 Generic error. **

### 2.14. BundleItemCallback

Callback for Bundle.forEach() method.

```webidl
  [Callback=FunctionOnly] interface BundleItemCallback {
    void onitem(DOMString key, any value, BundleValueType type);
  };
```

Since: 5.5

#### Methods

`**onitem **`Callback for Bundle.forEach() method.

```javascript
void onitem(DOMString key, any value, BundleValueType type);
```

Since: 5.5

Parameters:

- **key :
 Bundle item key. **
- **value :
 Bundle item value. **
- **type :
 Bundle item type. **

Code example:

```javascript
var bundle = new tizen.Bundle();
bundle.set("string-array", ["hello", "world"]);
bundle.set("string", "hello, world");

/* order in which items will be printed is unspecified. */
bundle.forEach(function(key, value, type)
{
  console.log("key: " + key);
  console.log("value: " + value);
  console.log("type: " + type);
  console.log("---");
});
```

Output example:

```
key: string-array
value: ["hello", "world"]
type: STRING_ARRAY
---
key: string
value: "hello, world"
type: STRING
```

## 3. Full WebIDL

```webidl
module Tizen {
  typedef octet[] ByteStream;
  enum FilterMatchFlag { "EXACTLY", "FULLSTRING", "CONTAINS", "STARTSWITH", "ENDSWITH", "EXISTS" };
  enum SortModeOrder { "ASC", "DESC" };
  enum CompositeFilterType { "UNION", "INTERSECTION" };
  enum BundleValueType { "STRING", "STRING_ARRAY", "BYTES", "BYTES_ARRAY" };
  Window implements TizenObject;
  [NoInterfaceObject] interface TizenObject {
    readonly attribute Tizen tizen;
  };
  [NoInterfaceObject] interface Tizen {
  };
  [Constructor(optional object? json)]
  interface Bundle {
    any get(DOMString key) raises(WebAPIException);
    void set(DOMString key, any value);
    BundleValueType typeOf(DOMString key) raises(WebAPIException);
    void forEach(BundleItemCallback callback);
    object toJSON();
    DOMString toString();
  };
  [NoInterfaceObject] interface AbstractFilter {
  };
  [Constructor(DOMString attributeName, optional FilterMatchFlag? matchFlag, optional any matchValue)]
  interface AttributeFilter : AbstractFilter {
    attribute DOMString attributeName;
    attribute FilterMatchFlag matchFlag;
    attribute any matchValue;
  };
  [Constructor(DOMString attributeName, optional any initialValue, optional any endValue)]
  interface AttributeRangeFilter : AbstractFilter {
    attribute DOMString attributeName;
    attribute any initialValue;
    attribute any endValue;
  };
  [Constructor(CompositeFilterType type, optional AbstractFilter[]? filters)]
  interface CompositeFilter : AbstractFilter {
    attribute CompositeFilterType type;
    attribute AbstractFilter[] filters;
  };
  [Constructor(DOMString attributeName, optional SortModeOrder? order)]
  interface SortMode {
    attribute DOMString attributeName;
    attribute SortModeOrder order;
  };
  [Constructor(double latitude, double longitude)]
  interface SimpleCoordinates {
    attribute double latitude;
    attribute double longitude;
  };
  [NoInterfaceObject] interface WebAPIException {
    const unsigned short INDEX_SIZE_ERR = 1;
    const unsigned short DOMSTRING_SIZE_ERR = 2;
    const unsigned short HIERARCHY_REQUEST_ERR = 3;
    const unsigned short WRONG_DOCUMENT_ERR = 4;
    const unsigned short INVALID_CHARACTER_ERR = 5;
    const unsigned short NO_DATA_ALLOWED_ERR = 6;
    const unsigned short NO_MODIFICATION_ALLOWED_ERR = 7;
    const unsigned short NOT_FOUND_ERR = 8;
    const unsigned short NOT_SUPPORTED_ERR = 9;
    const unsigned short INUSE_ATTRIBUTE_ERR = 10;
    const unsigned short INVALID_STATE_ERR = 11;
    const unsigned short SYNTAX_ERR = 12;
    const unsigned short INVALID_MODIFICATION_ERR = 13;
    const unsigned short NAMESPACE_ERR = 14;
    const unsigned short INVALID_ACCESS_ERR = 15;
    const unsigned short VALIDATION_ERR = 16;
    const unsigned short TYPE_MISMATCH_ERR = 17;
    const unsigned short SECURITY_ERR = 18;
    const unsigned short NETWORK_ERR = 19;
    const unsigned short ABORT_ERR = 20;
    const unsigned short URL_MISMATCH_ERR = 21;
    const unsigned short QUOTA_EXCEEDED_ERR = 22;
    const unsigned short TIMEOUT_ERR = 23;
    const unsigned short INVALID_NODE_TYPE_ERR = 24;
    const unsigned short DATA_CLONE_ERR = 25;
    readonly attribute unsigned short code;
    readonly attribute DOMString name;
    readonly attribute DOMString message;
  };
  [NoInterfaceObject] interface WebAPIError {
    readonly attribute unsigned short code;
    readonly attribute DOMString name;
    readonly attribute DOMString message;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface SuccessCallback {
    void onsuccess();
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void onerror(WebAPIError error);
  };
  [Callback=FunctionOnly] interface BundleItemCallback {
    void onitem(DOMString key, any value, BundleValueType type);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
