# Bluetooth API

The Bluetooth API defines interfaces and methods to manage Bluetooth.

The following Bluetooth functionalities are provided:

- Discovers nearby Bluetooth devices (Device discovery, including Bluetooth LE devices)
- Gets bonded devices information
- Controls bonding
- Connects to a service on a remote device and exchanges data
- Registers a service (RFCOMM) on a local device, which can be consumed by remote devices to exchange data
- Advertise for remote devices (including Bluetooth LE devices)
- Act as a GATT client (Generic Attribute Profile client)
- Configure the local GATT server (Generic Attribute Profile)
For more information on the Bluetooth features, see Bluetooth Guide .

Since: 1.0

## Table of Contents

- 1. Type Definitions
- 1.1. BluetoothAddress
- 1.2. BluetoothUUID
- 1.3. BluetoothSocketState
- 1.4. BluetoothLESolicitationUUID
- 1.5. BluetoothAdvertisePacketType
- 1.6. BluetoothAdvertisingState
- 1.7. BluetoothAdvertisingMode
- 1.8. Bytes
- 1.9. BluetoothGATTServiceVariant
- 1.10. BluetoothGATTCharacteristicVariant
- 1.11. BluetoothGATTDescriptorVariant
- 2. Interfaces
- 2.1. BluetoothManagerObject
- 2.2. BluetoothLEServiceData
- 2.3. BluetoothLEManufacturerData
- 2.4. BluetoothLEAdvertiseDataInit
- 2.5. BluetoothLEAdvertiseData
- 2.6. BluetoothManager
- 2.7. BluetoothAdapter
- 2.8. BluetoothLEAdapter
- 2.9. BluetoothGATTService
- 2.10. BluetoothGATTServerServiceInit
- 2.11. BluetoothGATTServerService
- 2.12. BluetoothGATTCharacteristic
- 2.13. BluetoothGATTServerCharacteristicInit
- 2.14. BluetoothGATTServerCharacteristic
- 2.15. BluetoothGATTDescriptor
- 2.16. BluetoothGATTServerDescriptorInit
- 2.17. BluetoothGATTServerDescriptor
- 2.18. BluetoothGATTServer
- 2.19. BluetoothLEScanCallback
- 2.20. BluetoothLEAdvertiseCallback
- 2.21. BluetoothLEConnectChangeCallback
- 2.22. ReadValueSuccessCallback
- 2.23. GATTRequestReply
- 2.24. ReadValueRequestCallback
- 2.25. WriteValueRequestCallback
- 2.26. NotificationCallback
- 2.27. ConnectionMtuCallback
- 2.28. BluetoothDevice
- 2.29. BluetoothLEDevice
- 2.30. BluetoothSocket
- 2.31. BluetoothClass
- 2.32. BluetoothClassDeviceMajor
- 2.33. BluetoothClassDeviceMinor
- 2.34. BluetoothClassDeviceService
- 2.35. BluetoothServiceHandler
- 2.36. BluetoothAdapterChangeCallback
- 2.37. BluetoothDeviceSuccessCallback
- 2.38. BluetoothDeviceArraySuccessCallback
- 2.39. BluetoothDiscoverDevicesSuccessCallback
- 2.40. BluetoothSocketSuccessCallback
- 2.41. BluetoothServiceSuccessCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| BluetoothManagerObject |  |
| BluetoothLEServiceData |  |
| BluetoothLEManufacturerData |  |
| BluetoothLEAdvertiseDataInit |  |
| BluetoothLEAdvertiseData |  |
| BluetoothManager | BluetoothAdapter getDefaultAdapter () BluetoothLEAdapter getLEAdapter () BluetoothGATTServer getGATTServer () byte[] toByteArray ( Bytes data) DOMString toDOMString ( Bytes data) Uint8Array toUint8Array ( Bytes data) BluetoothUUID uuidTo128bit ( BluetoothUUID uuid) BluetoothUUID uuidToShortestPossible ( BluetoothUUID uuid) boolean uuidsEqual ( BluetoothUUID uuid1, BluetoothUUID uuid2) |
| BluetoothAdapter | void setName (DOMString name, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void setChangeListener ( BluetoothAdapterChangeCallback listener) void unsetChangeListener () void discoverDevices ( BluetoothDiscoverDevicesSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void stopDiscovery (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void getKnownDevices ( BluetoothDeviceArraySuccessCallback successCallback, optional ErrorCallback ? errorCallback) void getDevice ( BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void createBonding ( BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void destroyBonding ( BluetoothAddress address, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void registerRFCOMMServiceByUUID ( BluetoothUUID uuid, DOMString name, BluetoothServiceSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| BluetoothLEAdapter | void startScan ( BluetoothLEScanCallback successCallback, optional ErrorCallback ? errorCallback) void stopScan () boolean isScanning () void startAdvertise ( BluetoothLEAdvertiseData advertiseData, BluetoothAdvertisePacketType packetType, BluetoothLEAdvertiseCallback successCallback, optional ErrorCallback ? errorCallback, optional BluetoothAdvertisingMode ? mode, optional boolean? connectable) void stopAdvertise () long addConnectStateChangeListener ( BluetoothLEConnectChangeCallback listener) void removeConnectStateChangeListener (long watchID) |
| BluetoothGATTService |  |
| BluetoothGATTServerServiceInit |  |
| BluetoothGATTServerService | void unregister (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) |
| BluetoothGATTCharacteristic | void readValue ( ReadValueSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void writeValue ( Bytes value, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) long addValueChangeListener ( ReadValueSuccessCallback callback) void removeValueChangeListener (long watchID) |
| BluetoothGATTServerCharacteristicInit |  |
| BluetoothGATTServerCharacteristic | void notifyAboutValueChange ( Bytes value, BluetoothAddress ? clientAddress, optional NotificationCallback ? notificationCallback, optional ErrorCallback ? errorCallback) void setReadValueRequestCallback ( ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback, optional SuccessCallback ? sendResponseSuccessCallback, optional ErrorCallback ? sendResponseErrorCallback) void setWriteValueRequestCallback ( WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback, optional SuccessCallback ? sendResponseSuccessCallback, optional ErrorCallback ? sendResponseErrorCallback) |
| BluetoothGATTDescriptor | void readValue ( ReadValueSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void writeValue ( Bytes value, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) |
| BluetoothGATTServerDescriptorInit |  |
| BluetoothGATTServerDescriptor | void setReadValueRequestCallback ( ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback, optional SuccessCallback ? sendResponseSuccessCallback, optional ErrorCallback ? sendResponseErrorCallback) void setWriteValueRequestCallback ( WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback, optional SuccessCallback ? sendResponseSuccessCallback, optional ErrorCallback ? sendResponseErrorCallback) |
| BluetoothGATTServer | void start (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void stop (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void registerService ( BluetoothGATTServerServiceInit service, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void unregisterAllServices (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void getConnectionMtu ( BluetoothAddress clientAddress, ConnectionMtuCallback callback, optional ErrorCallback ? errorCallback) |
| BluetoothLEScanCallback | void onsuccess ( BluetoothLEDevice device) |
| BluetoothLEAdvertiseCallback | void onstate ( BluetoothAdvertisingState state) |
| BluetoothLEConnectChangeCallback | void onconnected ( BluetoothLEDevice device) void ondisconnected ( BluetoothLEDevice device) |
| ReadValueSuccessCallback | void onread (byte[] value) |
| GATTRequestReply |  |
| ReadValueRequestCallback | GATTRequestReply ? onreadrequest ( BluetoothAddress clientAddress, long offset) |
| WriteValueRequestCallback | GATTRequestReply ? onwriterequest ( BluetoothAddress clientAddress, byte[] value, long offset, boolean replyRequired) |
| NotificationCallback | void onnotificationsuccess ( BluetoothAddress clientAddress) void onnotificationfail ( BluetoothAddress clientAddress, WebAPIException error) void onnotificationfinish ( BluetoothAddress clientAddress) |
| ConnectionMtuCallback | void onsuccess (long mtu) |
| BluetoothDevice | void connectToServiceByUUID ( BluetoothUUID uuid, BluetoothSocketSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| BluetoothLEDevice | void connect (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void disconnect (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) boolean isConnected () BluetoothGATTService getService ( BluetoothUUID uuid) BluetoothUUID [] getServiceAllUuids () long addConnectStateChangeListener ( BluetoothLEConnectChangeCallback listener) void removeConnectStateChangeListener (long watchID) unsigned long getAttMtu () void requestAttMtuChange (unsigned long newAttMtu) long addAttMtuChangeListener ( ConnectionMtuCallback callback) void removeAttMtuChangeListener (long watchId) |
| BluetoothSocket | unsigned long writeData ( Bytes data) byte[] readData () void close () |
| BluetoothClass | boolean hasService (unsigned short service) |
| BluetoothClassDeviceMajor |  |
| BluetoothClassDeviceMinor |  |
| BluetoothClassDeviceService |  |
| BluetoothServiceHandler | void unregister (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) |
| BluetoothAdapterChangeCallback | void onstatechanged (boolean powered) void onnamechanged (DOMString name) void onvisibilitychanged (boolean visible) |
| BluetoothDeviceSuccessCallback | void onsuccess ( BluetoothDevice device) |
| BluetoothDeviceArraySuccessCallback | void onsuccess ( BluetoothDevice [] devices) |
| BluetoothDiscoverDevicesSuccessCallback | void onstarted () void ondevicefound ( BluetoothDevice device) void ondevicedisappeared ( BluetoothAddress address) void onfinished ( BluetoothDevice [] foundDevices) |
| BluetoothSocketSuccessCallback | void onsuccess ( BluetoothSocket socket) |
| BluetoothServiceSuccessCallback | void onsuccess ( BluetoothServiceHandler handler) |

## 1. Type Definitions

### 1.1. BluetoothAddress

The address of a Bluetooth device.

```webidl
  typedef DOMString BluetoothAddress;
```

Since: 1.0

### 1.2. BluetoothUUID

The UUID of a Bluetooth object.

```webidl
  typedef DOMString BluetoothUUID;
```

Since: 1.0

According to the Bluetooth Core Specification , UUIDs used to represent Bluetooth objects can take 3 forms:

- 128-bit representation: "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX" , where each *'X' *stands for a hexadecimal digit. 
For example: "198d3a9c-e21a-4f72-a48b-39a6bad7e583" .
- 32-bit representation: "D 1 D 2 D 3 D 4 D 5 D 6 D 7 D 8 " , equivalent to "D 1 D 2 D 3 D 4 D 5 D 6 D 7 D 8 -0000-1000-8000-00805F9B34FB" , where D 1 ..D 8 stand for hexadecimal digits. 
For example: "e72ad71b" .
- 16-bit representation: "D 1 D 2 D 3 D 4 " , equivalent to "0000D 1 D 2 D 3 D 4 -0000-1000-8000-00805F9B34FB" , where D 1 ..D 4 stand for hexadecimal digits. 
For example: "d182" .
Unless stated otherwise, each function taking a UUID as a parameter will accept any of the 3 forms and make appropriate conversions. 
Unless stated otherwise, each UUID returned from a function and each UUID attribute of an object may be a 16-bit, 32-bit or 128-bit UUID.
Bluetooth API functions are case-insensitive with regard to UUIDs - lowercase ( abcdef ) and uppercase ( ABCDEF ) characters are recognized as valid hexadecimal digits.

Remark: The 128-bit UUID that is the base for UUIDs having 16-bit or 32-bit equivalents is defined available through the API in BluetoothManager::BASE_UUID .

### 1.3. BluetoothSocketState

Specified the Bluetooth socket state.

```webidl
  enum BluetoothSocketState { "CLOSED", "OPEN" };
```

Since: 1.0

- CLOSED - corresponds to closed bluetooth socket.
- OPEN - corresponds to opened bluetooth socket.

### 1.4. BluetoothLESolicitationUUID

The service solicitation UUID of the Bluetooth LE device.

```webidl
  typedef DOMString BluetoothLESolicitationUUID;
```

Since: 2.3.1

Remark: *BluetoothLESolicitationUUID *is an alias for BluetoothUUID . Values of both types can take the same 16-bit, 32-bit or 128-bit forms.
Functions taking *BluetoothLESolicitationUUID *parameters will accept the same UUID formats as those accepting BluetoothUUID values.

### 1.5. BluetoothAdvertisePacketType

The Bluetooth LE packet type.

```webidl
  enum BluetoothAdvertisePacketType { "ADVERTISE", "SCAN_RESPONSE" };
```

Since: 2.3.1

- ADVERTISE - the advertising packet
- SCAN_RESPONSE- the scan response packet

### 1.6. BluetoothAdvertisingState

The Bluetooth advertising state.

```webidl
  enum BluetoothAdvertisingState { "STARTED", "STOPPED" };
```

Since: 2.3.1

- STARTED - advertising has started
- STOPPED - advertising has stopped

### 1.7. BluetoothAdvertisingMode

The Bluetooth advertising mode.

```webidl
  enum BluetoothAdvertisingMode { "BALANCED", "LOW_LATENCY", "LOW_ENERGY" };
```

Since: 2.3.1

- BALANCED- Balanced advertising mode
- LOW_LATENCY- Low latency advertising mode
- LOW_ENERGY - Low energy advertising mode

### 1.8. Bytes

The Bytes type, that aggregates all types in Bluetooth API used to pass binary data. It can be either a *byte[] *or a *DOMString *or a *Uint8Array *.

```webidl
  typedef (byte[] or DOMString or Uint8Array) Bytes;
```

Since: 1.0

### 1.9. BluetoothGATTServiceVariant

The type of objects which are either BluetoothGATTService or BluetoothGATTServerService , depending on the context in which they appear.

```webidl
  typedef (BluetoothGATTService or BluetoothGATTServerService) BluetoothGATTServiceVariant;
```

Since: 6.0

### 1.10. BluetoothGATTCharacteristicVariant

The type of objects which are either BluetoothGATTCharacteristic or BluetoothGATTServerCharacteristic , depending on the context in which they appear.

```webidl
  typedef (BluetoothGATTCharacteristic or BluetoothGATTServerCharacteristic) BluetoothGATTCharacteristicVariant;
```

Since: 6.0

### 1.11. BluetoothGATTDescriptorVariant

The type of objects which are either BluetoothGATTDescriptor or BluetoothGATTServerDescriptor , depending on the context in which they appear.

```webidl
  typedef (BluetoothGATTDescriptor or BluetoothGATTServerDescriptor) BluetoothGATTDescriptorVariant;
```

Since: 6.0

## 2. Interfaces

### 2.1. BluetoothManagerObject

The BluetoothManagerObject interface defines what is instantiated by the *Tizen *object from the Tizen platform.

```webidl
  [NoInterfaceObject] interface BluetoothManagerObject {
    readonly attribute BluetoothManager bluetooth;
  };
```

```webidl
  Tizen implements BluetoothManagerObject;
```

Since: 1.0

The *tizen.bluetooth *object allows access to the Bluetooth API.

#### Attributes

- readonly BluetoothManager bluetooth Object representing a bluetooth manager.

Since: 1.0

### 2.2. BluetoothLEServiceData

The BluetoothLEServiceData interface is a service specific data container of Bluetooth LE device.

```webidl
  [Constructor(DOMString uuid, Bytes data)]
  interface BluetoothLEServiceData {
    attribute BluetoothUUID uuid;
    attribute DOMString data;
  };
```

Since: 2.3.1

#### Constructors

`**Constructor (DOMString, Bytes ) **`
```webidl
BluetoothLEServiceData(DOMString uuid, Bytes data);
```

Code example:

```javascript
/* Creates a serviceData. */
var service = new tizen.BluetoothLEServiceData("11e5", "0x1811");
```

#### Attributes

- BluetoothUUID uuid The UUID of service data.

Since: 2.3.1

Code example:

```javascript
/* Creates a serviceData. */
var service = new tizen.BluetoothLEServiceData("11e5", "0x1811");
service.uuid = "f23641a4";
```

- DOMString data The service data of the Bluetooth LE device.

Since: 2.3.1

Code example:

```javascript
/* Creates a serviceData. */
var service = new tizen.BluetoothLEServiceData("11e5", "0x1811");
service.data = "0x1815";
```

### 2.3. BluetoothLEManufacturerData

The BluetoothLEManufacturerData interface is a manufacturer specific data container for an advertise or scan response data.

```webidl
  [Constructor(DOMString id, Bytes data)]
  interface BluetoothLEManufacturerData {
    attribute DOMString id;
    attribute DOMString data;
  };
```

Since: 2.3.1

#### Constructors

`**Constructor (DOMString, Bytes ) **`
```webidl
BluetoothLEManufacturerData(DOMString id, Bytes data);
```

Code example:

```javascript
/* Creates a manufacturerData. */
var manufacturer = new tizen.BluetoothLEManufacturerData("127", "0x0057");
```

#### Attributes

- DOMString id The manufacturer assigned ID

Since: 2.3.1

Code example:

```javascript
/* Creates a manufacturerData. */
var manufacturer = new tizen.BluetoothLEManufacturerData("127", "0x0057");
manufacturer.id = "129";
```

- DOMString data The manufacturer data content

The string should consist of hexadecimal characters only (A-F, a-f, 0-9). If the string's length is odd, the last character will be omitted.
The string may start without or with one of below prefixes:

- "0x",
- "0X".
See also, usage of BluetoothLEManufacturerData .

Since: 2.3.1

Code example:

```javascript
/* Creates a manufacturerData. */
var manufacturer = new tizen.BluetoothLEManufacturerData("127", "0x0057");
manufacturer.data = "0x0059";
```

### 2.4. BluetoothLEAdvertiseDataInit

Provides a dictionary for specifying advertise or scan response data.

```webidl
  dictionary BluetoothLEAdvertiseDataInit {
    boolean? includeName;
    BluetoothUUID[]? uuids;
    BluetoothLESolicitationUUID[]? solicitationuuids;
    unsigned long? appearance;
    boolean? includeTxPowerLevel;
    BluetoothLEServiceData[]? servicesData;
    BluetoothLEManufacturerData? manufacturerData;
  };
```

Since: 2.3.1

This dictionary is used as an input parameter of the BluetoothLEAdvertiseData constructor.

Code example:

```javascript
var advertData =
{
  includeName: false,
  uuids: ["41a4"],
  solicitationuuids: ["58574d3f"],
  appearance: 192,
  includeTxPowerLevel: false
};
```

### 2.5. BluetoothLEAdvertiseData

The BluetoothLEAdvertiseData interface is an advertise or scan response data container for Bluetooth advertising.

```webidl
  [Constructor(optional BluetoothLEAdvertiseDataInit? init)]
  interface BluetoothLEAdvertiseData {
    attribute boolean? includeName;
    attribute BluetoothUUID[]? uuids;
    attribute BluetoothLESolicitationUUID[]? solicitationuuids;
    attribute unsigned long? appearance;
    attribute boolean? includeTxPowerLevel;
    attribute BluetoothLEServiceData[]? servicesData;
    attribute BluetoothLEManufacturerData? manufacturerData;
  };
```

Since: 2.3.1

The BluetoothLEAdvertiseData container for Bluetooth LE advertising.
This represents the data to be advertised as well as the scan response data for active scans.

Code example:

```javascript
var advertData =
{
  includeName: false,
  uuids: ["41a4"],
  solicitationuuids: ["58574d3f"],
  appearance: 192,
  includeTxPowerLevel: false
};
var advertise = new tizen.BluetoothLEAdvertiseData(advertData);
```

#### Constructors

`**Constructor ( BluetoothLEAdvertiseDataInit ?) **`
```webidl
BluetoothLEAdvertiseData(optional BluetoothLEAdvertiseDataInit? init);
```

#### Attributes

- boolean includeName [nullable] The flag indicating whether the device name should be included in advertise or scan response data.
If attribute is set to null, The default value is set to a false.

Since: 2.3.1

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();
advertise.includeName = true;
```

- BluetoothUUID[] uuids [nullable] The service UUIDs for advertise or scan response data.

UUIDs may be advertised in another formats than passed in *uuids *. The following conversions are applied:

- 16-bit values are advertised as 16-bit UUIDs
- 128-bit values, that have 16-bit equivalent UUIDs described in BluetoothUUID , are advertised as 16-bit UUIDs
- in any other case, UUIDs are advertised in 128-bit format

Since: 2.3.1

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();
advertise.uuids = ["180d", "7cae86d2-a021-11ea-bb37-0242ac130002"];
```

- BluetoothLESolicitationUUID[] solicitationuuids [nullable] The service solicitation UUIDs for advertise or scan response data.

UUIDs may be advertised in another formats than passed in *solicitationuuids *. The following conversions are applied:

- 16-bit values are advertised as 16-bit UUIDs
- 128-bit values, that have 16-bit equivalent UUIDs described in BluetoothUUID , are advertised as 16-bit UUIDs
- in any other case, UUIDs are advertised in 128-bit format

Since: 2.3.1

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();
advertise.solicitationuuids = ["180f", "7cae86d2-a021-11ea-bb37-0242ac130002"];
```

- unsigned long appearance [nullable] The external appearance of this device for advertise or scan response data.

See the list of appearance codes for sample values.

Since: 2.3.1

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();
advertise.appearance = 192;
```

- boolean includeTxPowerLevel [nullable] The transmission power level should be included in advertise or scan response data.
If attribute is set to null, The default value is set to a false.

Since: 2.3.1

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();
advertise.includeTxPowerLevel = true;
```

- BluetoothLEServiceData[] servicesData [nullable] The array of objects representing service data for advertise.

Since: 6.0

Remark: Only 16-bit BluetoothLEServiceData::uuid values can be advertised. Duplicated *uuid *values in *servicesData *are not allowed for advertising.

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();

var firstService = new tizen.BluetoothLEServiceData("11e5", "0x1811");
var secondService = new tizen.BluetoothLEServiceData("a5e8", "0x1815");
advertise.servicesData = [firstService, secondService];
```

- BluetoothLEManufacturerData manufacturerData [nullable] The manufacturer specific data for advertise or scan response data.

Since: 2.3.1

Code example:

```javascript
var advertise = new tizen.BluetoothLEAdvertiseData();
var manufacturer = new tizen.BluetoothLEManufacturerData("127", "0x0057");
advertise.manufacturerData = manufacturer;
```

### 2.6. BluetoothManager

The BluetoothManager interface provides access to the *BluetoothAdapter *object.

```webidl
  [NoInterfaceObject] interface BluetoothManager {
    const DOMString BASE_UUID = "00000000-0000-1000-8000-00805F9B34FB";
    readonly attribute BluetoothClassDeviceMajor deviceMajor;
    readonly attribute BluetoothClassDeviceMinor deviceMinor;
    readonly attribute BluetoothClassDeviceService deviceService;
    BluetoothAdapter getDefaultAdapter() raises(WebAPIException);
    BluetoothLEAdapter getLEAdapter() raises(WebAPIException);
    BluetoothGATTServer getGATTServer() raises(WebAPIException);
    byte[] toByteArray(Bytes data) raises(WebAPIException);
    DOMString toDOMString(Bytes data) raises(WebAPIException);
    Uint8Array toUint8Array(Bytes data) raises(WebAPIException);
    BluetoothUUID uuidTo128bit(BluetoothUUID uuid) raises(WebAPIException);
    BluetoothUUID uuidToShortestPossible(BluetoothUUID uuid) raises(WebAPIException);
    boolean uuidsEqual(BluetoothUUID uuid1, BluetoothUUID uuid2) raises(WebAPIException);
  };
```

Since: 1.0

#### Constants

- BASE_UUID The base for 128-bit representation of 16-bit and 32-bit UUIDs.

Since: 1.0

#### Attributes

- readonly BluetoothClassDeviceMajor deviceMajor The major device class identifier of Bluetooth class of device (CoD).

Since: 1.0

Code example:

```javascript
console.log(tizen.bluetooth.deviceMajor);
```

- readonly BluetoothClassDeviceMinor deviceMinor The minor device class identifier of Bluetooth class of device (CoD).

Since: 1.0

Code example:

```javascript
console.log(tizen.bluetooth.deviceMinor);
```

- readonly BluetoothClassDeviceService deviceService The major service class identifier of Bluetooth class of device (CoD).

Since: 1.0

Code example:

```javascript
console.log(tizen.bluetooth.deviceService);
```

#### Methods

`**getDefaultAdapter **`Gets the default local Bluetooth adapter.

```javascript
BluetoothAdapter getDefaultAdapter();
```

Since: 1.0

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Return value:

BluetoothAdapter: The local *BluetoothAdapter *object.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
try
{
  var adapter = tizen.bluetooth.getDefaultAdapter();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**getLEAdapter **`Gets the default Low Energy Bluetooth adapter.

```javascript
BluetoothLEAdapter getLEAdapter();
```

Since: 2.3.1

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: To check if this method is supported or not, use tizen.systeminfo.getCapability ("http://tizen.org/feature/network.bluetooth.le").

Return value:

BluetoothLEAdapter: The local *BluetoothLEAdapter *object.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the feature is not supported.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
try
{
  var adapter = tizen.bluetooth.getLEAdapter();
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**getGATTServer **`Gets the BluetoothGATTServer object, which allows starting, stopping the local GATT server, and configuring its services.

```javascript
BluetoothGATTServer getGATTServer();
```

Since: 6.0

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Return value:

BluetoothGATTServer: The BluetoothGATTServer interface to the local GATT server.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the feature is not supported.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var server = tizen.bluetooth.getGATTServer();
```

`**toByteArray **`Converts given data to byte array.

```javascript
byte[] toByteArray(Bytes data);
```

Since: 6.0

If given parameter is of type *DOMSting *the string should consist of hexadecimal characters only (A-F, a-f, 0-9). If the string's length is odd, the last character will be omitted. Only exception is string containing single zero, in which case [0] is returned.
The string may start without or with one of below prefixes:

- "0x",
- "0X".

Parameters:

- **data :
 The data can be either a *byte[] *or a *DOMString *or an *Uint8Array *. **

Return value:

byte[]: byte array with given data.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

Code example:

```javascript
var dataInt8Array = new Int8Array([-21, 31]);
var dataUint8Array = new Uint8Array([240, 129]);
var dataString = "0x18b1";

var fromInt8Array = tizen.bluetooth.toByteArray(dataInt8Array);
var fromUint8Array = tizen.bluetooth.toByteArray(dataUint8Array);
var fromString = tizen.bluetooth.toByteArray(dataString);

console.log("converted from Int8Array: " + JSON.stringify(fromInt8Array));
console.log("converted from Uint8Array: " + JSON.stringify(fromUint8Array));
console.log("converted from DOMString: " + JSON.stringify(fromString));
```

Output example:

```
converted from Int8Array: [235, 31]
converted from Uint8Array: [240, 129]
converted from DOMString: [244, 177]
```

`**toDOMString **`Converts given data to DOMString.

```javascript
DOMString toDOMString(Bytes data);
```

Since: 6.0

Parameters:

- **data :
 The data can be either a *byte[] *or a *DOMString *or an *Uint8Array *. **

Return value:

DOMString: DOMString with given data in the form of hexadecimal number preceded by "0x". The return string is always lowercase.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

Code example:

```javascript
var dataInt8Array = new Int8Array([-21, 31]);
var dataUint8Array = new Uint8Array([240, 129]);
var dataString = "0x18b1";
console.log("converted from Int8Array: " + tizen.bluetooth.toDOMString(dataInt8Array));
console.log("converted from Uint8Array: " + tizen.bluetooth.toDOMString(dataUint8Array));
console.log("converted from DOMString: " + tizen.bluetooth.toDOMString(dataString));
```

Output example:

```
converted from Int8Array: 0xeb1f
converted from Uint8Array: 0xf081
converted from DOMString: 0x18b1
```

`**toUint8Array **`Converts given data to Uint8Array.

```javascript
Uint8Array toUint8Array(Bytes data);
```

Since: 6.0

If given parameter is of type *DOMSting *the string should consist of hexadecimal characters only (A-F, a-f, 0-9). If the string's length is odd, the last character will be omitted. Only exception is string containing single zero, in which case Uint8Array([0]) is returned.
The string may start without or with one of below prefixes:

- "0x",
- "0X".

Parameters:

- **data :
 The data can be either a *byte[] *or a *DOMString *or an *Uint8Array *. **

Return value:

Uint8Array: byte array with given data.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

Code example:

```javascript
var dataInt8Array = new Int8Array([-21, 31]);
var dataUint8Array = new Uint8Array([240, 129]);
var dataString = "0x18b1";

var fromInt8Array = tizen.bluetooth.toUint8Array(dataInt8Array);
var fromUint8Array = tizen.bluetooth.toUint8Array(dataUint8Array);
var fromString = tizen.bluetooth.toUint8Array(dataString);

console.log("converted from Int8Array: " + JSON.stringify(fromInt8Array));
console.log("converted from Uint8Array: " + JSON.stringify(fromUint8Array));
console.log("converted from DOMString: " + JSON.stringify(fromString));
```

Output example:

```
converted from Int8Array: {"0":235, "1":31}
converted from Uint8Array: {"0":240, "1":129}
converted from DOMString: {"0":24, "1":177}
```

`**uuidTo128bit **`Converts given UUID to 128 bit representation.

```javascript
BluetoothUUID uuidTo128bit(BluetoothUUID uuid);
```

Since: 6.0

Parameters:

- **uuid :
 Valid UUID in any representation. **

Return value:

BluetoothUUID: 128 bit representation of given UUID.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, If given parameter is not a valid UUID.

Code example:

```javascript
var uuidFrom16bits = tizen.bluetooth.uuidTo128bit("1234");
var uuidFrom32bits = tizen.bluetooth.uuidTo128bit("ab5690ef");
var uuidFrom128bits = tizen.bluetooth.uuidTo128bit("abcdef01-2345-6789-abcd-ef0123456789");

console.log(uuidFrom16bits);
console.log(uuidFrom32bits);
console.log(uuidFrom128bits);
```

Output example:

```
00001234-0000-1000-8000-00805f9b34fb
ab5690ef-0000-1000-8000-00805f9b34fb
abcdef01-2345-6789-abcd-ef0123456789
```

`**uuidToShortestPossible **`Converts given UUID to the shortest format, in which it can be expressed.

```javascript
BluetoothUUID uuidToShortestPossible(BluetoothUUID uuid);
```

Since: 6.0

This function attempts to return the possible shortest UUID with the following priority:
1. 16 bit
2. 32 bit
3. 128 bit

Parameters:

- **uuid :
 Valid UUID in any representation. **

Return value:

BluetoothUUID: UUID in shortest possible representation.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, If given parameter is not a valid UUID.

Code example:

```javascript
tizen.bluetooth.uuidToShortestPossible("1234");
tizen.bluetooth.uuidToShortestPossible("0000acdf");
tizen.bluetooth.uuidToShortestPossible("ab5690ef-0000-1000-8000-00805F9B34FB");
tizen.bluetooth.uuidToShortestPossible("abcdef01-2345-6789-abcd-ef0123456789");
```

Output example:

```
1234
acdf
ab5690ef
abcdef01-2345-6789-abcd-ef0123456789
```

`**uuidsEqual **`Checks if given parameters are representations of the same UUID.

```javascript
boolean uuidsEqual(BluetoothUUID uuid1, BluetoothUUID uuid2);
```

Since: 6.0

Parameters:

- **uuid1 :
 Valid UUID in any representation. **
- **uuid2 :
 Valid UUID in any representation. **

Return value:

boolean: true if *uuid1 *is a representation of the same UUID as *uuid2 *, false otherwise.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, If any of given parameters is not a valid UUID.

Code example:

```javascript
tizen.bluetooth.uuidsEqual("1234", "00001234");
tizen.bluetooth.uuidsEqual("ab5690ef", "ab5690ef-0000-1000-8000-00805F9B34FB");
tizen.bluetooth.uuidsEqual("abcdef01-2345-6789-abcd-ef0123456789", "abcdef01");
```

Output example:

```
true
true
false
```

### 2.7. BluetoothAdapter

The BluetoothAdapter interface provides access to control the device's Bluetooth adapter.

```webidl
  [NoInterfaceObject] interface BluetoothAdapter {
    readonly attribute DOMString name;
    readonly attribute BluetoothAddress address;
    readonly attribute boolean powered;
    readonly attribute boolean visible;
    void setName(DOMString name, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                 raises(WebAPIException);
    void setChangeListener(BluetoothAdapterChangeCallback listener) raises(WebAPIException);
    void unsetChangeListener() raises(WebAPIException);
    void discoverDevices(BluetoothDiscoverDevicesSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    void stopDiscovery(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void getKnownDevices(BluetoothDeviceArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    void getDevice(BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                   raises(WebAPIException);
    void createBonding(BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                       raises(WebAPIException);
    void destroyBonding(BluetoothAddress address, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void registerRFCOMMServiceByUUID(BluetoothUUID uuid, DOMString name, BluetoothServiceSuccessCallback successCallback,
                                     optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 1.0

This interface offers methods to control local Bluetooth behavior, such as:

- Scanning for remote devices
- Accessing known devices
- Registering a service in the device service database

#### Attributes

- readonly DOMString name The readable name of the Bluetooth adapter.

Since: 1.0

Code example:

```javascript
/* Access adapter name. */
var adapter = tizen.bluetooth.getDefaultAdapter();
console.log("Bluetooth adapter name: " + adapter.name);
```

- readonly BluetoothAddress address The unique hardware address of the Bluetooth adapter, also known as the MAC address.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
console.log("Bluetooth device address: " + adapter.address);
```

- readonly boolean powered The current state of the Bluetooth adapter.

This attribute holds one of the following 2 values:

- true - If Bluetooth adapter is currently on
- false - If Bluetooth adapter is currently off

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
console.log("Bluetooth state: " + (adapter.powered ? "On" : "Off"));
```

- readonly boolean visible The current visibility state of the Bluetooth adapter, that is, whether the local device is discoverable by remote devices.

Since: 1.0

Code example:

```javascript
/* Queries the current visible state. */
var adapter = tizen.bluetooth.getDefaultAdapter();
console.log("Bluetooth Visibility: " + (adapter.visible ? "On" : "Off"));
```

#### Methods

`**setName **`Sets the local Bluetooth adapter name.

```javascript
void setName(DOMString name, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

Sends a request to Bluetooth hardware to change the name of the local Bluetooth adapter to *name *.

The ErrorCallback is launched with these error types:

- InvalidValuesError: If any of the input parameters contain an invalid value.
- ServiceNotAvailableError: If a Bluetooth device is turned off.
- UnknownError: In any other error case.
- NotSupportedError: If a device doesn't allow a Tizen Web application to change the name of the local Bluetooth adapter.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: To check if this method is supported or not, use tizen.systeminfo.getCapability("http://tizen.org/feature/network.bluetooth")

Parameters:

- **name :
            Name to set. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any of the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

var capability = tizen.systeminfo.getCapability("http://tizen.org/feature/network.bluetooth");

function changeName(newName)
{
  if (adapter.name != newName)
  {
    /* Initiate change name. */
    adapter.setName(newName,
        function()
        {
          console.log("Adapter name changed to " + adapter.name);
        },
        function(e)
        {
          console.log("Failed to change name: " + e.message);
        });
  }
}
if (capability === true)
{
  changeName("myDevice");
}
```

`**setChangeListener **`Sets the listener to receive notifications about changes of Bluetooth adapter.

```javascript
void setChangeListener(BluetoothAdapterChangeCallback listener);
```

Since: 2.2

Parameters:

- **listener :
 The Bluetooth Adapter event listener to set. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type SecurityError, if this functionality is not allowed.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var changeListener =
{
  onstatechanged: function(powered)
  {
    console.log("Power state is changed into: " + powered);
  },
  onnamechanged: function(name)
  {
    console.log("Name is changed to: " + name);
  },
  onvisibilitychanged: function(visible)
  {
    console.log("Visibility is changed into: " + visible);
  }
};

var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.setChangeListener(changeListener);
```

`**unsetChangeListener **`Unsets the listener, so stop receiving notifications about changes of Bluetooth adapter.

```javascript
void unsetChangeListener();
```

Since: 2.2

Calling this function has no effect if listener is not set.

Exceptions:

- WebAPIException
- with error type SecurityError, if this functionality is not allowed.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

var changeListener =
{
  onstatechanged: function(powered)
  {
    console.log("Power state is changed into: " + powered);
    if (!powered) adapter.unsetChangeListener();
  },
  onnamechanged: function(name)
  {
    console.log("Name is changed to: " + name);
  },
  onvisibilitychanged: function(visible)
  {
    console.log("Visibility is changed into: " + visible);
  }
};

adapter.setChangeListener(changeListener);
```

`**discoverDevices **`Discovers nearby Bluetooth devices if any, that is, devices within proximity to the local device.

```javascript
void discoverDevices(BluetoothDiscoverDevicesSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

This method initiates the device discovery process. Depending on the progress of this process the following methods are invoked:

- *BluetoothDiscoverDevicesSuccessCallback.onstarted() *- when a discovery process starts successfully.
- *BluetoothDiscoverDevicesSuccessCallback.ondevicefound() *- when any device is found in the process and this method is invoked with the device information. If no device is found, this method will never be invoked.
- *BluetoothDiscoverDevicesSuccessCallback.ondevicedisappeared() *- when a device goes out of proximity and this method is invoked with the address of the device.
- *BluetoothDiscoverDevicesSuccessCallback.onfinished() *- when a discovery process is completed.
A discovery process can be canceled anytime, by calling *stopDiscovery() *on the *BluetoothAdapter *.

The ErrorCallback is launched with these error types:

- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback :
  Callback function that is called when an asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
    Callback function that is called when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any of the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      startDiscovery();
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};
/* Discovery sample code. */

function startDiscovery()
{
  var discoverDevicesSuccessCallback =
  {
    onstarted: function()
    {
      console.log("Device discovery started");
    },
    ondevicefound: function(device)
    {
      console.log("Found device - name: " + device.name + ", Address: " + device.address);
    },
    ondevicedisappeared: function(address)
    {
      console.log("Device disappeared: " + address);
    },
    onfinished: function(devices)
    {
      console.log("Found Devices");
      for (var i = 0; i < devices.length; i++)
      {
        console.log("Name: " + devices[i].name + ", Address: " + devices[i].address);
      }
      console.log("Total: " + devices.length);
    }
  };

  /* Starts searching for nearby devices, for about 12 sec. */
  adapter.discoverDevices(discoverDevicesSuccessCallback, function(e)
  {
    console.log("Failed to search devices: " + e.message + "(" + e.name + ")");
  });
}

/* Execution. */

if (adapter.powered)
{
  console.log("Bluetooth is already enabled");
  startDiscovery();
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

`**stopDiscovery **`Stops an active device discovery session.

```javascript
void stopDiscovery(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

Device discovery is a heavyweight procedure, hence we recommend stopping discovery as soon as the required device is found. This method cancels an active discovery session.

The ErrorCallback is launched with these error types:

- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback [optional] [nullable] :
 Callback function to invoke when an asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
   Callback function to invoke when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any of the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      startDiscovery();
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};
/* Discovery sample code. */

/* Calls this method whenever user finds one of the devices. */
function cancelDiscovery()
{
  adapter.stopDiscovery(
      function()
      {
        console.log("Stop discovery success");
      },
      function(e)
      {
        console.log("Error while stopDiscovery:" + e.message);
      });
}

function startDiscovery()
{
  var discoverDevicesSuccessCallback =
  {
    onstarted: function()
    {
      console.log("Device discovery started");
    },
    ondevicefound: function(device)
    {
      console.log("Found device - name: " + device.name + ", Address: " + device.address);
      /* Shows the device to user to check if this is the device user is looking for. */
      /* For example, add this to list view. */

      cancelDiscovery();
    },
    ondevicedisappeared: function(address)
    {
      console.log("Device disappeared: " + address);
      /* Removes from list, as it is no longer valid. */
    },
    onfinished: function(devices)
    {
      console.log("Found Devices");
      for (var i = 0; i < devices.length; i++)
      {
        console.log("Name: " + devices[i].name + ", Address: " + devices[i].address);
      }
      console.log("Total: " + devices.length);
    }
  };

  /* Starts searching for nearby devices, for about 12 sec. */
  adapter.discoverDevices(discoverDevicesSuccessCallback, function(e)
  {
    console.log("Failed to search devices: " + e.message + "(" + e.name + ")");
  });
}

/* Execution. */

if (adapter.powered)
{
  console.log("Bluetooth is already enabled");
  startDiscovery();
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

`**getKnownDevices **`Gets all the known devices that have information stored in the local Bluetooth adapter.

```javascript
void getKnownDevices(BluetoothDeviceArraySuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

A known device is one of the following:

- a bonded device
- a device found in last inquiry process
On success, it returns the list of currently known devices through *BluetoothDeviceArraySuccessCallback *.

The ErrorCallback is launched with these error types:

- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback :
 Callback function to invoke at retrieval of a list of Bluetooth devices that were bonded (paired) to the local Bluetooth adapter. **
- **errorCallback [optional] [nullable] :
 Callback function to invoke in case of failure in finding bonded devices. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      adapter.getKnownDevices(onGotDevices, onError);
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};
/* getKnownDevices sample code. */

function onGotDevices(devices)
{
  console.log("Devices");
  for (var i = 0; i < devices.length; i++)
  {
    console.log(" Name: " + devices[i].name + ", Address: " + devices[i].address);
  }
  console.log("Total: " + devices.length);
}

function onError(e)
{
  console.log("Error: " + e.message);
}

/* Execution. */

if (adapter.powered)
{
  console.log("Bluetooth is already enabled");
  adapter.getKnownDevices(onGotDevices, onError);
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

`**getDevice **`Gets the *BluetoothDevice *object for a given device hardware address.

```javascript
void getDevice(BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

This method returns device information stored in the local Bluetooth adapter for the specified device *address *through
BluetoothDeviceSuccessCallback.
A valid hardware address must be passed, such as "35:F4:59:D1:7A:03".

The ErrorCallback is launched with these error types:

- NotFoundError - If there is no device with the given address
- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **address :
         Address of a remote Bluetooth device to get. **
- **successCallback :
 Callback function that is called when an asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
function gotDeviceInfo(device)
{
  console.log("Device Name: " + device.name);
  console.log("Device Address: " + device.address);
  console.log("Device Class: " + device.deviceClass.major);
  console.log("Is Bonded: " + (device.isBonded ? "Yes" : "No"));
}

function onError(e)
{
  console.log("Could not get device info:" + e.message);
}

var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("35:F4:59:D1:7A:03", gotDeviceInfo, onError);
```

`**createBonding **`Creates a bond with a remote device by initiating the bonding process with peer device, using the given MAC address. The remote device must be bonded with the local device in order to connect to services of the remote device and then exchange data with each other.

```javascript
void createBonding(BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

If the bonding process is successful, the device information is sent in *successCallback *.

The ErrorCallback is launched with these error types:

- NotFoundError - If there is no device with the given address
- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: Always perform discoverDevices() before bonding devices. This ensures that the device is available and ready for bonding. Otherwise, the bonding process might fail or end with unexpected result.

Parameters:

- **address :
         MAC address of remote Bluetooth address to bond with. **
- **successCallback :
 Callback function that is called when an asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
function onBondingSuccess(device)
{
  console.log("Device Name:" + device.name);
  console.log("Device Address:" + device.address);
  console.log("Device Service UUIDs:" + device.uuids.join("\n"));
}

function onError(e)
{
  console.log("Could not create bonding, reason:" + e.message);
}

var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.createBonding("35:F4:59:D1:7A:03", onBondingSuccess, onError);
```

`**destroyBonding **`Destroys the bond with a remote device.

```javascript
void destroyBonding(BluetoothAddress address, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

This method initiates the process of removing the specified *address *from the list of bonded devices.

The ErrorCallback is launched with these error types:

- NotFoundError - If there is no device with the given address
- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **address :
         Address of a bonded device. **
- **successCallback [optional] [nullable] :
 Callback function that is called when an asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

function gotDevice(device)
{
  if (device.isBonded)
  {
    /* Initiates destroying bonding. */
    adapter.destroyBonding(device.address,
        function()
        {
          console.log("Succeeded to destroy the bond success with:" + device.address);
        },
        function(e)
        {
          console.log(
              "Failed to destroy the bond with " + device.address + ", reason: " + e.message);
        });
  }
}

var deviceAddress = "35:F4:59:D1:7A:03";
adapter.getDevice(deviceAddress, gotDevice, function(e)
{
  console.log("Failed to get device info for " + deviceAddress + ", reason: " + e.message);
});
```

`**registerRFCOMMServiceByUUID **`Registers a service record in the device service record database with the specified *uuid *, *name *.

```javascript
void registerRFCOMMServiceByUUID(BluetoothUUID uuid, DOMString name, BluetoothServiceSuccessCallback successCallback,
                                 optional ErrorCallback? errorCallback);
```

Since: 1.0

On success of the service registration, it returns a *BluetoothServiceHandler *object as the first parameter of *successCallback *, and listens for client connections.
The service handler can be used to be notified on client connections or to unregister the service.
User interaction is mandatory to connect to a registered service.

If any client(remote device) connects to this service, then *BluetoothServiceHandler.onconnect() *is invoked with *BluetoothSocket *object.

*BluetoothServiceHandler.unregister() *can be used to unregister the service record from the device service database and stop listening for client connections.

The ErrorCallback is launched with these error types:

- InvalidValuesError - If any of the input parameters contain an invalid value
- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **uuid :
            UUID of the new service, to which clients connect. Only 128-bit UUIDs are supported. 16-bit and 32-bit UUIDs have to be converted to 128-bit equivalents before being passed to this function. **
- **name :
            Name of a service. **
- **successCallback :
 Callback function that is called on successful service registration. **
- **errorCallback [optional] [nullable] :
   Callback function that is called when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
/* Holds currently registered service record. */
var chatServiceHandler = null;
/* Holds currently open socket. */
var serviceSocket = null;

function chatServiceSuccessCb(recordHandler)
{
  console.log("Chat service registration succeeds!");
  chatServiceHandler = recordHandler;
  recordHandler.onconnect = function(socket)
  {
    console.log("Client connected: " + socket.peer.name + "," + socket.peer.address);
    serviceSocket = socket;
    /* Messages received from remote device. */
    socket.onmessage = function()
    {
      var data = socket.readData();
      /* Handles message code goes here. */
    };

    socket.onclose = function()
    {
      console.log("The socket is closed");
      serviceSocket = null;
    };
  };
}

function publishChatService()
{
  /* Only RFCOMM services with 128-bit UUIDs can be registered */
  var CHAT_SERVICE_UUID = "5BCE9431-6C75-32AB-AFE0-2EC108A30860";
  adapter.registerRFCOMMServiceByUUID(CHAT_SERVICE_UUID, "Chat service", chatServiceSuccessCb,
      /* Error handler. */
      function(e)
      {
        console.log("Could not register service record, Error: " + e.message);
      });
}

function unregisterChatService()
{
  if (chatServiceHandler != null)
  {
    chatServiceHandler.unregister(
        function()
        {
          console.log("Chat service is unregistered");
          chatServiceHandler = null;
        },
        function(e)
        {
          console.log("Failed to unregister service: " + e.message);
        });
  }
}
```

### 2.8. BluetoothLEAdapter

The BluetoothLEAdapter interface provides access to control the device's Bluetooth Low Energy adapter.

```webidl
  [NoInterfaceObject] interface BluetoothLEAdapter {
    void startScan(BluetoothLEScanCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void stopScan() raises(WebAPIException);
    boolean isScanning() raises(WebAPIException);
    void startAdvertise(BluetoothLEAdvertiseData advertiseData, BluetoothAdvertisePacketType packetType,
                        BluetoothLEAdvertiseCallback successCallback, optional ErrorCallback? errorCallback,
                        optional BluetoothAdvertisingMode? mode, optional boolean? connectable) raises(WebAPIException);
    void stopAdvertise() raises(WebAPIException);
    long addConnectStateChangeListener(BluetoothLEConnectChangeCallback listener) raises(WebAPIException);
    void removeConnectStateChangeListener(long watchID);
  };
```

Since: 2.3.1

This interface offers methods to control local Bluetooth Low Energy behavior, such as:

- Scanning and Advertising for remote devices

#### Methods

`**startScan **`Starts scanning for Low Energy advertisement.

```javascript
void startScan(BluetoothLEScanCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

There is no time limit for the bluetooth Low Energy scanning process. It can be canceled only by calling the *stopScan() *method in the *BluetoothLEAdapter *interface.

The *ErrorCallback *will be launched in the following situations:

- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback :
 Called when advertisement is found. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

- with error type InvalidStateError, if device is currently in progress of scanning, if the local Bluetooth le adapter is currently not enabled.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("[Found device] address: " + device.address);
});
```

`**stopScan **`Stops scanning for Low Energy advertisement.

```javascript
void stopScan();
```

Since: 2.3.1

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    adapter.stopScan();
  }
});
```

`**isScanning **`Checks if scanning for Bluetooth Low Energy devices is currently in progress.

```javascript
boolean isScanning();
```

Since: 6.0

Return value:

boolean: true , if the Bluetooth Low Energy Adapter has a scan in progress, false otherwise.

Exceptions:

- WebAPIException
- with error type NotSupportedError, if the device does not support this functionality.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
var scanningStarted = adapter.isScanning();
console.log("Scanning status: " + scanningStarted);
if (!scanningStarted)
{
  adapter.startScan(function onsuccess(device)
  {
    console.log("Scanning status: " + adapter.isScanning());
    adapter.stopScan();
  });
}
```

Output example:

```
Scanning status: false
Scanning status: true
```

`**startAdvertise **`Starts advertising for Low Energy Devices.

```javascript
void startAdvertise(BluetoothLEAdvertiseData advertiseData, BluetoothAdvertisePacketType packetType,
                    BluetoothLEAdvertiseCallback successCallback, optional ErrorCallback? errorCallback,
                    optional BluetoothAdvertisingMode? mode, optional boolean? connectable);
```

Since: 2.3.1

A advertising process can be canceled anytime, by calling *stopAdvertise() *on the *BluetoothLEAdapter *.

The *ErrorCallback *will be launched in the following situations:

- ServiceNotAvailableError - If a Bluetooth device is turned off
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: Values of service UUIDs and solicitation UUIDs may be converted to one of equivalent formats defined in BluetoothUUID before advertising. Consult the documentation of these fields for more information.

Remark: Consult the documentation of BluetoothLEAdvertiseData::serviceData for the information about the UUID format of service data that can be advertised.

Parameters:

- **advertiseData :
 BluetoothLEAdvertiseData object to be added. **
- **packetType :
 The bluetooth LE packet type. **
- **successCallback :
 Callback function that is called when advertise is started successfully. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **
- **mode [optional] [nullable] :
 The power and latency mode of advertising. The default mode is "BALANCED". **
- **connectable [optional] [nullable] :
 The connectable status. It's true if the advertisement will be connectable. The default value of the parameter is true . **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

- with error type QuotaExceededError, if any input attribute is not compatible with the maximum data size for this attribute.

- with error type InvalidValuesError, if advertising services data contains duplicated UUIDs.

- with error type InvalidStateError, if device is currently in progress of advertising, if the local Bluetooth le adapter is currently not enabled.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
/* 16-bit, 32-bit and 128-bit service UUIDs are supported (e.g. 180d, 281eb931, */
/* 7cae86d2-a021-11ea-bb37-0242ac130002). */
var battery_svc_uuid_16 = "180f";

/* 16-bit, 32-bit and 128-bit service solicitation UUIDs are supported(e.g. 180d, 281eb931, */
/* 7cae86d2-a021-11ea-bb37-0242ac130002). */
var heart_rate_svc_uuid_16 = "180d";
var advertiseOptions =
{
  includeName: true,          /* Whether the device name should be included. */
  includeTxPowerLevel: true,  /* Whether the transmission power level should be included. */
  appearance: 192,            /* External appearance of device, 192 - Generic Watch. */
  uuids: [battery_svc_uuid_16],
  solicitationuuids: [heart_rate_svc_uuid_16]
};

var advertiseData = new tizen.BluetoothLEAdvertiseData(advertiseOptions);
var connectable = true;

adapter.startAdvertise(advertiseData, "ADVERTISE",
    function onstate(state)
    {
      console.log("Advertiser state: " + state);
    },
    function(e)
    {
      console.log("Failed to startAdvertise: " + e.message);
    },
    "LOW_LATENCY", connectable);
```

`**stopAdvertise **`Stops advertising for Low Energy Devices.

```javascript
void stopAdvertise();
```

Since: 2.3.1

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
/* 16-bit, 32-bit and 128-bit service UUIDs are supported (e.g. 180d, 281eb931, */
/* 7cae86d2-a021-11ea-bb37-0242ac130002). */
var battery_svc_uuid_16 = "180f";

/* 16-bit, 32-bit and 128-bit service solicitation UUIDs are supported (e.g. 180d, 281eb931, */
/* 7cae86d2-a021-11ea-bb37-0242ac130002). */
var heart_rate_svc_uuid_16 = "180d";
var advertiseOptions =
{
  includeName: true,          /* Whether the device name should be included. */
  includeTxPowerLevel: true,  /* Whether the transmission power level should be included. */
  appearance: 192,            /* External appearance of device, 192 - Generic Watch. */
  uuids: [battery_svc_uuid_16],
  solicitationuuids: [heart_rate_svc_uuid_16]
};

var advertiseData = new tizen.BluetoothLEAdvertiseData(advertiseOptions);

adapter.startAdvertise(advertiseData, "ADVERTISE", function onstate(state)
{
  console.log("Advertiser state: " + state);
});
adapter.stopAdvertise();
```

`**addConnectStateChangeListener **`Registers a listener that is called whenever a GATT connection with another device is established or terminated.

```javascript
long addConnectStateChangeListener(BluetoothLEConnectChangeCallback listener);
```

Since: 6.0

The BluetoothLEConnectChangeCallback , registered with this function, is called in the following cases:

- When the connection between a remote client and a local GATT server is established or terminated.
- When the connection between a local client and a remote GATT server is established or terminated.

Parameters:

- **listener :
 A listener function called when the connection state changes. **

Return value:

long: The watchID to be used to unregister the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
/* This application is running the local GATT Server and does not connect to remote GATT servers. */
/* To be able to notify connected clients about characteristic values' changes, it saves their data. */
var connectedClients = [];

function onConnected(device)
{
  console.log("A client connected: " + device.address);
  connectedClients.push(device);
}

function onDisconnected(device)
{
  console.log("A client disconnected: " + device.address);
  connectedClients = connectedClients.filter(function(connectedClient)
  {
    return connectedClient.address !== device.address;
  });
}

tizen.bluetooth.getLEAdapter().addConnectStateChangeListener(
    {onconnected: onConnected, ondisconnected: onDisconnected});
```

Output example:

```
A client connected: 6A:33:B1:17:D4:81
A client connected: 4B:1F:DD:35:41:19
A client connected: CC:D4:11:E5:72:4B
A client disconnected: 6A:33:B1:17:D4:81
```

`**removeConnectStateChangeListener **`Unregisters a listener called whenever a GATT connection with another device is established or terminated.

```javascript
void removeConnectStateChangeListener(long watchID);
```

Since: 6.0

This function unregisters a BluetoothLEConnectChangeCallback registered with BluetoothLEAdapter.addConnectStateChangeListener() method.

Parameters:

- **watchID :
 The watchID identifier returned by BluetoothGATTServer.addConnectStateChangeListener() method. **

Code example:

```javascript
/* This application is running the local GATT Server and does not connect to remote GATT servers. */
function onConnected(device)
{
  console.log("A client connected: " + device.address);
}

function onDisconnected(device)
{
  console.log("A client disconnected: " + device.address);
}

/* Save watchId to be able to remove the listener later */
var watchId = tizen.bluetooth.getLEAdapter().addConnectStateChangeListener(
    {onconnected: onConnected, ondisconnected: onDisconnected});

/* A little later, the listener is no longer needed, and can be removed with */
/* removeConnectStateChangeListener(watchId) method */
```

Output example:

```
A client connected: 6A:33:B1:17:D4:81
A client connected: 4B:1F:DD:35:41:19
A client connected: CC:D4:11:E5:72:4B
A client disconnected: 6A:33:B1:17:D4:81
```

### 2.9. BluetoothGATTService

Bluetooth Low Energy service. The service can be retrieved with BluetoothLEDevice::getService().

```webidl
  [NoInterfaceObject] interface BluetoothGATTService {
    readonly attribute BluetoothUUID? serviceUuid;
    readonly attribute BluetoothGATTServiceVariant[] services;
    readonly attribute BluetoothGATTCharacteristicVariant[] characteristics;
  };
```

Since: 2.3.1

Code example:

```javascript
function onconnected(device)
{
  console.log("Connected to device");
  var service = device.getService(device.uuids[0]);
  console.log("Service got");
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("[Found device] address: " + device.address);
  device.connect(onconnected.bind(null, device), onerror);
});
```

#### Attributes

- readonly BluetoothUUID serviceUuid [nullable] UUID of the service.

Since: 6.0

Remark: *serviceUuid *is set to null , if the value cannot be retrieved.

Code example:

```javascript
var service = device.getService(device.uuids[0]);
if (service.serviceUuid === null)
{
  console.error("Could not read service UUID");
}
else
{
  console.log("Service UUID " + service.serviceUuid);
}
```

- readonly BluetoothGATTServiceVariant[] services A list of services included in this service.

Since: 2.3.1

Remark: It can be either type BluetoothGATTService for services retrieved from remote GATT servers or type BluetoothGATTServerService for services retrieved from the local GATT server.

Code example:

```javascript
var service = device.getService(device.uuids[0]);
for (var i = 0; i < service.services.length; ++i)
{
  console.log("Subservices UUID " + service.services[i].uuid);
}
```

- readonly BluetoothGATTCharacteristicVariant[] characteristics A list of characteristics in this service.

Since: 2.3.1

Remark: It can be either type BluetoothGATTCha racteristic for characteristics retrieved from services of remote GATT servers or type BluetoothGATTServerCharacteristic for characteristics retrieved from services of local GATT server.

Code example:

```javascript
var service = device.getService(device.uuids[0]);
for (var i = 0; i < service.characteristics.length; ++i)
{
  console.log("Subservices UUID " + service.characteristics[i].isWritable);
}
```

### 2.10. BluetoothGATTServerServiceInit

A dictionary for specifying GATT service parameters.

```webidl
  dictionary BluetoothGATTServerServiceInit {
    BluetoothUUID serviceUuid;
    boolean isPrimary = true;
    BluetoothGATTServerServiceInit[]? includedServices = null;
    BluetoothGATTServerCharacteristicInit[]? characteristics = null;
  };
```

Since: 6.0

This dictionary defines the GATT services to be registered to the local GATT server.

Code example:

```javascript
/* serviceA and serviceB are objects of type BluetoothGATTServerServiceInit. */
/* hrmCharacteristic is a BluetoothGATTServerCharacteristicInit object. */
var serviceParameters =
{
  serviceUuid: "4b102e75",
  isPrimary: true,
  includedServices: [serviceA, serviceB],
  characteristics: [hrmCharacteristic]
};
```

### 2.11. BluetoothGATTServerService

The class representing a Bluetooth GATT service provided by the local GATT server.

```webidl
  [NoInterfaceObject] interface BluetoothGATTServerService : BluetoothGATTService {
    readonly attribute boolean isPrimary;
    void unregister(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 6.0

#### Attributes

- readonly boolean isPrimary Flag indicating whether the service is primary or secondary.

Since: 6.0

#### Methods

`**unregister **`Unregisters the service and all its characteristics from the local GATT server.

```javascript
void unregister(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

The ErrorCallback is launched with these error types:

- InvalidStateError - If the service cannot be unregistered in the current state of the GATT server.
- AbortError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: GATT services included in other GATT services cannot be unregistered.

Remark: If this method is called for the only GATT service, currently registered in the local running GATT server, the server stops running.

Parameters:

- **successCallback [optional] [nullable] :
 Callback function that is called when the service is successfully unregistered from the local GATT server. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
/* The service has been registered in the GATT server for a while. Now it is no longer needed. */
function onsuccess()
{
  console.log("Service unregistered");
}

function onerror(error)
{
  console.log("Failed to unregister service: " + error.message);
}

tizen.bluetooth.getGATTServer().services[0].unregister(onsuccess, onerror);
```

### 2.12. BluetoothGATTCharacteristic

A characteristic provided by Bluetooth Low Energy service.

```webidl
  [NoInterfaceObject] interface BluetoothGATTCharacteristic {
    readonly attribute BluetoothGATTDescriptorVariant[] descriptors;
    readonly attribute boolean isBroadcast;
    readonly attribute boolean hasExtendedProperties;
    readonly attribute boolean isNotify;
    readonly attribute boolean isIndication;
    readonly attribute boolean isReadable;
    readonly attribute boolean isSignedWrite;
    readonly attribute boolean isWritable;
    readonly attribute boolean isWriteNoResponse;
    readonly attribute BluetoothUUID? uuid;
    void readValue(ReadValueSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void writeValue(Bytes value, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                    raises(WebAPIException);
    long addValueChangeListener(ReadValueSuccessCallback callback) raises(WebAPIException);
    void removeValueChangeListener(long watchID);
  };
```

Since: 2.3.1

#### Attributes

- readonly BluetoothGATTDescriptorVariant[] descriptors A list of descriptors in this characteristic.

Since: 2.3.1

Remark: The type of this field is BluetoothGATTDescriptor for descriptors of characteristics retrieved from services of remote GATT servers and BluetoothGATTServerDescriptor for descriptors of characteristics retrieved from the services of local GATT server.

- readonly boolean isBroadcast Indicates if the characteristic is broadcastable.

Since: 2.3.1

- readonly boolean hasExtendedProperties Indicates if the characteristic has extended properties.

Since: 2.3.1

- readonly boolean isNotify Indicates if the characteristic supports notification.

Since: 2.3.1

- readonly boolean isIndication Indicates if the characteristic supports indication.

Since: 2.3.1

- readonly boolean isReadable Indicates if the characteristic is readable.

Since: 2.3.1

- readonly boolean isSignedWrite Indicates if the characteristic supports write with the signature.

Since: 2.3.1

- readonly boolean isWritable Indicates if the characteristic is writable.

Since: 2.3.1

- readonly boolean isWriteNoResponse Indicates if the characteristic supports writing without response.

Since: 2.3.1

- readonly BluetoothUUID uuid [nullable] UUID of the characteristic.

Since: 6.0

Remark: *uuid *is set to null , if the value cannot be retrieved.

#### Methods

`**readValue **`Reads the characteristic value from the remote device. Updates characteristic value attribute.

```javascript
void readValue(ReadValueSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: BluetothGATTServerCharacteristic objects do not support this function. An attempt to call it for such an object will result in an exception.

Parameters:

- **successCallback :
 Callback function that is called when the characteristic value is read successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidStateError, if the local Bluetooth le adapter is currently not enabled.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the method is called for BluetoothGATTServerCharacteristic .

Code example:

```javascript
function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function proccessDevice(device)
{
  device.connect(onConnected, onerror);
  function onConnected()
  {
    var service = device.getService(device.uuids[0]);
    if (service.characteristics.length > 0)
    {
      var characteristic = service.characteristics[0];
      characteristic.readValue(function(val)
      {
        console.log("Value read: " + val);
        device.disconnect();
      });
    }
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    proccessDevice(device);
  }
});
```

`**writeValue **`Writes the characteristic value to the remote device.

```javascript
void writeValue(Bytes value, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: BluetothGATTServerCharacteristic objects do not support this function. An attempt to call it for such an object will result in an exception.

Parameters:

- **value :
 The characteristic value to write. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the characteristic value is written successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidStateError, if the local Bluetooth le adapter is currently not enabled.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the method is called for BluetoothGATTServerCharacteristic .

Code example:

```javascript
function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function proccessDevice(device)
{
  device.connect(onConnected, onerror);
  function onConnected()
  {
    var service = device.getService(device.uuids[0]);
    if (service.characteristics.length > 0)
    {
      var characteristic = service.characteristics[0];
      var data = new Array(1, 2, 3, 4, 5, 6);
      characteristic.writeValue(data,
          function()
          {
            console.log("Value written");
            device.disconnect();
          },
          function(e)
          {
            console.log("Failed to write: " + e.message);
          });
    }
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    proccessDevice(device);
  }
});
```

`**addValueChangeListener **`Registers a callback to be called when characteristic value of the characteristic changes.

```javascript
long addValueChangeListener(ReadValueSuccessCallback callback);
```

Since: 2.3.1

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: BluetothGATTServerCharacteristic objects do not support this function. An attempt to call it for such an object will result in an exception.

Parameters:

- **callback :
 Listener function that is called when the connection state changes. **

Return value:

long: The watchID to be used to unregister the listener.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the method is called for BluetoothGATTServerCharacteristic .

Code example:

```javascript
function proccessDevice(device)
{
  function onConnected()
  {
    var service = device.getService("5BCE9431-6C75-32AB-AFE0-2EC108A30860");
    if (service.characteristics.length > 0)
    {
      var characteristic = service.characteristics[0];
      var watchID;

      watchID = characteristic.addValueChangeListener(function(value)
      {
        console.log("Characteristic value changed: " + value);
        characteristic.removeValueChangeListener(watchID);
        device.disconnect();
      });
    }
  }
  device.connect(onConnected);
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    adapter.stopScan();
    proccessDevice(device);
  }
});
```

`**removeValueChangeListener **`Unregisters a characteristic value change listener.

```javascript
void removeValueChangeListener(long watchID);
```

Since: 2.3.1

Calling this function has no effect if there is no listener with given id.

Remark: Example of using can be find at addValueChangeListener code example.

Remark: Value change listeners cannot be registered and thus unregistered for BluetothGATTServerCharacteristic objects. An attempt to remove value change listener for such an object will result in no operation.

Parameters:

- **watchID :
 The watchID identifier returned by the addValueChangeListener() method. **

### 2.13. BluetoothGATTServerCharacteristicInit

A dictionary for specifying GATT characteristic parameters.

```webidl
  dictionary BluetoothGATTServerCharacteristicInit {
    BluetoothUUID uuid;
    BluetoothGATTServerDescriptorInit[]? descriptors = null;
    boolean isBroadcast = false;
    boolean hasExtendedProperties = false;
    boolean isNotify = false;
    boolean isIndication = false;
    boolean isReadable = false;
    boolean isSignedWrite = false;
    boolean isWritable = false;
    boolean isWriteNoResponse = false;
    boolean readPermission = false;
    boolean writePermission = false;
    boolean encryptedReadPermission = false;
    boolean encryptedWritePermission = false;
    boolean encryptedSignedReadPermission = false;
    boolean encryptedSignedWritePermission = false;
    ReadValueRequestCallback? readValueRequestCallback = null;
    SuccessCallback? readValueSendResponseSuccessCallback = null;
    ErrorCallback? readValueSendResponseErrorCallback = null;
    WriteValueRequestCallback? writeValueRequestCallback = null;
    SuccessCallback? writeValueSendResponseSuccessCallback = null;
    ErrorCallback? writeValueSendResponseErrorCallback = null;
  };
```

Since: 6.0

This dictionary is used as a definition of a characteristic to be registered in a service of the local GATT server. 
*readValueRequestCallback *and *writeValueRequestCallback *are callbacks called when a client reads or writes the value of the characteristic respectively. They can be set or replaced with another functions, after registering the service containing the characteristic, with BluetoothGATTServerCharacteristic.setReadValueRequestCallback() and BluetoothGATTServerCharacteristic.setWriteValueRequestCallback() . 
*readValueSendResponseSuccessCallback *and *writeValueSendResponseSuccessCallback *are success callbacks called when a response sent from *readValueRequestCallback *or *writeValueRequestCallback *reaches client. They can be set or replaced with another functions, after registering the service containing the characteristic, with BluetoothGATTServerCharacteristic.setReadValueRequestCallback() and BluetoothGATTServerCharacteristic.setWriteValueRequestCallback() . 
*readValueSendResponseErrorCallback *and *writeValueSendResponseErrorCallback *are error callbacks called when an attempt to send a response to a client from *readValueRequestCallback *or *writeValueRequestCallback *fails. They can be set or replaced with another functions, after registering the service containing the characteristic, with BluetoothGATTServerCharacteristic.setReadValueRequestCallback() and BluetoothGATTServerCharacteristic.setWriteValueRequestCallback() .

Code example:

```javascript
/* nameDescriptor, placeDescriptor are BluetoothGATTServerDescriptorInit objects */
/* readValueCallback, writeValueCallback are read/write request callbacks */
/* readValueSendResponseSuccessCallback and writeValueSendResponseSuccessCallback */
/* are success callbacks */
/* and writeValueSendResponseErrorCallback and readValueSendResponseErrorCallback */
/* are error callbacks */
var characteristicParameters =
{
  uuid: "0180",
  descriptors: [nameDescriptor, placeDescriptor],
  /* Characteristic's properties */
  isBroadcast: false,
  hasExtendedProperties: false,
  isNotify: false,
  isIndication: false,
  isReadable: true,
  isSignedWrite: false,
  isWritable: true,
  isWriteNoResponse: false,
  /* Characteristic's permissions */
  readPermission: true,
  writePermission: true,
  encryptedReadPermission: false,
  encryptedWritePermission: false,
  encryptedSignedReadPermission: false,
  encryptedSignedWritePermission: false,
  readValueRequestCallback: readValueCallback,
  readValueSendResponseSuccessCallback: readValueSendResponseSuccessCallback,
  readValueSendResponseErrorCallback: readValueSendResponseErrorCallback,
  writeValueRequestCallback: writeValueCallback,
  writeValueSendResponseSuccessCallback: writeValueSendResponseSuccessCallback,
  writeValueSendResponseErrorCallback: writeValueSendResponseErrorCallback
};
```

### 2.14. BluetoothGATTServerCharacteristic

A subclass representing GATT characteristic used to construct a service of the local Bluetooth GATT server.
It extends BluetoothGATTCharacteristic with permissions and methods implementing interactions of the characteristic with remote clients.

```webidl
  [NoInterfaceObject] interface BluetoothGATTServerCharacteristic : BluetoothGATTCharacteristic {
    readonly attribute boolean readPermission;
    readonly attribute boolean writePermission;
    readonly attribute boolean encryptedReadPermission;
    readonly attribute boolean encryptedWritePermission;
    readonly attribute boolean encryptedSignedReadPermission;
    readonly attribute boolean encryptedSignedWritePermission;
    void notifyAboutValueChange(Bytes value, BluetoothAddress? clientAddress, optional NotificationCallback? notificationCallback,
                                optional ErrorCallback? errorCallback) raises(WebAPIException);
    void setReadValueRequestCallback(ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback? successCallback,
                                     optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                     optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
    void setWriteValueRequestCallback(WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback? successCallback,
                                      optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                      optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
  };
```

Since: 6.0

#### Attributes

- readonly boolean readPermission Indicates if clients have the permission to read the value of the characteristic.

Since: 6.0

- readonly boolean writePermission Indicates if clients have the permission to write the value of the characteristic.

Since: 6.0

- readonly boolean encryptedReadPermission Indicates if clients have the permission to read the value of the characteristic through encrypted connections.

Since: 6.0

- readonly boolean encryptedWritePermission Indicates if clients have the permission to write the value of the characteristic through encrypted connections.

Since: 6.0

- readonly boolean encryptedSignedReadPermission Indicates if clients have the permission to perform signed reads of the characteristic's value.

Since: 6.0

- readonly boolean encryptedSignedWritePermission Indicates if clients have the permission to perform signed writes of the characteristic's value.

Since: 6.0

#### Methods

`**notifyAboutValueChange **`Notifies the clients of the local GATT server of the changes in the characteristic.

```javascript
void notifyAboutValueChange(Bytes value, BluetoothAddress? clientAddress, optional NotificationCallback? notificationCallback,
                            optional ErrorCallback? errorCallback);
```

Since: 6.0

This function sends a BLE notification or indication about a change of characteristic's value to clients that registered for it. If a particular client is specified, only he gets the update.
Otherwise it is sent to all clients connected to the local GATT server, who registered for the updates.

Clients can only register for characteristic's notifications or indications, if the characteristic defines a Client Characteristic Configuration Descriptor (CCCD), as described in the Bluetooth standard.
CCCD has to be defined as any other descriptor, using BluetoothGATTServerDescriptorInit .

The ErrorCallback is launched with these error types:

- InvalidValuesError - If any of the parameters is invalid.
- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: To notify the clients the service with current characteristic must be registered (see BluetoothGATTServer::registerService() ) and available for clients (see BluetoothGATTServer::start() ).

Parameters:

- **value :
                The new value of the characteristic. **
- **clientAddress [nullable] :
        The address of the client to be notified about the value change. If a *null *is passed, all clients will be notified. **
- **notificationCallback [optional] [nullable] :
 The callback called for each attempt of a client notification. **
- **errorCallback [optional] [nullable] :
        Callback function that is called in case of failure of sending notification. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server with at least one service which has at least one */
/* characteristic already exists */
var callback =
{
  onnotificationsuccess: function(clientAddress)
  {
    console.log(clientAddress + " notified about change.");
  },
  onnotificationfail: function(clientAddress, error)
  {
    console.error("Couldn't notify " + clientAddress + " about change:" + error.name);
  },
  onnotificationfinish: function(clientAddress)
  {
    console.log("Finished notifying about change.");
  }
};

function errorCallback(error)
{
  console.error("Failed to notify about value change: " + error.name + ": " + error.message);
}

server.services[0].characteristics[0].notifyAboutValueChange("1234", null, callback, errorCallback);
```

`**setReadValueRequestCallback **`Registers the callback called when a client reads the value of the characteristic from the local GATT server.

```javascript
void setReadValueRequestCallback(ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback? successCallback,
                                 optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                 optional ErrorCallback? sendResponseErrorCallback);
```

Since: 6.0

The callback, registered with this function, is called when a remote client requests to read the value of the characteristic.
The server can respond to such requests by returning a GATTRequestReply object from the callback.
If ReadValueRequestCallback for the characteristic is not registered, or it does not return a GATTRequestReply , clients will not be able to get the value of this characteristic.

A callback set with this function overwrites any previously set ReadValueRequestCallback .

The *errorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.
The *sendResponseErrorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- InvalidValuesError - If *GATTRequestReply::statusCode *or *GATTRequestReply::data *is invalid.
- AbortError - If any other error occurs.
Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **readValueRequestCallback :
 The callback called when a client reads the value of the characteristic. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the readValueRequestCallback is registered successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure of readValueRequestCallback registration. **
- **sendResponseSuccessCallback [optional] [nullable] :
 Callback function that is called when responses returned from readValueRequestCallbacks are sent successfully. **
- **sendResponseErrorCallback [optional] [nullable] :
   Callback function that is called when  responses returned from readValueRequestCallbacks are not sent due to an error. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server with at least one service which has at least one */
/* characteristic already exists */
var callback = function(clientAddress, offset)
{
  console.log(clientAddress + " requested to read characteristic's value with offset: " + offset);
  return new tizen.GATTRequestReply(0, "0x1234");
};

server.services[0].characteristics[0].setReadValueRequestCallback(callback);
```

`**setWriteValueRequestCallback **`Registers the callback called when a client writes the value of the characteristic of the local GATT server.

```javascript
void setWriteValueRequestCallback(WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback? successCallback,
                                  optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                  optional ErrorCallback? sendResponseErrorCallback);
```

Since: 6.0

The callback, registered with this function, is called when a remote client requests to write the value of the characteristic.
The server can respond to such requests by returning a GATTRequestReply object from the callback.
If WriteValueRequestCallback for the characteristic is not registered, or it does not return a GATTRequestReply , clients will not be able to get the value of this characteristic.

A callback set with this function overwrites any previously set WriteValueRequestCallback .

The *errorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.
The *sendResponseErrorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- InvalidValuesError - If *GATTRequestReply::statusCode *or *GATTRequestReply::data *is invalid.
- AbortError - If any other error occurs.
Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **writeValueRequestCallback :
 The callback called when a client writes the value of the characteristic. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the writeValueRequestCallback is registered successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure of writeValueRequestCallback registration. **
- **sendResponseSuccessCallback [optional] [nullable] :
 Callback function that is called when responses returned from writeValueRequestCallbacks are sent successfully. **
- **sendResponseErrorCallback [optional] [nullable] :
   Callback function that is called when  responses returned from writeValueRequestCallbacks are not sent due to an error. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server with at least one service which has at least one */
/* characteristic already exists */
var callback = function(clientAddress, value, offset, replyRequired)
{
  console.log(clientAddress + " requested to write characteristic's value: " + value +
              " with offset: " + offset);
  return replyRequired ? new tizen.GATTRequestReply(0, "0x1234") : null;
};

server.services[0].characteristics[0].setWriteValueRequestCallback(callback);
```

### 2.15. BluetoothGATTDescriptor

Bluetooth Low Energy descriptor.

```webidl
  [NoInterfaceObject] interface BluetoothGATTDescriptor {
    readonly attribute BluetoothUUID? uuid;
    void readValue(ReadValueSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void writeValue(Bytes value, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                    raises(WebAPIException);
  };
```

Since: 2.3.1

#### Attributes

- readonly BluetoothUUID uuid [nullable] UUID of the descriptor.

Since: 6.0

Remark: *uuid *is set to null , if the value cannot be retrieved.

#### Methods

`**readValue **`Reads descriptor value from remote device. Updates descriptor value attribute.

```javascript
void readValue(ReadValueSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: BluetothGATTServerDescriptor objects do not support this function. An attempt to call it for such an object will result in an exception.

Parameters:

- **successCallback :
 Callback function that is called when the descriptor value is read successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidStateError, if the local Bluetooth le adapter is currently not enabled.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the method is called for BluetoothGATTServerDescriptor .

Code example:

```javascript
function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function proccessDevice(device)
{
  device.connect(onConnected, onerror);
  function onConnected()
  {
    var service = device.getService(device.uuids[0]);
    if (service.characteristics.length > 0)
    {
      var characteristic = service.characteristics[0];
      var descriptor = characteristic.descriptors[0];
      descriptor.readValue(function(val)
      {
        console.log("Value read: " + val);
        device.disconnect();
      });
    }
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    proccessDevice(device);
  }
});
```

`**writeValue **`Writes the descriptor value to the remote device.

```javascript
void writeValue(Bytes value, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: BluetothGATTServerDescriptor objects do not support this function. An attempt to call it for such an object will result in an exception.

Parameters:

- **value :
 The descriptor value to write. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the descriptor value is written successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidStateError, if the local Bluetooth le adapter is currently not enabled.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type NotSupportedError, if the method is called for BluetoothGATTServerDescriptor .

Code example:

```javascript
function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function proccessDevice(device)
{
  device.connect(onConnected, onerror);
  function onConnected()
  {
    var service = device.getService(device.uuids[0]);
    if (service.characteristics.length > 0)
    {
      var characteristic = service.characteristics[0];
      var data = new Array(1, 2, 3, 4, 5, 6);
      var descriptor = characteristic.descriptors[0];
      descriptor.writeValue(data,
          function()
          {
            console.log("Value written");
            device.disconnect();
          },
          function(e)
          {
            console.log("Failed to write: " + e.message);
          });
    }
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    proccessDevice(device);
  }
});
```

### 2.16. BluetoothGATTServerDescriptorInit

A dictionary for specifying GATT descriptor parameters.

```webidl
  dictionary BluetoothGATTServerDescriptorInit {
    BluetoothUUID uuid;
    boolean readPermission = false;
    boolean writePermission = false;
    boolean encryptedReadPermission = false;
    boolean encryptedWritePermission = false;
    boolean encryptedSignedReadPermission = false;
    boolean encryptedSignedWritePermission = false;
    ReadValueRequestCallback? readValueRequestCallback = null;
    SuccessCallback? readValueSendResponseSuccessCallback = null;
    ErrorCallback? readValueSendResponseErrorCallback = null;
    WriteValueRequestCallback? writeValueRequestCallback = null;
    SuccessCallback? writeValueSendResponseSuccessCallback = null;
    ErrorCallback? writeValueSendResponseErrorCallback = null;
  };
```

Since: 6.0

This dictionary is used as a definition of a descriptor to be registered in a characteristic of the local GATT server. 
*readValueRequestCallback *and *writeValueRequestCallback *are callbacks called when a client reads or writes the value of the descriptor respectively. They can be set or replaced with another functions after registering the service containing the descriptor with BluetoothGATTServerDescriptor.setReadValueRequestCallback() and BluetoothGATTServerDescriptor.setWriteValueRequestCallback() . 
*readValueSendResponseSuccessCallback *and *writeValueSendResponseSuccessCallback *are success callbacks called when a response sent from *readValueRequestCallback *or *writeValueRequestCallback *reaches client. They can be set or replaced with another functions, after registering the service containing the characteristic, with BluetoothGATTServerDescriptor.setReadValueRequestCallback() and BluetoothGATTServerDescriptor.setWriteValueRequestCallback() . 
*readValueSendResponseErrorCallback *and *writeValueSendResponseErrorCallback *are error callbacks called when an attempt to send a response to a client from *readValueRequestCallback *or *writeValueRequestCallback *fails. They can be set or replaced with another functions, after registering the service containing the characteristic, with BluetoothGATTServerDescriptor.setReadValueRequestCallback() and BluetoothGATTServerDescriptor.setWriteValueRequestCallback() .

Code example:

```javascript
/* readValueCallback, writeValueCallback are read/write request callbacks */
/* readValueSendResponseSuccessCallback and writeValueSendResponseSuccessCallback are success */
/* callbacks */
/* and writeValueSendResponseErrorCallback and readValueSendResponseErrorCallback are error */
/* callbacks */
var descriptorProperties =
{
  uuid: "0180",
  /* Descriptor's permissions */
  readPermission: true,
  writePermission: true,
  encryptedReadPermission: false,
  encryptedWritePermission: false,
  encryptedSignedReadPermission: false,
  encryptedSignedWritePermission: false,
  /* Read/write value callbacks */
  readValueRequestCallback: readValueCallback,
  readValueSendResponseSuccessCallback: readValueSendResponseSuccessCallback,
  readValueSendResponseErrorCallback: readValueSendResponseErrorCallback,
  writeValueRequestCallback: writeValueCallback,
  writeValueSendResponseSuccessCallback: writeValueSendResponseSuccessCallback,
  writeValueSendResponseErrorCallback: writeValueSendResponseErrorCallback
};
```

### 2.17. BluetoothGATTServerDescriptor

A subclass representing GATT descriptors of characteristics registered in services of the local server.
It extends BluetoothGATTDescriptor with permissions and methods implementing interactions of the descriptor with remote clients.

```webidl
  [NoInterfaceObject] interface BluetoothGATTServerDescriptor : BluetoothGATTDescriptor {
    readonly attribute boolean readPermission;
    readonly attribute boolean writePermission;
    readonly attribute boolean encryptedReadPermission;
    readonly attribute boolean encryptedWritePermission;
    readonly attribute boolean encryptedSignedReadPermission;
    readonly attribute boolean encryptedSignedWritePermission;
    void setReadValueRequestCallback(ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback? successCallback,
                                     optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                     optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
    void setWriteValueRequestCallback(WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback? successCallback,
                                      optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                      optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
  };
```

Since: 6.0

#### Attributes

- readonly boolean readPermission Indicates if clients have the permission to read the value of the descriptor.

Since: 6.0

- readonly boolean writePermission Indicates if clients have the permission to write the value of the descriptor.

Since: 6.0

- readonly boolean encryptedReadPermission Indicates if clients have the permission to read the value of the descriptor through encrypted connections.

Since: 6.0

- readonly boolean encryptedWritePermission Indicates if clients have the permission to write the value of the descriptor through encrypted connections.

Since: 6.0

- readonly boolean encryptedSignedReadPermission Indicates if clients have the permission to perform signed reads of the charactersitic's value.

Since: 6.0

- readonly boolean encryptedSignedWritePermission Indicates if clients have the permission to perform signed writes of the charactersitic's value.

Since: 6.0

#### Methods

`**setReadValueRequestCallback **`Registers the callback called when a client reads the value of the descriptor from the local GATT server.

```javascript
void setReadValueRequestCallback(ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback? successCallback,
                                 optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                 optional ErrorCallback? sendResponseErrorCallback);
```

Since: 6.0

The callback, registered with this function, is called when a remote client requests to read the value of the descriptor.
The server can respond to such requests by returning a GATTRequestReply object from the callback.
If ReadValueRequestCallback for the descriptor is not registered, or it does not return a GATTRequestReply , clients will not be able to get the value of this descriptor.

A callback set with this function overwrites any previously set ReadValueRequestCallback .

The *errorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.
The *sendResponseErrorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- InvalidValuesError - If *GATTRequestReply::statusCode *or *GATTRequestReply::data *is invalid.
- AbortError - If any other error occurs.
Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **readValueRequestCallback :
 The callback called when a client reads the value of the descriptor. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the readValueRequestCallback is registered successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure of readValueRequestCallback registration. **
- **sendResponseSuccessCallback [optional] [nullable] :
 Callback function that is called when responses returned from readValueRequestCallbacks are sent successfully. **
- **sendResponseErrorCallback [optional] [nullable] :
   Callback function that is called when  responses returned from readValueRequestCallbacks are not sent due to an error. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server with at least one service which has at least one */
/* characteristic with at least one descriptor already exists */
var callback = function(clientAddress, offset)
{
  console.log(clientAddress + " requested to read characteristic's value with offset: " + offset);
  return new tizen.GATTRequestReply(0, "0x1234");
};
server.services[0].characteristics[0].descriptors[0].setReadValueRequestCallback(callback);
```

`**setWriteValueRequestCallback **`Registers the callback called when a remote client writes the value of the descriptor from the local GATT server.

```javascript
void setWriteValueRequestCallback(WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback? successCallback,
                                  optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                  optional ErrorCallback? sendResponseErrorCallback);
```

Since: 6.0

The callback, registered with this function, is called when a remote client requests to write the value of the descriptor.
The server can respond to such requests by returning a GATTRequestReply object from the callback.
If WriteValueRequestCallback for the descriptor is not registered, or it does not return a GATTRequestReply , clients will not be able to get the value of this descriptor.

A callback set with this function overwrites any previously set WriteValueRequestCallback .

The *errorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.
The *sendResponseErrorCallback *will be launched in the following situations:

- NotSupportedError - If the feature is not supported.
- InvalidValuesError - If *GATTRequestReply::statusCode *or *GATTRequestReply::data *is invalid.
- AbortError - If any other error occurs.
Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **writeValueRequestCallback :
 The callback called when a client writes the value of the descriptor. **
- **successCallback [optional] [nullable] :
 Callback function that is called when the writeValueRequestCallback is registered successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure of writeValueRequestCallback registration. **
- **sendResponseSuccessCallback [optional] [nullable] :
 Callback function that is called when responses returned from writeValueRequestCallbacks are sent successfully. **
- **sendResponseErrorCallback [optional] [nullable] :
   Callback function that is called when  responses returned from writeValueRequestCallbacks are not sent due to an error. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server with at least one service which has at least one */
/* characteristic with at least one descriptor already exists */
var callback = function(clientAddress, value, offset, replyRequired)
{
  console.log(clientAddress + " requested to write descriptor's value: " + value +
              " with offset: " + offset);
  return replyRequired ? new tizen.GATTRequestReply(0, "0x1234") : null;
};
server.services[0].characteristics[0].descriptors[0].setWriteValueRequestCallback(callback);
```

### 2.18. BluetoothGATTServer

The BluetoothGATTServer interface provides access to control the local GATT server: starting and stopping it, registering and unregistering local GATT services, and getting the ATT MTU (Attribute Protocol Maximum Transmission Unit) values.

```webidl
  [NoInterfaceObject] interface BluetoothGATTServer {
    readonly attribute boolean isRunning;
    readonly attribute BluetoothGATTServerService[] services;
    void start(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void stop(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void registerService(BluetoothGATTServerServiceInit service, optional SuccessCallback? successCallback,
                         optional ErrorCallback? errorCallback) raises(WebAPIException);
    void unregisterAllServices(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
    void getConnectionMtu(BluetoothAddress clientAddress, ConnectionMtuCallback callback, optional ErrorCallback? errorCallback)
                          raises(WebAPIException);
  };
```

Since: 6.0

#### Attributes

- readonly boolean isRunning The flag indicating if remote GATT clients can currently connect to the server, exposing services defined in BluetoothGATTServer::services . It is toggled on start() and stop() calls.

Since: 6.0

- readonly BluetoothGATTServerService[] services The list of GATT services hosted on this server.

Since: 6.0

#### Methods

`**start **`Starts the local GATT server. After it starts, it can conduct GATT server operations. Also, the remote clients can discover and use the services provided by the local Bluetooth GATT Server.

```javascript
void start(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

The *ErrorCallback *will be launched in the following situations:

- InvalidStateError - If the server is already running.
- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback [optional] [nullable] :
 Called when the server is started. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **

Exceptions:

- WebAPIException
- with error type InvalidStateError, if the Bluetooth adapter is not enabled.

- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var onSuccess = function()
{
  console.log("Server started successfully!");
};

var onError = function(e)
{
  console.error("Server didn't start, error: " + e);
};

var server = tizen.bluetooth.getGATTServer();

server.start(onSuccess, onError);
```

Output example:

```
Server started successfully!
```

`**stop **`Stops GATT server operation.

```javascript
void stop(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

After the stop, remote clients will not be able to discover the local GATT server's services.

The *ErrorCallback *will be launched in the following situations:

- InvalidStateError - If the server is not running.
- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback [optional] [nullable] :
 Called when the server is stopped. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **

Exceptions:

- WebAPIException
- with error type InvalidStateError, if the Bluetooth adapter is not enabled.

- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
/* this example assumes that local gatt server already exists and it is started */
var onSuccess = function()
{
  console.log("Server stopped successfully!");
};

var onError = function(e)
{
  console.error("Server didn't stop, error: " + e);
};

server.stop(onSuccess, onError);
```

Output example:

```
Server stopped successfully!
```

`**registerService **`Registers a primary service in the local GATT server.

```javascript
void registerService(BluetoothGATTServerServiceInit service, optional SuccessCallback? successCallback,
                     optional ErrorCallback? errorCallback);
```

Since: 6.0

The service is available for clients after BluetoothGATTServer::start() call.

The ErrorCallback is launched with these error types:

- InvalidStateError - If the service cannot be registered in the current state of the server.
- NotSupportedError - If the feature is not supported.
- InvalidValuesError - If any of the input parameters contains an invalid value
- AbortError - If any other error occurs.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: Services can only be registered before starting server.

Parameters:

- **service :
 The definition of a service to be registered in the local GATT server. **
- **successCallback [optional] [nullable] :
 Called when the local GATT server's services are successfully registered. **
- **errorCallback [optional] [nullable] :
 The method to invoke when an error occurs. **

Exceptions:

- WebAPIException
- with error type InvalidStateError, if the Bluetooth adapter is not enabled.

- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var gattService = {serviceUuid: "0955", isPrimary: false, services: [], characteristics: []};

var successCB = function()
{
  console.log("Service successfully registered!");
};

var errorCB = function(e)
{
  console.log("Service not registered, error: " + e);
};

var server = tizen.bluetooth.getGATTServer();

server.registerService(gattService, successCB, errorCB);
```

Output example:

```
Service successfully registered!
```

`**unregisterAllServices **`Unregisters all services from the local GATT server.

```javascript
void unregisterAllServices(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 6.0

This method unregisters all services and all their characteristics from the local GATT server.

The ErrorCallback is launched with these error types:

- InvalidStateError - If the service cannot be unregistered in the current state of the GATT server.
- AbortError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: Currently running local GATT server is stopped after calling this method.

Parameters:

- **successCallback [optional] [nullable] :
 Callback function that is called when services are successfully unregistered from the local GATT server. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server already exists */
var successCB = function()
{
  console.log("Services successfully unregistered!");
};

var errorCB = function(e)
{
  console.log("Services not unregistered, error: " + e);
};

server.unregisterAllServices(successCB, errorCB);
```

Output example:

```
Services successfully unregistered!
```

`**getConnectionMtu **`Gets the ATT MTU for the connection with a client.

```javascript
void getConnectionMtu(BluetoothAddress clientAddress, ConnectionMtuCallback callback, optional ErrorCallback? errorCallback);
```

Since: 6.0

The *ErrorCallback *is launched with these error types:

- InvalidStateError - If the server is not running.
- NotSupportedError - If the feature is not supported.
- AbortError - If any other error occurs.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **clientAddress :
 MAC address of the client, for connection with whom the MTU is to be retrieved. **
- **callback :
 Callback functions that are called when the connection state changes. **
- **errorCallback [optional] [nullable] :
 Callback function that is called when getting MTU of a connection fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* this example assumes that the local gatt server already exists */
var successCB = function(mtu)
{
  console.log("ATT MTU value is: " + mtu);
};

var errorCB = function(e)
{
  console.log("Cannot retrieve the ATT MTU, error: " + e);
};

server.getConnectionMtu("12:34:56:78:90:ab", successCB, errorCB);
```

Output example:

```
ATT MTU value is: 123
```

### 2.19. BluetoothLEScanCallback

Bluetooth scanning process interface that defines the success callback for *BluetoothLEAdapter.startScan() *

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothLEScanCallback {
    void onsuccess(BluetoothLEDevice device);
  };
```

Since: 2.3.1

Remark: Example of using can be find at startScan code example.

#### Methods

`**onsuccess **`Called when a new device is successfully discovered in the process of scanning.

```javascript
void onsuccess(BluetoothLEDevice device);
```

Since: 2.3.1

Parameters:

- **device :
 Device that is found. **

### 2.20. BluetoothLEAdvertiseCallback

Bluetooth advertising process interface that defines the success callback for *BluetoothLEAdapter.startAdvertise() *

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothLEAdvertiseCallback {
    void onstate(BluetoothAdvertisingState state);
  };
```

Since: 2.3.1

Remark: Example of using can be find at startAdvertise code example.

#### Methods

`**onstate **`Called when the advertising state is changed.

```javascript
void onstate(BluetoothAdvertisingState state);
```

Since: 2.3.1

Parameters:

- **state :
 State that is Advertising process. **

### 2.21. BluetoothLEConnectChangeCallback

Bluetooth LE connecting process interface that defines callbacks for getting notified about changes of connect to a specific LE based service on a remote Bluetooth LE device.

```webidl
  [Callback, NoInterfaceObject] interface BluetoothLEConnectChangeCallback {
    void onconnected(BluetoothLEDevice device);
    void ondisconnected(BluetoothLEDevice device);
  };
```

Since: 2.3.1

Remark: Example of using can be find at addConnectStateChangeListener code example.

#### Methods

`**onconnected **`Called at the beginning of connect to a specific LE based service on a remote Bluetooth LE device.

```javascript
void onconnected(BluetoothLEDevice device);
```

Since: 2.3.1

`**ondisconnected **`Called at the beginning of disconnect to a specific LE based service on a remote Bluetooth LE device.

```javascript
void ondisconnected(BluetoothLEDevice device);
```

Since: 2.3.1

### 2.22. ReadValueSuccessCallback

The ReadValueSuccessCallback interface implements the callback for BluetoothGATTCharacteristic.readValue() and BluetoothGATTDescriptor.readValue() methods.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ReadValueSuccessCallback {
    void onread(byte[] value);
  };
```

Since: 2.3.1

Remark: Example of using can be find at BluetoothGATTCharacteristic.readValue() and BluetoothGATTDescriptor.readValue() code examples.

#### Methods

`**onread **`Called when a characteristic value has been read.

```javascript
void onread(byte[] value);
```

Since: 2.3.1

Parameters:

- **value :
 Read characteristic value. **

### 2.23. GATTRequestReply

Representation of the local GATT server's response to request read/write to characteristic/descriptor.

```webidl
  [Constructor(long statusCode = 0, optional Bytes data)]
  interface GATTRequestReply {
    attribute long statusCode;
    attribute Bytes? data;
  };
```

Since: 6.0

#### Constructors

`**Constructor (long, Bytes ) **`
```webidl
GATTRequestReply(long statusCode = 0, optional Bytes data);
```

#### Attributes

- long statusCode Reply status code.

Since: 6.0

- Bytes data [nullable] Response data. It is only relevant for read value requests. It will be ignored in replies to write requests and thus can be uninitialized in such replies.

Since: 6.0

### 2.24. ReadValueRequestCallback

The ReadValueRequestCallback interface implements the callback for *BluetoothGATTServerCharacteristicInit.readValueRequestCallback() *, BluetoothGATTServerCharacteristic.setReadValueRequestCallback() , *BluetoothGATTServerDescriptorInit.readValueRequestCallback() *and BluetoothGATTServerDescriptor.setReadValueRequestCallback() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ReadValueRequestCallback {
    GATTRequestReply? onreadrequest(BluetoothAddress clientAddress, long offset);
  };
```

Since: 6.0

Remark: Example of using can be found at BluetoothGATTServerCharacteristic.setReadValueRequestCallback() and BluetoothGATTServerDescriptor.setReadValueRequestCallback() code examples.

#### Methods

`**onreadrequest **`Called when a client makes a read request for GATT characteristic to the connected local GATT server.

```javascript
GATTRequestReply? onreadrequest(BluetoothAddress clientAddress, long offset);
```

Since: 6.0

The server should reply to requests by returning a GATTRequestReply object with requested data and a proper status code.
If the callback does not return a GATTRequestReply , the client will not receive a response.

Parameters:

- **clientAddress :
 MAC address of the client that requested the value read of the GATT entity. **
- **offset :
 The offset given for the value of characteristic to read. **

Return value:

GATTRequestReply [nullable] : *GATTRequestReply *object with a status code and requested data.

### 2.25. WriteValueRequestCallback

The WriteValueRequestCallback interface implements the callback for *BluetoothGATTServerCharacteristicInit.writeValueRequestCallback() *, BluetoothGATTServerCharacteristic.setWriteValueRequestCallback() , *BluetoothGATTServerDescriptorInit.writeValueRequestCallback() *and BluetoothGATTServerDescriptor.setWriteValueRequestCallback() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface WriteValueRequestCallback {
    GATTRequestReply? onwriterequest(BluetoothAddress clientAddress, byte[] value, long offset, boolean replyRequired);
  };
```

Since: 6.0

Remark: Example of using can be found at BluetoothGATTServerCharacteristic.setWriteValueRequestCallback() and BluetoothGATTServerDescriptor.setWriteValueRequestCallback() code examples.

#### Methods

`**onwriterequest **`Called when a client connected to the local GATT server requests characteristic's value write.

```javascript
GATTRequestReply? onwriterequest(BluetoothAddress clientAddress, byte[] value, long offset, boolean replyRequired);
```

Since: 6.0

The server should reply to requests by returning a GATTRequestReply object with a status code.
If the callback does not return a GATTRequestReply , the client will not receive a response.

Parameters:

- **clientAddress :
 MAC address of the client that requested the value write of the GATT entity. **
- **value :
 Value to be written to the GATT entity. **
- **offset :
 Offset from which the value is to be written. **
- **replyRequired :
 Flag indicating whether the client requested an answer to the request. If it's false, the client preforms the *write without response *operation defined in Bluetooth Core Specification. **

### 2.26. NotificationCallback

The NotificationCallback interface implements the success callback for BluetoothGATTServerCharacteristic.notifyAboutValueChange() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface NotificationCallback {
    void onnotificationsuccess(BluetoothAddress clientAddress);
    void onnotificationfail(BluetoothAddress clientAddress, WebAPIException error);
    void onnotificationfinish(BluetoothAddress clientAddress);
  };
```

Since: 6.0

Remark: Example of using can be found at BluetoothGATTServerCharacteristic.notifyAboutValueChange() code examples.

#### Methods

`**onnotificationsuccess **`Called when the local GATT server successfully notifies a client of a characteristic's value change.

```javascript
void onnotificationsuccess(BluetoothAddress clientAddress);
```

Since: 6.0

Parameters:

- **clientAddress :
 MAC address of the client that was notified. **

`**onnotificationfail **`Called when the local GATT server fails to notify a client of a characteristic's value change.

```javascript
void onnotificationfail(BluetoothAddress clientAddress, WebAPIException error);
```

Since: 6.0

Parameters:

- **clientAddress :
 MAC address of the client that was notified. **
- **error :
 The error type and an error message from Tizen's Bluetooth LE stack. **

`**onnotificationfinish **`Called when the last of all client notifications was sent.

```javascript
void onnotificationfinish(BluetoothAddress clientAddress);
```

Since: 6.0

Parameters:

- **clientAddress :
 MAC address of the last client that was notified. **

### 2.27. ConnectionMtuCallback

The ConnectionMtuCallback interface implements the callback for BluetoothGATTServer.getConnectionMtU() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ConnectionMtuCallback {
    void onsuccess(long mtu);
  };
```

Since: 6.0

Remark: Example of using can be found at BluetoothGATTServer.getConnectionMtu() code example.

#### Methods

`**onsuccess **`Called when the requested ATT MTU size for a connection is ready.

```javascript
void onsuccess(long mtu);
```

Since: 6.0

Parameters:

- **mtu :
 The requested ATT MTU value for the connection with another Bluetooth LE device. **

### 2.28. BluetoothDevice

The BluetoothDevice interface represents a remote Bluetooth device.

```webidl
  [NoInterfaceObject] interface BluetoothDevice {
    readonly attribute DOMString name;
    readonly attribute BluetoothAddress address;
    readonly attribute BluetoothClass deviceClass;
    readonly attribute boolean isBonded;
    readonly attribute boolean isTrusted;
    readonly attribute boolean isConnected;
    readonly attribute BluetoothUUID[] uuids;
    void connectToServiceByUUID(BluetoothUUID uuid, BluetoothSocketSuccessCallback successCallback,
                                optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 1.0

A *BluetoothDevice *object can be retrieved using one of the following APIs:

- BluetoothAdapter.getDevice()
- BluetoothAdapter.getKnownDevices()
- BluetoothAdapter.discoverDevices()
- BluetoothAdapter.createBonding()

#### Attributes

- readonly DOMString name The readable name of this remote device.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  console.log("Device Name: " + device.name);
});
```

- readonly BluetoothAddress address The hardware address of this remote device.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  console.log("Device Address: " + device.address);
});
```

- readonly BluetoothClass deviceClass The device class, which represents the type of the device and the services it provides.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  console.log("Device Major Class: " + device.deviceClass.major);
});
```

- readonly boolean isBonded The bond state of this remote device with the local device.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  console.log("Is bonded: " + (device.isBonded ? "Yes" : "No"));
});
```

- readonly boolean isTrusted The flag indicating whether the local device recognizes this remote device as a trusted device or not.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  console.log("Is trusted: " + (device.isTrusted ? "Yes" : "No"));
});
```

- readonly boolean isConnected The flag indicating whether the connection state of this remote device with the local device.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  console.log("Is connected: " + (device.isConnected ? "Yes" : "No"));
});
```

- readonly BluetoothUUID[] uuids The list of 128-bit service UUIDs available on this remote device.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
var CHAT_SERVICE_UUID = "5BCE9431-6C75-32AB-AFE0-2EC108A30860";
adapter.getDevice("11:22:33:44:55:66", function(device)
{
  var uuids = device.uuids;
  var services = "";
  for (var i = 0; i < uuids.length; i++)
  {
    services += uuids[i] + "\n";
  }
  console.log("Services found: " + services);
  if (uuids.indexOf(CHAT_SERVICE_UUID) != -1)
  {
    /* Connects to service. */
    device.connectToServiceByUUID(CHAT_SERVICE_UUID,
        function(socket)
        {
          /* Connected to service, handle socket. */
        },
        function(e)
        {
          console.log("Could not connect to chat service !!!. Error: " + e.message);
        });
  }
});
```

#### Methods

`**connectToServiceByUUID **`Connects to a specified service identified by *uuid *on this remote device.

```javascript
void connectToServiceByUUID(BluetoothUUID uuid, BluetoothSocketSuccessCallback successCallback,
                            optional ErrorCallback? errorCallback);
```

Since: 1.0

If opening a connection is successful, then a *BluetoothSocket *object with open state is sent using *successCallback *, through which data can be exchanged by both devices.

The ErrorCallback is launched with these error types:

- NotFoundError - If there is no service with the specified *uuid *
- InvalidValuesError - If any of the input parameters contain an invalid value
- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **uuid :
            128-bit unique identifier, which specifies the service on the remote device. **
- **successCallback :
 Callback function that is called when an asynchronous call completes successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called when opening of a socket fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
      {
        console.log("Error: " + e.message);
      });
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};

/* connectToServiceByUUID sample code. */

var clientSocket = null;

/* Calls a method that is invoked when user wants to send a message to a remote device. */
function sendMessage(msg)
{
  /* Validates socket state, if everything is ok. */
  if (clientSocket != null && clientSocket.state == "OPEN")
  {
    /* Sends the message. */
    clientSocket.writeData(msg);
  }
}

/* Calls a method that is invoked when a socket is open. */
function onSocketConnected(socket)
{
  clientSocket = socket;
  console.log("Opening a socket successfully!!!");
  socket.onmessage = function()
  {
    var data = socket.readData();
    var recvmsg = "";
    for (var i = 0; i < data.length; i++)
    {
      recvmsg += String.fromCharCode(data[i]);
    }
    console.log("server msg >> " + recvmsg);
  };

  socket.onclose = function()
  {
    console.log("socket disconnected");
  };
}

function onDeviceReady(device)
{
  /* Validates device and service uuid. */
  if (device.uuids.indexOf("5BCE9431-6C75-32AB-AFE0-2EC108A30860") != -1)
  {
    /* Opens socket. */
    device.connectToServiceByUUID(
        "5BCE9431-6C75-32AB-AFE0-2EC108A30860", onSocketConnected, function(e)
        {
          console.log("Error connecting to service. Reason: " + e.message);
        });
  }
  else
  {
    console.log("Chat service is not supported by this device");
  }
}

/* Execution. */

if (adapter.powered)
{
  console.log("Bluetooth is already enabled");
  adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
  {
    console.log("Error: " + e.message);
  });
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

### 2.29. BluetoothLEDevice

The BluetoothLEDevice interface represents a remote Bluetooth LE device.

```webidl
  [NoInterfaceObject] interface BluetoothLEDevice {
    readonly attribute BluetoothAddress address;
    readonly attribute DOMString? name;
    readonly attribute long? txpowerlevel;
    readonly attribute unsigned long? appearance;
    readonly attribute BluetoothUUID[]? uuids;
    readonly attribute BluetoothLESolicitationUUID[]? solicitationuuids;
    readonly attribute BluetoothLEServiceData[]? serviceData;
    readonly attribute BluetoothLEManufacturerData? manufacturerData;
    readonly attribute long? rssi;
    void connect(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void disconnect(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    boolean isConnected() raises(WebAPIException);
    BluetoothGATTService getService(BluetoothUUID uuid) raises(WebAPIException);
    BluetoothUUID[] getServiceAllUuids() raises(WebAPIException);
    long addConnectStateChangeListener(BluetoothLEConnectChangeCallback listener) raises(WebAPIException);
    void removeConnectStateChangeListener(long watchID);
    unsigned long getAttMtu() raises(WebAPIException);
    void requestAttMtuChange(unsigned long newAttMtu) raises(WebAPIException);
    long addAttMtuChangeListener(ConnectionMtuCallback callback) raises(WebAPIException);
    void removeAttMtuChangeListener(long watchId) raises(WebAPIException);
  };
```

Since: 2.3.1

A *BluetoothLEDevice *object can be retrieved by using one of the following APIs:

- BluetoothLEAdapter.startScan()
- BluetoothLEConnectChangeCallback() passed to BluetoothGATTServer.registerClientConnectedCallback()

#### Attributes

- readonly BluetoothAddress address The address of the Bluetooth LE device from the scan result information.

Since: 2.3.1

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("Found device: " + device.address);
});
```

- readonly DOMString name [nullable] The name of the Bluetooth LE device from the scan result information.

Since: 2.3.1

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("Found device: " + device.name);
});
```

- readonly long txpowerlevel [nullable] The transmission power level of the Bluetooth LE device from the scan result information.

It represents the current transmit power level in dBm, and the level ranges from -100 dBm to +20 dBm to a resolution of 1 dBm.

Since: 2.3.1

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("Found device: " + device.txpowerlevel);
});
```

- readonly unsigned long appearance [nullable] The appearance of the Bluetooth LE device from the scan result information.

Since: 2.3.1

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("Found device: " + device.appearance);
});
```

- readonly BluetoothUUID[] uuids [nullable] The list of service UUIDs from scan result.

Since: 2.3.1

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  var uuids = device.uuids;
  var services = "";
  for (var i = 0; i < uuids.length; i++)
  {
    services += uuids[i] + "\n";
  }
  console.log("Service found: " + services);
});
```

- readonly BluetoothLESolicitationUUID[] solicitationuuids [nullable] The list of service solicitation UUIDs available on Bluetooth LE device from the scan result information.

Since: 2.3.1

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  var uuids = device.solicitationuuids;
  var services = "";
  for (var i = 0; i < uuids.length; i++)
  {
    services += uuids[i] + "\n";
  }
  console.log("Service solicitations found: " + services);
});
```

- readonly BluetoothLEServiceData[] serviceData [nullable] The list of service data available on Bluetooth LE device from the scan result information.

Since: 2.3.1

Remark: On devices prior to Tizen 6.0, service data is found only when its BluetoothLEServiceData::uuid is 16-bit. Finding service data with 128-bit BluetoothLEServiceData::uuid is supported since Tizen 6.0.

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  var serviceData = device.serviceData;
  var data = "";
  for (var i = 0; i < serviceData.length; i++)
  {
    data += serviceData[i].id + serviceData[i].data + "\n";
  }
  console.log("Service data found: " + data);
});
```

- readonly BluetoothLEManufacturerData manufacturerData [nullable] The manufacturer data from the scan result information.

Since: 2.3.1

Remark: This value will be set to *null *, if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();

/* On an advertising device:. */
var advertiseOptions =
{
  manufacturerData: new tizen.BluetoothLEManufacturerData("127", "0xDeadc0dE")
};
var advertiseData = new tizen.BluetoothLEAdvertiseData(advertiseOptions);

adapter.startAdvertise(advertiseData, "ADVERTISE",
    function onstate(state)
    {
      console.log("Advertiser state: " + state);
    },
    function(e)
    {
      console.log("Failed to startAdvertise : " + e.message);
    },
    "LOW_LATENCY");

/* On scanning device:. */
adapter.startScan(function onsuccess(device)
{
  var manufacturerData = device.manufacturerData;
  console.log("Found device, manufacturerData: " + JSON.stringify(device.manufacturerData));
});
```

Output example:

```
Advertiser state: STARTED

Found device, manufacturerData: {"id":"127","data":"DEADC0DE"}
```

- readonly long rssi [nullable] The received signal strength indicator in dBm (decibel-milliwatts) units.

The signal strength depends on distance (between the device and the beacon) and broadcasting power value.

Since: 3.0

Remark: Since Tizen 6.0, this value can be a *null *, but only if the object is obtained from BluetoothLEConnectChangeCallback .

Code example:

```javascript
var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  console.log("Found device: " + device.name);
  console.log("RSSI: " + device.rssi);
});
```

Output example:

```
Found device: beacon
RSSI: -25
```

#### Methods

`**connect **`Establishes Low Energy connection to the device.

```javascript
void connect(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

Connection is required to *readValue() *and *writeValue() *from the remote device.

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Remark: Establishing a connection can make device's Bluetooth stack busy. With the result, some of the operations, such as BluetoothLEAdapter::stopScan() can fail until *connect() *'s callback such as *successCallback() *or *errorCallback() *is triggered.

Parameters:

- **successCallback [optional] [nullable] :
 Callback function that is called when the connection is established successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function onconnected()
{
  console.log("Connected to device");
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    device.connect(onconnected, onerror);
  }
});
```

`**disconnect **`Disconnects from the device.

```javascript
void disconnect(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.3.1

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback [optional] [nullable] :
 Callback function that is called when the connection is finished successfully. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type InvalidStateError, if device is currently not connected

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
function onerror(e)
{
  console.log("Error occurred: " + e.message);
}

function onDeviceFound(device)
{
  function ondisconnect()
  {
    console.log("Disconnected");
  }

  function onconnected()
  {
    console.log("Connected to device");
    device.disconnect(ondisconnect, onerror);
  }

  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    device.connect(onconnected, onerror);
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(onDeviceFound, onerror);
```

`**isConnected **`Checks if Bluetooth Low Energy device is currently connected.

```javascript
boolean isConnected();
```

Since: 6.0

Return value:

boolean: true if the device is currently connected, false otherwise.

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
var dev;

function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function onconnected()
{
  console.log("Connected to device: " + dev.isConnected());
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    adapter.stopScan();
    dev = device;
    var connected = dev.isConnected();
    console.log("Found device: " + device.name + ", connected: " + connected);
    if (!connected)
    {
      device.connect(onconnected, onerror);
    }
  }
});
```

Output example:

```
Found device: TestDevice, connected: false
Connected to device: true
```

`**getService **`Retrieves a service from the device for the given UUID.

```javascript
BluetoothGATTService getService(BluetoothUUID uuid);
```

Since: 2.3.1

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **uuid :
 UUID of the service. **

Return value:

BluetoothGATTService: Retrieved service for the given UUID.

Exceptions:

- WebAPIException
- with error type NotFoundError, if there is no service with the given UUID.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type InvalidStateError, if the GATT service is not available.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function onconnected(device)
{
  console.log("Connected to device");
  var service = device.getService(device.uuids[0]);
  console.log("Service got");
}

function onerror(e)
{
  console.log("Error occurred: " + e.message);
}

function onDeviceFound(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    device.connect(onconnected.bind(null, device), onerror);
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(onDeviceFound, onerror);
```

`**getServiceAllUuids **`Retrieves list of all service UUIDs from connected GATT server.

```javascript
BluetoothUUID[] getServiceAllUuids();
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Return value:

BluetoothUUID[]: The array of all service UUIDs that belong to the connected GATT server.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if GATT server is not available.

- with error type NotSupportedError, if the feature is not supported.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
/* Below variable should represent valid address of discoverable bluetooth low energy device. */
var remoteAddress = "11:22:33:44:55:66";

function onconnected(device)
{
  console.log("Connected to device");
  var services = device.getServiceAllUuids();
  console.log("Services length " + services.length);
}

function onerror(e)
{
  console.log("Error occurred: " + e.message);
}

function onDeviceFound(device)
{
  if (device.address == remoteAddress)
  {
    device.connect(onconnected.bind(null, device), onerror);
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(onDeviceFound, onerror);
```

Output example:

```
Connected to device
Services length 2
```

`**addConnectStateChangeListener **`Registers a listener to be called when the device connects or disconnects.

```javascript
long addConnectStateChangeListener(BluetoothLEConnectChangeCallback listener);
```

Since: 2.3.1

Parameters:

- **listener :
 Listener functions that are called when the connection state changes. **

Return value:

long: The watchID to be used to unregister the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
function onerror(e)
{
  console.log("Error occurred: " + e.message);
}

function onDeviceFound(device)
{
  var onConnectionStateChange =
  {
    onconnected: function(device)
    {
      console.log("Device " + device.name + " connected");
    },
    ondisconnected: function(device)
    {
      console.log("Device " + device.name + " disconnected");
    }
  };

  if (device.address === "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    device.addConnectStateChangeListener(onConnectionStateChange);
    device.connect();
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(onDeviceFound, onerror);
```

`**removeConnectStateChangeListener **`Unregisters a Bluetooth device connection listener.

```javascript
void removeConnectStateChangeListener(long watchID);
```

Since: 2.3.1

Calling this function has no effect if there is no listener with given id.

Parameters:

- **watchID :
 The watchID identifier returned by the addConnectStateChangeListener() method. **

Code example:

```javascript
function onerror(e)
{
  console.log("Error occurred: " + e.message);
}

function onDeviceFound(device)
{
  var onConnectionStateChange =
  {
    onconnected: function(device)
    {
      console.log("Device " + device.name + " connected");
    },
    ondisconnected: function(device)
    {
      console.log("Device " + device.name + " disconnected");
      device.removeConnectStateChangeListener(listenerID);
    }
  };

  if (device.address === "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    listenerID = device.addConnectStateChangeListener(onConnectionStateChange);
    device.connect();
  }
}

var adapter = tizen.bluetooth.getLEAdapter();
var listenerID = null;
adapter.startScan(onDeviceFound, onerror);
```

`**getAttMtu **`Gets the current value of Attribute Protocol(ATT) Maximum Transmission Unit(MTU) from the connected device.

```javascript
unsigned long getAttMtu();
```

Since: 6.0

Return value:

unsigned long: Current ATT MTU value.

Exceptions:

- WebAPIException
- with error type InvalidStateError, if the remote device is not connected.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var dev;

function onerror(e)
{
  console.log("Failed to connect to device: " + e.message);
}

function onconnected()
{
  console.log("Connected to device, ATT MTU: " + dev.getAttMtu());
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    dev = device;
    console.log("Found device: " + device.name);
    device.connect(onconnected, onerror);
  }
});
```

Output example:

```
Found device: TestDevice
Connected to device, ATT MTU: 23
```

`**requestAttMtuChange **`Requests the GATT server to change the Attribute Protocol (ATT) Maximum Transmission Unit (MTU) value.

```javascript
void requestAttMtuChange(unsigned long newAttMtu);
```

Since: 6.0

Remark: ATT MTU value is determined between two connected devices and change will be successful only if both devices support the given value of ATT MTU.

Parameters:

- **newAttMtu :
 The new ATT MTU value, that will be sent to GATT server. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
function proccessDevice(device)
{
  function onConnected()
  {
    var attMtu = device.getAttMtu();
    console.log("Initial ATT MTU value: " + attMtu);
    watchID = device.addAttMtuChangeListener(function(value)
    {
      console.log("ATT MTU changed to: " + value);
      device.removeAttMtuChangeListener(watchID);
      device.disconnect();
    });
    device.requestAttMtuChange(64);
  }
  device.connect(onConnected);
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    adapter.stopScan();
    proccessDevice(device);
  }
});
```

Output example:

```
Found device: TestDevice
Initial ATT MTU value: 31
ATT MTU changed to: 64
```

`**addAttMtuChangeListener **`Registers a listener to be called when ATT MTU value is changed.

```javascript
long addAttMtuChangeListener(ConnectionMtuCallback callback);
```

Since: 6.0

Remark: ATT MTU value is determined between two connected devices and change takes place after both devices agrees to new value, both connected devices can initiate the ATT MTU value change by sending the request.

Parameters:

- **callback :
 Listener function that is called when the connection's ATT MTU changes. **

Return value:

long: The watchID to be used to unregister the listener.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if an input attribute is not compatible with the expected type for this attribute.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
function proccessDevice(device)
{
  function onConnected()
  {
    var attMtu = device.getAttMtu();
    console.log("Initial ATT MTU value: " + attMtu);
    watchID = device.addAttMtuChangeListener(function(value)
    {
      console.log("ATT MTU changed to: " + value);
      device.removeAttMtuChangeListener(watchID);
      device.disconnect();
    });
    device.requestAttMtuChange(64);
  }
  device.connect(onConnected);
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    adapter.stopScan();
    proccessDevice(device);
  }
});
```

Output example:

```
Found device: TestDevice
Initial ATT MTU value: 31
ATT MTU changed to: 64
```

`**removeAttMtuChangeListener **`Unregisters the ATT MTU value change listener.

```javascript
void removeAttMtuChangeListener(long watchId);
```

Since: 6.0

Parameters:

- **watchId :
 The watchID identifier returned by the addAttMtuChangeListener() method. **

Exceptions:

- WebAPIException
- with error type UnknownError, if any error occurs.

Code example:

```javascript
function proccessDevice(device)
{
  function onConnected()
  {
    var attMtu = device.getAttMtu();
    console.log("Initial ATT MTU value: " + attMtu);
    watchID = device.addAttMtuChangeListener(function(value)
    {
      console.log("ATT MTU changed to: " + value);
      device.removeAttMtuChangeListener(watchID);
      device.disconnect();
    });
    device.requestAttMtuChange(64);
  }
  device.connect(onConnected);
}

var adapter = tizen.bluetooth.getLEAdapter();
adapter.startScan(function onsuccess(device)
{
  if (device.address == "11:22:33:44:55:66")
  {
    console.log("Found device: " + device.name);
    adapter.stopScan();
    proccessDevice(device);
  }
});
```

Output example:

```
Found device: TestDevice
Initial ATT MTU value: 31
ATT MTU changed to: 64
```

### 2.30. BluetoothSocket

The BluetoothSocket interface represents the Bluetooth socket.

```webidl
  [NoInterfaceObject] interface BluetoothSocket {
    readonly attribute BluetoothUUID uuid;
    readonly attribute BluetoothSocketState state;
    readonly attribute BluetoothDevice peer;
    [TreatNonCallableAsNull] attribute SuccessCallback? onmessage raises(WebAPIException);
    [TreatNonCallableAsNull] attribute SuccessCallback? onclose raises(WebAPIException);
    unsigned long writeData(Bytes data) raises(WebAPIException);
    byte[] readData() raises(WebAPIException);
    void close() raises(WebAPIException);
  };
```

Since: 1.0

The socket object is created by *BluetoothDevice.connectToServiceByUUID() *or *BluetoothAdapter.registerRFCOMMServiceByUUID() *.

#### Attributes

- readonly BluetoothUUID uuid The service UUID to which this socket is connected.

Since: 1.0

- readonly BluetoothSocketState state The socket state.

Since: 1.0

- readonly BluetoothDevice peer The peer device to which this socket is connected.

Since: 1.0

- SuccessCallback onmessage [nullable] Called when an incoming message is received successfully from the peer.
By default, this attribute is set to null.

Since: 1.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

- SuccessCallback onclose [nullable] Called when the socket is closed successfully.
By default, this attribute is set to null.

Since: 1.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

#### Methods

`**writeData **`Writes data as a sequence of bytes onto the socket and returns the number of bytes actually written.

```javascript
unsigned long writeData(Bytes data);
```

Since: 1.0

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **data :
 The data to send. **

Return value:

unsigned long: The number of bytes actually sent.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameters in not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
      {
        console.log("Error: " + e.message);
      });
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};

/* writeData sample code. */

function onSocketConnected(socket)
{
  console.log("Opened connection to remote device");
  socket.onmessage = function()
  {
    console.log("Message received: " + socket.readData());
  };

  socket.onclose = function()
  {
    console.log("Socket closed with " + socket.peer.name);
  };

  /* Sends data to peer. */
  var textmsg = "Test";
  var sendtextmsg = new Array();
  for (var i = 0; i < textmsg.length; i++)
  {
    sendtextmsg[i] = textmsg.charCodeAt(i);
  }
  socket.writeData(sendtextmsg);
}

function onSocketError(e)
{
  console.log("Error connecting to service. Reason: " + e.message);
}

function onDeviceReady(device)
{
  /* Validates device and service uuid. */
  if (device.uuids.indexOf("5BCE9431-6C75-32AB-AFE0-2EC108A30860") != -1)
  {
    /* Opens socket. */
    device.connectToServiceByUUID(
        "5BCE9431-6C75-32AB-AFE0-2EC108A30860", onSocketConnected, onSocketError);
  }
}

/* Execution. */

if (adapter.powered)
{
  console.log("Bluetooth is already enabled");
  adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
  {
    console.log("Error: " + e.message);
  });
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

`**readData **`Reads data from the socket.

```javascript
byte[] readData();
```

Since: 1.0

This method should be called only in the *BluetoothSocket.onmessage *handler, that is, when data is ready on the socket.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Return value:

byte[]: The sequence of bytes successfully read.

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
      {
        console.log("Error: " + e.message);
      });
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};

/* readData sample code. */

function onError(e)
{
  console.log("Error connecting to service. Reason: " + e.message);
}

function onSocketConnected(socket)
{
  console.log("Opening socket success!!!");

  socket.onmessage = function()
  {
    /* Gets a message from peer, reads it. */
    var data = socket.readData();

    /* Code to evaluate message goes here. */
  };

  socket.onclose = function()
  {
    console.log("Socket closed with " + socket.peer.name);
  };
}

function onDeviceReady(device)
{
  /* Validates device and service uuid. */
  if (device.uuids.indexOf("5BCE9431-6C75-32AB-AFE0-2EC108A30860") != -1)
  {
    /* Opens socket. */
    device.connectToServiceByUUID(
        "5BCE9431-6C75-32AB-AFE0-2EC108A30860", onSocketConnected, onError);
  }
}

/* Execution. */

if (adapter.powered)
{
  console.log("Bluetooth is already enabled");
  adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
  {
    console.log("Error: " + e.message);
  });
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

`**close **`Closes the socket.

```javascript
void close();
```

Since: 1.0

**BluetoothSocket.state **changes to CLOSED , and *BluetoothSocket.onclose() *is invoked on success.

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Exceptions:

- WebAPIException
- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

/* Purpose of code below is to enable Bluetooth on the device. */

var bluetoothSwitchAppControl = new tizen.ApplicationControl(
    "http://tizen.org/appcontrol/operation/edit", null, "application/x-bluetooth-on-off");
function launchSuccess()
{
  console.log("Bluetooth Settings application is successfully launched");
}
function launchError(error)
{
  alert("An error occurred: " + error.name +
        ". Please enable Bluetooth through the Settings application");
}
var serviceReply =
{
  /* Called when the launched application reports success. */
  onsuccess: function(data)
  {
    if (adapter.powered)
    {
      console.log("Bluetooth is successfully turned on");
      startDiscovery();
    }
    else
    {
      console.log("Bluetooth is still switched off");
    }
  },
  /* Called when launched application reports failure. */
  onfailure: function()
  {
    alert("Bluetooth Settings application reported failure");
  }
};

function onSocketConnected(socket)
{
  console.log("Opened connection to remote device " + socket.peer.name);
  socket.onclose = function()
  {
    console.log("Socket closed with " + socket.peer.name);
  };
  socket.close();
}

function onSocketError(e)
{
  console.log("Error connecting to service. Reason: " + e.message);
}

function onDeviceReady(device)
{
  /* Validates device and service uuid. */
  if (device.uuids.indexOf("5BCE9431-6C75-32AB-AFE0-2EC108A30860") != -1)
  {
    device.connectToServiceByUUID(
        "5BCE9431-6C75-32AB-AFE0-2EC108A30860", onSocketConnected, onSocketError);
  }
}

if (adapter.powered)
{
  /* Gets the BluetoothDevice object. */
  adapter.getDevice("35:F4:59:D1:7A:03", onDeviceReady, function(e)
  {
    console.log("Error: " + e.message);
  });
}
else
{
  console.log("Try to launch the Bluetooth Settings application");
  tizen.application.launchAppControl(
      bluetoothSwitchAppControl, null, launchSuccess, launchError, serviceReply);
}
```

### 2.31. BluetoothClass

The BluetoothClass interface represents Bluetooth Class of Device/Service(CoD).

```webidl
  [NoInterfaceObject] interface BluetoothClass {
    readonly attribute octet major;
    readonly attribute octet minor;
    readonly attribute unsigned short[] services;
    boolean hasService(unsigned short service) raises(WebAPIException);
  };
```

Since: 1.0

Bluetooth device class describes the characteristics and capabilities of a device.

Bluetooth CoD is a 24-bit integer created by the union of three components:

- Exactly one **Major Device Class **(bits 8-12 of CoD) - This is the highest level of granularity for defining a Bluetooth Device.
- Exactly one **Minor Device Class **(bits 2-7 of CoD) - This is to be interpreted only in the context of the Major Device Class. Thus, the meaning of these bits may change, depending on the value of "Major Device Class".
- Zero or more **Major Service Classes **(bits 13-23) - Represents the services supported by the device.
The Major and Minor classes are intended to define a general family of devices with which any particular implementation wishes to be associated.
No assumptions should be made about specific functionality or characteristics of any application, based solely on the assignment of a Major or minor device class.

#### Attributes

- readonly octet major The major device class.

The *BluetoothClassDeviceMajor *interface contains the list of known values.

Since: 1.0

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

function evaluateDevice(address)
{
  adapter.getDevice(address,
      function(device)
      {
        if (device.deviceClass.major == tizen.bluetooth.deviceMajor.COMPUTER)
        {
          /* Shows computer icon for this device. */
          console.log("Device is computer");
        }
        else if (device.deviceClass.major == tizen.bluetooth.deviceMajor.PHONE)
        {
          /* Shows phone icon. */
          console.log("Device is a Phone");
        }
      },
      function(e)
      {
        console.log("Couldn't get any device with the given address: " + e.message);
      });
}

evaluateDevice("11:22:33:44:55:66");
```

- readonly octet minor The minor device class.

The *BluetoothClassDeviceMinor *interface contains the list of known values.

Since: 1.0

- readonly unsigned short[] services The services provided by this device and it refers to the *BluetoothClassDeviceService *interface for the list of possible
values.

Since: 1.0

#### Methods

`**hasService **`Checks whether the given service exists in the *services *.

```javascript
boolean hasService(unsigned short service);
```

Since: 1.0

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **service :
 Service to check. **

Return value:

boolean: true , if given service exists in the *services *.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type SecurityError, if the application does not have the privilege to call this method.

- with error type UnknownError, if any other error occurs.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
adapter.getDevice("12:34:56:78:9A:BC",
    function(device)
    {
      if (device.deviceClass.hasService(tizen.bluetooth.deviceService.POSITIONING))
      {
        console.log("Device supports Positioning service");
      }
    },
    function(e)
    {
      console.log("Couldn't get device for given address: " + e.message);
    });
```

### 2.32. BluetoothClassDeviceMajor

The BluetoothClassDeviceMajor interface holds the identifiers for major device classes of Bluetooth CoD.

```webidl
  [NoInterfaceObject] interface BluetoothClassDeviceMajor {
    const octet MISC = 0x00;
    const octet COMPUTER = 0x01;
    const octet PHONE = 0x02;
    const octet NETWORK = 0x03;
    const octet AUDIO_VIDEO = 0x04;
    const octet PERIPHERAL = 0x05;
    const octet IMAGING = 0x06;
    const octet WEARABLE = 0x07;
    const octet TOY = 0x08;
    const octet HEALTH = 0x09;
    const octet UNCATEGORIZED = 0x1F;
  };
```

Since: 1.0

### 2.33. BluetoothClassDeviceMinor

The BluetoothClassDeviceMinor interface holds the identifiers for minor device classes of Bluetooth CoD.

```webidl
  [NoInterfaceObject] interface BluetoothClassDeviceMinor {
    const octet COMPUTER_UNCATEGORIZED = 0x00;
    const octet COMPUTER_DESKTOP = 0x01;
    const octet COMPUTER_SERVER = 0x02;
    const octet COMPUTER_LAPTOP = 0x03;
    const octet COMPUTER_HANDHELD_PC_OR_PDA = 0x04;
    const octet COMPUTER_PALM_PC_OR_PDA = 0x05;
    const octet COMPUTER_WEARABLE = 0x06;
    const octet PHONE_UNCATEGORIZED = 0x00;
    const octet PHONE_CELLULAR = 0x01;
    const octet PHONE_CORDLESS = 0x02;
    const octet PHONE_SMARTPHONE = 0x03;
    const octet PHONE_MODEM_OR_GATEWAY = 0x04;
    const octet PHONE_ISDN = 0x05;
    const octet AV_UNRECOGNIZED = 0x00;
    const octet AV_WEARABLE_HEADSET = 0x01;
    const octet AV_HANDSFREE = 0x02;
    const octet AV_MICROPHONE = 0x04;
    const octet AV_LOUDSPEAKER = 0x05;
    const octet AV_HEADPHONES = 0x06;
    const octet AV_PORTABLE_AUDIO = 0x07;
    const octet AV_CAR_AUDIO = 0x08;
    const octet AV_SETTOP_BOX = 0x09;
    const octet AV_HIFI = 0x0a;
    const octet AV_VCR = 0x0b;
    const octet AV_VIDEO_CAMERA = 0x0c;
    const octet AV_CAMCORDER = 0x0d;
    const octet AV_MONITOR = 0x0e;
    const octet AV_DISPLAY_AND_LOUDSPEAKER = 0x0f;
    const octet AV_VIDEO_CONFERENCING = 0x10;
    const octet AV_GAMING_TOY = 0x12;
    const octet PERIPHERAL_UNCATEGORIZED = 0;
    const octet PERIPHERAL_KEYBOARD = 0x10;
    const octet PERIPHERAL_POINTING_DEVICE = 0x20;
    const octet PERIPHERAL_KEYBOARD_AND_POINTING_DEVICE = 0x30;
    const octet PERIPHERAL_JOYSTICK = 0x01;
    const octet PERIPHERAL_GAMEPAD = 0x02;
    const octet PERIPHERAL_REMOTE_CONTROL = 0x03;
    const octet PERIPHERAL_SENSING_DEVICE = 0x04;
    const octet PERIPHERAL_DEGITIZER_TABLET = 0x05;
    const octet PERIPHERAL_CARD_READER = 0x06;
    const octet PERIPHERAL_DIGITAL_PEN = 0x07;
    const octet PERIPHERAL_HANDHELD_SCANNER = 0x08;
    const octet PERIPHERAL_HANDHELD_INPUT_DEVICE = 0x09;
    const octet IMAGING_UNCATEGORIZED = 0x00;
    const octet IMAGING_DISPLAY = 0x04;
    const octet IMAGING_CAMERA = 0x08;
    const octet IMAGING_SCANNER = 0x10;
    const octet IMAGING_PRINTER = 0x20;
    const octet WEARABLE_WRITST_WATCH = 0x01;
    const octet WEARABLE_PAGER = 0x02;
    const octet WEARABLE_JACKET = 0x03;
    const octet WEARABLE_HELMET = 0x04;
    const octet WEARABLE_GLASSES = 0x05;
    const octet TOY_ROBOT = 0x01;
    const octet TOY_VEHICLE = 0x02;
    const octet TOY_DOLL = 0x03;
    const octet TOY_CONTROLLER = 0x04;
    const octet TOY_GAME = 0x05;
    const octet HEALTH_UNDEFINED = 0x00;
    const octet HEALTH_BLOOD_PRESSURE_MONITOR = 0x01;
    const octet HEALTH_THERMOMETER = 0x02;
    const octet HEALTH_WEIGHING_SCALE = 0x03;
    const octet HEALTH_GLUCOSE_METER = 0x04;
    const octet HEALTH_PULSE_OXIMETER = 0x05;
    const octet HEALTH_PULSE_RATE_MONITOR = 0x06;
    const octet HEALTH_DATA_DISPLAY = 0x07;
    const octet HEALTH_STEP_COUNTER = 0x08;
    const octet HEALTH_BODY_COMPOSITION_ANALYZER = 0x09;
    const octet HEALTH_PEAK_FLOW_MONITOR = 0x0a;
    const octet HEALTH_MEDICATION_MONITOR = 0x0b;
    const octet HEALTH_KNEE_PROSTHESIS = 0x0c;
    const octet HEALTH_ANKLE_PROSTHESIS = 0x0d;
  };
```

Since: 1.0

### 2.34. BluetoothClassDeviceService

The BluetoothClassDeviceService interface holds identifiers for the major service classes of Bluetooth CoD.

```webidl
  [NoInterfaceObject] interface BluetoothClassDeviceService {
    const unsigned short LIMITED_DISCOVERABILITY = 0x0001;
    const unsigned short POSITIONING = 0x0008;
    const unsigned short NETWORKING = 0x0010;
    const unsigned short RENDERING = 0x0020;
    const unsigned short CAPTURING = 0x0040;
    const unsigned short OBJECT_TRANSFER = 0x0080;
    const unsigned short AUDIO = 0x0100;
    const unsigned short TELEPHONY = 0x0200;
    const unsigned short INFORMATION = 0x0400;
  };
```

Since: 1.0

### 2.35. BluetoothServiceHandler

The BluetoothServiceHandler interface provides methods to handle Bluetooth service.

```webidl
  [NoInterfaceObject] interface BluetoothServiceHandler {
    readonly attribute BluetoothUUID uuid;
    readonly attribute DOMString name;
    readonly attribute boolean isConnected;
    [TreatNonCallableAsNull] attribute BluetoothSocketSuccessCallback? onconnect raises(WebAPIException);
    void unregister(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 1.0

#### Attributes

- readonly BluetoothUUID uuid The UUID of the service. See example .

Since: 1.0

- readonly DOMString name The name of the service. See example .

Since: 1.0

- readonly boolean isConnected The flag indicating whether any remote devices is using this service. See example .

Since: 1.0

- BluetoothSocketSuccessCallback onconnect [nullable] Called when a remote device is connected successfully to this service.
By default, this attribute is set to null.

Since: 1.0

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input attribute is not compatible with the expected type for this attribute.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();

function chatServiceSuccessCb(handler)
{
  console.log("Chat service " + handler.name + " with UUID " + handler.uuid +
              " is successfully registered!");
  console.log("There is " + (handler.isConnected ? "a" : "no") + " device using this service");

  handler.onconnect = function(socket)
  {
    console.log("Client is connected: " + socket.peer.name + "," + socket.peer.address);
    socket.onmessage = function()
    {
      var data = socket.readData();
      /* Handle message code goes here. */
    };

    /* Expected close. */
    socket.onclose = function()
    {
      console.log("The socket is closed");
    };
  };
}

function errorCb(e)
{
  console.log("Could not register service record, Error: " + e.message);
}

var CHAT_SERVICE_UUID = "5BCE9431-6C75-32AB-AFE0-2EC108A30860";
adapter.registerRFCOMMServiceByUUID(
    CHAT_SERVICE_UUID, "Chat service", chatServiceSuccessCb, errorCb);
```

#### Methods

`**unregister **`Unregisters a service record from the Bluetooth services record database and stops listening for new connections to this service.

```javascript
void unregister(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 1.0

The ErrorCallback is launched with these error types:

- UnknownError - If any other error occurs

Privilege level: public

Privilege: http://tizen.org/privilege/bluetooth

Parameters:

- **successCallback [optional] [nullable] :
 Callback function that is called when the record is removed successfully from the service records database. **
- **errorCallback [optional] [nullable] :
   Callback function that is called in case of failure (to unregister). **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
var adapter = tizen.bluetooth.getDefaultAdapter();
var chatServiceHandler = null;

function chatServiceSuccessCb(handler)
{
  console.log("Chat service registration was successful!");

  chatServiceHandler = handler;
  handler.onconnect = function(socket)
  {
    console.log("Client is connected: " + socket.peer.name + "," + socket.peer.address);
    socket.onmessage = function()
    {
      var data = socket.readData();
      /* Handle message code goes here. */
    };

    /* Expected close. */
    socket.onclose = function()
    {
      console.log("The socket is closed");
    };
  };
}

function publishChatService()
{
  var CHAT_SERVICE_UUID = "5BCE9431-6C75-32AB-AFE0-2EC108A30860";
  adapter.registerRFCOMMServiceByUUID(CHAT_SERVICE_UUID, "Chat service", chatServiceSuccessCb,
      /* Error handler. */
      function(e)
      {
        console.log("Could not register service record, Error: " + e.message);
      });
}

function unRegisterChatService()
{
  if (chatServiceHandler != null)
  {
    chatServiceHandler.unregister(
        function()
        {
          chatServiceHandler = null;
          console.log("Chat service is unregistered");
        },
        function(e)
        {
          console.log("Error: " + e.message);
        });
  }
}
```

### 2.36. BluetoothAdapterChangeCallback

The BluetoothAdapterChangeCallback interface specifies a set of methods to be invoked when the changes of Bluetooth adapter occur.

```webidl
  [Callback, NoInterfaceObject] interface BluetoothAdapterChangeCallback {
    void onstatechanged(boolean powered);
    void onnamechanged(DOMString name);
    void onvisibilitychanged(boolean visible);
  };
```

Since: 2.2

Remark: Example of using can be find at setChangeListener code example.

#### Methods

`**onstatechanged **`Called when the power state is changed.

```javascript
void onstatechanged(boolean powered);
```

Since: 2.2

Parameters:

- **powered :
 Flag indicating power state of local Bluetooth: true means power-on, false means power-off. **

`**onnamechanged **`Called when the name is changed.

```javascript
void onnamechanged(DOMString name);
```

Since: 2.2

Parameters:

- **name :
 Name of local Bluetooth. **

`**onvisibilitychanged **`Called when the visibility is changed.

```javascript
void onvisibilitychanged(boolean visible);
```

Since: 2.2

Parameters:

- **visible :
 Flag indicating visibility of local Bluetooth: true means that local Bluetooth is discoverable, false means that local Bluetooth is hidden from other devices. **

### 2.37. BluetoothDeviceSuccessCallback

The BluetoothDeviceSuccessCallback interface implements the success callback BluetoothAdapter.getDevice() and BluetoothAdapter.createBonding() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothDeviceSuccessCallback {
    void onsuccess(BluetoothDevice device);
  };
```

Since: 1.0

Remark: Example of using can be find at getDevice and createBonding code examples.

#### Methods

`**onsuccess **`Called on success.

```javascript
void onsuccess(BluetoothDevice device);
```

Since: 1.0

Parameters:

- **device :
 BluetoothDevice object. **

### 2.38. BluetoothDeviceArraySuccessCallback

The BluetoothDeviceArraySuccessCallback interface that defines the success callback for BluetoothAdapter.getKnownDevices() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothDeviceArraySuccessCallback {
    void onsuccess(BluetoothDevice[] devices);
  };
```

Since: 1.0

Remark: Example of using can be find at getKnownDevices code example.

#### Methods

`**onsuccess **`Called when device information is ready.

```javascript
void onsuccess(BluetoothDevice[] devices);
```

Since: 1.0

Parameters:

- **devices :
 List of devices known to local Bluetooth adapter.
Each element is a BluetoothDevice. **

### 2.39. BluetoothDiscoverDevicesSuccessCallback

The BluetoothDiscoverDevicesSuccessCallback interface that defines the success callback for BluetoothAdapter.discoverDevices() .

```webidl
  [Callback, NoInterfaceObject] interface BluetoothDiscoverDevicesSuccessCallback {
    void onstarted();
    void ondevicefound(BluetoothDevice device);
    void ondevicedisappeared(BluetoothAddress address);
    void onfinished(BluetoothDevice[] foundDevices);
  };
```

Since: 1.0

Remark: Example of using can be find at discoverDevices code example.

#### Methods

`**onstarted **`Called at the beginning of a device discovery process for finding the nearby Bluetooth device.

```javascript
void onstarted();
```

Since: 1.0

`**ondevicefound **`Called when a new device is discovered in the process of inquiry/discovery.

```javascript
void ondevicefound(BluetoothDevice device);
```

Since: 1.0

Parameters:

- **device :
 Device that is found. **

`**ondevicedisappeared **`Called when a device is lost from proximity.
After that, this device is no longer visible.

```javascript
void ondevicedisappeared(BluetoothAddress address);
```

Since: 1.0

Parameters:

- **address :
 Address of the device that is no longer in range or visible. **

`**onfinished **`Called when the device discovery process has finished.

```javascript
void onfinished(BluetoothDevice[] foundDevices);
```

Since: 1.0

Parameters:

- **foundDevices :
 Array of devices found in this discovery session. **

### 2.40. BluetoothSocketSuccessCallback

The BluetoothSocketSuccessCallback interface that defines the success method for BluetoothDevice.connectToServiceByUUID() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothSocketSuccessCallback {
    void onsuccess(BluetoothSocket socket);
  };
```

Since: 1.0

Remark: Example of using can be find at connectToServiceByUUID code example.

#### Methods

`**onsuccess **`Called when the connection to a service is ready.

```javascript
void onsuccess(BluetoothSocket socket);
```

Since: 1.0

Parameters:

- **socket :
 Socket to connect to the specified service on a remote device. **

### 2.41. BluetoothServiceSuccessCallback

The BluetoothServiceSuccessCallback interface implements the success callback for BluetoothAdapter.registerRFCOMMServiceByUUID() .

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothServiceSuccessCallback {
    void onsuccess(BluetoothServiceHandler handler);
  };
```

Since: 1.0

Remark: Example of using can be find at registerRFCOMMServiceByUUID code example.

#### Methods

`**onsuccess **`Called when registering a service with the local device is successful.

```javascript
void onsuccess(BluetoothServiceHandler handler);
```

Since: 1.0

Parameters:

- **handler :
 Bluetooth service handler. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the Bluetooth application runs on a device with Bluetooth feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.bluetooth
To guarantee that the Bluetooth healthcare application runs on a device with Bluetooth health profile feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.bluetooth.health
To guarantee that the Bluetooth Low Energy application runs on a device with Bluetooth Low Energy feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.bluetooth.le
To guarantee that the Bluetooth Low Energy application runs on a device with Bluetooth Low Energy GATT Client feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.bluetooth.le.gatt.client
To guarantee that the Bluetooth Low Energy application runs on a device with Bluetooth Low Energy GATT Server feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.bluetooth.le.gatt.server

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module Bluetooth {
  typedef DOMString BluetoothAddress;
  typedef DOMString BluetoothUUID;
  typedef DOMString BluetoothLESolicitationUUID;
  typedef (byte[] or DOMString or Uint8Array) Bytes;
  typedef (BluetoothGATTService or BluetoothGATTServerService) BluetoothGATTServiceVariant;
  typedef (BluetoothGATTCharacteristic or BluetoothGATTServerCharacteristic) BluetoothGATTCharacteristicVariant;
  typedef (BluetoothGATTDescriptor or BluetoothGATTServerDescriptor) BluetoothGATTDescriptorVariant;
  enum BluetoothSocketState { "CLOSED", "OPEN" };
  enum BluetoothAdvertisePacketType { "ADVERTISE", "SCAN_RESPONSE" };
  enum BluetoothAdvertisingState { "STARTED", "STOPPED" };
  enum BluetoothAdvertisingMode { "BALANCED", "LOW_LATENCY", "LOW_ENERGY" };
  dictionary BluetoothLEAdvertiseDataInit {
    boolean? includeName;
    BluetoothUUID[]? uuids;
    BluetoothLESolicitationUUID[]? solicitationuuids;
    unsigned long? appearance;
    boolean? includeTxPowerLevel;
    BluetoothLEServiceData[]? servicesData;
    BluetoothLEManufacturerData? manufacturerData;
  };
  dictionary BluetoothGATTServerServiceInit {
    BluetoothUUID serviceUuid;
    boolean isPrimary = true;
    BluetoothGATTServerServiceInit[]? includedServices = null;
    BluetoothGATTServerCharacteristicInit[]? characteristics = null;
  };
  dictionary BluetoothGATTServerCharacteristicInit {
    BluetoothUUID uuid;
    BluetoothGATTServerDescriptorInit[]? descriptors = null;
    boolean isBroadcast = false;
    boolean hasExtendedProperties = false;
    boolean isNotify = false;
    boolean isIndication = false;
    boolean isReadable = false;
    boolean isSignedWrite = false;
    boolean isWritable = false;
    boolean isWriteNoResponse = false;
    boolean readPermission = false;
    boolean writePermission = false;
    boolean encryptedReadPermission = false;
    boolean encryptedWritePermission = false;
    boolean encryptedSignedReadPermission = false;
    boolean encryptedSignedWritePermission = false;
    ReadValueRequestCallback? readValueRequestCallback = null;
    SuccessCallback? readValueSendResponseSuccessCallback = null;
    ErrorCallback? readValueSendResponseErrorCallback = null;
    WriteValueRequestCallback? writeValueRequestCallback = null;
    SuccessCallback? writeValueSendResponseSuccessCallback = null;
    ErrorCallback? writeValueSendResponseErrorCallback = null;
  };
  dictionary BluetoothGATTServerDescriptorInit {
    BluetoothUUID uuid;
    boolean readPermission = false;
    boolean writePermission = false;
    boolean encryptedReadPermission = false;
    boolean encryptedWritePermission = false;
    boolean encryptedSignedReadPermission = false;
    boolean encryptedSignedWritePermission = false;
    ReadValueRequestCallback? readValueRequestCallback = null;
    SuccessCallback? readValueSendResponseSuccessCallback = null;
    ErrorCallback? readValueSendResponseErrorCallback = null;
    WriteValueRequestCallback? writeValueRequestCallback = null;
    SuccessCallback? writeValueSendResponseSuccessCallback = null;
    ErrorCallback? writeValueSendResponseErrorCallback = null;
  };
  Tizen implements BluetoothManagerObject;
  [NoInterfaceObject] interface BluetoothManagerObject {
    readonly attribute BluetoothManager bluetooth;
  };
  [Constructor(DOMString uuid, Bytes data)]
  interface BluetoothLEServiceData {
    attribute BluetoothUUID uuid;
    attribute DOMString data;
  };
  [Constructor(DOMString id, Bytes data)]
  interface BluetoothLEManufacturerData {
    attribute DOMString id;
    attribute DOMString data;
  };
  [Constructor(optional BluetoothLEAdvertiseDataInit? init)]
  interface BluetoothLEAdvertiseData {
    attribute boolean? includeName;
    attribute BluetoothUUID[]? uuids;
    attribute BluetoothLESolicitationUUID[]? solicitationuuids;
    attribute unsigned long? appearance;
    attribute boolean? includeTxPowerLevel;
    attribute BluetoothLEServiceData[]? servicesData;
    attribute BluetoothLEManufacturerData? manufacturerData;
  };
  [NoInterfaceObject] interface BluetoothManager {
    const DOMString BASE_UUID = "00000000-0000-1000-8000-00805F9B34FB";
    readonly attribute BluetoothClassDeviceMajor deviceMajor;
    readonly attribute BluetoothClassDeviceMinor deviceMinor;
    readonly attribute BluetoothClassDeviceService deviceService;
    BluetoothAdapter getDefaultAdapter() raises(WebAPIException);
    BluetoothLEAdapter getLEAdapter() raises(WebAPIException);
    BluetoothGATTServer getGATTServer() raises(WebAPIException);
    byte[] toByteArray(Bytes data) raises(WebAPIException);
    DOMString toDOMString(Bytes data) raises(WebAPIException);
    Uint8Array toUint8Array(Bytes data) raises(WebAPIException);
    BluetoothUUID uuidTo128bit(BluetoothUUID uuid) raises(WebAPIException);
    BluetoothUUID uuidToShortestPossible(BluetoothUUID uuid) raises(WebAPIException);
    boolean uuidsEqual(BluetoothUUID uuid1, BluetoothUUID uuid2) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothAdapter {
    readonly attribute DOMString name;
    readonly attribute BluetoothAddress address;
    readonly attribute boolean powered;
    readonly attribute boolean visible;
    void setName(DOMString name, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                 raises(WebAPIException);
    void setChangeListener(BluetoothAdapterChangeCallback listener) raises(WebAPIException);
    void unsetChangeListener() raises(WebAPIException);
    void discoverDevices(BluetoothDiscoverDevicesSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    void stopDiscovery(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void getKnownDevices(BluetoothDeviceArraySuccessCallback successCallback, optional ErrorCallback? errorCallback)
                         raises(WebAPIException);
    void getDevice(BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                   raises(WebAPIException);
    void createBonding(BluetoothAddress address, BluetoothDeviceSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                       raises(WebAPIException);
    void destroyBonding(BluetoothAddress address, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                        raises(WebAPIException);
    void registerRFCOMMServiceByUUID(BluetoothUUID uuid, DOMString name, BluetoothServiceSuccessCallback successCallback,
                                     optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothLEAdapter {
    void startScan(BluetoothLEScanCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void stopScan() raises(WebAPIException);
    boolean isScanning() raises(WebAPIException);
    void startAdvertise(BluetoothLEAdvertiseData advertiseData, BluetoothAdvertisePacketType packetType,
                        BluetoothLEAdvertiseCallback successCallback, optional ErrorCallback? errorCallback,
                        optional BluetoothAdvertisingMode? mode, optional boolean? connectable) raises(WebAPIException);
    void stopAdvertise() raises(WebAPIException);
    long addConnectStateChangeListener(BluetoothLEConnectChangeCallback listener) raises(WebAPIException);
    void removeConnectStateChangeListener(long watchID);
  };
  [NoInterfaceObject] interface BluetoothGATTService {
    readonly attribute BluetoothUUID? serviceUuid;
    readonly attribute BluetoothGATTServiceVariant[] services;
    readonly attribute BluetoothGATTCharacteristicVariant[] characteristics;
  };
  [NoInterfaceObject] interface BluetoothGATTServerService : BluetoothGATTService {
    readonly attribute boolean isPrimary;
    void unregister(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothGATTCharacteristic {
    readonly attribute BluetoothGATTDescriptorVariant[] descriptors;
    readonly attribute boolean isBroadcast;
    readonly attribute boolean hasExtendedProperties;
    readonly attribute boolean isNotify;
    readonly attribute boolean isIndication;
    readonly attribute boolean isReadable;
    readonly attribute boolean isSignedWrite;
    readonly attribute boolean isWritable;
    readonly attribute boolean isWriteNoResponse;
    readonly attribute BluetoothUUID? uuid;
    void readValue(ReadValueSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void writeValue(Bytes value, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                    raises(WebAPIException);
    long addValueChangeListener(ReadValueSuccessCallback callback) raises(WebAPIException);
    void removeValueChangeListener(long watchID);
  };
  [NoInterfaceObject] interface BluetoothGATTServerCharacteristic : BluetoothGATTCharacteristic {
    readonly attribute boolean readPermission;
    readonly attribute boolean writePermission;
    readonly attribute boolean encryptedReadPermission;
    readonly attribute boolean encryptedWritePermission;
    readonly attribute boolean encryptedSignedReadPermission;
    readonly attribute boolean encryptedSignedWritePermission;
    void notifyAboutValueChange(Bytes value, BluetoothAddress? clientAddress, optional NotificationCallback? notificationCallback,
                                optional ErrorCallback? errorCallback) raises(WebAPIException);
    void setReadValueRequestCallback(ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback? successCallback,
                                     optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                     optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
    void setWriteValueRequestCallback(WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback? successCallback,
                                      optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                      optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothGATTDescriptor {
    readonly attribute BluetoothUUID? uuid;
    void readValue(ReadValueSuccessCallback successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void writeValue(Bytes value, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                    raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothGATTServerDescriptor : BluetoothGATTDescriptor {
    readonly attribute boolean readPermission;
    readonly attribute boolean writePermission;
    readonly attribute boolean encryptedReadPermission;
    readonly attribute boolean encryptedWritePermission;
    readonly attribute boolean encryptedSignedReadPermission;
    readonly attribute boolean encryptedSignedWritePermission;
    void setReadValueRequestCallback(ReadValueRequestCallback readValueRequestCallback, optional SuccessCallback? successCallback,
                                     optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                     optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
    void setWriteValueRequestCallback(WriteValueRequestCallback writeValueRequestCallback, optional SuccessCallback? successCallback,
                                      optional ErrorCallback? errorCallback, optional SuccessCallback? sendResponseSuccessCallback,
                                      optional ErrorCallback? sendResponseErrorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothGATTServer {
    readonly attribute boolean isRunning;
    readonly attribute BluetoothGATTServerService[] services;
    void start(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void stop(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void registerService(BluetoothGATTServerServiceInit service, optional SuccessCallback? successCallback,
                         optional ErrorCallback? errorCallback) raises(WebAPIException);
    void unregisterAllServices(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                               raises(WebAPIException);
    void getConnectionMtu(BluetoothAddress clientAddress, ConnectionMtuCallback callback, optional ErrorCallback? errorCallback)
                          raises(WebAPIException);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothLEScanCallback {
    void onsuccess(BluetoothLEDevice device);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothLEAdvertiseCallback {
    void onstate(BluetoothAdvertisingState state);
  };
  [Callback, NoInterfaceObject] interface BluetoothLEConnectChangeCallback {
    void onconnected(BluetoothLEDevice device);
    void ondisconnected(BluetoothLEDevice device);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ReadValueSuccessCallback {
    void onread(byte[] value);
  };
  [Constructor(long statusCode = 0, optional Bytes data)]
  interface GATTRequestReply {
    attribute long statusCode;
    attribute Bytes? data;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ReadValueRequestCallback {
    GATTRequestReply? onreadrequest(BluetoothAddress clientAddress, long offset);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface WriteValueRequestCallback {
    GATTRequestReply? onwriterequest(BluetoothAddress clientAddress, byte[] value, long offset, boolean replyRequired);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface NotificationCallback {
    void onnotificationsuccess(BluetoothAddress clientAddress);
    void onnotificationfail(BluetoothAddress clientAddress, WebAPIException error);
    void onnotificationfinish(BluetoothAddress clientAddress);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ConnectionMtuCallback {
    void onsuccess(long mtu);
  };
  [NoInterfaceObject] interface BluetoothDevice {
    readonly attribute DOMString name;
    readonly attribute BluetoothAddress address;
    readonly attribute BluetoothClass deviceClass;
    readonly attribute boolean isBonded;
    readonly attribute boolean isTrusted;
    readonly attribute boolean isConnected;
    readonly attribute BluetoothUUID[] uuids;
    void connectToServiceByUUID(BluetoothUUID uuid, BluetoothSocketSuccessCallback successCallback,
                                optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothLEDevice {
    readonly attribute BluetoothAddress address;
    readonly attribute DOMString? name;
    readonly attribute long? txpowerlevel;
    readonly attribute unsigned long? appearance;
    readonly attribute BluetoothUUID[]? uuids;
    readonly attribute BluetoothLESolicitationUUID[]? solicitationuuids;
    readonly attribute BluetoothLEServiceData[]? serviceData;
    readonly attribute BluetoothLEManufacturerData? manufacturerData;
    readonly attribute long? rssi;
    void connect(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    void disconnect(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
    boolean isConnected() raises(WebAPIException);
    BluetoothGATTService getService(BluetoothUUID uuid) raises(WebAPIException);
    BluetoothUUID[] getServiceAllUuids() raises(WebAPIException);
    long addConnectStateChangeListener(BluetoothLEConnectChangeCallback listener) raises(WebAPIException);
    void removeConnectStateChangeListener(long watchID);
    unsigned long getAttMtu() raises(WebAPIException);
    void requestAttMtuChange(unsigned long newAttMtu) raises(WebAPIException);
    long addAttMtuChangeListener(ConnectionMtuCallback callback) raises(WebAPIException);
    void removeAttMtuChangeListener(long watchId) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothSocket {
    readonly attribute BluetoothUUID uuid;
    readonly attribute BluetoothSocketState state;
    readonly attribute BluetoothDevice peer;
    [TreatNonCallableAsNull] attribute SuccessCallback? onmessage raises(WebAPIException);
    [TreatNonCallableAsNull] attribute SuccessCallback? onclose raises(WebAPIException);
    unsigned long writeData(Bytes data) raises(WebAPIException);
    byte[] readData() raises(WebAPIException);
    void close() raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothClass {
    readonly attribute octet major;
    readonly attribute octet minor;
    readonly attribute unsigned short[] services;
    boolean hasService(unsigned short service) raises(WebAPIException);
  };
  [NoInterfaceObject] interface BluetoothClassDeviceMajor {
    const octet MISC = 0x00;
    const octet COMPUTER = 0x01;
    const octet PHONE = 0x02;
    const octet NETWORK = 0x03;
    const octet AUDIO_VIDEO = 0x04;
    const octet PERIPHERAL = 0x05;
    const octet IMAGING = 0x06;
    const octet WEARABLE = 0x07;
    const octet TOY = 0x08;
    const octet HEALTH = 0x09;
    const octet UNCATEGORIZED = 0x1F;
  };
  [NoInterfaceObject] interface BluetoothClassDeviceMinor {
    const octet COMPUTER_UNCATEGORIZED = 0x00;
    const octet COMPUTER_DESKTOP = 0x01;
    const octet COMPUTER_SERVER = 0x02;
    const octet COMPUTER_LAPTOP = 0x03;
    const octet COMPUTER_HANDHELD_PC_OR_PDA = 0x04;
    const octet COMPUTER_PALM_PC_OR_PDA = 0x05;
    const octet COMPUTER_WEARABLE = 0x06;
    const octet PHONE_UNCATEGORIZED = 0x00;
    const octet PHONE_CELLULAR = 0x01;
    const octet PHONE_CORDLESS = 0x02;
    const octet PHONE_SMARTPHONE = 0x03;
    const octet PHONE_MODEM_OR_GATEWAY = 0x04;
    const octet PHONE_ISDN = 0x05;
    const octet AV_UNRECOGNIZED = 0x00;
    const octet AV_WEARABLE_HEADSET = 0x01;
    const octet AV_HANDSFREE = 0x02;
    const octet AV_MICROPHONE = 0x04;
    const octet AV_LOUDSPEAKER = 0x05;
    const octet AV_HEADPHONES = 0x06;
    const octet AV_PORTABLE_AUDIO = 0x07;
    const octet AV_CAR_AUDIO = 0x08;
    const octet AV_SETTOP_BOX = 0x09;
    const octet AV_HIFI = 0x0a;
    const octet AV_VCR = 0x0b;
    const octet AV_VIDEO_CAMERA = 0x0c;
    const octet AV_CAMCORDER = 0x0d;
    const octet AV_MONITOR = 0x0e;
    const octet AV_DISPLAY_AND_LOUDSPEAKER = 0x0f;
    const octet AV_VIDEO_CONFERENCING = 0x10;
    const octet AV_GAMING_TOY = 0x12;
    const octet PERIPHERAL_UNCATEGORIZED = 0;
    const octet PERIPHERAL_KEYBOARD = 0x10;
    const octet PERIPHERAL_POINTING_DEVICE = 0x20;
    const octet PERIPHERAL_KEYBOARD_AND_POINTING_DEVICE = 0x30;
    const octet PERIPHERAL_JOYSTICK = 0x01;
    const octet PERIPHERAL_GAMEPAD = 0x02;
    const octet PERIPHERAL_REMOTE_CONTROL = 0x03;
    const octet PERIPHERAL_SENSING_DEVICE = 0x04;
    const octet PERIPHERAL_DEGITIZER_TABLET = 0x05;
    const octet PERIPHERAL_CARD_READER = 0x06;
    const octet PERIPHERAL_DIGITAL_PEN = 0x07;
    const octet PERIPHERAL_HANDHELD_SCANNER = 0x08;
    const octet PERIPHERAL_HANDHELD_INPUT_DEVICE = 0x09;
    const octet IMAGING_UNCATEGORIZED = 0x00;
    const octet IMAGING_DISPLAY = 0x04;
    const octet IMAGING_CAMERA = 0x08;
    const octet IMAGING_SCANNER = 0x10;
    const octet IMAGING_PRINTER = 0x20;
    const octet WEARABLE_WRITST_WATCH = 0x01;
    const octet WEARABLE_PAGER = 0x02;
    const octet WEARABLE_JACKET = 0x03;
    const octet WEARABLE_HELMET = 0x04;
    const octet WEARABLE_GLASSES = 0x05;
    const octet TOY_ROBOT = 0x01;
    const octet TOY_VEHICLE = 0x02;
    const octet TOY_DOLL = 0x03;
    const octet TOY_CONTROLLER = 0x04;
    const octet TOY_GAME = 0x05;
    const octet HEALTH_UNDEFINED = 0x00;
    const octet HEALTH_BLOOD_PRESSURE_MONITOR = 0x01;
    const octet HEALTH_THERMOMETER = 0x02;
    const octet HEALTH_WEIGHING_SCALE = 0x03;
    const octet HEALTH_GLUCOSE_METER = 0x04;
    const octet HEALTH_PULSE_OXIMETER = 0x05;
    const octet HEALTH_PULSE_RATE_MONITOR = 0x06;
    const octet HEALTH_DATA_DISPLAY = 0x07;
    const octet HEALTH_STEP_COUNTER = 0x08;
    const octet HEALTH_BODY_COMPOSITION_ANALYZER = 0x09;
    const octet HEALTH_PEAK_FLOW_MONITOR = 0x0a;
    const octet HEALTH_MEDICATION_MONITOR = 0x0b;
    const octet HEALTH_KNEE_PROSTHESIS = 0x0c;
    const octet HEALTH_ANKLE_PROSTHESIS = 0x0d;
  };
  [NoInterfaceObject] interface BluetoothClassDeviceService {
    const unsigned short LIMITED_DISCOVERABILITY = 0x0001;
    const unsigned short POSITIONING = 0x0008;
    const unsigned short NETWORKING = 0x0010;
    const unsigned short RENDERING = 0x0020;
    const unsigned short CAPTURING = 0x0040;
    const unsigned short OBJECT_TRANSFER = 0x0080;
    const unsigned short AUDIO = 0x0100;
    const unsigned short TELEPHONY = 0x0200;
    const unsigned short INFORMATION = 0x0400;
  };
  [NoInterfaceObject] interface BluetoothServiceHandler {
    readonly attribute BluetoothUUID uuid;
    readonly attribute DOMString name;
    readonly attribute boolean isConnected;
    [TreatNonCallableAsNull] attribute BluetoothSocketSuccessCallback? onconnect raises(WebAPIException);
    void unregister(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
  [Callback, NoInterfaceObject] interface BluetoothAdapterChangeCallback {
    void onstatechanged(boolean powered);
    void onnamechanged(DOMString name);
    void onvisibilitychanged(boolean visible);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothDeviceSuccessCallback {
    void onsuccess(BluetoothDevice device);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothDeviceArraySuccessCallback {
    void onsuccess(BluetoothDevice[] devices);
  };
  [Callback, NoInterfaceObject] interface BluetoothDiscoverDevicesSuccessCallback {
    void onstarted();
    void ondevicefound(BluetoothDevice device);
    void ondevicedisappeared(BluetoothAddress address);
    void onfinished(BluetoothDevice[] foundDevices);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothSocketSuccessCallback {
    void onsuccess(BluetoothSocket socket);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface BluetoothServiceSuccessCallback {
    void onsuccess(BluetoothServiceHandler handler);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
