# Events API

This plugin provides information about events defined in cordova.

Original documentation: Cordova Events .

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

| Event name | Event handler callback |
| --- | --- |
| deviceready | DeviceReadyEventCallback |
| pause | PauseEventCallback |
| resume | ResumeEventCallback |
| backbutton | BackButtonEventCallback |
| menubutton | MenuButtonEventCallback |
| searchbutton | SearchButtonEventCallback |
| startcallbutton | StartCallEventCallback |
| endcallbutton | EndCallButtonEventCallback |
| volumedownbutton | VolumeDownButtonEventCallback |
| volumeupbutton | VolumeUpButtonEventCallback |
| Network Information events |
| online | OnlineEventCallback |
| offline | OfflineEventCallback |

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. DeviceReadyEventCallback
- 1.2. PauseEventCallback
- 1.3. ResumeEventCallback
- 1.4. BackButtonEventCallback
- 1.5. MenuButtonEventCallback
- 1.6. SearchButtonEventCallback
- 1.7. StartCallEventCallback
- 1.8. EndCallButtonEventCallback
- 1.9. VolumeDownButtonEventCallback
- 1.10. VolumeUpButtonEventCallback
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| DeviceReadyEventCallback | void ondeviceready () |
| PauseEventCallback | void onpause () |
| ResumeEventCallback | void onresume () |
| BackButtonEventCallback | void onbackbutton () |
| MenuButtonEventCallback | void onmenubutton () |
| SearchButtonEventCallback | void onsearchbutton () |
| StartCallEventCallback | void onstartcallbutton () |
| EndCallButtonEventCallback | void onendcallbutton () |
| VolumeDownButtonEventCallback | void onvolumedownbutton () |
| VolumeUpButtonEventCallback | void onvolumeupbutton () |

## 1. Interfaces

### 1.1. DeviceReadyEventCallback

Callback for the event which fires when Cordova is fully loaded

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface DeviceReadyEventCallback {
    void ondeviceready();
  };
```

Since: 3.0

The domready event is essential to any application. It signals that Cordova's device APIs have loaded and are ready to access.

Cordova consists of two code bases: native and JavaScript. While the native code loads, a custom loading image displays. However, JavaScript only loads once the DOM loads. This means the web app may potentially call a Cordova JavaScript function before the corresponding native code becomes available.

The deviceready event fires once Cordova has fully loaded. Once the event fires, you can safely make calls to Cordova APIs. Applications typically attach an event listener with document.addEventListener once the HTML document's DOM has loaded.

The deviceready event behaves somewhat differently from others. Any event handler registered after the deviceready event fires has its callback function called immediately.

Original documentation: Cordova deviceready event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  /* Now safe to use device APIs. */
}
```

#### Methods

`**ondeviceready **`Called when Cordova is fully loaded.

```javascript
void ondeviceready();
```

Since: 3.0

### 1.2. PauseEventCallback

Callback for the event which fires when an application is put into the background

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface PauseEventCallback {
    void onpause();
  };
```

Since: 3.0

The pause event fires when the native platform puts the application into the background, typically when the user switches to a different application.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova pause event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("pause", onPause, false);
}

function onPause()
{
  /* Handle the pause event. */
}
```

#### Methods

`**onpause **`Called when an application is put into the background.

```javascript
void onpause();
```

Since: 3.0

### 1.3. ResumeEventCallback

Callback for the event which fires when an application is retrieved from the background

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface ResumeEventCallback {
    void onresume();
  };
```

Since: 3.0

The resume event fires when the native platform pulls the application out from the background.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova resume event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("resume", onResume, false);
}

function onResume()
{
  /* Handle the resume event. */
}
```

#### Methods

`**onresume **`Called when an application is retrieved from the background.

```javascript
void onresume();
```

Since: 3.0

### 1.4. BackButtonEventCallback

Callback for the event which fires when the user presses the back button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface BackButtonEventCallback {
    void onbackbutton();
  };
```

Since: 3.0

To override the default back-button behavior, register an event listener for the backbutton event, typically by calling document.addEventListener() once you receive the deviceready event.
It is no longer necessary to call any other method to override the back-button behavior.

Original documentation: Cordova backbutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("backbutton", onBackKeyDown, false);
}

function onBackKeyDown()
{
  /* Handle the back button. */
}
```

#### Methods

`**onbackbutton **`Called when user presses the back button.

```javascript
void onbackbutton();
```

Since: 3.0

### 1.5. MenuButtonEventCallback

Callback for the event which fires when the user presses the menu button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface MenuButtonEventCallback {
    void onmenubutton();
  };
```

Since: 3.0

Applying an event handler for the menubutton event overrides the default menu button behavior.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova menubutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("menubutton", onMenuKeyDown, false);
}

function onMenuKeyDown()
{
  /* Handle the menu button. */
}
```

#### Methods

`**onmenubutton **`Called when user presses the menu button.

```javascript
void onmenubutton();
```

Since: 3.0

### 1.6. SearchButtonEventCallback

Callback for the event which fires when the user presses the search button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface SearchButtonEventCallback {
    void onsearchbutton();
  };
```

Since: 3.0

If you need to override the default search button behavior on Android you can register an event listener for the searchbutton event.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova searchbutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("searchbutton", onSearchKeyDown, false);
}

function onSearchKeyDown()
{
  /* Handle the search button. */
}
```

#### Methods

`**onsearchbutton **`Called when user presses the search button.

```javascript
void onsearchbutton();
```

Since: 3.0

### 1.7. StartCallEventCallback

Callback for the event which fires when the user presses the start call button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface StartCallEventCallback {
    void onstartcallbutton();
  };
```

Since: 3.0

If you need to override the default start call behavior you can register an event listener for the startcallbutton event.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova startcallbutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("startcallbutton", onStartCallKeyDown, false);
}

function onStartCallKeyDown()
{
  /* Handle the start call button. */
}
```

#### Methods

`**onstartcallbutton **`Called when user presses the start call button.

```javascript
void onstartcallbutton();
```

Since: 3.0

### 1.8. EndCallButtonEventCallback

Callback for the event which fires when the user presses the end call button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface EndCallButtonEventCallback {
    void onendcallbutton();
  };
```

Since: 3.0

The endcallbutton event overrides the default end call behavior.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova endcallbutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("endcallbutton", onEndCallKeyDown, false);
}

function onEndCallKeyDown()
{
  /* Handle the end call button. */
}
```

#### Methods

`**onendcallbutton **`Called when user presses the end call button.

```javascript
void onendcallbutton();
```

Since: 3.0

### 1.9. VolumeDownButtonEventCallback

Callback for the event which fires when the user presses the volume down button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface VolumeDownButtonEventCallback {
    void onvolumedownbutton();
  };
```

Since: 3.0

If you need to override the default volume down behavior you can register an event listener for the volumedownbutton event.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova volumedownbutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("volumedownbutton", onVolumeDownKeyDown, false);
}

function onVolumeDownKeyDown()
{
  /* Handle the volume down button. */
}
```

#### Methods

`**onvolumedownbutton **`Called when user presses the volume down button.

```javascript
void onvolumedownbutton();
```

Since: 3.0

### 1.10. VolumeUpButtonEventCallback

Callback for the event which fires when the user presses the volume up button

```webidl
  [NoInterfaceObject, Callback=FunctionOnly] interface VolumeUpButtonEventCallback {
    void onvolumeupbutton();
  };
```

Since: 3.0

If you need to override the default volume up behavior you can register an event listener for the volumeupbutton event.

Applications typically should use document.addEventListener() to attach an event listener once the deviceready event fires.

Original documentation: Cordova volumeupbutton event

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  document.addEventListener("volumeupbutton", onVolumeUpKeyDown, false);
}

function onVolumeUpKeyDown()
{
  /* Handle the volume up button. */
}
```

#### Methods

`**onvolumeupbutton **`Called when user presses the volume up button.

```javascript
void onvolumeupbutton();
```

Since: 3.0

## 2. Full WebIDL

```webidl
module Events {
  [NoInterfaceObject, Callback=FunctionOnly] interface DeviceReadyEventCallback {
    void ondeviceready();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface PauseEventCallback {
    void onpause();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface ResumeEventCallback {
    void onresume();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface BackButtonEventCallback {
    void onbackbutton();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface MenuButtonEventCallback {
    void onmenubutton();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface SearchButtonEventCallback {
    void onsearchbutton();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface StartCallEventCallback {
    void onstartcallbutton();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface EndCallButtonEventCallback {
    void onendcallbutton();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface VolumeDownButtonEventCallback {
    void onvolumedownbutton();
  };
  [NoInterfaceObject, Callback=FunctionOnly] interface VolumeUpButtonEventCallback {
    void onvolumeupbutton();
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
