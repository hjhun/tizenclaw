# PrivacyPrivilege API

This Privacy Privilege API defines a set of APIs that manage the permissions for using a privacy-related privileges of application.

**Deprecated. **Deprecated Since 8.0.

A Tizen Web application has privileges defined in *config.xml *file, but for legal purposes, in case of privacy-related privileges, there could be a need of asking user directly with proper pop-up.
List of privacy-related privileges is available on Security and API Privileges page.
Privacy Privilege API allows:

- Checking if user granted permission for using a privacy-related privilege.
- Requesting pop-up about giving permission for using privacy-related privilege.

Since: 4.0

## Table of Contents

- 1. Type Definitions
- 2. Interfaces
- 3. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |

## 1. Type Definitions

## 2. Interfaces

## 3. Full WebIDL

```webidl
module PrivacyPrivilege {
  Tizen implements PrivacyPrivilegeManagerObject;
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
