# Cordova API

This API provides common Cordova functionality.

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. CordovaManagerObject
- 1.2. Cordova
- 1.3. SuccessCallback
- 1.4. ErrorCallback
- 1.5. DOMException
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| CordovaManagerObject |  |
| Cordova |  |
| SuccessCallback | void onsuccess () |
| ErrorCallback | void onerror ( DOMException error) |
| DOMException |  |

## 1. Interfaces

### 1.1. CordovaManagerObject

CordovaManagerObject implemented in Window

```webidl
  [NoInterfaceObject] interface CordovaManagerObject {
    readonly attribute Cordova cordova;
  };
```

```webidl
  Window implements CordovaManagerObject;
```

Since: 3.0

### 1.2. Cordova

The Cordova interface defines what is instantiated by the cordova object

```webidl
  [NoInterfaceObject] interface Cordova {
  };
```

Since: 3.0

### 1.3. SuccessCallback

Basic success callback, no parameters.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface SuccessCallback {
    void onsuccess();
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Success

```javascript
void onsuccess();
```

Since: 3.0

### 1.4. ErrorCallback

Basic error callback.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void onerror(DOMException error);
  };
```

Since: 3.0

#### Methods

`**onerror **`Success

```javascript
void onerror(DOMException error);
```

Since: 3.0

Parameters:

- **error :
 Error object containing some information about the error. **

### 1.5. DOMException

See DOMException .

```webidl
  interface DOMException {
    readonly attribute short code;
    readonly attribute DOMString name;
    readonly attribute DOMString message;
  };
```

Since: 3.0

#### Attributes

- readonly short code The number representing the type of the error.

Since: 3.0

- readonly DOMString name The short text representing the type of the error.

Since: 3.0

- readonly DOMString message A text containing information about the error.

Since: 3.0

## 2. Full WebIDL

```webidl
module Cordova {
  Window implements CordovaManagerObject;
  [NoInterfaceObject] interface CordovaManagerObject {
    readonly attribute Cordova cordova;
  };
  [NoInterfaceObject] interface Cordova {
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface SuccessCallback {
    void onsuccess();
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void onerror(DOMException error);
  };
  interface DOMException {
    readonly attribute short code;
    readonly attribute DOMString name;
    readonly attribute DOMString message;
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
