# HumanActivityMonitor API

The Human Activity Monitor API defines interfaces and methods to manage human activity data from various sensors on the device.

The following human activity monitor functionality is provided:

- Set up callbacks for data change notification
- Get current human activity monitor data
- Record and read human activity data
- Recognize activities and gestures
The gesture recognition API allows applications to be notified and react when the user performs different types of gestures, for example,  when the device was tapped, shaken up, picked up or moved along axis.

The activity recognition API allows applications to be notified and react when a user activity is recognized, for example, the user starts to run, walk or is in moving vehicle.

For more information about how to use Human Activity Monitor API, see Human Activity Monitor Guide .

Since: 2.3

## Table of Contents

- 1. Type Definitions
- 1.1. HumanActivityType
- 1.2. HumanActivityRecorderType
- 1.3. PedometerStepStatus
- 1.4. SleepStatus
- 2. Interfaces
- 2.1. HumanActivityMonitorManagerObject
- 2.2. HumanActivityMonitorManager
- 2.3. StepDifference
- 2.4. HumanActivityRecorderOption
- 2.5. HumanActivityRecorderQuery
- 2.6. HumanActivityData
- 2.7. HumanActivityPedometerData
- 2.8. HumanActivityAccumulativePedometerData
- 2.9. HumanActivityHRMData
- 2.10. HumanActivityGPSInfo
- 2.11. HumanActivityGPSInfoArray
- 2.12. HumanActivitySleepMonitorData
- 2.13. HumanActivitySleepDetectorData
- 2.14. HumanActivityMonitorOption
- 2.15. HumanActivityRecorderData
- 2.16. HumanActivityRecorderPedometerData
- 2.17. HumanActivityRecorderHRMData
- 2.18. HumanActivityRecorderSleepMonitorData
- 2.19. HumanActivityRecorderPressureData
- 2.20. HumanActivityMonitorSuccessCallback
- 2.21. HumanActivityReadRecorderSuccessCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| HumanActivityMonitorManagerObject |  |
| HumanActivityMonitorManager | void getHumanActivityData ( HumanActivityType type, HumanActivityMonitorSuccessCallback successCallback, optional ErrorCallback ? errorCallback) void start ( HumanActivityType type, optional HumanActivityMonitorSuccessCallback ? changedCallback, optional ErrorCallback ? errorCallback, optional HumanActivityMonitorOption ? option) void stop ( HumanActivityType type) void setAccumulativePedometerListener ( HumanActivityMonitorSuccessCallback changeCallback) void unsetAccumulativePedometerListener () void startRecorder ( HumanActivityRecorderType type, optional HumanActivityRecorderOption option) void stopRecorder ( HumanActivityRecorderType type) void readRecorderData ( HumanActivityRecorderType type, HumanActivityRecorderQuery ? query, HumanActivityReadRecorderSuccessCallback successCallback, optional ErrorCallback ? errorCallback) |
| StepDifference |  |
| HumanActivityRecorderOption |  |
| HumanActivityRecorderQuery |  |
| HumanActivityData |  |
| HumanActivityPedometerData |  |
| HumanActivityAccumulativePedometerData |  |
| HumanActivityHRMData |  |
| HumanActivityGPSInfo |  |
| HumanActivityGPSInfoArray |  |
| HumanActivitySleepMonitorData |  |
| HumanActivitySleepDetectorData |  |
| HumanActivityMonitorOption |  |
| HumanActivityRecorderData |  |
| HumanActivityRecorderPedometerData |  |
| HumanActivityRecorderHRMData |  |
| HumanActivityRecorderSleepMonitorData |  |
| HumanActivityRecorderPressureData |  |
| HumanActivityMonitorSuccessCallback | void onsuccess (optional HumanActivityData ? humanactivitydata) |
| HumanActivityReadRecorderSuccessCallback | void onsuccess ( HumanActivityRecorderData [] humanactivitydata) |

## 1. Type Definitions

### 1.1. HumanActivityType

Specifies the supported human activity monitor types.

```webidl
  enum HumanActivityType { "PEDOMETER", "HRM", "GPS", "SLEEP_MONITOR", "SLEEP_DETECTOR" };
```

Since: 2.3

The human activity monitor types defined by this enumerator are:

- PEDOMETER - Pedometer data
- HRM - Heart rate monitor (Heart rate and RR interval)
- GPS - GPS information (latitude, longitude and speed)
- SLEEP_MONITOR - Sleep monitor (sleep state)
- SLEEP_DETECTOR - Sleep detector (sleep status)

Remark: *SLEEP_MONITOR *is supported since Tizen 3.0

Remark: *SLEEP_DETECTOR *and *STRESS_MONITOR *are supported since Tizen 5.0

### 1.2. HumanActivityRecorderType

Specifies the human activity recorder types.

```webidl
  enum HumanActivityRecorderType { "PEDOMETER", "HRM", "SLEEP_MONITOR", "PRESSURE" };
```

Since: 3.0

The human activity recorder types defined by this enumerator are:

- PEDOMETER - Pedometer recorder type
- HRM - Heart rate monitor (Heart rate)
- SLEEP_MONITOR - Sleep monitor (sleep state)
- PRESSURE - Pressure sensor

### 1.3. PedometerStepStatus

Specifies the pedometer user's current movement type.

```webidl
  enum PedometerStepStatus { "NOT_MOVING", "WALKING", "RUNNING", "UNKNOWN" };
```

Since: 2.3

- NOT_MOVING - The user remains stationary
- WALKING - The user is walking
- RUNNING - The user is running
- UNKNOWN - The user's movement type is uncertain

Remark: *UNKNOWN *is supported since Tizen 3.0

### 1.4. SleepStatus

Specifies the sleep monitor user's sleep status.

```webidl
  enum SleepStatus { "ASLEEP", "AWAKE", "UNKNOWN" };
```

Since: 3.0

- ASLEEP - The user is asleep
- AWAKE - The user is awake
- UNKNOWN - Sleep status could not be determined

Code example:

```javascript
function onchangedCB(sleepInfo)
{
  console.log("Sleep status: " + sleepInfo.status);
  console.log("Timestamp: " + sleepInfo.timestamp);
}

tizen.humanactivitymonitor.start("SLEEP_MONITOR", onchangedCB);
```

Output example:

```
Sleep status: ASLEEP
Timestamp: 1456735296123
```

## 2. Interfaces

### 2.1. HumanActivityMonitorManagerObject

The HumanActivityMonitorManagerObject interface defines what is instantiated by the *Tizen *object.
The *tizen.humanactivitymonitor *object allows access to the human activity data.

```webidl
  [NoInterfaceObject] interface HumanActivityMonitorManagerObject {
    readonly attribute HumanActivityMonitorManager humanactivitymonitor;
  };
```

```webidl
  Tizen implements HumanActivityMonitorManagerObject;
```

Since: 2.3

#### Attributes

- readonly HumanActivityMonitorManager humanactivitymonitor Object representing a exif manager.

Since: 2.3

### 2.2. HumanActivityMonitorManager

The HumanActivityMonitorManager interface provides methods to access human activity data.

```webidl
  [NoInterfaceObject] interface HumanActivityMonitorManager {
    void getHumanActivityData(HumanActivityType type, HumanActivityMonitorSuccessCallback successCallback,
                              optional ErrorCallback? errorCallback) raises(WebAPIException);
    void start(HumanActivityType type, optional HumanActivityMonitorSuccessCallback? changedCallback,
               optional ErrorCallback? errorCallback, optional HumanActivityMonitorOption? option) raises(WebAPIException);
    void stop(HumanActivityType type) raises(WebAPIException);
    void setAccumulativePedometerListener(HumanActivityMonitorSuccessCallback changeCallback) raises(WebAPIException);
    void unsetAccumulativePedometerListener() raises(WebAPIException);
    void startRecorder(HumanActivityRecorderType type, optional HumanActivityRecorderOption option) raises(WebAPIException);
    void stopRecorder(HumanActivityRecorderType type) raises(WebAPIException);
    void readRecorderData(HumanActivityRecorderType type, HumanActivityRecorderQuery? query,
                          HumanActivityReadRecorderSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                          raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**getHumanActivityData **`Gets the current human activity data for certain human activity types.

```javascript
void getHumanActivityData(HumanActivityType type, HumanActivityMonitorSuccessCallback successCallback,
                          optional ErrorCallback? errorCallback);
```

Since: 2.3

The *start() *method should be called to turn on the sensor before calling the *getHumanActivityData() *method. If not, ServiceNotAvailableError occurs.

If the given type is not supported on a device, NotSupportedError is thrown.

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError: If the *getHumanActivityData() *method is called without previously calling the *start() *method

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Remark: getHumanActivityData() method can only be used with the HRM and PEDOMETER types.

Remark: This function may fail if it is called before the sensor is ready. In case of interval-driven sensors, it is recommended to call the function after at least one sensor event is delivered. Otherwise, applications can retry to call this function to be sure that the sensor is ready.

Parameters:

- **type :
 Human activity data type to read (HRM or PEDOMETER). **
- **successCallback :
 Callback method to be invoked when the human activity data has been read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if registering the success callback fails because of an unknown error.

- with error type NotSupportedError, if the given type is not supported on a device or by this method.

- with error type SecurityError, if the application does not have the privilege to use this function.

Code example:

```javascript
function onsuccessCB(pedometerInfo)
{
  console.log("Step status: " + pedometerInfo.stepStatus);
  console.log("Cumulative total step count: " + pedometerInfo.cumulativeTotalStepCount);
  console.log("Accumulative total step count: " + pedometerInfo.accumulativeTotalStepCount);
}

function onerrorCB(error)
{
  console.log("Error occurs, name: " + error.name + ", message: " + error.message);
}

function onchangedCB(pedometerdata)
{
  console.log("From now on, you will be notified when the pedometer data changes");
  /* To get the current data information. */
  tizen.humanactivitymonitor.getHumanActivityData("PEDOMETER", onsuccessCB, onerrorCB);
}

tizen.humanactivitymonitor.start("PEDOMETER", onchangedCB);
```

Output example:

```
From now on, you will be notified when the pedometer data changes.
Step status: WALKING
Cumulative total step count: 100
```

`**start **`Starts a sensor and registers a change listener to be called when new human activity data for a given human activity type is available.

```javascript
void start(HumanActivityType type, optional HumanActivityMonitorSuccessCallback? changedCallback,
           optional ErrorCallback? errorCallback, optional HumanActivityMonitorOption? option);
```

Since: 2.3

The *ErrorCallback *method is launched with these error types:

- ServiceNotAvailableError - If the human activity service is not available. For the GPS type, if the GPS function is disabled by the user in the location settings, it is not possible to receive notifications when the GPS value changes.

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Remark: The **"http://tizen.org/privilege/location" **privilege is required for only the GPS type.
That means that both **"http://tizen.org/privilege/healthinfo" **and **"http://tizen.org/privilege/location" **should be declared in config.xml file for the GPS type.
For other types, only **"http://tizen.org/privilege/healthinfo" **should be declared.

Remark: *errorCallback *and *option *are supported since Tizen 3.0.

Parameters:

- **type :
 Human activity type to register a listener for.
- **Conditional privilege: **For using GPS value, privilege **http://tizen.org/privilege/location (public level) **is needed since Tizen 2.3.
**
- **changedCallback [optional] [nullable] :
 Callback method to be invoked when new human activity data is available 
Note that the listener is not called for the successful start of a human activity sensor.
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **
- **option [optional] [nullable] :
 The option to set the period and the interval for several human activity types 
By default, this parameter is set to null.
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if registering the listener fails because of an unknown error.

- with error type NotSupportedError, if the given type is not supported on a device.

- with error type SecurityError, if the application does not have the privilege to use this function.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

Code example:

```javascript
function onchangedCB(pedometerInfo)
{
  console.log("Step status: " + pedometerInfo.stepStatus);
  console.log("Cumulative total step count: " + pedometerInfo.cumulativeTotalStepCount);
}

tizen.humanactivitymonitor.start("PEDOMETER", onchangedCB);
```

Output example:

```
Step status: WALKING
Cumulative total step count: 100
```

Code example:

```javascript
function onchangedCB(info)
{
  var gpsInfo = info.gpsInfo;
  for (var index = 0; index < gpsInfo.length; index++)
  {
    console.log("latitude: " + gpsInfo[index].latitude);
    console.log("longitude: " + gpsInfo[index].longitude);
  }
}

function onerrorCB(error)
{
  console.log("Error occurred, name: " + error.name + ", message: " + error.message);
}

try
{
  tizen.humanactivitymonitor.start(
      "GPS", onchangedCB, onerrorCB, {callbackInterval: 150000, sampleInterval: 1000});
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**stop **`Stops the sensor and unregisters a previously registered listener for available human activity data.

```javascript
void stop(HumanActivityType type);
```

Since: 2.3

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Remark: The **"http://tizen.org/privilege/location" **privilege is required for only the GPS type.
That means that both **"http://tizen.org/privilege/healthinfo" **and **"http://tizen.org/privilege/location" **should be declared in config.xml file for the GPS type.
For other types, only **"http://tizen.org/privilege/healthinfo" **should be declared.

Parameters:

- **type :
 Human activity type to unregister the listener for.
- **Conditional privilege: **For using GPS value, privilege **http://tizen.org/privilege/location (public level) **is needed since Tizen 2.3.
**

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if unregistering the listener fails because of an unknown error.

- with error type NotSupportedError, if the given type is not supported on a device.

- with error type SecurityError, if the application does not have the privilege to use this function.

Code example:

```javascript
tizen.humanactivitymonitor.stop("PEDOMETER");
```

`**setAccumulativePedometerListener **`Starts the sensor and registers a listener to be called when new accumulative pedometer data is available.

```javascript
void setAccumulativePedometerListener(HumanActivityMonitorSuccessCallback changeCallback);
```

Since: 2.3

Note that the setAccumulativePedometerListener() method does not need to call the sensor's start() method.

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Parameters:

- **changeCallback :
 Callback method to be invoked when new accumulative pedometer data is available 
Callback is invoked with HumanActivityAccumulativePedometerData as an argument.
Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type UnknownError, if registering the listener fails because of an unknown error.

- with error type NotSupportedError, if the pedometer sensor is not supported on a device.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
function onchangedCB(pedometerInfo)
{
  console.log("Step status: " + pedometerInfo.stepStatus);
  console.log("Accumulative total step count: " + pedometerInfo.accumulativeTotalStepCount);
}

tizen.humanactivitymonitor.setAccumulativePedometerListener(onchangedCB);
```

Output example:

```
Step status: WALKING
Accumulative total step count: 100
```

`**unsetAccumulativePedometerListener **`Stops the sensor and unregisters a previously registered listener for the accumulative pedometer data.

```javascript
void unsetAccumulativePedometerListener();
```

Since: 2.3

Calling this function has no effect if listener is not set.

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Exceptions:

- WebAPIException
- with error type UnknownError, if unregistering the listener fails because of an unknown error.

- with error type SecurityError, if the application does not have the privilege to call this method.

Code example:

```javascript
tizen.humanactivitymonitor.unsetAccumulativePedometerListener();
```

`**startRecorder **`Starts recording human activity data for a given human activity type.

```javascript
void startRecorder(HumanActivityRecorderType type, optional HumanActivityRecorderOption option);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Parameters:

- **type :
 Human activity type to record. **
- **option [optional] :
 The option to set an interval and a period for retention. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to use this function.

- with error type NotSupportedError, if the human activity recorder type is not supported.

- with error type AbortError, if the system operation was aborted.

- with error type ServiceNotAvailableError, if the human activity recorder type is already started by any application of a package.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

Code example:

```javascript
var type = "PRESSURE";
var options =
{
  retentionPeriod: 1  /* 1 hour. */
};

try
{
  tizen.humanactivitymonitor.startRecorder(type, options);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**stopRecorder **`Stops recording human activity data for a given human activity type.

```javascript
void stopRecorder(HumanActivityRecorderType type);
```

Since: 3.0

Parameters:

- **type :
 Human activity type to stop recording. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if the human activity recorder type is not supported.

- with error type AbortError, if the system operation was aborted.

Code example:

```javascript
var type = "PRESSURE";
try
{
  tizen.humanactivitymonitor.startRecorder(type);
  /* Do something. */

  tizen.humanactivitymonitor.stopRecorder(type);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

`**readRecorderData **`Reads the recorded human activity data with some query.

```javascript
void readRecorderData(HumanActivityRecorderType type, HumanActivityRecorderQuery? query,
                      HumanActivityReadRecorderSuccessCallback successCallback, optional ErrorCallback? errorCallback);
```

Since: 3.0

If another application has recorded data for a particular human activity type, your application can read that data.
Therefore, you can use this method to read without calling *startRecorder() *.

The *ErrorCallback *method is launched with these error types:

- AbortError: If the system operation was aborted while reading data asynchronously.
- NotFoundError: If no recorder data is available.

Privilege level: public

Privilege: http://tizen.org/privilege/healthinfo

Parameters:

- **type :
 Human activity type to record. **
- **query [nullable] :
 The query to use. **
- **successCallback :
 Callback method to be invoked when recorded human activity data is successfully read. **
- **errorCallback [optional] [nullable] :
 Callback method to be invoked when an error occurs. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type SecurityError, if the application does not have the privilege to use this function.

- with error type NotSupportedError, if the human activity recorder type is not supported.

- with error type AbortError, if the system operation was aborted when it is requested to read data.

- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

Code example:

```javascript
function onerror(error)
{
  console.log(error.name + ": " + error.message);
}

function onread(data)
{
  for (var idx = 0; idx < data.length; ++idx)
  {
    console.log("startTime: " + data[idx].startTime);
    console.log("endTime: " + data[idx].endTime);
    console.log("calories: " + data[idx].calorie);
  }
}

var type = "PEDOMETER";
var query = {};
try
{
  tizen.humanactivitymonitor.readRecorderData(type, query, onread, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
startTime: 1420311755
endTime: 1420313238
calories: 24.83
```

### 2.3. StepDifference

The StepDifference interface represents the count difference between steps and timestamp.

```webidl
  [NoInterfaceObject] interface StepDifference {
    readonly attribute long stepCountDifference;
    readonly attribute long timestamp;
  };
```

Since: 2.3

#### Attributes

- readonly long stepCountDifference Count difference between the steps.

Since: 2.3

- readonly long timestamp Timestamp in seconds.

Since: 2.3

### 2.4. HumanActivityRecorderOption

The HumanActivityRecorderOption dictionary contains options, such as the *interval *, to use with startRecorder().

```webidl
  dictionary HumanActivityRecorderOption {
    long interval;
    long retentionPeriod;
  };
```

Since: 3.0

Code example:

```javascript
var option = {interval: 10, retentionPeriod: 1};
```

#### Dictionary members

long interval Interval in minutes at which human activity recorder data will be recorded.

For the HRM type, the *interval *can be between 10 and 1440 (1 day) inclusive. 
If *interval *is not specified, it is set to the default value of 1440 minutes (1 day). 
For other human activity recorder types, *interval *will be ignored.

Since: 3.0

Remark: The specified interval is only a suggested interval between sensor measurements.
You will get at least one sensor measurement within the interval you specify, but the actual interval between sensor measurements can be affected by other applications and the system.
To reduce the system overhead, it is recommended to set the longest interval that you can, because the system usually chooses the shortest interval among all intervals specified.

long retentionPeriod Retention period in hours for which human activity recorder data should be retained.

The *retentionPeriod *can be between 1 and 744 (31 days) inclusive. 
If *retentionPeriod *is not specified, it is set to the default value of 1 hour.

Since: 3.0

### 2.5. HumanActivityRecorderQuery

The HumanActivityRecorderQuery dictionary contains query, such as the *startTime *, the *endTime *, the *anchorTime *and the *interval *, to use with readRecorderData().

```webidl
  dictionary HumanActivityRecorderQuery {
    long startTime;
    long endTime;
    long anchorTime;
    long interval;
  };
```

Since: 3.0

#### Dictionary members

long startTime The start time of the data to be queried. Epoch time in seconds.

The *startTime *should be greater than or equal to zero. 
If *startTime *is not specified, it is set to the default value of 1 day ago.

Since: 3.0

long endTime The end time of the date to be queried. Epoch time in seconds.

The *endTime *should be greater than *startTime *. 
If *endTime *is not specified, it is set to the current time.

Since: 3.0

long anchorTime The anchor point to slice the read data. Epoch time in seconds.

For the PEDOMETER and PRESSURE type, the *anchorTime *can only be used. 
The *anchorTime *should be greater than or equal to zero. 
If *anchorTime *is not specified, it will be set to the *endTime *.

The *interval *will extend away from the *anchorTime *in both directions.
The exact date does not matter for the *anchorTime *.
This is because the *anchorTime *is used in combination with the interval.
For example, the *anchorTime *can be 1:00 am, January 1, 2000 or 1:00 am, August 15, 2010 with a 1 day interval. In both cases, the *anchorTime *will be 1:00 am internally.

Since: 3.0

Code example:

```javascript
function onerror(error)
{
  console.log(error.name + ": " + error.message);
}

function onread(data)
{
  for (var idx = 0; idx < data.length; ++idx)
  {
    console.log("*** " + idx);
    console.log("max pressure: " + data[idx].max);
    console.log("min pressure: " + data[idx].min);
    console.log("average: " + data[idx].average);
  }
}

var type = "PRESSURE";
var now = new Date();
var startTime = now.setDate(now.getDate() - 4);
var anchorTime = new Date(2000, 1, 2, 6).getTime();
var query =
{
  startTime: startTime / 1000,
  anchorTime: anchorTime / 1000,
  interval: 1440  /* 1 day. */
};

try
{
  tizen.humanactivitymonitor.readRecorderData(type, query, onread, onerror);
}
catch (err)
{
  console.log(err.name + ": " + err.message);
}
```

Output example:

```
*** 0
max pressure: 1013.00
min pressure: 930.00
average: 980.00
*** 1
max pressure: 1012.00
min pressure: 954.00
average: 986.00
*** 2
max pressure: 950.00
min pressure: 904.00
average: 932.00
*** 3
max pressure: 1012.00
min pressure: 920.00
average: 942.00
*** 4
max pressure: 1012.00
min pressure: 1005.00
average: 1008.00
```

long interval Interval in minutes at which human activity recorder data will be read.

The *interval *should be greater than or equal to zero. 
For the PEDOMETER and PRESSURE type, if *interval *is not specified, it is set to the difference between *endTime *and *startTime *. 
For the PRESSURE type, if it is set to zero, all raw data recorded from *startTime *to *endTime *will be returned. 
For other recorder types, *interval *will be ignored.

Since: 3.0

### 2.6. HumanActivityData

The HumanActivityData interface is a common abstract interface used by the different types of human activity data.

```webidl
  [NoInterfaceObject] interface HumanActivityData {
  };
```

Since: 2.3

### 2.7. HumanActivityPedometerData

The HumanActivityPedometerData interface represents pedometer data.

```webidl
  [NoInterfaceObject] interface HumanActivityPedometerData : HumanActivityData {
    readonly attribute PedometerStepStatus stepStatus;
    readonly attribute double speed;
    readonly attribute double walkingFrequency;
    readonly attribute double cumulativeDistance;
    readonly attribute double cumulativeCalorie;
    readonly attribute double cumulativeTotalStepCount;
    readonly attribute double cumulativeWalkStepCount;
    readonly attribute double cumulativeRunStepCount;
    readonly attribute double accumulativeDistance;
    readonly attribute double accumulativeCalorie;
    readonly attribute double accumulativeTotalStepCount;
    readonly attribute double accumulativeWalkStepCount;
    readonly attribute double accumulativeRunStepCount;
    readonly attribute StepDifference[] stepCountDifferences;
  };
```

Since: 2.3

#### Attributes

- readonly PedometerStepStatus stepStatus The current movement type.

Since: 2.3

- readonly double speed Current speed in km/h.

Since: 2.3

- readonly double walkingFrequency Step count per second.

Since: 2.3

- readonly double cumulativeDistance Cumulative distance traveled since the last start() method call in meters.

Since: 2.3

- readonly double cumulativeCalorie Cumulative calories burnt since the last start() method call in kcal.

Since: 2.3

- readonly double cumulativeTotalStepCount Cumulative walking and running step count since the last start() method call.

The value is the sum of *cumulativeWalkStepCount *and *cumulativeRunStepCount *.

Since: 2.3

- readonly double cumulativeWalkStepCount Cumulative walking step count since the last start() method call.

Since: 2.3

- readonly double cumulativeRunStepCount Cumulative running step count since the last start() method call.

Since: 2.3

- readonly double accumulativeDistance Accumulative distance traveled since the device boot in meters.

Since: 6.0

- readonly double accumulativeCalorie Accumulative calories burnt since the device boot in kcal.

Since: 6.0

- readonly double accumulativeTotalStepCount Accumulative walking and running step count since the device boot.

Since: 6.0

- readonly double accumulativeWalkStepCount Accumulative walking step count since the device boot.

Since: 6.0

- readonly double accumulativeRunStepCount Accumulative running step count since the device boot.

Since: 6.0

- readonly StepDifference[] stepCountDifferences Array of the StepDifference.

Since: 2.3

### 2.8. HumanActivityAccumulativePedometerData

The HumanActivityAccumulativePedometerData interface represents pedometer motion data since the device boot.

```webidl
  [NoInterfaceObject] interface HumanActivityAccumulativePedometerData : HumanActivityData {
    readonly attribute PedometerStepStatus stepStatus;
    readonly attribute double speed;
    readonly attribute double walkingFrequency;
    readonly attribute double accumulativeDistance;
    readonly attribute double accumulativeCalorie;
    readonly attribute double accumulativeTotalStepCount;
    readonly attribute double accumulativeWalkStepCount;
    readonly attribute double accumulativeRunStepCount;
    readonly attribute StepDifference[] stepCountDifferences;
  };
```

Since: 2.3

#### Attributes

- readonly PedometerStepStatus stepStatus Current movement type.

Since: 2.3

- readonly double speed Current speed in km/h.

Since: 2.3

- readonly double walkingFrequency Step count per second.

Since: 2.3

- readonly double accumulativeDistance Accumulative distance traveled since the device boot in meters.

Since: 2.3

- readonly double accumulativeCalorie Accumulative calories burnt since the device boot in kcal.

Since: 2.3

- readonly double accumulativeTotalStepCount Accumulative walking and running step count since the device boot.

The value is the sum of *accumulativeWalkStepCount *and *accumulativeRunStepCount *.

Since: 2.3

- readonly double accumulativeWalkStepCount Accumulative walking step count since the device boot.

Since: 2.3

- readonly double accumulativeRunStepCount Accumulative running step count since the device boot.

Since: 2.3

- readonly StepDifference[] stepCountDifferences Array of the StepDifference.

Since: 2.3

### 2.9. HumanActivityHRMData

The HumanActivityHRMData interface represents Heart Rate Monitor(HRM) data.

```webidl
  [NoInterfaceObject] interface HumanActivityHRMData : HumanActivityData {
    readonly attribute long heartRate;
    readonly attribute long rRInterval;
  };
```

Since: 2.3

#### Attributes

- readonly long heartRate Heart rate in beats per minute.
When a user takes off the watch device, the heartRate is set to -3. When a user shakes the watch, the heartRate is set to -2.

Since: 2.3

- readonly long rRInterval Peak-to-peak interval in millisecond(s).

Since: 2.3

### 2.10. HumanActivityGPSInfo

The HumanActivityGPSInfo interface represents GPS information.

```webidl
  [NoInterfaceObject] interface HumanActivityGPSInfo {
    readonly attribute double latitude;
    readonly attribute double longitude;
    readonly attribute double altitude;
    readonly attribute double speed;
    readonly attribute long errorRange;
    readonly attribute long timestamp;
  };
```

Since: 2.3

#### Attributes

- readonly double latitude An attribute to indicate the user's latitude in degrees.

Since: 2.3

- readonly double longitude An attribute to indicate the user's longitude in degrees.

Since: 2.3

- readonly double altitude An attribute to indicate the user's altitude in meters.

Since: 2.3

- readonly double speed An attribute to indicate the speed in km/h.

Since: 2.3

- readonly long errorRange An attribute to indicate the error range of the user's position in meters.

Since: 2.3

- readonly long timestamp An attribute to indicate timestamp in seconds.

Since: 2.3

### 2.11. HumanActivityGPSInfoArray

The HumanActivityGPSInfoArray interface represents GPS information array.

```webidl
  [NoInterfaceObject] interface HumanActivityGPSInfoArray : HumanActivityData {
    readonly attribute HumanActivityGPSInfo[] gpsInfo;
  };
```

Since: 2.3

#### Attributes

- readonly HumanActivityGPSInfo[] gpsInfo An attribute to indicate the array of GPS information.

Since: 2.3

### 2.12. HumanActivitySleepMonitorData

The HumanActivitySleepMonitorData interface represents sleep monitor data.

```webidl
  [NoInterfaceObject] interface HumanActivitySleepMonitorData : HumanActivityData {
    readonly attribute SleepStatus status;
    readonly attribute long long timestamp;
  };
```

Since: 3.0

Remark: If the device's display is off, multiple callbacks consisting of sleep monitor data are all invoked at once at a device specific interval. There is a callback for each minute in the interval. For example, if the device's interval is 20 minutes, 20 callbacks will be invoked every 20 minutes. When the display is turned on, all callbacks which have not been invoked are invoked and the callback is invoked every one minute from then on. Therefore, if the display is turned on at 25 minutes, five callbacks will be invoked.

#### Attributes

- readonly SleepStatus status The sleep status.

Since: 3.0

- readonly long long timestamp The time when the sleep status is recognized. Epoch time in milliseconds.

Since: 3.0

### 2.13. HumanActivitySleepDetectorData

The HumanActivitySleepDetectorData interface represents sleep detector data.

```webidl
  [NoInterfaceObject] interface HumanActivitySleepDetectorData : HumanActivityData {
    readonly attribute SleepStatus status;
  };
```

Since: 5.0

#### Attributes

- readonly SleepStatus status Sleep state (can be UNKNOWN, ASLEEP and AWAKE).

Since: 5.0

### 2.14. HumanActivityMonitorOption

The HumanActivityMonitorOption dictionary contains options, such as the *callbackInterval *and the *sampleInterval *, to use with start().

```webidl
  dictionary HumanActivityMonitorOption {
    long callbackInterval;
    long sampleInterval;
  };
```

Since: 3.0

#### Dictionary members

long callbackInterval The interval in milliseconds (ms) at which human activity data will be sent to the Web Application. 
For the GPS type, *callbackInterval *should be greater than or equal to the *sampleInterval *. The maximum permissible value for *callbackInterval *is device specific. If *callbackInterval *is not specified or zero, it is set to the default value of 150000ms. The *callbackInterval *will be ignored when the display is on. Instead, The *callbackInterval *will be set to the *sampleInterval *. 
For the HRM type, *callbackInterval *can be between 10ms and 1000ms inclusive, however, if it not specified or zero, it is set by the default value of 100ms. 
For other activity types, *callbackInterval *will be ignored. Since: 3.0

Remark: The specified interval is only a suggested interval between sensor measurements. You will get at least one sensor measurement within the interval you specify, but the actual interval between sensor measurements can be affected by other applications and the system. To reduce the system overhead, it is recommended to set the longest interval that you can, because the system usually chooses the shortest interval among all intervals specified.

long sampleInterval GPS information sampling interval in milliseconds (ms) 
For the GPS type, *sampleInterval *should be greater than or equal to 1000ms. The maximum permissible value for *sampleInterval *is device specific. If *sampleInterval *is not specified or zero, it is set to the the default value of 1000ms. 
For other activity types, *sampleInterval *will be ignored. Since: 3.0

### 2.15. HumanActivityRecorderData

The HumanActivityRecorderData interface is a common abstract interface used for the different types of human activity recorder data.

```webidl
  [NoInterfaceObject] interface HumanActivityRecorderData {
    readonly attribute long startTime;
    readonly attribute long endTime;
  };
```

Since: 3.0

#### Attributes

- readonly long startTime Recording start time of the data in this HumanActivityRecorderData object. Epoch time in seconds.

Since: 3.0

- readonly long endTime Recording end time of the data in this HumanActivityRecorderData object. Epoch time in seconds.

Since: 3.0

### 2.16. HumanActivityRecorderPedometerData

The HumanActivityRecorderPedometerData interface represents recorded PEDOMETER data.

```webidl
  [NoInterfaceObject] interface HumanActivityRecorderPedometerData : HumanActivityRecorderData {
    readonly attribute double distance;
    readonly attribute double calorie;
    readonly attribute double totalStepCount;
    readonly attribute double walkStepCount;
    readonly attribute double runStepCount;
  };
```

Since: 3.0

#### Attributes

- readonly double distance Distance traveled from *startTime *to *endTime *in meters.

Since: 3.0

- readonly double calorie Calories burnt from *startTime *to *endTime *in kcal.

Since: 3.0

- readonly double totalStepCount Walking and running step count from *startTime *to *endTime *. The value is the sum of *walkingStepCount *and *runningStepCount *.

Since: 3.0

- readonly double walkStepCount Walking step count from *startTime *to *endTime *.

Since: 3.0

- readonly double runStepCount Running step count from *startTime *to *endTime *.

Since: 3.0

### 2.17. HumanActivityRecorderHRMData

The HumanActivityRecorderHRMData interface represents a recorded HRM data.

```webidl
  [NoInterfaceObject] interface HumanActivityRecorderHRMData : HumanActivityRecorderData {
    readonly attribute long heartRate;
  };
```

Since: 3.0

#### Attributes

- readonly long heartRate Heart rate in beats per minute.

Since: 3.0

### 2.18. HumanActivityRecorderSleepMonitorData

The HumanActivityRecorderSleepMonitorData interface represents a recorded SLEEP_MONITOR data.

```webidl
  [NoInterfaceObject] interface HumanActivityRecorderSleepMonitorData : HumanActivityRecorderData {
    readonly attribute SleepStatus status;
  };
```

Since: 3.0

#### Attributes

- readonly SleepStatus status The sleep status.

Since: 3.0

### 2.19. HumanActivityRecorderPressureData

The HumanActivityRecorderPressureData interface represents a recorded PRESSURE data.

```webidl
  [NoInterfaceObject] interface HumanActivityRecorderPressureData : HumanActivityRecorderData {
    readonly attribute double? max;
    readonly attribute double? min;
    readonly attribute double? average;
  };
```

Since: 3.0

#### Attributes

- readonly double max [nullable] Max pressure in hectopascal (hPa).

Since: 3.0

- readonly double min [nullable] Min pressure in hectopascal (hPa).

Since: 3.0

- readonly double average [nullable] Average pressure in hectopascal (hPa).

Since: 3.0

### 2.20. HumanActivityMonitorSuccessCallback

The HumanActivityMonitorSuccessCallback interface is a callback interface that is invoked when new human activity data is available.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface HumanActivityMonitorSuccessCallback {
    void onsuccess(optional HumanActivityData? humanactivitydata);
  };
```

Since: 2.3

#### Methods

`**onsuccess **`Called when there is new human activity data available.

```javascript
void onsuccess(optional HumanActivityData? humanactivitydata);
```

Since: 2.3

Parameters:

- **humanactivitydata [optional] [nullable] :
 New human activity data

### 2.21. HumanActivityReadRecorderSuccessCallback

The HumanActivityReadRecorderSuccessCallback interface is a callback interface that is invoked when recorded human activity data is successfully read.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface HumanActivityReadRecorderSuccessCallback {
    void onsuccess(HumanActivityRecorderData[] humanactivitydata);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when recorded human activity data is successfully read.

```javascript
void onsuccess(HumanActivityRecorderData[] humanactivitydata);
```

Since: 3.0

Parameters:

- **humanactivitydata :
 Recorded human activity data. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the Human Activity Monitor application runs on a device which supports this API, declare the following feature requirements in the config file:

- http://tizen.org/feature/humanactivitymonitor
To guarantee that the pedometer application runs on a device with pedometer, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.pedometer
To guarantee that the wrist-up gesture recognition application runs on a device with wrist up, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.wrist_up
To guarantee that the gesture recognition application runs on a device with gesture recognition feature, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.gesture_recognition
To guarantee that the Heart Rate Monitor application runs on a device with heart rate monitor, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.heart_rate_monitor
To guarantee that the GPS batch information tracking application runs on a device with GPS batch feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/location.batch
To guarantee that the activity information tracking application runs on a device with activity recognition feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.activity_recognition
To guarantee that the human sleep state tracking application runs on a device with sleep monitor feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/sensor.sleep_monitor
To guarantee that the barometer (pressure) sensor application runs on a device with a barometric (pressure) sensor, declare the following feature requirement in the config file:

- http://tizen.org/feature/sensor.barometer

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module HumanActivityMonitor {
  enum HumanActivityType { "PEDOMETER", "HRM", "GPS", "SLEEP_MONITOR", "SLEEP_DETECTOR" };
  enum HumanActivityRecorderType { "PEDOMETER", "HRM", "SLEEP_MONITOR", "PRESSURE" };
  enum PedometerStepStatus { "NOT_MOVING", "WALKING", "RUNNING", "UNKNOWN" };
  enum SleepStatus { "ASLEEP", "AWAKE", "UNKNOWN" };
  dictionary HumanActivityRecorderOption {
    long interval;
    long retentionPeriod;
  };
  dictionary HumanActivityRecorderQuery {
    long startTime;
    long endTime;
    long anchorTime;
    long interval;
  };
  dictionary HumanActivityMonitorOption {
    long callbackInterval;
    long sampleInterval;
  };
  Tizen implements HumanActivityMonitorManagerObject;
  [NoInterfaceObject] interface HumanActivityMonitorManagerObject {
    readonly attribute HumanActivityMonitorManager humanactivitymonitor;
  };
  [NoInterfaceObject] interface HumanActivityMonitorManager {
    void getHumanActivityData(HumanActivityType type, HumanActivityMonitorSuccessCallback successCallback,
                              optional ErrorCallback? errorCallback) raises(WebAPIException);
    void start(HumanActivityType type, optional HumanActivityMonitorSuccessCallback? changedCallback,
               optional ErrorCallback? errorCallback, optional HumanActivityMonitorOption? option) raises(WebAPIException);
    void stop(HumanActivityType type) raises(WebAPIException);
    void setAccumulativePedometerListener(HumanActivityMonitorSuccessCallback changeCallback) raises(WebAPIException);
    void unsetAccumulativePedometerListener() raises(WebAPIException);
    void startRecorder(HumanActivityRecorderType type, optional HumanActivityRecorderOption option) raises(WebAPIException);
    void stopRecorder(HumanActivityRecorderType type) raises(WebAPIException);
    void readRecorderData(HumanActivityRecorderType type, HumanActivityRecorderQuery? query,
                          HumanActivityReadRecorderSuccessCallback successCallback, optional ErrorCallback? errorCallback)
                          raises(WebAPIException);
  };
  [NoInterfaceObject] interface StepDifference {
    readonly attribute long stepCountDifference;
    readonly attribute long timestamp;
  };
  [NoInterfaceObject] interface HumanActivityData {
  };
  [NoInterfaceObject] interface HumanActivityPedometerData : HumanActivityData {
    readonly attribute PedometerStepStatus stepStatus;
    readonly attribute double speed;
    readonly attribute double walkingFrequency;
    readonly attribute double cumulativeDistance;
    readonly attribute double cumulativeCalorie;
    readonly attribute double cumulativeTotalStepCount;
    readonly attribute double cumulativeWalkStepCount;
    readonly attribute double cumulativeRunStepCount;
    readonly attribute double accumulativeDistance;
    readonly attribute double accumulativeCalorie;
    readonly attribute double accumulativeTotalStepCount;
    readonly attribute double accumulativeWalkStepCount;
    readonly attribute double accumulativeRunStepCount;
    readonly attribute StepDifference[] stepCountDifferences;
  };
  [NoInterfaceObject] interface HumanActivityAccumulativePedometerData : HumanActivityData {
    readonly attribute PedometerStepStatus stepStatus;
    readonly attribute double speed;
    readonly attribute double walkingFrequency;
    readonly attribute double accumulativeDistance;
    readonly attribute double accumulativeCalorie;
    readonly attribute double accumulativeTotalStepCount;
    readonly attribute double accumulativeWalkStepCount;
    readonly attribute double accumulativeRunStepCount;
    readonly attribute StepDifference[] stepCountDifferences;
  };
  [NoInterfaceObject] interface HumanActivityHRMData : HumanActivityData {
    readonly attribute long heartRate;
    readonly attribute long rRInterval;
  };
  [NoInterfaceObject] interface HumanActivityGPSInfo {
    readonly attribute double latitude;
    readonly attribute double longitude;
    readonly attribute double altitude;
    readonly attribute double speed;
    readonly attribute long errorRange;
    readonly attribute long timestamp;
  };
  [NoInterfaceObject] interface HumanActivityGPSInfoArray : HumanActivityData {
    readonly attribute HumanActivityGPSInfo[] gpsInfo;
  };
  [NoInterfaceObject] interface HumanActivitySleepMonitorData : HumanActivityData {
    readonly attribute SleepStatus status;
    readonly attribute long long timestamp;
  };
  [NoInterfaceObject] interface HumanActivitySleepDetectorData : HumanActivityData {
    readonly attribute SleepStatus status;
  };
  [NoInterfaceObject] interface HumanActivityRecorderData {
    readonly attribute long startTime;
    readonly attribute long endTime;
  };
  [NoInterfaceObject] interface HumanActivityRecorderPedometerData : HumanActivityRecorderData {
    readonly attribute double distance;
    readonly attribute double calorie;
    readonly attribute double totalStepCount;
    readonly attribute double walkStepCount;
    readonly attribute double runStepCount;
  };
  [NoInterfaceObject] interface HumanActivityRecorderHRMData : HumanActivityRecorderData {
    readonly attribute long heartRate;
  };
  [NoInterfaceObject] interface HumanActivityRecorderSleepMonitorData : HumanActivityRecorderData {
    readonly attribute SleepStatus status;
  };
  [NoInterfaceObject] interface HumanActivityRecorderPressureData : HumanActivityRecorderData {
    readonly attribute double? max;
    readonly attribute double? min;
    readonly attribute double? average;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface HumanActivityMonitorSuccessCallback {
    void onsuccess(optional HumanActivityData? humanactivitydata);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface HumanActivityReadRecorderSuccessCallback {
    void onsuccess(HumanActivityRecorderData[] humanactivitydata);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
