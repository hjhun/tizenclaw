# MediaKey API

The Media Key API provides functions to get notified when a media key has been pressed or released.

Media keys are the keys of a Bluetooth headset which control multimedia playback.

For more information on the Media Key features, see Media Key Guide .

Since: 2.3

## Table of Contents

- 1. Type Definitions
- 1.1. MediaKeyType
- 2. Interfaces
- 2.1. MediaKeyManagerObject
- 2.2. MediaKeyManager
- 2.3. MediaKeyEventCallback
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| MediaKeyManagerObject |  |
| MediaKeyManager | void setMediaKeyEventListener ( MediaKeyEventCallback callback) void unsetMediaKeyEventListener () |
| MediaKeyEventCallback | void onpressed ( MediaKeyType type) void onreleased ( MediaKeyType type) |

## 1. Type Definitions

### 1.1. MediaKeyType

The available media keys

```webidl
  enum MediaKeyType { "MEDIA_PLAY", "MEDIA_STOP", "MEDIA_PAUSE", "MEDIA_PREVIOUS", "MEDIA_NEXT", "MEDIA_FAST_FORWARD", "MEDIA_REWIND",
    "MEDIA_PLAY_PAUSE" };
```

Since: 2.3

- MEDIA_PLAY - the Play media key
- MEDIA_STOP - the Stop media key
- MEDIA_PAUSE - the Pause media key
- MEDIA_PREVIOUS - the Previous media key
- MEDIA_NEXT - the Next media key
- MEDIA_FAST_FORWARD - the Fast Forward media key
- MEDIA_REWIND - the Rewind media key
- MEDIA_PLAY_PAUSE - the Play/Pause media key

## 2. Interfaces

### 2.1. MediaKeyManagerObject

The MediaKeyManagerObject interface defines what is instantiated in the tizen object.

```webidl
  [NoInterfaceObject] interface MediaKeyManagerObject {
    readonly attribute MediaKeyManager mediakey;
  };
```

```webidl
  Tizen implements MediaKeyManagerObject;
```

Since: 2.3

There is a tizen.mediakey object that allows accessing the functionality of the Media Key API.

#### Attributes

- readonly MediaKeyManager mediakey Object representing a media key manager.

Since: 2.3

### 2.2. MediaKeyManager

The MediaKeyManager interface provides the functionalities to get information about media key events.

```webidl
  [NoInterfaceObject] interface MediaKeyManager {
    void setMediaKeyEventListener(MediaKeyEventCallback callback) raises(WebAPIException);
    void unsetMediaKeyEventListener() raises(WebAPIException);
  };
```

Since: 2.3

#### Methods

`**setMediaKeyEventListener **`Registers a listener to be called when a media key is pressed or released.

```javascript
void setMediaKeyEventListener(MediaKeyEventCallback callback);
```

Since: 2.3

Parameters:

- **callback :
 Callback method to be invoked when a media key has been pressed or released. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if the input parameter is not compatible with the expected type.

- with error type UnknownError in any other error case.

Code example:

```javascript
tizen.mediakey.setMediaKeyEventListener({
  onpressed: function(key)
  {
    console.log("Pressed key: " + key);
  },
  onreleased: function(key)
  {
    console.log("Released key: " + key);
  }
});
```

`**unsetMediaKeyEventListener **`Unsubscribes from receiving notification for detecting the media key event.

```javascript
void unsetMediaKeyEventListener();
```

Since: 2.3

Calling this function has no effect if listener is not set.

Exceptions:

- WebAPIException
- with error type UnknownError in any other error case.

Code example:

```javascript
tizen.mediakey.unsetMediaKeyEventListener();
```

### 2.3. MediaKeyEventCallback

The MediaKeyEventCallback interface specifies a media key event callback for getting notified information about the media key events.

```webidl
  [Callback, NoInterfaceObject] interface MediaKeyEventCallback {
    void onpressed(MediaKeyType type);
    void onreleased(MediaKeyType type);
  };
```

Since: 2.3

#### Methods

`**onpressed **`Called when a media key has been pressed.

```javascript
void onpressed(MediaKeyType type);
```

Since: 2.3

Parameters:

- **type :
 The pressed media key. **

`**onreleased **`Called when a media key has been released.

```javascript
void onreleased(MediaKeyType type);
```

Since: 2.3

Parameters:

- **type :
 The released media key. **

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee that the Media Key application runs on a device with Bluetooth feature, declare the following feature requirements in the config file:

- http://tizen.org/feature/network.bluetooth.audio.media

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module MediaKey {
  enum MediaKeyType { "MEDIA_PLAY", "MEDIA_STOP", "MEDIA_PAUSE", "MEDIA_PREVIOUS", "MEDIA_NEXT", "MEDIA_FAST_FORWARD", "MEDIA_REWIND",
    "MEDIA_PLAY_PAUSE" };
  Tizen implements MediaKeyManagerObject;
  [NoInterfaceObject] interface MediaKeyManagerObject {
    readonly attribute MediaKeyManager mediakey;
  };
  [NoInterfaceObject] interface MediaKeyManager {
    void setMediaKeyEventListener(MediaKeyEventCallback callback) raises(WebAPIException);
    void unsetMediaKeyEventListener() raises(WebAPIException);
  };
  [Callback, NoInterfaceObject] interface MediaKeyEventCallback {
    void onpressed(MediaKeyType type);
    void onreleased(MediaKeyType type);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
