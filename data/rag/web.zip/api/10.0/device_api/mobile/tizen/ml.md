# MachineLearning API

Machine Learning features help you to handle Neural Network Frameworks (NNFWs), like TensorFlow and TensorFlow-Lite. The main features of the Machine Learning API include:

- Single API: useful for a simple usage scenario of neural network models. It allows invoking a neural network model with a single instance of input data for the model directly. For more information, see ML Single API .
- Pipeline API: useful for an advanced usage scenario of neural network models. It allows creating inference pipelines with multiple neural network models. For more information, see ML Pipeline API .
- Trainer API: useful for creating and training Machine Learning models locally on the device. For more information, see ML Trainer API .

Since: 6.5

## Table of Contents

- 1. Type Definitions
- 1.1. TensorType
- 1.2. HWType
- 1.3. NNFWType
- 1.4. Bytes
- 2. Interfaces
- 2.1. MachineLearningManagerObject
- 2.2. MachineLearningManager
- 2.3. TensorRawData
- 2.4. TensorsData
- 2.5. TensorsInfo
- 3. Related Feature
- 4. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| MachineLearningManagerObject |  |
| MachineLearningManager | boolean checkNNFWAvailability ( NNFWType nnfw, HWType hw, optional DOMString customRequirement) |
| TensorRawData |  |
| TensorsData | TensorRawData getTensorRawData (long index, optional long[] location, optional long[] size) void setTensorRawData (long index, Bytes buffer, optional long[] location, optional long[] size) void dispose () |
| TensorsInfo | long addTensorInfo (DOMString? name, TensorType type, long[] dimensions) TensorsInfo clone () boolean equals ( TensorsInfo other) long[] getDimensions (long index) DOMString getTensorName (long index) TensorsData getTensorsData () long getTensorSize (long index) TensorType getTensorType (long index) void setDimensions (long index, long[] dimensions) void setTensorName (long index, DOMString name) void setTensorType (long index, TensorType type) void dispose () |

## 1. Type Definitions

### 1.1. TensorType

Specifies type of Tensor.

```webidl
  enum TensorType { "INT8", "UINT8", "INT16", "UINT16", "FLOAT32", "INT32", "UINT32", "FLOAT64", "INT64", "UINT64", "UNKNOWN" };
```

Since: 6.5

- INT8 - 8-bit integer.
- UINT8 - 8-bit unsigned integer.
- INT16 - 16-bit integer.
- UINT16 - 16-bit unsigned integer.
- FLOAT32 - 32-bit float.
- INT32 - 32-bit integer.
- UINT32 - 32-bit unsigned integer.
- FLOAT64 - 64-bit float.
- INT64 - 64-bit integer.
- UINT64 - 64-bit unsigned integer.
- UNKNOWN - Unknown type.

### 1.2. HWType

Specifies type of hardware resources to be used for NNFWs.

```webidl
  enum HWType  { "ANY", "AUTO", "CPU", "CPU_NEON", "CPU_SIMD", "GPU", "NPU", "NPU_EDGE_TPU", "NPU_MOVIDIUS", "NPU_SLSI", "NPU_SR",
    "NPU_VIVANTE" };
```

Since: 6.5

Use checkNNFWAvailability() method to verify whether type is supported.

- ANY - Hardware resource is not specified.
- AUTO - Try to schedule and optimize if possible.
- CPU - Any CPU if possible.
- CPU_NEON - NEON in CPU.
- CPU_SIMD - SIMD in CPU if possible.
- GPU - Any GPU if possible.
- NPU - Any NPU if possible.
- NPU_EDGE_TPU - Google Coral Edge TPU (USB).
- NPU_MOVIDIUS - Intel Movidius Stick.
- NPU_SLSI - Samsung S.LSI.
- NPU_SR - Any SR (Samsung Research) made NPU.
- NPU_VIVANTE - VeriSilicon's Vivante.

### 1.3. NNFWType

Specifies type of Neural Network Framework.

```webidl
  enum NNFWType { "ANY", "ARM_NN", "CUSTOM_FILTER", "EDGE_TPU", "MVNC", "NNFW", "NNTR_INF", "OPEN_VINO", "PYTORCH", "SNAP", "SNPE",
    "TRIX_ENGINE", "TENSORFLOW", "TENSORFLOW_LITE", "VD_AIFW", "VIVANTE" };
```

Since: 6.5

Use checkNNFWAvailability() method to verify whether type is supported.

- ANY - NNFW is not specified (Try to determine the NNFW with file extension).
- ARM_NN - Arm Neural Network framework (support for caffe and TensorFlow-lite).
- CUSTOM_FILTER - Custom filter (Independent shared object).
- EDGE_TPU - Google Coral Edge TPU (USB).
- MVNC - Intel Movidius Neural Compute SDK (libmvnc).
- NNFW - Neural Network Inference Framework, which is developed by Samsung Research.
- NNTR_INF - Samsung Research On-device Training Framework (NNTrainer).
- OPEN_VINO - Intel OpenVINO.
- PYTORCH - PyTorch (.pt).
- SNAP - Samsung Neural Acceleration Platform
- SNPE - Qualcomm SNPE (Snapdragon Neural Processing Engine) (.dlc).
- TRIX_ENGINE - TRIxENGINE which accesses TRIV/TRIA NPU low-level drivers directly (.tvn). In some commercial products with TRIx NPU series, the low-level drivers might be not available to applications. In such cases, high-level drivers that wrap the low-level drivers will be provided (e.g. VD-AIFW).
- TENSORFLOW - TensorFlow (.pb).
- TENSORFLOW_LITE - TensorFlow-lite (.tflite).
- VD_AIFW - Inference framework for Samsung Tizen TV.
- VIVANTE - VeriSilicon's Vivante.

### 1.4. Bytes

The Bytes type aggregates byte types in ML API and is used to pass binary data. It can be either a *byte[] *or a *TypedArray *.

```webidl
  typedef (byte[] or TypedArray) Bytes;
```

Since: 6.5

## 2. Interfaces

### 2.1. MachineLearningManagerObject

The MachineLearningManagerObject interface defines what is instantiated by the *Tizen *object from the Tizen platform.

```webidl
  [NoInterfaceObject] interface MachineLearningManagerObject {
    readonly attribute MachineLearningManager ml;
  };
```

```webidl
  Tizen implements MachineLearningManagerObject;
```

Since: 6.5

The *tizen.ml *object allows access to the Machine Learning API.

#### Attributes

- readonly MachineLearningManager ml Object representing a machine learning manager.

Since: 6.5

### 2.2. MachineLearningManager

The MachineLearningManager entry interface provides methods to query the ML.

```webidl
  [NoInterfaceObject] interface MachineLearningManager {
    readonly attribute MachineLearningSingle single;
    readonly attribute MachineLearningPipeline pipeline;
    readonly attribute MachineLearningTrainer trainer;
    boolean checkNNFWAvailability(NNFWType nnfw, HWType hw, optional DOMString customRequirement) raises(WebAPIException);
  };
```

Since: 6.5

#### Attributes

- readonly MachineLearningSingle single Provides methods for Machine Learning Single Shot API .

Since: 6.5

- readonly MachineLearningPipeline pipeline Provides methods for Machine Learning Pipeline API .

Since: 6.5

- readonly MachineLearningTrainer trainer Provides methods for Machine Learning Trainer API .

Since: 6.5

#### Methods

`**checkNNFWAvailability **`Checks whether Neural Network Framework with provided configuration is supported.

```javascript
boolean checkNNFWAvailability(NNFWType nnfw, HWType hw, optional DOMString customRequirement);
```

Since: 6.5

Parameters:

- **nnfw :
 Neural Network Framework to check. Set "ANY" to skip checking *nnfw *. **
- **hw :
 Hardware resource to check. Set "ANY" to skip checking *hw *. **
- **customRequirement [optional] :
 Custom requirement for a more fine-grained filtering of NNFWs. It is only supported by some NNFWs and hardware types. **

Return value:

boolean: true if configuration is available, false otherwise.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var fw = "TENSORFLOW_LITE";
var hw = "CPU";
var available = tizen.ml.checkNNFWAvailability(fw, hw);
console.log(fw + " with " + hw + " is " + (available ? "" : "not ") + "supported");
```

Output example:

```
TENSORFLOW_LITE with CPU is supported
```

### 2.3. TensorRawData

TensorRawData interface provides information about raw data gathered from tensor.

```webidl
  [NoInterfaceObject] interface TensorRawData {
    readonly attribute TypedArray data;
    readonly attribute long size;
    readonly attribute long[] shape;
  };
```

Since: 6.5

#### Attributes

- readonly TypedArray data Raw tensor data. Array type inside TensorRawData is deduced by the type of the tensor.

| Tensor type | Returned array type |
| --- | --- |
| INT8 | Int8Array |
| UINT8 | UInt8Array |
| INT16 | Int16Array |
| UINT16 | UInt16Array |
| FLOAT32 | Float32Array |
| INT32 | Int32Array |
| UINT32 | Uint32Array |
| FLOAT64 | Float64Array |
| INT64 | BigInt64Array |
| UINT64 | BigUInt64Array |
| UNKNOWN | Uint8Array |

Since: 6.5

- readonly long size Size of returned data in bytes.

Since: 6.5

- readonly long[] shape Shape of raw tensor data - the length (number of elements) of each of the axes of a tensor.
Tensors with rank up to 4 are supported, so length of the shape array will be always 4 and axes not defined by user will be filled with 1.

Since: 6.5

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor", "UINT8", [2, 3]);
var tensorsData = tensorsInfo.getTensorsData();
var rawData = tensorsData.getTensorRawData(0);
console.log("Shape: " + rawData.shape);

/* Always call dispose() when you no longer need the objects */
tensorsData.dispose();
tensorsInfo.dispose();
```

Output example:

```
Shape: 2,3,1,1
```

### 2.4. TensorsData

The TensorsData interface sets and gets the buffer data for each Tensor.

```webidl
  [NoInterfaceObject] interface TensorsData {
    readonly attribute unsigned long count;
    readonly attribute TensorsInfo tensorsInfo raises(WebAPIException);
    TensorRawData getTensorRawData(long index, optional long[] location, optional long[] size) raises(WebAPIException);
    void setTensorRawData(long index, Bytes buffer, optional long[] location, optional long[] size) raises(WebAPIException);
    void dispose();
  };
```

Since: 6.5

#### Attributes

- readonly unsigned long count Number of tensors in TensorsData object.

Since: 6.5

- readonly TensorsInfo tensorsInfo Information about tensor.

Since: 6.5

Exceptions:

- WebAPIException
- with error type NotSupportedError, if this feature is not supported.

- with error type AbortError, if any other error occurs.

#### Methods

`**getTensorRawData **`Gets tensor data at a given index. Data location and size can be provided to limit returned buffer, otherwise whole tensor will be returned.

```javascript
TensorRawData getTensorRawData(long index, optional long[] location, optional long[] size);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **
- **location [optional] :
 The location of the data start point. Array length can be less than tensor rank, rest will have implicit 0 as starting position. **
- **size [optional] :
 The size of the data. Array length can be less than tensor rank, rest will have implicit -1. A value of -1 requests the rest of the data in selected dimension. **

Return value:

TensorRawData: Raw tensor data. Array type inside TensorRawData is deduced by the type of the tensor.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
Dimensions and location in Tizen ML API are explained as follows:

           /  0 1 2               0 1 2
          /   3 4 5               y 4 5
    dim3 /    6 7 8               6 7 8
        /     9 0 1               9 0 1
       /
      | 0 1 2               0 1 2
      | 3 4 5               3 4 5
 dim2 | 6 x 8               6 7 8
      | 9 0 1               9 0 1
        -----
        dim1
        ------------------------------
                    dim4

The order of axes is: [dim1, dim2, dim3, dim4], which means that the dimensions array of the tensor is equal to [3, 4, 2, 2].
Location of element marked as x is [1, 2, 0, 0] and location of y is [0, 1, 1, 1]
```

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor", "UINT8", [4, 4]);
var tensorsData = tensorsInfo.getTensorsData();
tensorsData.setTensorRawData(0, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
/* Data inside tensor: */
/*  0  1  2  3 */
/*  4  5  6  7 */
/*  8  9 10 11 */
/* 12 13 14 15 */

/* location [1, 0] means column 1 and row 0 - starting point is at element (1) */
/* size [3, 2] means 3 columns (elements in a row) and 2 rows (elements in a column) */
/* So return value should be equal to: */
/*  1  2  3 */
/*  4  5  6 */
var rawData1 = tensorsData.getTensorRawData(0, [1, 0], [3, 2]);
console.log(rawData1);

var rawData2 = tensorsData.getTensorRawData(0, [1, 0], [1, 1]);
console.log(rawData2);

/* Always call dispose() when you no longer need the objects */
tensorsData.dispose();
tensorsInfo.dispose();
```

Output example:

```
TensorRawData {data: Uint8Array(6), size: 6, shape: Array(4)}
  data: Uint8Array(6) [1, 2, 3, 5, 6, 7]
  shape: (4) [3, 2, 1, 1]
  size: 6
TensorRawData {data: Uint8Array(1), size: 1, shape: Array(4)}
  data: Uint8Array [1]
  shape: (4) [1, 1, 1, 1]
  size: 1
```

`**setTensorRawData **`Sets tensor data at a given index. Location and size of modified data can be provided.

```javascript
void setTensorRawData(long index, Bytes buffer, optional long[] location, optional long[] size);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **
- **buffer :
 Raw tensor data to be set. If *buffer *is too small or too big, InvalidValuesError will be thrown. **
- **location [optional] :
 The location of the data start point. Array length can be less than tensor rank, rest will have implicit 0 as starting position. **
- **size [optional] :
 The size of the data. Array length can be less than tensor rank, rest will have implicit -1. A value of -1 sets the rest of the data in selected dimension. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor", "UINT8", [3, 3]);
var tensorsData = tensorsInfo.getTensorsData();

/* Set whole tensor */
tensorsData.setTensorRawData(0, [0, 1, 2, 3, 4, 5, 6, 7, 8]);
var rawData1 = tensorsData.getTensorRawData(0);
console.log(rawData1.data);

/* Set only one value */
tensorsData.setTensorRawData(0, [13], [1, 1], [1, 1]);
var rawData2 = tensorsData.getTensorRawData(0);
console.log(rawData2.data);

/* Set only one value. No need for size parameter, because there is exactly */
/* one value needed in tensor from location [2,2] to the end of the tensor */
tensorsData.setTensorRawData(0, [22], [2, 2]);
var rawData3 = tensorsData.getTensorRawData(0);
console.log(rawData3.data);

/* Set all values in one dimension */
tensorsData.setTensorRawData(0, [10, 11, 12], [0, 1], [-1, 1]);
var rawData4 = tensorsData.getTensorRawData(0);
console.log(rawData4.data);

/* Always call dispose() when you no longer need the objects */
tensorsData.dispose();
tensorsInfo.dispose();
```

Output example:

```
Uint8Array(9) [0, 1, 2, 3, 4, 5, 6, 7, 8]
Uint8Array(9) [0, 1, 2, 3, 13, 5, 6, 7, 8]
Uint8Array(9) [0, 1, 2, 3, 13, 5, 6, 7, 22]
Uint8Array(9) [0, 1, 2, 10, 11, 12, 6, 7, 22]
```

`**dispose **`Disposes an object and releases the memory. Object should not be used after calling this method. Using diposed object will trigger AbortError .

```javascript
void dispose();
```

Since: 6.5

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor", "UINT8", [2, 2]);
var tensorsData = tensorsInfo.getTensorsData();
console.log(tensorsData.getTensorRawData(0));
tensorsData.dispose();
try
{
  console.log(tensorsData.getTensorRawData(0));
}
catch (e)
{
  console.log("Exception occurred: " + e.message);
}

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
TensorRawData {data: Uint8Array(4), size: 4, shape: Array(4)}
Exception occurred: TensorsData is disposed
```

### 2.5. TensorsInfo

The TensorsInfo interface manages tensor information such as name, type, and dimensions.

```webidl
  [Constructor() raises(WebAPIException)]
  interface TensorsInfo {
    readonly attribute unsigned long count;
    long addTensorInfo(DOMString? name, TensorType type, long[] dimensions) raises(WebAPIException);
    TensorsInfo clone() raises(WebAPIException);
    boolean equals(TensorsInfo other) raises(WebAPIException);
    long[] getDimensions(long index) raises(WebAPIException);
    DOMString getTensorName(long index) raises(WebAPIException);
    TensorsData getTensorsData() raises(WebAPIException);
    long getTensorSize(long index) raises(WebAPIException);
    TensorType getTensorType(long index) raises(WebAPIException);
    void setDimensions(long index, long[] dimensions) raises(WebAPIException);
    void setTensorName(long index, DOMString name) raises(WebAPIException);
    void setTensorType(long index, TensorType type) raises(WebAPIException);
    void dispose();
  };
```

Since: 6.5

#### Constructors

`**Constructor () **`Creates TensorsInfo object.

```webidl
TensorsInfo() raises(WebAPIException);
```

Exceptions:

- WebAPIException
- with error type AbortError, if any error occurs.

#### Attributes

- readonly unsigned long count Number of tensor information already added to object.

Since: 6.5

#### Methods

`**addTensorInfo **`Add a Tensor information to the TensorsInfo instance.

```javascript
long addTensorInfo(DOMString? name, TensorType type, long[] dimensions);
```

Since: 6.5

Remark: TensorsInfo object can hold information of up to 16 tensors. An attempt to add more tensors will trigger AbortError .

Parameters:

- **name [nullable] :
 Name of Tensor. **
- **type :
 Data element type of Tensor. **
- **dimensions :
 Array with tensor's dimensions. Each value determines number of elements in each dimension. The maximum supported rank is 4. Values on bigger indexes are discarded. In case, the dimensions length is less than 4, the remaining values are filled with 1. **

Return value:

long: index of newly added tensor.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
console.log("tensorsInfo.count: " + tensorsInfo.count);
tensorsInfo.addTensorInfo("tensor", "UINT8", [2, 2]);
console.log("tensorsInfo.count: " + tensorsInfo.count);

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
tensorsInfo.count: 0
tensorsInfo.count: 1
```

`**clone **`Clones a TensorsInfo object.

```javascript
TensorsInfo clone();
```

Since: 6.5

Return value:

TensorsInfo: Cloned object.

Exceptions:

- WebAPIException
- with error type AbortError, if any error occurs.

Code example:

```javascript
var t1 = new tizen.ml.TensorsInfo();
t1.addTensorInfo("tensor1", "UINT8", [1, 1]);
var t2 = t1.clone();

console.log("name: " + t1.getTensorName(0) + ", type: " + t1.getTensorType(0) + ", dimensions: " +
            t1.getDimensions(0));
console.log("name: " + t2.getTensorName(0) + ", type: " + t2.getTensorType(0) + ", dimensions: " +
            t2.getDimensions(0));

/* Always call dispose() when you no longer need the objects */
t2.dispose();
t1.dispose();
```

Output example:

```
name: tensor1, type: UINT8, dimensions: 1,1,1,1
name: tensor1, type: UINT8, dimensions: 1,1,1,1
```

`**equals **`Compares *object *with TensorsInfo and checks whether it has the same contents or not.
One TensorsInfo is equal to another when they both have the same type and dimensions.

```javascript
boolean equals(TensorsInfo other);
```

Since: 6.5

Parameters:

- **other :
 Object to compare. **

Return value:

boolean: true if the given object has the same contents, false otherwise.

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
var t1 = new tizen.ml.TensorsInfo();
t1.addTensorInfo("tensor1", "UINT8", [1, 1]);
var t2 = t1.clone();
console.log("Is t1 equal to t2: " + t1.equals(t2));
console.log("Changing name of first tensor in t2");
t2.setTensorName(0, "different");
console.log("Is t1 equal to t2: " + t1.equals(t2));
console.log("Changing type of first tensor in t2");
t2.setTensorType(0, "INT8");
console.log("Is t1 equal to t2: " + t1.equals(t2));

/* Always call dispose() when you no longer need the objects */
t2.dispose();
t1.dispose();
```

Output example:

```
Is t1 equal to t2: true
Changing name of first tensor in t2
Is t1 equal to t2: true
Changing type of first tensor in t2
Is t1 equal to t2: false
```

`**getDimensions **`Gets the dimensions of the tensor at a given index.

```javascript
long[] getDimensions(long index);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **

Return value:

long[]: Array with tensor's dimensions. Each value determines number of elements in each dimension.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
tensorsInfo.addTensorInfo("tensor2", "INT16", [4, 5, 3]);
console.log("Dimensions of first tensor in tensorsInfo: " + tensorsInfo.getDimensions(0));
console.log("Dimensions of second tensor in tensorsInfo: " + tensorsInfo.getDimensions(1));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Dimensions of first tensor in tensorsInfo: 2,2,1,1
Dimensions of second tensor in tensorsInfo: 4,5,3,1
```

`**getTensorName **`Gets the name of the tensor at a given index.

```javascript
DOMString getTensorName(long index);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **

Return value:

DOMString: The tensor name.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
tensorsInfo.addTensorInfo("tensor2", "INT16", [4, 5, 3]);
console.log("Name of first tensor in tensorsInfo: " + tensorsInfo.getTensorName(0));
console.log("Name of second tensor in tensorsInfo: " + tensorsInfo.getTensorName(1));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Name of first tensor in tensorsInfo: tensor1
Name of second tensor in tensorsInfo: tensor2
```

`**getTensorsData **`Creates a TensorsData instance based on information of TensorsInfo.
Each execution of this method creates a new TensorsData object.

```javascript
TensorsData getTensorsData();
```

Since: 6.5

Return value:

TensorsData: TensorsData instance.

Exceptions:

- WebAPIException
- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
/* 0 1 2 */
/* 3 4 5 */
/* 6 7 8 */
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor", "UINT8", [3, 3]);
var tensorsData = tensorsInfo.getTensorsData();
tensorsData.setTensorRawData(0, [0, 1, 2, 3, 4, 5, 6, 7, 8]);

console.log("Get whole tensor");
var rawData1 = tensorsData.getTensorRawData(0);
console.log("shape: " + rawData1.shape + " data: " + rawData1.data);

console.log("Get only one value");
var rawData2 = tensorsData.getTensorRawData(0, [1, 1], [1, 1]);
console.log("shape: " + rawData2.shape + " data: " + rawData2.data);

console.log("Get all values from location to the end of tensor");
var rawData3 = tensorsData.getTensorRawData(0, [1, 1]);
console.log("shape: " + rawData3.shape + " data: " + rawData3.data);

/* Here we start from the value (3) and request all values in first dimension (column counter) */
/* and only one value in second dimension (row counter), so we expect to get: */
/* 3 4 5 */
console.log("Get all values in one dimension");
var rawData4 = tensorsData.getTensorRawData(0, [0, 1], [-1, 1]);
console.log("shape: " + rawData4.shape + " data: " + rawData4.data);

/* Always call dispose() when you no longer need the objects */
tensorsData.dispose();
tensorsInfo.dispose();
```

Output example:

```
Get whole tensor
shape: 3,3,1,1 data: 0,1,2,3,4,5,6,7,8
Get only one value
shape: 1,1,1,1 data: 4
Get all values from location to the end of tensor
shape: 2,2,1,1 data: 4,5,7,8
Get all values in one dimension
shape: 3,1,1,1 data: 3,4,5
```

`**getTensorSize **`Calculates the byte size of tensor data.

```javascript
long getTensorSize(long index);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. If an application needs to get the total byte size of tensors, set the index to -1. **

Return value:

long: The byte size of tensor.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
tensorsInfo.addTensorInfo("tensor2", "INT16", [4, 5, 3]);
console.log("Size of first tensor in tensorsInfo: " + tensorsInfo.getTensorSize(0));
console.log("Size of second tensor in tensorsInfo: " + tensorsInfo.getTensorSize(1));
console.log("Total size of tensorsInfo: " + tensorsInfo.getTensorSize(-1));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Size of first tensor in tensorsInfo: 4
Size of second tensor in tensorsInfo: 120
Total size of tensorsInfo: 124
```

`**getTensorType **`Gets the type of the tensor at a given index.

```javascript
TensorType getTensorType(long index);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **

Return value:

TensorType: The tensor type.

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
tensorsInfo.addTensorInfo("tensor2", "INT16", [4, 5, 3]);
console.log("Type of first tensor in tensorsInfo: " + tensorsInfo.getTensorType(0));
console.log("Type of second tensor in tensorsInfo: " + tensorsInfo.getTensorType(1));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Type of first tensor in tensorsInfo: UINT8
Type of second tensor in tensorsInfo: INT16
```

`**setDimensions **`Sets the dimensions of the tensor at a given index.

```javascript
void setDimensions(long index, long[] dimensions);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **
- **dimensions :
 Array with tensor's dimensions to be set. Each value determines number of elements in each dimension. Valid array contains only positive numbers. The maximum supported rank is 4. Values on bigger indexes are discarded. In case, the dimensions length is less than 4, the remaining values are filled with 1. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
console.log("Dimensions of first tensor in tensorsInfo: " + tensorsInfo.getDimensions(0));
tensorsInfo.setDimensions(0, [4, 4, 4, 4]);
console.log("Dimensions after update: " + tensorsInfo.getDimensions(0));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Dimensions of first tensor in tensorsInfo: 2,2,1,1
Dimensions after update: 4,4,4,4
```

`**setTensorName **`Sets the name of the tensor at a given index.

```javascript
void setTensorName(long index, DOMString name);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **
- **name :
 The tensor name to be set. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
console.log("Name of first tensor in tensorsInfo: " + tensorsInfo.getTensorName(0));
tensorsInfo.setTensorName(0, "different_name");
console.log("Name after update: " + tensorsInfo.getTensorName(0));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Name of first tensor in tensorsInfo: tensor1
Name after update: different_name
```

`**setTensorType **`Sets the type of the tensor at a given index.

```javascript
void setTensorType(long index, TensorType type);
```

Since: 6.5

Parameters:

- **index :
 The index of the tensor. **
- **type :
 The tensor type to be set. **

Exceptions:

- WebAPIException
- with error type InvalidValuesError, if any of the input parameters contain an invalid value.

- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

- with error type NotSupportedError, if this feature is not supported, or given property is not available.

- with error type AbortError, if any other error occurs.

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor1", "UINT8", [2, 2]);
console.log("Type of first tensor in tensorsInfo: " + tensorsInfo.getTensorType(0));
tensorsInfo.setTensorType(0, "FLOAT32");
console.log("Type after update: " + tensorsInfo.getTensorType(0));

/* Always call dispose() when you no longer need the objects */
tensorsInfo.dispose();
```

Output example:

```
Type of first tensor in tensorsInfo: UINT8
Type after update: FLOAT32
```

`**dispose **`Disposes an object and releases the memory. Object should not be used after calling this method. Using diposed object will trigger AbortError .

```javascript
void dispose();
```

Since: 6.5

Code example:

```javascript
var tensorsInfo = new tizen.ml.TensorsInfo();
tensorsInfo.addTensorInfo("tensor", "UINT8", [2, 2]);
console.log("Name of first tensor in tensorsInfo: " + tensorsInfo.getTensorName(0));
tensorsInfo.dispose();
try
{
  console.log("Name of first tensor in tensorsInfo: " + tensorsInfo.getTensorName(0));
}
catch (e)
{
  console.log("Exception occurred: " + e.message);
}
```

Output example:

```
Name of first tensor in tensorsInfo: tensor
Exception occurred: TensorsInfo is disposed
```

## 3. Related Feature

Method tizen.systeminfo.getCapability() can be used in application runtime to check whether this API is supported. To guarantee the running of the application on a device which supports Machine Learning API feature, declare the following feature requirement in the config file:

- http://tizen.org/feature/machine_learning
To guarantee the running of the application on a device which supports Machine Learning Inference API feature, declare the following feature requirement in the config file:

- http://tizen.org/feature/machine_learning.inference
To guarantee the running of the application on a device which supports Machine Learning Trainer API feature, declare the following feature requirement in the config file:

- http://tizen.org/feature/machine_learning.training

For more information, see Application Filtering.
## 4. Full WebIDL

```webidl
module MachineLearning {
  typedef (byte[] or TypedArray) Bytes;
  enum TensorType { "INT8", "UINT8", "INT16", "UINT16", "FLOAT32", "INT32", "UINT32", "FLOAT64", "INT64", "UINT64", "UNKNOWN" };
  enum HWType  { "ANY", "AUTO", "CPU", "CPU_NEON", "CPU_SIMD", "GPU", "NPU", "NPU_EDGE_TPU", "NPU_MOVIDIUS", "NPU_SLSI", "NPU_SR",
    "NPU_VIVANTE" };
  enum NNFWType { "ANY", "ARM_NN", "CUSTOM_FILTER", "EDGE_TPU", "MVNC", "NNFW", "NNTR_INF", "OPEN_VINO", "PYTORCH", "SNAP", "SNPE",
    "TRIX_ENGINE", "TENSORFLOW", "TENSORFLOW_LITE", "VD_AIFW", "VIVANTE" };
  Tizen implements MachineLearningManagerObject;
  [NoInterfaceObject] interface MachineLearningManagerObject {
    readonly attribute MachineLearningManager ml;
  };
  [NoInterfaceObject] interface MachineLearningManager {
    readonly attribute MachineLearningSingle single;
    readonly attribute MachineLearningPipeline pipeline;
    readonly attribute MachineLearningTrainer trainer;
    boolean checkNNFWAvailability(NNFWType nnfw, HWType hw, optional DOMString customRequirement) raises(WebAPIException);
  };
  [NoInterfaceObject] interface TensorRawData {
    readonly attribute TypedArray data;
    readonly attribute long size;
    readonly attribute long[] shape;
  };
  [NoInterfaceObject] interface TensorsData {
    readonly attribute unsigned long count;
    readonly attribute TensorsInfo tensorsInfo raises(WebAPIException);
    TensorRawData getTensorRawData(long index, optional long[] location, optional long[] size) raises(WebAPIException);
    void setTensorRawData(long index, Bytes buffer, optional long[] location, optional long[] size) raises(WebAPIException);
    void dispose();
  };
  [Constructor() raises(WebAPIException)]
  interface TensorsInfo {
    readonly attribute unsigned long count;
    long addTensorInfo(DOMString? name, TensorType type, long[] dimensions) raises(WebAPIException);
    TensorsInfo clone() raises(WebAPIException);
    boolean equals(TensorsInfo other) raises(WebAPIException);
    long[] getDimensions(long index) raises(WebAPIException);
    DOMString getTensorName(long index) raises(WebAPIException);
    TensorsData getTensorsData() raises(WebAPIException);
    long getTensorSize(long index) raises(WebAPIException);
    TensorType getTensorType(long index) raises(WebAPIException);
    void setDimensions(long index, long[] dimensions) raises(WebAPIException);
    void setTensorName(long index, DOMString name) raises(WebAPIException);
    void setTensorType(long index, TensorType type) raises(WebAPIException);
    void dispose();
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
