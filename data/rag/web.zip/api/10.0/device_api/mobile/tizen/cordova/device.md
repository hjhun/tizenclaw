# Device API

This plugin defines a global device object, which describes the device's hardware and software.
Although the object is in the global scope, it is not available until the deviceready event.

Original documentation: Cordova Device .

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. DeviceManagerObject
- 1.2. Device
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| DeviceManagerObject |  |
| Device |  |

## 1. Interfaces

### 1.1. DeviceManagerObject

The *window.device *object allows access to the functionality of the Device API.

```webidl
  [NoInterfaceObject] interface DeviceManagerObject {
    readonly attribute Device device;
  };
```

```webidl
  Window implements DeviceManagerObject;
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 1.2. Device

The device object describes the device's hardware and software.

```webidl
  [NoInterfaceObject] interface Device {
    readonly attribute DOMString cordova;
    readonly attribute DOMString model;
    readonly attribute DOMString platform;
    readonly attribute DOMString uuid;
    readonly attribute DOMString version;
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Attributes

- readonly DOMString cordova Returns the version of Cordova running on the device.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  console.log("Device Cordova: " + device.cordova);
}
```

Output example:

```
Device Cordova: 5.1.1
```

- readonly DOMString model Get the the name of the device's model or product. The value is set by the device manufacturer and may be different across versions of the same product.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  console.log("Device Model: " + device.model);
}
```

Output example:

```
Device Model: tm1
```

- readonly DOMString platform Get the device's operating system name.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  console.log("Device Platform: " + device.platform);
}
```

Output example:

```
Device Platform: Tizen
```

- readonly DOMString uuid Get the device's Universally Unique Identifier (UUID). The details of how a UUID is generated are determined by the device manufacturer and are specific to the device's platform or model.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  console.log("Device UUID: " + device.uuid);
}
```

Output example:

```
Device UUID: 2LR1b3MXfEUSFvH04m4e1EXYvQA=
```

- readonly DOMString version Get the operating system version.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Code example:

```javascript
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady()
{
  console.log("Device Version: " + device.version);
}
```

Output example:

```
Device Version: 3.0
```

## 2. Full WebIDL

```webidl
module Device {
  Window implements DeviceManagerObject;
  [NoInterfaceObject] interface DeviceManagerObject {
    readonly attribute Device device;
  };
  [NoInterfaceObject] interface Device {
    readonly attribute DOMString cordova;
    readonly attribute DOMString model;
    readonly attribute DOMString platform;
    readonly attribute DOMString uuid;
    readonly attribute DOMString version;
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
