# Globalization API

This plugin obtains information and performs operations specific to the user's locale,
language, and timezone. Note the difference between locale and language: locale controls how numbers,
dates, and times are displayed for a region, while language determines what language text appears as,
independently of locale settings. Often developers use locale to set both settings, but there is no reason
a user couldn't set her language to "English" but locale to "French", so that text is displayed in English
but dates, times, etc., are displayed as they are in France. Unfortunately, most mobile platforms
currently do not make a distinction between these settings.

Original documentation: Cordova Globalization

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. GlobalizationManagerObject
- 1.2. GlobalizationManager
- 1.3. DateOptions
- 1.4. CurrencyPattern
- 1.5. GetDateNamesOptions
- 1.6. NumberPatternOptions
- 1.7. DatePattern
- 1.8. NumberPattern
- 1.9. GlobalizationDate
- 1.10. DSTSuccessCallback
- 1.11. StringSuccessCallback
- 1.12. ArrayStringSuccessCallback
- 1.13. LongSuccessCallback
- 1.14. DoubleSuccessCallback
- 1.15. GlobalizationDateSuccessCallback
- 1.16. PatternSuccessCallback
- 1.17. GetDatePatternSuccessCallback
- 1.18. GetNumberPatternSuccessCallback
- 1.19. GlobalizationError
- 1.20. ErrorCallback
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| GlobalizationManagerObject |  |
| GlobalizationManager | void getPreferredLanguage ( StringSuccessCallback onsuccess, ErrorCallback onerror) void getLocaleName ( StringSuccessCallback onsuccess, ErrorCallback onerror) void dateToString (Date date, StringSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options) void getCurrencyPattern (DOMString currencyCode, PatternSuccessCallback onsuccess, ErrorCallback onerror) void getDateNames ( ArrayStringSuccessCallback onsuccess, ErrorCallback onerror, optional GetDateNamesOptions options) void getDatePattern ( GetDatePatternSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options) void getFirstDayOfWeek ( LongSuccessCallback onsuccess, ErrorCallback onerror) void getNumberPattern ( GetNumberPatternSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options) void isDayLightSavingsTime (Date date, DSTSuccessCallback onsuccess, ErrorCallback onerror) void numberToString (double number, StringSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options) void stringToDate (DOMString dateString, GlobalizationDateSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options) void stringToNumber (DOMString numberString, DoubleSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options) |
| DateOptions |  |
| CurrencyPattern |  |
| GetDateNamesOptions |  |
| NumberPatternOptions |  |
| DatePattern |  |
| NumberPattern |  |
| GlobalizationDate |  |
| DSTSuccessCallback | void onsuccess (object properties) |
| StringSuccessCallback | void onsuccess (object properties) |
| ArrayStringSuccessCallback | void onsuccess (object properties) |
| LongSuccessCallback | void onsuccess (object properties) |
| DoubleSuccessCallback | void onsuccess (object properties) |
| GlobalizationDateSuccessCallback | void onsuccess (Date date) |
| PatternSuccessCallback | void onsuccess ( CurrencyPattern pattern) |
| GetDatePatternSuccessCallback | void onsuccess ( DatePattern pattern) |
| GetNumberPatternSuccessCallback | void onsuccess ( NumberPattern pattern) |
| GlobalizationError |  |
| ErrorCallback | void onerror ( DOMException error) |

## 1. Interfaces

### 1.1. GlobalizationManagerObject

The GlobalizationManagerObject interface.

```webidl
  [NoInterfaceObject] interface GlobalizationManagerObject {
    readonly attribute GlobalizationManager globalization;
  };
```

```webidl
  Navigator implements GlobalizationManagerObject;
```

Since: 3.0

### 1.2. GlobalizationManager

The GlobalizationManager interface embodies Globalization module methods.

```webidl
  [NoInterfaceObject] interface GlobalizationManager {
    void getPreferredLanguage(StringSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void getLocaleName(StringSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void dateToString(Date date, StringSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options)
                      raises(TypeError);
    void getCurrencyPattern(DOMString currencyCode, PatternSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void getDateNames(ArrayStringSuccessCallback onsuccess, ErrorCallback onerror, optional GetDateNamesOptions options)
                      raises(TypeError);
    void getDatePattern(GetDatePatternSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options)
                        raises(TypeError);
    void getFirstDayOfWeek(LongSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void getNumberPattern(GetNumberPatternSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options)
                          raises(TypeError);
    void isDayLightSavingsTime(Date date, DSTSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void numberToString(double number, StringSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options)
                        raises(TypeError);
    void stringToDate(DOMString dateString, GlobalizationDateSuccessCallback onsuccess, ErrorCallback onerror,
                      optional DateOptions options) raises(TypeError);
    void stringToNumber(DOMString numberString, DoubleSuccessCallback onsuccess, ErrorCallback onerror,
                        optional NumberPatternOptions options) raises(TypeError);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**getPreferredLanguage **`Gets the BCP 47 language tag for the client's current language.

```javascript
void getPreferredLanguage(StringSuccessCallback onsuccess, ErrorCallback onerror);
```

Since: 3.0

Returns the BCP-47 compliant language identifier tag to the successCallback
with a properties object as a parameter. That object should have a value property
with a String value.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 The callback method to be invoked if the preferred language
is obtained successfully. **
- **onerror :
 The callback method called when errors occur
during this method's execution. **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en-US language, */
/* this outputs the text similar to the results that follow. */

navigator.globalization.getPreferredLanguage(
    function(language)
    {
      console.log("Language: " + language.value);
    },
    function()
    {
      console.log("Error getting language");
    });
```

Output example:

```
Language: en-US
```

`**getLocaleName **`Returns the BCP 47 compliant tag for the client's current locale settings.

```javascript
void getLocaleName(StringSuccessCallback onsuccess, ErrorCallback onerror);
```

Since: 3.0

Returns the BCP 47 compliant locale identifier string to the successCallback
with a properties object as a parameter. That object should have a value
property with a String value. The locale tag will consist of a two-letter
lower case language code, two-letter upper case country code, and (unspecified)
variant code, separated by a hyphen.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 The callback function called when the locale name
has been obtained successfully. **
- **onerror :
 The callback method invoked in case of errors
occuring while getting a locale name. **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en-US language, */
/* this outputs the text similar to the results that follow. */

navigator.globalization.getLocaleName(
    function(locale)
    {
      console.log("Locale: " + locale.value);
    },
    function()
    {
      console.log("Error getting locale");
    });
```

Output example:

```
Locale: en-US
```

`**dateToString **`Returns a date formatted as a string according to the client's locale and timezone.

```javascript
void dateToString(Date date, StringSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options);
```

Since: 3.0

Returns the date formatted as a String via a value property accessible from the object
passed as a parameter to the successCallback.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **date :
 The date to be converted to a DOMString. It should be of type Date. **
- **onsuccess :
 The callback method called after a successful conversion. **
- **onerror :
 The callback method called if errors occur during conversion. **
- **options [optional] :
 Optional parameter defining conversion options. The default values are: {formatLength : "short", selector : "date and time"} . **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en-US language, */
/* this should output text similar to the results that follow. */
/* This example uses the default conversion options. */

navigator.globalization.dateToString(new Date(),
    function(date)
    {
      console.log("Date: " + date.value);
    },
    function()
    {
      console.log("Error getting dateString");
    },
    {formatLength: "short", selector: "date and time"});
```

Output example:

```
Date: 9/25/2012 4:21PM
```

`**getCurrencyPattern **`Returns a pattern string to format and parse currency values according to
the client's user preferences and ISO 4217 currency code.

```javascript
void getCurrencyPattern(DOMString currencyCode, PatternSuccessCallback onsuccess, ErrorCallback onerror);
```

Since: 3.0

The pattern information is returned in the onsuccess callback with pattern object
as a parameter.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **currencyCode :
 ISO 4217 compliant currency code provided as a DOMString,
for example "USD". **
- **onsuccess :
 The callback method invoked after a successful conversion. **
- **onerror :
 The callback method called if errors occur during the conversion. **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en-US language and the selected */
/* currency is United States dollars, this outputs */
/* the text similar to the results that follow. */

navigator.globalization.getCurrencyPattern("USD",
    function(pattern)
    {
      console.log("pattern: " + pattern.pattern);
      console.log("code: " + pattern.code);
      console.log("fraction: " + pattern.fraction);
      console.log("rounding: " + pattern.rounding);
      console.log("decimal: " + pattern.decimal);
      console.log("grouping: " + pattern.grouping);
    },
    function()
    {
      console.log("Error getting pattern");
    });
```

Output example:

```
pattern: $#,##0.##;($#,##0.##)
code: USD
fraction: 2
rounding: 0
decimal: .
grouping: ,
```

`**getDateNames **`Returns an array of the names of the months or the days of the week,
depending on the client's user preferences and calendar.

```javascript
void getDateNames(ArrayStringSuccessCallback onsuccess, ErrorCallback onerror, optional GetDateNamesOptions options);
```

Since: 3.0

If this method executes successfully, it invokes the onsuccess callback
with months' or days' names passed as an Array of DOMString values
in a parameter. This array features names starting from either
the first month in the year or the first day of the week
depending on the option selected.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 The function to be called if this method returns the names correctly. **
- **onerror :
 The function to be called in case of error occuring. **
- **options [optional] :
 An optional parameter specifying additional options.
The default value is {type: "wide", item: "months"} **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en_US language, */
/* this example logs the names of months, as per locale settings */
/* with text similar to the results that follow. */

navigator.globalization.getDateNames(
    function(names)
    {
      for (var i = 0; i < names.value.length; i++)
      {
        console.log("month: " + names.value[i]);
      }
    },
    function()
    {
      console.log("Error getting names");
    },
    {type: "wide", item: "months"});
```

Output example:

```
month: January
month: February
month: March
month: April
month: May
month: June
month: July
month: August
month: September
month: October
month: November
month: December
```

`**getDatePattern **`Gets a pattern string to format and parse dates according to the client's
user preferences.

```javascript
void getDatePattern(GetDatePatternSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options);
```

Since: 3.0

If this method executes successfully, the onsuccess callback is invoked
with a DatePattern object passed as a parameter.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 The method to be invoked when this function executes successfully. **
- **onerror :
 The function to be invoked in case of errors occuring. **
- **options [optional] :
 The DateOptions object containing additional options.
The default value is {formatLength: "short", selector: "date and time"} . **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* This example displays the locale date pattern. */
/* When the browser is set to the en-US locale, */
/* this outputs the text similar to the results that follow. */

function checkDatePattern()
{
  navigator.globalization.getDatePattern(
      function(date)
      {
        console.log("Date pattern: " + date.pattern);
      },
      function()
      {
        console.log("Error getting pattern");
      },
      {formatLength: "short", selector: "date and time"});
}

checkDatePattern();
```

Output example:

```
Date pattern: M/d/yyyy h:mm a
```

`**getFirstDayOfWeek **`Gets the first day of the week according to the client's
user preferences and calendar.

```javascript
void getFirstDayOfWeek(LongSuccessCallback onsuccess, ErrorCallback onerror);
```

Since: 3.0

The days of the week are numbered starting from 1, where 1 is assumed to be Sunday.
If successful, it invokes onsuccess callback with a LongSuccessCallback object
as a parameter. That object has a value property representing the number of
the first day of a week.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 The method to be called when this function executes successfully. **
- **onerror :
 The method to be invoked in case of errors occuring. **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en_US locale, */
/* this outputs the text similar to "day: 1". */

navigator.globalization.getFirstDayOfWeek(
    function(day)
    {
      console.log("Day: " + day.value);
    },
    function()
    {
      console.log("Error getting first day of week");
    });
```

Output example:

```
Day: 1
```

`**getNumberPattern **`Gets a pattern string to format and parse numbers
according to the client's user preferences.

```javascript
void getNumberPattern(GetNumberPatternSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options);
```

Since: 3.0

The obtained pattern is then passed to the onsuccess callback
as a parameter.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **onsuccess :
 The callback method to be invoked
when this function executes successfully. **
- **onerror :
 The callback method to be invoked
in case of errors occuring during this method's execution. **
- **options [optional] :
 Defines the type of numeric value for which
the pattern will be returned. **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en_US locale, */
/* this example outputs the text similar to the results that follow. */

navigator.globalization.getNumberPattern(
    function(pattern)
    {
      console.log("pattern: " + pattern.pattern);
      console.log("symbol: " + pattern.symbol);
      console.log("fraction: " + pattern.fraction);
      console.log("rounding: " + pattern.rounding);
      console.log("positive: " + pattern.positive);
      console.log("negative: " + pattern.negative);
      console.log("decimal: " + pattern.decimal);
      console.log("grouping: " + pattern.grouping);
    },
    function()
    {
      console.log("An error occurred");
    },
    {type: "decimal"});
```

Output example:

```
pattern: #,##0.###
symbol: .
fraction: 0
rounding: 0
positive:
negative: -
decimal: .
grouping: ,
```

`**isDayLightSavingsTime **`Indicates whether or not daylight savings time is in effect
for a given date using the client's time zone and calendar.

```javascript
void isDayLightSavingsTime(Date date, DSTSuccessCallback onsuccess, ErrorCallback onerror);
```

Since: 3.0

If this function executes successfully, the onsuccess callback
will be invoked with a dstStatus object as a parameter. That object
would contain a dst property with a Boolean value. The true value
indicates that the DST is in effect for the given date.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **date :
 The Date object for which the daylight savings time status will be checked. **
- **onsuccess :
 The callback method to be called when this function
successfully completes its execution. **
- **onerror :
 The callback method to be called in case of
errors occuring during this method's execution. **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* During the summer, and if the browser is set to a DST-enabled timezone, */
/* this logs text similar to "dst: true". */

navigator.globalization.isDayLightSavingsTime(new Date(),
    function(date)
    {
      console.log("dst: " + date.dst);
    },
    function()
    {
      console.log("Error getting the DST state");
    });
```

Output example:

```
dst: true
```

`**numberToString **`Returns a number formatted as a string
according to the client's user preferences.

```javascript
void numberToString(double number, StringSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options);
```

Since: 3.0

The formatted number string is returned by onsuccess callback with
a properties object as a parameter. That object contains a property value
of DOMString type containing the result of the conversion.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **number :
 The number that will be converted to a DOMString
in accordance with the client's user preferences. **
- **onsuccess :
 The callback function executed when the conversion
is done successfully. The results of the conversion are passed
as a parameter to this callback function. **
- **onerror :
 The callback function executed in case of errors
occuring during the conversion. The GlobalizationError object with
the details is passed as a parameter to this callback function. **
- **options [optional] :
 Additional options specifying the details of conversion.
It is a dictionary with a single property type .
The default value of this parameter is {type: "decimal"} . **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en_US locale, */
/* this code displays the results that follow. */

navigator.globalization.numberToString(3.1415926,
    function(number)
    {
      console.log("Decimal number: " + number.value);
    },
    function()
    {
      console.log("Error getting number");
    },
    {type: "decimal"});

navigator.globalization.numberToString(1000003,
    function(number)
    {
      console.log("Big decimal number: " + number.value);
    },
    function()
    {
      console.log("Error getting number");
    },
    {type: "decimal"});

navigator.globalization.numberToString(0.3183099,
    function(number)
    {
      console.log("Percentile: " + number.value);
    },
    function()
    {
      console.log("Error getting number");
    },
    {type: "percent"});

navigator.globalization.numberToString(1099.95,
    function(number)
    {
      console.log("Currency: " + number.value);
    },
    function()
    {
      console.log("Error getting number");
    },
    {type: "currency"});
```

Output example:

```
Decimal number: 3.142
Big decimal number: 1,000,003
Percentile: 32%
Currency: $1,099.95
```

`**stringToDate **`Parses a date formatted as a DOMString according to the client's
user preferences and calendar using the time zone of the client.
Returns the corresponding date object.

```javascript
void stringToDate(DOMString dateString, GlobalizationDateSuccessCallback onsuccess, ErrorCallback onerror,
                  optional DateOptions options);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **dateString :
 a string containing the representation of a date to be converted
to a Date object. **
- **onsuccess :
 The callback method invoked when the conversion completes successfully.
The result of conversion is passed as a parameter to this callback. **
- **onerror :
 The callback method invoked in case of errors occuring during
the conversion. A GlobalizationError object is passed as a parameter
to this callback. **
- **options [optional] :
 Additional options specifying the details of the conversion.
The default value is {formatLength: "short", selector: "date and time"} . **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* when the browser is set to the en_US locale, */
/* this example outputs text similar to the results that follow. */
/* Note that the month integer is one less than the string, */
/* as the month integer represents an array index. */

navigator.globalization.stringToDate("9/25/2012",
    function(date)
    {
      console.log("month: " + date.month + ", day: " + date.day + ", year: " + date.year);
    },
    function()
    {
      console.log("Error getting date");
    },
    {selector: "date"});
```

Output example:

```
month: 8, day: 25, year: 2012
```

`**stringToNumber **`Parses a number formatted as a string according to the client's
user preferences and returns the corresponding number.

```javascript
void stringToNumber(DOMString numberString, DoubleSuccessCallback onsuccess, ErrorCallback onerror,
                    optional NumberPatternOptions options);
```

Since: 3.0

If successful, the result of the conversion is passed as a parameter to the onsuccess
callback method.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **numberString :
 The DOMString containing a text representation of a number
to be converted to a double data type. **
- **onsuccess :
 The callback method called after a successful conversion.
The result of a conversion is passed as a parameter of this callback method. **
- **onerror :
 The callback method invoked in case of errors occuring during
the conversion. The error is passed as a parameter of this callback method. **
- **options [optional] :
 Additional options specifying the details of the conversion.
The default value is {type: "decimal"} **

Exceptions:

- TypeError
- if any of the input parameters contains an invalid value.

Code example:

```javascript
/* When the browser is set to the en_US locale, */
/* this displays the text similar to the results that follow. */

navigator.globalization.stringToNumber("1234.56",
    function(number)
    {
      console.log("Number: " + number.value);
    },
    function()
    {
      console.log("Error getting number");
    },
    {type: "decimal"});
```

Output example:

```
Number: 1234.56
```

### 1.3. DateOptions

DateOptions is a dictionary containing options for date conversions.

```webidl
  dictionary DateOptions {
    DOMString formatLength;
    DOMString selector;
  };
```

Since: 3.0

#### Dictionary members

DOMString formatLength Indicates the length of DOMString representation of the date.

Valid values are:

- "short"
- "medium"
- "long"
- "full"

Since: 3.0

DOMString selector Indicates the selector for DOMString representation of the date.

Valid values are:

- "date"
- "time"
- "date and time"

Since: 3.0

### 1.4. CurrencyPattern

CurrencyPattern is a dictionary containing currency formatting properties.

```webidl
  dictionary CurrencyPattern {
    DOMString pattern;
    DOMString code;
    long fraction;
    double rounding;
    DOMString decimal;
    DOMString grouping;
  };
```

Since: 3.0

#### Dictionary members

DOMString pattern The currency pattern to format and parse the currency values.
The patterns follow Unicode Technical Standard #35.

Since: 3.0

DOMString code The ISO 4217 currency code for the pattern.

Since: 3.0

long fraction The number of fractional digits to use when parsing and formatting currency.

Since: 3.0

double rounding The rounding increment to use when parsing and formatting.

Since: 3.0

DOMString decimal The decimal symbol to use for parsing and formatting.

Since: 3.0

DOMString grouping The grouping symbol to use for parsing and formatting.

Since: 3.0

### 1.5. GetDateNamesOptions

The GetDateNamesOptions dictionary contains options used in getDateNames method.

```webidl
  dictionary GetDateNamesOptions {
    DOMString type;
    DOMString item;
  };
```

Since: 3.0

#### Dictionary members

DOMString type Determines whether to use abbreviated (narrow) or full-length (wide) names.

The following values are valid:

- "narrow" - Abbreviated names will be returned.
- "wide" - Full names will be returned.

Since: 3.0

DOMString item Determines whether to return the names of months or the names of days.

The following values are valid:

- "months" - The names of months will be returned.
- "days" - The names of days of the week will be returned.

Since: 3.0

### 1.6. NumberPatternOptions

The NumberPatternOptions dictionary contains options
used in handling numerical locale settings.

```webidl
  dictionary NumberPatternOptions {
    DOMString type;
  };
```

Since: 3.0

#### Dictionary members

DOMString type The type determines the genus of numeric value,
for which the pattern will be extracted.

The following values are valid:

- "decimal" - Indicates that the pattern for the
decimal numbers should be extracted.
- "percent" - Indicates that the pattern for the
percents should be extracted.
- "currency" - Indicates that the pattern for the
currency values should be extracted.

Since: 3.0

### 1.7. DatePattern

The DatePattern dictionary contains the information obtained in getDatePattern method.

```webidl
  dictionary DatePattern {
    DOMString pattern;
    DOMString timezone;
    long utc_offset;
    long dst_offset;
  };
```

Since: 3.0

#### Dictionary members

DOMString pattern The date and time pattern to format and parse dates.
The patterns follow Unicode Technical Standard #35.

Since: 3.0

DOMString timezone The abbreviated name of the time zone on client's device.

Since: 3.0

long utc_offset The current difference in seconds between the client's time zone
and coordinated universal time.

Since: 3.0

long dst_offset The current daylight saving time offset in seconds between the client's
non-daylight saving time zone and the client's daylight saving time zone.

Since: 3.0

### 1.8. NumberPattern

The NumberPattern dictionary contains the information obtained
by calling the getNumberPattern method.

```webidl
  dictionary NumberPattern {
    DOMString pattern;
    DOMString symbol;
    long fraction;
    double rounding;
    DOMString positive;
    DOMString negative;
    DOMString decimal;
    DOMString grouping;
  };
```

Since: 3.0

#### Dictionary members

DOMString pattern The number pattern to format and parse numbers.
The patterns follow Unicode Technical Standard #35.

Since: 3.0

DOMString symbol The symbol to use when formatting and parsing,
such as percent or currency symbol.

Since: 3.0

long fraction The number of fractional digits to use
when parsing and formatting.

Since: 3.0

double rounding The rounding increment to use when parsing and formatting.

Since: 3.0

DOMString positive The symbol to use for positive numbers
when parsing and formatting.

Since: 3.0

DOMString negative The symbol to use for negative numbers
when parsing and formatting.

Since: 3.0

DOMString decimal The decimal symbol to use for parsing and formatting.

Since: 3.0

DOMString grouping The grouping symbol to use for parsing and formatting.

Since: 3.0

### 1.9. GlobalizationDate

The GlobalizationDate dictionary represents a point in time,
similar to a Date object in javascript.

```webidl
  dictionary GlobalizationDate {
    long year;
    long month;
    long day;
    long hour;
    long minute;
    long second;
    long millisecond;
  };
```

Since: 3.0

#### Dictionary members

long year The four digit year.

Since: 3.0

long month The month index in range (0, 11) inclusively.

Since: 3.0

long day The day of month in range (1, 31) inclusively.

Since: 3.0

long hour The hour in range (0, 23) inclusively.

Since: 3.0

long minute The minute in range (0, 59) inclusively.

Since: 3.0

long second The second in range (0, 59) inclusively.

Since: 3.0

long millisecond The milliseconds in range (0, 999) inclusively.

Since: 3.0

### 1.10. DSTSuccessCallback

A callback method invoked on successful extraction
of Daylight Saving Time data.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DSTSuccessCallback {
    void onsuccess(object properties);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns the DST data successfully.

```javascript
void onsuccess(object properties);
```

Since: 3.0

Parameters:

- **properties :
 An object containing the field "dst" of boolean type. **

### 1.11. StringSuccessCallback

A callback method invoked on successful extraction of
a data encoded as a DOMString.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface StringSuccessCallback {
    void onsuccess(object properties);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns the properties object with data successfully.

```javascript
void onsuccess(object properties);
```

Since: 3.0

Parameters:

- **properties :
 An object containing the field "value" of a DOMString type. **

### 1.12. ArrayStringSuccessCallback

The callback method invoked on successful extraction of
the data represented as an array of DOMString values.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ArrayStringSuccessCallback {
    void onsuccess(object properties);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns the array of DOMString values successfully.

```javascript
void onsuccess(object properties);
```

Since: 3.0

Parameters:

- **properties :
 an object with the field "value"
containing an Array of DOMString values. **

### 1.13. LongSuccessCallback

The callback method invoked on successful extraction
of the data represented as a long integer value.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface LongSuccessCallback {
    void onsuccess(object properties);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns a numeric (long) data successfully.

```javascript
void onsuccess(object properties);
```

Since: 3.0

Parameters:

- **properties :
 An object containing the field "value" of a long type. **

### 1.14. DoubleSuccessCallback

The callback method invoked on successful extraction
of the data represented as a double precision numeric value.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface DoubleSuccessCallback {
    void onsuccess(object properties);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns a numeric (double) data successfully.

```javascript
void onsuccess(object properties);
```

Since: 3.0

Parameters:

- **properties :
 An object containing the field "value" of a double type. **

### 1.15. GlobalizationDateSuccessCallback

The callback method invoked on successful extraction
of the GlobalizationDate object.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface GlobalizationDateSuccessCallback {
    void onsuccess(Date date);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns a GlobalizationDate object successfully.

```javascript
void onsuccess(Date date);
```

Since: 3.0

Parameters:

- **date :
 a GlobalizationDate object containing the date information. **

### 1.16. PatternSuccessCallback

The callback method invoked on successful extraction
of a CurrencyPattern object.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface PatternSuccessCallback {
    void onsuccess(CurrencyPattern pattern);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns the currency pattern information successfully.

```javascript
void onsuccess(CurrencyPattern pattern);
```

Since: 3.0

Parameters:

- **pattern :
 a CurrencyPattern object containing retrieved information. **

### 1.17. GetDatePatternSuccessCallback

The callback method invoked on succesful extraction
of a DatePattern object.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface GetDatePatternSuccessCallback {
    void onsuccess(DatePattern pattern);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns the date pattern information successfully.

```javascript
void onsuccess(DatePattern pattern);
```

Since: 3.0

Parameters:

- **pattern :
 a DatePattern object containing retrieved information. **

### 1.18. GetNumberPatternSuccessCallback

The callback method invoked on successful extraction
of a NumberPattern object.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface GetNumberPatternSuccessCallback {
    void onsuccess(NumberPattern pattern);
  };
```

Since: 3.0

#### Methods

`**onsuccess **`Called when a function returns the number pattern information successfully.

```javascript
void onsuccess(NumberPattern pattern);
```

Since: 3.0

Parameters:

- **pattern :
 a NumberPattern object containing retrieved information. **

### 1.19. GlobalizationError

The GlobalizationError interface

```webidl
  interface GlobalizationError {
    const short UNKNOWN_ERROR = 0;
    const short FORMATTING_ERROR = 1;
    const short PARSING_ERROR = 2;
    const short PATTERN_ERROR = 3;
    attribute long code;
    attribute DOMString message;
  };
```

Since: 3.0

#### Constants

- UNKNOWN_ERROR Unknown error

Since: 3.0

- FORMATTING_ERROR Formatting error

Since: 3.0

- PARSING_ERROR Parsing error

Since: 3.0

- PATTERN_ERROR Pattern error

Since: 3.0

#### Attributes

- long code One of the following codes representing the error type.

- 0: GlobalizationError.UNKNOWN_ERROR
- 1: GlobalizationError.FORMATTING_ERROR
- 2: GlobalizationError.PARSING_ERROR
- 3: GlobalizationError.PATTERN_ERROR

Since: 3.0

- DOMString message A text message that includes the error's explanation and/or details.

Since: 3.0

### 1.20. ErrorCallback

Basic error callback.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void onerror(DOMException error);
  };
```

Since: 3.0

#### Methods

`**onerror **`Success

```javascript
void onerror(DOMException error);
```

Since: 3.0

Parameters:

- **error :
 Error object containing some information about the error. **

## 2. Full WebIDL

```webidl
module Globalization {
  dictionary DateOptions {
    DOMString formatLength;
    DOMString selector;
  };
  dictionary CurrencyPattern {
    DOMString pattern;
    DOMString code;
    long fraction;
    double rounding;
    DOMString decimal;
    DOMString grouping;
  };
  dictionary GetDateNamesOptions {
    DOMString type;
    DOMString item;
  };
  dictionary NumberPatternOptions {
    DOMString type;
  };
  dictionary DatePattern {
    DOMString pattern;
    DOMString timezone;
    long utc_offset;
    long dst_offset;
  };
  dictionary NumberPattern {
    DOMString pattern;
    DOMString symbol;
    long fraction;
    double rounding;
    DOMString positive;
    DOMString negative;
    DOMString decimal;
    DOMString grouping;
  };
  dictionary GlobalizationDate {
    long year;
    long month;
    long day;
    long hour;
    long minute;
    long second;
    long millisecond;
  };
  Navigator implements GlobalizationManagerObject;
  [NoInterfaceObject] interface GlobalizationManagerObject {
    readonly attribute GlobalizationManager globalization;
  };
  [NoInterfaceObject] interface GlobalizationManager {
    void getPreferredLanguage(StringSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void getLocaleName(StringSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void dateToString(Date date, StringSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options)
                      raises(TypeError);
    void getCurrencyPattern(DOMString currencyCode, PatternSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void getDateNames(ArrayStringSuccessCallback onsuccess, ErrorCallback onerror, optional GetDateNamesOptions options)
                      raises(TypeError);
    void getDatePattern(GetDatePatternSuccessCallback onsuccess, ErrorCallback onerror, optional DateOptions options)
                        raises(TypeError);
    void getFirstDayOfWeek(LongSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void getNumberPattern(GetNumberPatternSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options)
                          raises(TypeError);
    void isDayLightSavingsTime(Date date, DSTSuccessCallback onsuccess, ErrorCallback onerror) raises(TypeError);
    void numberToString(double number, StringSuccessCallback onsuccess, ErrorCallback onerror, optional NumberPatternOptions options)
                        raises(TypeError);
    void stringToDate(DOMString dateString, GlobalizationDateSuccessCallback onsuccess, ErrorCallback onerror,
                      optional DateOptions options) raises(TypeError);
    void stringToNumber(DOMString numberString, DoubleSuccessCallback onsuccess, ErrorCallback onerror,
                        optional NumberPatternOptions options) raises(TypeError);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DSTSuccessCallback {
    void onsuccess(object properties);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface StringSuccessCallback {
    void onsuccess(object properties);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ArrayStringSuccessCallback {
    void onsuccess(object properties);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface LongSuccessCallback {
    void onsuccess(object properties);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface DoubleSuccessCallback {
    void onsuccess(object properties);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface GlobalizationDateSuccessCallback {
    void onsuccess(Date date);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface PatternSuccessCallback {
    void onsuccess(CurrencyPattern pattern);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface GetDatePatternSuccessCallback {
    void onsuccess(DatePattern pattern);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface GetNumberPatternSuccessCallback {
    void onsuccess(NumberPattern pattern);
  };
  interface GlobalizationError {
    const short UNKNOWN_ERROR = 0;
    const short FORMATTING_ERROR = 1;
    const short PARSING_ERROR = 2;
    const short PATTERN_ERROR = 3;
    attribute long code;
    attribute DOMString message;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ErrorCallback {
    void onerror(DOMException error);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
