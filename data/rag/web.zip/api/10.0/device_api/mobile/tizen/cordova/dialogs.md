# Dialogs API

This plugin provides the ability to make different types of notifications to the user.

Original documentation: Cordova Dialogs .

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. DialogsManagerObject
- 1.2. DialogsManager
- 1.3. PromptData
- 1.4. ConfirmCallback
- 1.5. PromptCallback
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| DialogsManagerObject |  |
| DialogsManager | void alert (DOMString message, SuccessCallback alertCallback, optional DOMString? title, optional DOMString? buttonName) void confirm (DOMString message, ConfirmCallback confirmCallback, optional DOMString? title, optional DOMString[]? buttonNames) void prompt (DOMString message, PromptCallback promptCallback, optional DOMString? title, optional DOMString[]? buttonNames, optional DOMString? defaultText) void beep (long times) |
| PromptData |  |
| ConfirmCallback | void onsuccess (long buttonIndex) |
| PromptCallback | void onsuccess ( PromptData data) |

## 1. Interfaces

### 1.1. DialogsManagerObject

The *DialogsManagerObject *interface defines what is instantiated in the *Navigator *object.

```webidl
  [NoInterfaceObject] interface DialogsManagerObject {
    readonly attribute DialogsManager notification;
  };
```

```webidl
  Navigator implements DialogsManagerObject;
```

Since: 3.0

The *navigator.notification *object allows access to the Dialogs API.

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 1.2. DialogsManager

The *DialogsManager *interface provides methods for global operations related to notifications to the user.

```webidl
  [NoInterfaceObject] interface DialogsManager {
    void alert(DOMString message, SuccessCallback alertCallback, optional DOMString? title, optional DOMString? buttonName);
    void confirm(DOMString message, ConfirmCallback confirmCallback, optional DOMString? title, optional DOMString[]? buttonNames);
    void prompt(DOMString message, PromptCallback promptCallback, optional DOMString? title, optional DOMString[]? buttonNames,
                optional DOMString? defaultText);
    void beep(long times);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**alert **`Shows a custom alert with one button.

```javascript
void alert(DOMString message, SuccessCallback alertCallback, optional DOMString? title, optional DOMString? buttonName);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **message :
 The message to be shown to the user by dialog dialog. **
- **alertCallback :
 The callback to be invoked when alert dialog would be dismissed. **
- **title [optional] [nullable] :
 The title of dialog box. Default value is "Dialog". **
- **buttonName [optional] [nullable] :
 Button name to be shown on dialog box. Default value is "OK". **

Code example:

```javascript
var alertDismissed = function()
{
  console.log("Alert was dismissed");
};

navigator.notification.alert("Please click OK button", alertDismissed, "OK click alert", "OK");
```

Output example:

```
Alert was dismissed
```

`**confirm **`Shows a custom confirm box with set of buttons.

```javascript
void confirm(DOMString message, ConfirmCallback confirmCallback, optional DOMString? title, optional DOMString[]? buttonNames);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **message :
 The message to be shown to the user by dialog box. **
- **confirmCallback :
 The callback to be invoked when user perform an action on dialog box.
Callback provides index of button pressed (1,2,3 etc.) or 0, if dialog was dismissed without button press. **
- **title [optional] [nullable] :
 The title of dialog box. Default value is "Confirm". **
- **buttonNames [optional] [nullable] :
 Button names to be shown on dialog box. Default values are ["OK", "Cancel"]. **

Code example:

```javascript
var confirmCallback = function(buttonIndex)
{
  console.log("Selected option was " + buttonIndex);
};

navigator.notification.confirm(
    "Choose one option", confirmCallback, "Options", ["Option1", "Option2"]);
```

Output example:

```
Selected option was 1
```

`**prompt **`Shows a custom confirm box with set of buttons.

```javascript
void prompt(DOMString message, PromptCallback promptCallback, optional DOMString? title, optional DOMString[]? buttonNames,
            optional DOMString? defaultText);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **message :
 The message to be shown to the user by dialog box. **
- **promptCallback :
 The callback to be invoked when user perform an action on dialog box.
Callback provides *PromptData *object, which holds all data provided by user. **
- **title [optional] [nullable] :
 The title of dialog box. Default value is "Prompt". **
- **buttonNames [optional] [nullable] :
 Button names to be shown on dialog box. Default values are ["OK", "Cancel"]. **
- **defaultText [optional] [nullable] :
 Default text to be shown in textbox of dialog box. Default value is an empty string (""). **

Code example:

```javascript
var promptCallback = function(results)
{
  console.log("Hello " + results.input1 + ", you selected option " + results.buttonIndex);
};

navigator.notification.prompt(
    "Please enter your name", promptCallback, "Registration Box", ["Ok", "Exit"], "e.g. Jane Doe");
```

Output example:

```
Hello Jane Doe, you selected option 1
```

`**beep **`Method allows to make custom number of beeps by device.

```javascript
void beep(long times);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **times :
 The number of times to repeat the beep. **

Code example:

```javascript
var times = 2;
console.log("Device would beep " + times + " times");
navigator.notification.beep(times);
```

Output example:

```
Device would beep 2 times
```

### 1.3. PromptData

The object returned from prompt dialog.

```webidl
  [NoInterfaceObject] interface PromptData {
    readonly attribute long buttonIndex;
    readonly attribute DOMString input1;
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Remark: Example usage is described on method prompt .

#### Attributes

- readonly long buttonIndex The index of button, which was pressed by user.
the index uses one-based indexing, so the values could be 1, 2, 3, etc.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

- readonly DOMString input1 The text entered by user in the prompt of dialog box.

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

### 1.4. ConfirmCallback

The callback function used to return index of pressed button of confirm dialog.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface ConfirmCallback {
    void onsuccess(long buttonIndex);
  };
```

Since: 3.0

Remark: Example usage is described on method confirm .

#### Methods

`**onsuccess **`Called when the user perform action on confirm dialog.

```javascript
void onsuccess(long buttonIndex);
```

Since: 3.0

Parameters:

- **buttonIndex :
 The index of button, which was pressed by user.
the index uses one-based indexing, so the values could be 1, 2, 3, etc. **

### 1.5. PromptCallback

The callback function used to return data from prompt dialog.

```webidl
  [Callback=FunctionOnly, NoInterfaceObject] interface PromptCallback {
    void onsuccess(PromptData data);
  };
```

Since: 3.0

Remark: Example usage is described on method prompt .

#### Methods

`**onsuccess **`Called when the user perform action on prompt dialog.

```javascript
void onsuccess(PromptData data);
```

Since: 3.0

Parameters:

- **data :
 The data input into dialog box. **

## 2. Full WebIDL

```webidl
module Dialogs {
  Navigator implements DialogsManagerObject;
  [NoInterfaceObject] interface DialogsManagerObject {
    readonly attribute DialogsManager notification;
  };
  [NoInterfaceObject] interface DialogsManager {
    void alert(DOMString message, SuccessCallback alertCallback, optional DOMString? title, optional DOMString? buttonName);
    void confirm(DOMString message, ConfirmCallback confirmCallback, optional DOMString? title, optional DOMString[]? buttonNames);
    void prompt(DOMString message, PromptCallback promptCallback, optional DOMString? title, optional DOMString[]? buttonNames,
                optional DOMString? defaultText);
    void beep(long times);
  };
  [NoInterfaceObject] interface PromptData {
    readonly attribute long buttonIndex;
    readonly attribute DOMString input1;
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface ConfirmCallback {
    void onsuccess(long buttonIndex);
  };
  [Callback=FunctionOnly, NoInterfaceObject] interface PromptCallback {
    void onsuccess(PromptData data);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
