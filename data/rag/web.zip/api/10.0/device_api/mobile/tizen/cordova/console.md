# Console API

The Console module provides function to access the console.
Original documentation: Cordova Console .

**Remark: **Usage of cordova API needs *http://tizen.org/privilege/filesystem.read *privilege.

Since: 3.0

## Table of Contents

- 1. Interfaces
- 1.1. ConsoleManagerObject
- 1.2. ConsoleManager
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| ConsoleManagerObject |  |
| ConsoleManager | void log (DOMString text) void error (DOMString text) void warn (DOMString text) void info (DOMString text) void debug (DOMString text) void assert (boolean expression, DOMString message) void dir (Object obj) void dirxml (Object obj) void time (DOMString label) void timeEnd (DOMString label) |

## 1. Interfaces

### 1.1. ConsoleManagerObject

```webidl
  [NoInterfaceObject] interface ConsoleManagerObject {
    readonly attribute ConsoleManager console;
  };
```

```webidl
  Window implements ConsoleManagerObject;
```

Since: 3.0

The ConsoleManagerObject interface.

### 1.2. ConsoleManager

The ConsoleManager interface embodies Console module methods.

```webidl
  [NoInterfaceObject] interface ConsoleManager {
    void log(DOMString text);
    void error(DOMString text);
    void warn(DOMString text);
    void info(DOMString text);
    void debug(DOMString text);
    void assert(boolean expression, DOMString message);
    void dir(Object obj);
    void dirxml(Object obj);
    void time(DOMString label);
    void timeEnd(DOMString label);
  };
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

#### Methods

`**log **`Prints a line of text to a standard output.
The text will be logged as a standard message.

```javascript
void log(DOMString text);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **text :
 The text to be printed. **

Code example:

```javascript
console.log("A is for Alice");
```

Output example:

```
A is for Alice
```

`**error **`Prints a line of text to a standard output.
The text will be logged as an error message.

```javascript
void error(DOMString text);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **text :
 The text to be printed. **

Code example:

```javascript
console.error("B is for Bob");
```

Output example:

```
B is for Bob
```

`**warn **`Prints a line of text to a standard output.
The text will be logged as a warning message.

```javascript
void warn(DOMString text);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **text :
 The text to be printed. **

Code example:

```javascript
console.warn("C is for Christopher");
```

Output example:

```
C is for Christopher
```

`**info **`Prints a line of text to a standard output.
The text will be logged as an info message.

```javascript
void info(DOMString text);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **text :
 The text to be printed. **

Code example:

```javascript
console.info("D is for Dorothy");
```

Output example:

```
D is for Dorothy
```

`**debug **`Prints a line of text to a standard output.
The text will be logged as a debug message.

```javascript
void debug(DOMString text);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **text :
 The text to be printed. **

Code example:

```javascript
console.debug("E is for Eve");
```

Output example:

```
E is for Eve
```

`**assert **`If the specified expression is false,
the message is written to the console.

```javascript
void assert(boolean expression, DOMString message);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **expression :
 The expression to be evaluated. **
- **message :
 The message to be displayed if an expression is false. **

Code example:

```javascript
var felix = "Felix";

/* This assertion checks whether the first letter in name "Felix" is "A". */
console.assert(felix.charAt(0) === "A", felix + " does not start with A");
```

Output example:

```
Felix does not start with A
```

`**dir **`Prints a JavaScript representation of the specified object.
If the object being logged is an HTML element, the JavaScript
Object view is forced.

```javascript
void dir(Object obj);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **obj :
 An object whose JavaScript representation will be printed. **

Code example:

```javascript
var john = {name: "John", surname: "Doe"};
console.dir(john.name);
```

Output example:

```
John
```

`**dirxml **`Prints an XML/HTML Element representation of the specified object
if possible or the JavaScript Object if it is not.

```javascript
void dirxml(Object obj);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **obj :
 An object whose XML/HTML Element representation will be printed. **

Code example:

```javascript
var john = {name: "John", surname: "Doe"};
console.dirxml(john.surname);
```

Output example:

```
Doe
```

`**time **`Starts a new timer with an associated label. When console.timeEnd() is called with the same label, the timer is stopped and the elapsed time
is displayed in the console. Timer values are accurate to the sub-millisecond.

```javascript
void time(DOMString label);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **label :
 The label to start timing with. **

Code example:

```javascript
console.time("Big array initialization");
var array = new Array(1000000);
for (var i = array.length - 1; i >= 0; i -= 1)
{
  array[i] = new Object();
}
console.timeEnd("Big array initialization");
```

Output example:

```
Big array initialization: 461.989ms
```

`**timeEnd **`Stops the timer with the specified label and prints the elapsed time.

```javascript
void timeEnd(DOMString label);
```

Since: 3.0

Privilege level: public

Privilege: http://tizen.org/privilege/filesystem.read

Parameters:

- **label :
 The label associated to the timing (with the use of console.time() method). **

Code example:

```javascript
console.time("Big array initialization");
var array = new Array(1000000);
for (var i = array.length - 1; i >= 0; i -= 1)
{
  array[i] = new Object();
}
console.timeEnd("Big array initialization");
```

Output example:

```
Big array initialization: 461.989ms
```

## 2. Full WebIDL

```webidl
module Console {
  Window implements ConsoleManagerObject;
  [NoInterfaceObject] interface ConsoleManagerObject {
    readonly attribute ConsoleManager console;
  };
  [NoInterfaceObject] interface ConsoleManager {
    void log(DOMString text);
    void error(DOMString text);
    void warn(DOMString text);
    void info(DOMString text);
    void debug(DOMString text);
    void assert(boolean expression, DOMString message);
    void dir(Object obj);
    void dirxml(Object obj);
    void time(DOMString label);
    void timeEnd(DOMString label);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
