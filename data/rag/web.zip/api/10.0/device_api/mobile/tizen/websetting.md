# WebSetting API

This Web Setting API defines a set of APIs that manages the setting states of the Web view in your Web application.

A Tizen Web application includes a web view and the properties below of the web view can be managed via the Web Setting API:

- Delete all the cookies saved for the web view in the Web application.
- Set a custom user agent string of the web view in the Web application.
Note that all the settings using the Web Setting API is bound to your application; thus, no other applications are affected via the Web Setting API calls within your application.

For more information on the Web Setting features, see Web Setting Guide .

Since: 2.2

## Table of Contents

- 1. Interfaces
- 1.1. WebSettingObject
- 1.2. WebSettingManager
- 2. Full WebIDL
---
## Summary of Interfaces and Methods

| Interface | Method |
| --- | --- |
| WebSettingObject |  |
| WebSettingManager | void setUserAgentString (DOMString userAgent, optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) void removeAllCookies (optional SuccessCallback ? successCallback, optional ErrorCallback ? errorCallback) |

## 1. Interfaces

### 1.1. WebSettingObject

This interface defines what is instantiated for the Web Setting API by the *Tizen *object from the Tizen Platform.

```webidl
  [NoInterfaceObject] interface WebSettingObject {
    readonly attribute WebSettingManager websetting;
  };
```

```webidl
  Tizen implements WebSettingObject;
```

Since: 2.2

*tizen.websetting *object is available to manage the settings of the Web view in your Web application.

#### Attributes

- readonly WebSettingManager websetting Object representing a web settings manager.

Since: 2.2

### 1.2. WebSettingManager

This is the top-level interface for the Web Setting API that managed the settings of the Web view in your Web application.

```webidl
  [NoInterfaceObject] interface WebSettingManager {
    void setUserAgentString(DOMString userAgent, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                            raises(WebAPIException);
    void removeAllCookies(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
```

Since: 2.2

#### Methods

`**setUserAgentString **`Sets the custom user agent string for your Web application.

```javascript
void setUserAgentString(DOMString userAgent, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.2

This method allows the user to set the user agent string of the Web view in the Web application.  By default, the Web view in your application
has the same user agent string as the Tizen browser on the device.

The *ErrorCallback *is launched with these error types:

- UnknownError - If any error occurs while setting the user agent string.
- InvalidValuesError - If any of the input parameters contain an invalid value.

Parameters:

- **userAgent :
 User agent to set for the Web view in your Web application. **
- **successCallback [optional] [nullable] :
 To be invoked if the requested setting operation succeeds. **
- **errorCallback [optional] [nullable] :
 To be invoked if the requested setting operation fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
function successCallback()
{
  console.log("The requested user agent string has just been set successfully");
}

tizen.websetting.setUserAgentString("the new user agent string to set", successCallback);
```

`**removeAllCookies **`Removes all the cookies saved for the Web view in your Web application.

```javascript
void removeAllCookies(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback);
```

Since: 2.2

The Web view in your Web application can store cookies like a browser. This method allows the user to remove all the cookies saved for the Web application.

The *ErrorCallback *is launched with these error types:

- UnknownError - If any error occurs while deleting the cookies.

**Warning: **http://tizen.org/privilege/websetting(public level privilege) **MUST NOT **be declared to use this API since 2.4.

Parameters:

- **successCallback [optional] [nullable] :
 To be invoked if the requested delete operation succeeds. **
- **errorCallback [optional] [nullable] :
 To be invoked if the requested delete operation fails. **

Exceptions:

- WebAPIException
- with error type TypeMismatchError, if any input parameter is not compatible with the expected type for that parameter.

Code example:

```javascript
function successCallback()
{
  console.log("The cookies saved for your application have just been removed");
}

tizen.websetting.removeAllCookies(successCallback);
```

## 2. Full WebIDL

```webidl
module WebSetting {
  Tizen implements WebSettingObject;
  [NoInterfaceObject] interface WebSettingObject {
    readonly attribute WebSettingManager websetting;
  };
  [NoInterfaceObject] interface WebSettingManager {
    void setUserAgentString(DOMString userAgent, optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback)
                            raises(WebAPIException);
    void removeAllCookies(optional SuccessCallback? successCallback, optional ErrorCallback? errorCallback) raises(WebAPIException);
  };
};
```

Except as noted, this content - excluding the Code Examples - is licensed under Creative Commons Attribution 3.0 and all of the Code Examples contained herein are licensed under BSD-3-Clause . 
For details, see the Content License .
